import { generateApi } from 'swagger-typescript-api';
import path from 'path';
import 'dotenv/config';

generateApi({
  name: 'types.ts',
  generateClient: false,
  output: path.resolve(process.cwd(), './src/core/Api'),
  // Get the URL from the env but fallback if not available
  url:
    process.env.API_SCHEMA_URL ??
    'https://api.dev1.abstractsecurity.dev/openapi.json'
});
