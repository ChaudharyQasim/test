# Abstract UI

## Links

- [Dev](https://main.d2uo0d861qa6o4.amplifyapp.com/)
- [Storybook](https://main--64c93b16320d43b668c299f3.chromatic.com)

## Local Setup

- Install Node v18+
- Install Project Deps `npm i --force`
- Start Project `npm start`

## Commands

- `start` - Starts the app in development mode via Vite
- `storybook` - Starts storybook
- `build` - Builds the app for production via Vite
- `build-storybook` - Builds the storybook for production
- `test` - Run unit tests via Vitest
- `format` - Runs ESLint and Prettier and fixes problems.

# .env.development

## Reuqired env variables

To run the backend remotely, replace `VITE_API_URL` with https://api.dev1.abstractsecurity.dev.
Alternatively, you can retain the default value if the [https://github.com/AbstractSecurity/web-api](web-api) is properly set up.

```
VITE_API_URL="http://localhost:8000"
VITE_AUTH_URL="http://localhost:3000"
```

## Required if wanna use google auth

```
VITE_GOOGLE_CLIENT_ID=""
VITE_GOOGLE_CLIENT_SECRET=""
```

### Steps to generate a google credentials

To generate the google credentials go to: [google cloud](https://console.cloud.google.com/) > APIs & Services > Credentials > + CREATE CREDENTIALS

Once in there you have to Authorized the origins, in this case for local just add
`http://localhost:3000` in `Authorized JavaScript origins` and `Authorized redirect URIs`

## Required if wanna use MS auth

```
VITE_AZURE_AD_CLIENT_ID=""
VITE_AZURE_AD_CLIENT_SECRET=""
VITE_AZURE_AD_TENANT_ID=""
```

### Steps to generate an azure-ad credentials

To generate the azure createndials go to: [Azure portal](https://portal.azure.com/) > Azure active directory > App registrations > + NEW REGISTRATION

Once you have created the new registration click in `+ Add a platform` > Single-page application and in `Redirect URIs` add `http://localhost:3000`
