import { api } from './BaseApi';

import {
  DeleteFunctionType,
  ListPipelineOut,
  SavePipelineDetails
} from 'App/PipelineManager/Pipeline.types';
import {
  CreateFunctionIn,
  GetPipelineOut,
  GetPipelineFunctions,
  ResponseMessage,
  RouteIn,
  RouteOut,
  UpdateFunctionIn,
  DeleteCSVOut,
  ListCSVOut,
  UploadCSVOut
} from './types';
import { formatDuration } from 'reablocks';

const PIPELINE_BASE_URL = '/v1/pipelines';

type PipelineFilterTagValuesType = {
  tags: string[];
};

type GetPipelineFilterTagValuesType = ({
  tagType
}: {
  tagType: 'pipeline' | 'rule';
}) => Promise<PipelineFilterTagValuesType>;

export const getPipelineList = async ({
  organization_id,
  constructedUrl,
  signal
}): Promise<ListPipelineOut> => {
  const response = await api.get(
    `${PIPELINE_BASE_URL}/list-pipelines${constructedUrl}`,
    {
      params: {
        organization_id
      },
      signal
    }
  );
  return response.data;
};

export const getPipelineFilterTagValues: GetPipelineFilterTagValuesType =
  async ({ tagType }) => {
    const response = await api.get(`${PIPELINE_BASE_URL}/get-filter-values`, {
      params: {
        tag_type: tagType
      }
    });
    return response.data;
  };

export const deletePipelineRoute = async (route_id: string): Promise<any> => {
  const response = await api.delete(
    `${PIPELINE_BASE_URL}/delete-route/${route_id}`
  );
  return response.data;
};

export const getPipelineById = async (
  pipelineId: string
): Promise<GetPipelineOut> => {
  const response = await api.get(
    `${PIPELINE_BASE_URL}/get-pipeline/${pipelineId}`
  );
  return response.data;
};

export const updatePipeline = async (
  pipelineId: string,
  payload: any
): Promise<SavePipelineDetails> => {
  const response = await api.patch(
    `${PIPELINE_BASE_URL}/update-pipeline/${pipelineId}`,
    payload
  );
  return response.data;
};

export const getFoundationalList = async (
  searchString: string
): Promise<GetPipelineFunctions[]> => {
  const response = await api.get(
    `${PIPELINE_BASE_URL}/foundational-functions`,
    {
      params: {
        name: searchString
      }
    }
  );
  return response.data;
};

export const getFunctionList = async ({
  organization_id,
  function_type,
  pageSize = 10,
  pageNumber = 1,
  searchString = ''
}): Promise<GetPipelineFunctions[]> => {
  const response = await api.get(`${PIPELINE_BASE_URL}/list-functions`, {
    params: {
      organization_id,
      function_type,
      page_size: pageSize,
      page_number: pageNumber,
      name: searchString
    }
  });
  return response.data;
};

export const deleteFunction = async ({
  id,
  isForceDelete = false,
  csv_file_id = null
}): Promise<DeleteFunctionType> => {
  const response = await api.delete(
    `${PIPELINE_BASE_URL}/delete-function/${id}`,
    {
      params: {
        force_delete: isForceDelete,
        csv_file_id
      }
    }
  );
  return response.data;
};

export const createRoute = async (params: RouteIn): Promise<RouteOut> => {
  const response = await api.post(`${PIPELINE_BASE_URL}/create-route`, params);
  return response.data;
};

export const getRouteByVendorId = async (
  vendor_account_id: string
): Promise<RouteOut[]> => {
  const response = await api.get(
    `${PIPELINE_BASE_URL}/get-vendoraccount-routes/${vendor_account_id}`
  );
  return response.data;
};

export const deleteRoute = async (
  routeId: string
): Promise<ResponseMessage> => {
  const response = await api.delete(
    `${PIPELINE_BASE_URL}/delete-route/${routeId}`
  );
  return response.data;
};

export const getRouteByConfigurationId = async (
  configurationId: string,
  vendor_account_id: string
): Promise<RouteOut[]> => {
  const response = await api.get(
    `${PIPELINE_BASE_URL}/get-route/${configurationId}`,
    {
      params: {
        vendor_account_id
      }
    }
  );
  return response.data;
};

export const createFunction = async (
  customFunction: CreateFunctionIn
): Promise<any> => {
  const response = await api.post(
    `${PIPELINE_BASE_URL}/create-custom-function`,
    customFunction
  );
  return response.data;
};

export const updateFunction = async ({
  functionId,
  customFunction
}: {
  functionId: string;
  customFunction: UpdateFunctionIn;
}): Promise<UpdateFunctionIn> => {
  const response = await api.patch(
    `${PIPELINE_BASE_URL}/update-custom-function/${functionId}`,
    customFunction
  );
  return response.data;
};

export const getEnrichmentCSVList = async ({
  pageNumber,
  pageSize
}: {
  pageNumber: string;
  pageSize: number;
}): Promise<ListCSVOut> => {
  const response = await api.get(`${PIPELINE_BASE_URL}/list-csv`, {
    params: {
      page_size: pageSize,
      page_number: pageNumber
    }
  });
  return response.data;
};

export const deleteEnrichment = async ({
  fileName,
  fileId
}: {
  fileName: string;
  fileId: string;
}): Promise<DeleteCSVOut> => {
  const response = await api.delete(`${PIPELINE_BASE_URL}/delete-csv`, {
    params: {
      file_name: fileName,
      file_id: fileId
    }
  });
  return response.data;
};

export const newEnrichment = async ({
  file,
  onUploadProgress
}): Promise<UploadCSVOut> => {
  const startTime = Date.now();

  const config = {
    onUploadProgress: progressEvent => {
      const { loaded, total } = progressEvent;
      const percentage = ((loaded / total) * 100).toFixed(2);

      const timeElapsed = Date.now() - startTime;
      const uploadSpeed = loaded / timeElapsed;
      const duration = (total - loaded) / uploadSpeed;
      const estimatedTimeRemaining = formatDuration(duration, '0 s');

      onUploadProgress({ percentage, estimatedTimeRemaining });
    },
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  };

  const response = await api.post(
    `${PIPELINE_BASE_URL}/upload-csv`,
    file,
    config
  );
  return response.data;
};
