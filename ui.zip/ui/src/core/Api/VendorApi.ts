import { type } from 'os';
import { api } from './BaseApi';

// Types
import {
  VendorAccountIn,
  VendorAccountOut,
  VendorAccountStatusOut,
  GetGithubRunnerTokenOut,
  UpdateWorkflowRunIdIn,
  AccountDetailsIn,
  ConfigurationOut,
  GetStackUrlOut
} from './types';

export type GithubRunnerType = {
  vendor_account_id: string;
  aws_account_id: string;
};

export type UpdateOnboardingType = {
  /** Message */
  message: string;
};

export type VendorStatusType = {
  workflow_type: string;
  vendor_account_id: string;
};

export type RegionType = {
  label: string;
  value: string;
};

export type Vendor = {
  config: object;
  id: number;
  label: string;
  name: string;
  regions: RegionType[];
};

const VENDOR_BASE_URL = '/v1/vendor-accounts';
const VENDOR_ACCOUNT_V2 = '/v2/vendor-accounts';

// Services
export const postInitiateVendor = async (
  postData: VendorAccountIn
): Promise<GetStackUrlOut> => {
  const response = await api.post(
    `${VENDOR_BASE_URL}/initiate-onboarding`,
    postData
  );
  return response.data;
};

export const getListVendors = async (): Promise<Vendor[]> => {
  const response = await api.get(`${VENDOR_ACCOUNT_V2}/list-vendors`);
  return response.data;
};

export const getListTenantsAccounts = async (
  organization_id: number
): Promise<VendorAccountOut[]> => {
  const response = await api.get(
    `${VENDOR_BASE_URL}/${organization_id}/list-tenant-accounts`
  );
  return response.data;
};

export const getGithubRunnerToken = async ({
  vendor_account_id,
  aws_account_id
}: GithubRunnerType): Promise<GetGithubRunnerTokenOut> => {
  const response = await api.get(`${VENDOR_BASE_URL}/get-github-runner-token`, {
    params: {
      vendor_account_id,
      aws_account_id
    }
  });
  return response.data;
};

export const getVendorStatus = async ({
  workflow_type,
  vendor_account_id
}: VendorStatusType): Promise<VendorAccountStatusOut> => {
  const response = await api.get(`${VENDOR_BASE_URL}/get-github-runner-token`, {
    params: {
      vendor_account_id,
      workflow_type
    }
  });
  return response.data;
};

export const updateVendorWorkflowRunId = async ({
  run_identifier,
  run_id
}: UpdateWorkflowRunIdIn): Promise<string> => {
  const response = await api.patch(
    `${VENDOR_BASE_URL}/update-workflow-run-id`,
    {
      run_identifier,
      run_id
    }
  );
  return response.data;
};

export const updateOnboardingStatus = async ({
  vendor_account_id,
  stack_details,
  onboarding_status,
  error_details
}: AccountDetailsIn): Promise<ConfigurationOut> => {
  const response = await api.patch(
    `${VENDOR_BASE_URL}/update-workflow-run-id`,
    {
      vendor_account_id,
      stack_details,
      onboarding_status,
      error_details
    }
  );
  return response.data;
};

export const updateVendorOffBoardAccount = async (
  vendor_account_id: string
): Promise<ConfigurationOut> => {
  const response = await api.patch(
    `${VENDOR_BASE_URL}/offboard-account/${vendor_account_id}`
  );
  return response.data;
};
