import { AxiosResponse } from 'axios';
import { api } from './BaseApi';

// Types

export enum SocialAuthProviders {
  GOOGLE = 'google',
  MICROSOFT = 'microsoft'
}

export type PostLoginType = {
  email: string;
};

export type PostPasscodeType = {
  code: string;
};

export type PostSignupType = {
  email: string;
  first_name: string;
  last_name: string;
};

const V2_USERS = '/v2/users';
const V2_AUTH = '/v2/auth';

// Endpoints
export const postLogin = (formData: PostLoginType): Promise<AxiosResponse> => {
  return api.post(`${V2_AUTH}/login`, formData);
};

export const postVerifyPasscode = (
  formData: PostPasscodeType
): Promise<AxiosResponse> => {
  return api.post(`${V2_AUTH}/verify-code`, formData);
};

export const postSignUp = (
  formData: PostSignupType
): Promise<AxiosResponse> => {
  return api.post(`${V2_USERS}/`, formData);
};

export const getSignOut = (): Promise<AxiosResponse> => {
  return api.get(`${V2_AUTH}/logout`);
};

export const getVerifyAuth = (): Promise<AxiosResponse> => {
  return api.get(`${V2_AUTH}/`);
};
