import { api } from './BaseApi';
import { PAGE_LIMIT_DEFAULT } from 'shared/utils/Constants';
import { ListConfigurationType } from 'App/Integrations/Integration.types';
import {
  ConfigurationCreate,
  ConfigurationUpdate,
  DeleteConfigurationOut,
  GetConfigurationOut,
  GetIntegrationExecutionHistory,
  ValidateConfiguration
} from './types';

const CONFIGURATION_BASE_URL = '/v1/configurations';

export const getConfigurationById = async (
  id: string,
  vendor_account_id: string
): Promise<GetConfigurationOut> => {
  const response = await api.get(`${CONFIGURATION_BASE_URL}/${id}`, {
    params: {
      vendor_account_id
    }
  });
  return response.data;
};

export const getEnabledIntegration = async (
  constructedUrl: string,
  fetchDefaultConfiguration: boolean = false
): Promise<ListConfigurationType> => {
  const response = await api.get(
    `${CONFIGURATION_BASE_URL}/${constructedUrl}`,
    {
      params: {
        default: fetchDefaultConfiguration
      }
    }
  );
  return response.data;
};

export const createConfiguration = async (
  configurationObject: ConfigurationCreate
) => {
  const response = await api.post(
    `${CONFIGURATION_BASE_URL}/`,
    configurationObject
  );
  return response.data;
};

export const deleteConfiguration = async (
  id: number | string,
  params: { vendor_account_id: string }
): Promise<DeleteConfigurationOut> => {
  const response = await api.delete(`${CONFIGURATION_BASE_URL}/${id}`, {
    params
  });
  return response.data;
};

export const updateConfiguration = async (
  id: number | string,
  payload: ConfigurationUpdate
): Promise<GetConfigurationOut> => {
  const response = await api.patch(`${CONFIGURATION_BASE_URL}/${id}`, payload);
  return response.data;
};

export const validateConfiguration = async (
  configurationObject: ValidateConfiguration
) => {
  const response = await api.post(
    `${CONFIGURATION_BASE_URL}/validate`,
    configurationObject
  );
  return response.data;
};

export const getConfigurationLogs = async (
  id: string,
  vendor_account_id: string,
  page_number: number
): Promise<GetIntegrationExecutionHistory[]> => {
  const response = await api.get(`${CONFIGURATION_BASE_URL}/log/${id}`, {
    params: {
      vendor_account_id,
      page_number,
      page_size: PAGE_LIMIT_DEFAULT
    }
  });
  return response.data;
};
