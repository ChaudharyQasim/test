import { MessageType, api } from './BaseApi';
import { UpdateUser, DetailUserOut } from './types';

const USERS_BASE_URL = '/users';

const axiosPatchConfig = {
  headers: {
    'Content-Type': 'multipart/form-data'
  }
};

export const getUser = async (): Promise<DetailUserOut> => {
  const response = await api.get(`${USERS_BASE_URL}/get-user`);
  return response.data;
};

export const updateUserImage = async ({
  id,
  patchData
}: {
  id: number;
  patchData: FormData;
}): Promise<MessageType> => {
  const response = await api.patch(
    `${USERS_BASE_URL}/image/${id}`,
    patchData,
    axiosPatchConfig
  );
  return response.data;
};

export const deleteUserImage = async ({
  id
}: {
  id: number;
}): Promise<MessageType> => {
  const response = await api.delete(`${USERS_BASE_URL}/image/${id}`);
  return response.data;
};

export const updateUser = async (
  patchData: UpdateUser
): Promise<UpdateUser> => {
  const response = await api.patch(`${USERS_BASE_URL}/`, patchData);
  return response.data;
};
