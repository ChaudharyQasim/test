import { AUDIT_PAGE_LIMIT_DEFAULT } from 'shared/utils/Constants';
import { MessageType, api } from './BaseApi';
import { AcceptInvitation, Permission } from './types';

const axiosPatchConfig = {
  headers: {
    'Content-Type': 'multipart/form-data'
  }
};

// Types
export type InvitationsType = {
  email?: string;
  is_accepted?: boolean;
  is_active?: boolean;
  organization_id: number;
  organization_name?: string;
  token?: AcceptInvitation;
};

export type PermissionObjectType = {
  [key: string]: boolean;
};

export type UserOrganizationType = {
  id: number;
  name: string;
  domains: string[];
};

export type UpdateOrgDetailsType = Omit<UserOrganizationType, 'id'>;

export type MemberOrganizationType = {
  enabled: boolean;
  role: {
    id: number;
    name: string;
    nanoid: string;
    organization_id: number;
  };
  user: {
    id: number;
    email: string;
    first_name: string;
    last_name: string;
    nanoid: string;
    current_organization_id: number;
    username: string;
    picture_url: string;
  };
};

export type InvitedByUser = {
  id: number;
  email: string;
  username: string;
  first_name: string;
  last_name: string;
  picture_url: string;
  is_active: boolean;
};

export type OrganizationInvitationType = {
  created_at: Date;
  email: string;
  is_active: boolean;
  invited_by_user: InvitedByUser;
};

export type OrganizationDetailType = {
  organization: UserOrganizationType;
  invitations: OrganizationInvitationType[];
  users: MemberOrganizationType[];
};

export type OrganizationType = {
  domains: string[];
  name: string;
  client_id: string;
  id: number;
  nanoid: string;
  user_pool_id: string;
  picture_url: string;
};

export type CreateOrganizationType = {
  name: string;
  domains: string[];
};

export type BulkInvitationType = {
  organization_id: number;
  emails: { email: string }[];
};

export type UpdateOrganizationType = {
  id: number;
  patchData: {
    name: string;
    domains: string[];
  };
};

// Services
export const getOrganizationInvitations = async (): Promise<
  InvitationsType[]
> => {
  const response = await api.get('/invitations/orgs');
  return response.data;
};

export const getUserOrganizations = async ({
  id
}): Promise<UserOrganizationType[]> => {
  const response = await api.get(`/organizations/user/${id}`);
  return response.data;
};

export const getOrganizationById = async (
  id: number
): Promise<OrganizationDetailType> => {
  const response = await api.get(`/organizations/${id}`);
  return response.data;
};

export const updateOrganization = async ({
  id,
  patchData
}: UpdateOrganizationType): Promise<UserOrganizationType> => {
  const response = await api.patch(`/organizations/${id}`, patchData);
  return response.data;
};

export const updateAcceptOrgInvitation = async ({
  patchData
}): Promise<any> => {
  const response = await api.patch('/invitations/', patchData);
  return response.data;
};

export const updateCurrentOrganization = async ({
  patchData
}): Promise<any> => {
  const response = await api.patch(
    '/organizations/current-organization',
    patchData
  );
  return response.data;
};

export const postCreateOrganization = async (
  organization: CreateOrganizationType
): Promise<any> => {
  const response = await api.post('/organizations/', organization);
  return response.data;
};

export const updateImageOrganization = async ({
  id,
  patchData
}: {
  id: number;
  patchData: FormData;
}): Promise<MessageType> => {
  const response = await api.patch(
    `/organizations/image/${id}`,
    patchData,
    axiosPatchConfig
  );
  return response.data;
};

export const deleteOrganizationImage = async ({
  id
}: {
  id: number;
}): Promise<MessageType> => {
  const response = await api.delete(`/organizations/image/${id}`);
  return response.data;
};

export const postBulkInvitations = async ({
  organization_id,
  emails
}: BulkInvitationType): Promise<any> => {
  const response = await api.post(
    `/invitations/bulk-invitations/${organization_id}`,
    emails
  );
  return response.data;
};

export const deleteOrganization = async (
  organization_id: number
): Promise<any> => {
  const response = await api.delete(`/organizations/leave-organization`, {
    data: {
      organization_id
    }
  });
  return response.data;
};

export const getPermissions = async (): Promise<Permission[]> => {
  const response = await api.get('/permissions');
  return response.data;
};

export const getAuditLogsOrganization = async (
  organization_id: number,
  next_token?: string
): Promise<any> => {
  const response = await api.get(`/audit/logs`, {
    params: {
      organization_id,
      next_token,
      page_size: AUDIT_PAGE_LIMIT_DEFAULT
    }
  });
  return response.data;
};
