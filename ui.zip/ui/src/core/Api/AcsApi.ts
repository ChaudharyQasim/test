import { api } from './BaseApi';

import { FieldOperations } from 'shared/elements/EventCondition';
import { ACSFieldType } from './types';

const ACS_BASE_URL = '/v1/acs';

export const getAcsFields = async (): Promise<ACSFieldType[]> => {
  const response = await api.get(`${ACS_BASE_URL}/fields`);
  return response.data;
};

export const getAcsFieldOperations = async (): Promise<FieldOperations> => {
  const response = await api.get(`${ACS_BASE_URL}/operations`);
  return response.data;
};

export const getFields = async () => {
  const response = await api.get(`${ACS_BASE_URL}/field-selection`);
  return response.data;
};
