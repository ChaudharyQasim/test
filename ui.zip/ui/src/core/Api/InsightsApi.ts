import { api } from './BaseApi';

// Types
import {
  AddCommentRequest,
  CommentDetail,
  CreateInsightRequest,
  InsightList,
  InsightOut,
  InsightsMetrics,
  Reaction,
  UpdateInsightAssigneesRequest,
  UpdateInsightCategoryRequest,
  UpdateInsightRequest
} from './types';
import {
  MitreTechniqueType,
  TechniquesType
} from 'shared/data/MitreTechniques/MitreTechniques.types';

const INSIGHT_BASE_URL = '/insights';

// Services
export const getMITRETechniques = async (): Promise<TechniquesType> => {
  const response = await api.get(`${INSIGHT_BASE_URL}/techniques/`);
  return response.data;
};

export const updateMitreTechniques = async ({
  insightId,
  techniques
}: {
  insightId: string;
  techniques: MitreTechniqueType[];
}): Promise<string> => {
  const response = await api.patch(
    `${INSIGHT_BASE_URL}/${insightId}/update-mitre-attack-techniques`,
    techniques
  );
  return response.data;
};

export const getInsights = async (
  userEmail: string,
  params?: {
    page_number?: number;
    page_size?: number;
    severity?: string;
    assignee?: string;
    status?: string;
    keyword?: string;
  }
): Promise<InsightList> => {
  const response = await api.get(`${INSIGHT_BASE_URL}/`, {
    params: {
      ...params,
      sort: '-created_date'
    }
  });
  return response.data;
};

export const getInsightsById = async (
  insightId: string
): Promise<InsightOut> => {
  const response = await api.get(`${INSIGHT_BASE_URL}/${insightId}`);
  return response.data;
};

export const getInsightComments = async (
  insightId: string
): Promise<CommentDetail[]> => {
  const response = await api.get(`${INSIGHT_BASE_URL}/${insightId}/comments`);
  return response.data;
};

export const updateInsight = async (
  insightId: string,
  insightData: UpdateInsightRequest
): Promise<InsightOut> => {
  const response = await api.patch(
    `${INSIGHT_BASE_URL}/${insightId}`,
    insightData
  );
  return response.data;
};

export const updateAssigneeInsight = async (
  insightId: string,
  insightData: UpdateInsightAssigneesRequest
): Promise<InsightOut> => {
  const response = await api.patch(
    `${INSIGHT_BASE_URL}/${insightId}/add-assignee`,
    insightData
  );
  return response.data;
};

export const updateRemoveAssigneeInsight = async (
  insightId: string,
  insightData: UpdateInsightAssigneesRequest
): Promise<InsightOut> => {
  const response = await api.patch(
    `${INSIGHT_BASE_URL}/${insightId}/remove-assignee`,
    insightData
  );
  return response.data;
};

export const updateCategoryInsight = async (
  insightId: string,
  insightData: UpdateInsightCategoryRequest
): Promise<InsightOut> => {
  const response = await api.patch(
    `${INSIGHT_BASE_URL}/${insightId}/add-category`,
    insightData
  );
  return response.data;
};

export const updateRemoveCategoryInsight = async (
  insightId: string,
  insightData: UpdateInsightCategoryRequest
): Promise<InsightOut> => {
  const response = await api.patch(
    `${INSIGHT_BASE_URL}/${insightId}/remove-category`,
    insightData
  );
  return response.data;
};

export const postInsightComment = async (
  insightId: string,
  insightData: AddCommentRequest
): Promise<CommentDetail> => {
  const response = await api.post(
    `${INSIGHT_BASE_URL}/${insightId}/comments`,
    insightData
  );
  return response.data;
};

export const deleteInsightComment = async (
  commentId: string
): Promise<{ message: string }> => {
  const response = await api.delete(
    `${INSIGHT_BASE_URL}/comments/${commentId}`
  );
  return response.data;
};

export const deleteInsight = async (
  insightId: string
): Promise<{ message: string }> => {
  const response = await api.delete(`${INSIGHT_BASE_URL}/${insightId}`);
  return response.data;
};

export const postAddReaction = async (
  commentId: string,
  reaction: Reaction
): Promise<CommentDetail> => {
  const response = await api.post(
    `${INSIGHT_BASE_URL}/comments/${commentId}/reactions/add`,
    reaction
  );
  return response.data;
};

export const postRemoveReaction = async (
  commentId: string,
  reaction: Reaction
): Promise<CommentDetail> => {
  const response = await api.post(
    `${INSIGHT_BASE_URL}/comments/${commentId}/reactions/remove`,
    reaction
  );
  return response.data;
};

export const postCreateInsight = async (
  insight: CreateInsightRequest
): Promise<InsightOut> => {
  const response = await api.post(`${INSIGHT_BASE_URL}/`, insight);
  return response.data;
};

export const getInsightMetrics = async ({
  timeframe = '1D'
}: {
  timeframe: string;
}): Promise<InsightsMetrics> => {
  const response = await api.get(`${INSIGHT_BASE_URL}/dashboard/metrics`, {
    params: {
      timeframe
    }
  });
  return response.data;
};
