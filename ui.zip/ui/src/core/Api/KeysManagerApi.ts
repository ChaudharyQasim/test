import { api } from './BaseApi';

// Types
import {
  CreateAPIKey,
  CreateAPIKeyResponse,
  ListAPIKeysResponse,
  ResponseMessage
} from './types';

const API_KEY_BASE_URL = '/v1/api-keys';
export const getApiKeys = async (): Promise<ListAPIKeysResponse[]> => {
  const response = await api.get(`${API_KEY_BASE_URL}/`);
  return response.data;
};

export const postCreateApiKey = async (
  data: CreateAPIKey
): Promise<CreateAPIKeyResponse> => {
  const response = await api.post(`${API_KEY_BASE_URL}/`, data);
  return response.data;
};

export const deleteDeleteApiKey = async (
  key_id: number
): Promise<ResponseMessage> => {
  const response = await api.delete(`${API_KEY_BASE_URL}/${key_id}`);
  return response.data;
};
