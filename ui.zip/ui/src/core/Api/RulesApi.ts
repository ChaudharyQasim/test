import { api } from './BaseApi';
import {
  RuleEventCategories,
  RuleIn,
  RuleOut,
  RuleStateEnum,
  RuleUpdateIn,
  RulesListOut,
  Severity
} from './types';

const RULES_BASE_URL = '/v1/rules';

// Types
export type RulesListParams = {
  page_number?: number;
  page_size?: number;
  type?: string;
  state?: RuleStateEnum;
  severity?: Severity;
  author?: string[];
  tags?: string[];
  name?: string;
  description?: string;
};

export interface RuleDetailType extends RuleIn {
  created_by: string;
  created_at: string;
  query_json: any;
}

export interface RuleInExtended extends Omit<RuleIn, 'event_categories'> {
  event_categories?: RuleEventCategories[];
}

export type RuleDetailOut = {
  rule_details: RuleDetailType;
};

export type RuleQueryType = {
  params?: RulesListParams;
  constructedUrl?: string;
};

// Services
export const getRulesList = async ({
  params = {},
  constructedUrl = ''
}: RuleQueryType): Promise<RulesListOut> => {
  const response = await api.get(`${RULES_BASE_URL}/${constructedUrl}`, {
    params
  });
  return response.data;
};

export const getRuleDetail = async (ruleId: string): Promise<RuleDetailOut> => {
  const response = await api.get(`${RULES_BASE_URL}/${ruleId}`);
  return response.data;
};

export const createRule = async (data: RuleInExtended): Promise<RuleOut> => {
  const response = await api.post(`${RULES_BASE_URL}/`, data);
  return response.data;
};

export const updateRule = async ({
  data,
  ruleId
}: {
  data: RuleUpdateIn;
  ruleId: string;
}): Promise<RuleOut> => {
  const response = await api.patch(`${RULES_BASE_URL}/${ruleId}`, data);
  return response.data;
};

export const postCreateNewRule = async (
  data: RuleInExtended
): Promise<RuleOut> => {
  const response = await api.post(`${RULES_BASE_URL}/`, data);
  return response.data;
};

export const deleteRule = async (ruleId: string): Promise<RuleOut> => {
  const response = await api.delete(`${RULES_BASE_URL}/${ruleId}`);
  return response.data;
};

export const saveAllRules = async (): Promise<string> => {
  const response = await api.post(`${RULES_BASE_URL}/save-all`);
  return response.data;
};
