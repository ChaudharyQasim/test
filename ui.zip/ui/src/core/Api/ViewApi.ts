import { api } from './BaseApi';
import { FormattedTableData, StreamViewGraphType } from 'App/Views/View.type';
import { GetEvents, GetEventsTimeline } from './types';

export const STREAM_VIEWER_BASE_URL = '/v1/streamviewer';

export const getViewTableData = async (
  viewPayload: GetEvents
): Promise<FormattedTableData> => {
  const response = await api.post(
    `${STREAM_VIEWER_BASE_URL}/search`,
    viewPayload
  );
  return response.data;
};

export const getViewGraphData = async (
  viewPayload: GetEventsTimeline
): Promise<StreamViewGraphType[]> => {
  const response = await api.post(
    `${STREAM_VIEWER_BASE_URL}/timeline`,
    viewPayload
  );
  return response.data;
};
