import { api } from './BaseApi';
import { DashboardMetricsOut } from 'core/Api';

const DASHBOARD_BASE_URL = '/v1/dashboard';

export const getDashboardMetrics = async ({
  timeframe = '1W'
}: {
  timeframe: string;
}): Promise<DashboardMetricsOut> => {
  const response = await api.get(`${DASHBOARD_BASE_URL}/metrics`, {
    params: {
      timeframe
    }
  });
  return response.data;
};
