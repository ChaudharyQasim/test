import { api } from './BaseApi';

export type OrganizationUser = {
  id: number;
  username: string;
  email: string;
  org_id: number;
  first_name: string;
  last_name: string;
};

export const getOrganizationUsers = async (
  org_id: number
): Promise<OrganizationUser[]> => {
  const response = await api.get('/users/get-user-list', {
    params: { org_id }
  });
  return response.data;
};
