import {
  api,
  CreateRole,
  MessageType,
  Permission,
  UpdateRole,
  UpdateRoleUser
} from 'core/Api';

export type RoleType = {
  id: number;
  name: string;
  permissions: Permission[];
};

export const postCreateRole = async (role: CreateRole): Promise<any> => {
  const response = await api.post('/role', role);
  return response.data;
};

export const getRoles = async (organization_id: number): Promise<any> => {
  const response = await api.get(`/roles/${organization_id}`);
  return response.data;
};

export const updateUserRole = async (
  patchData: UpdateRoleUser
): Promise<MessageType> => {
  const response = await api.patch('/role-user', patchData);
  return response.data;
};

export const updateRole = async (
  patchData: UpdateRole
): Promise<MessageType> => {
  const response = await api.patch('/role', patchData);
  return response.data;
};

export const deleteUserRole = async (role_id: number): Promise<MessageType> => {
  const response = await api.delete(`/role/${role_id}`);
  return response.data;
};
