/* eslint-disable */
/* tslint:disable */

/*
 * ---------------------------------------------------------------
 * ## THIS FILE WAS GENERATED VIA SWAGGER-TYPESCRIPT-API        ##
 * ##                                                           ##
 * ## AUTHOR: acacode                                           ##
 * ## SOURCE: https://github.com/acacode/swagger-typescript-api ##
 * ---------------------------------------------------------------
 */

/**
 * ACSFieldType
 * ACS field and it's type.
 */
export interface ACSFieldType {
  /** ACS Fields Enum. */
  field: FieldEnum;
  /** ACS basic types Enum. */
  data_type: TypeEnum;
}

/**
 * AcceptInvitation
 * Schema for accepting an invitation to an organization.
 *
 * Attributes:
 *     token (uuid): Invitation token
 */
export interface AcceptInvitation {
  /**
   * Token
   * @format uuid
   */
  token: string;
}

/**
 * AccountDetailsIn
 * Request model for create vendor account.
 */
export interface AccountDetailsIn {
  /** Vendor Account Id */
  vendor_account_id: string;
  /**
   * Stack Details
   * @default {}
   */
  stack_details?: object;
  /** Onboarding Status */
  onboarding_status: string;
  /**
   * Error Details
   * @default {}
   */
  error_details?: object;
}

/** AddCommentRequest */
export interface AddCommentRequest {
  /**
   * Content
   * @example "This is a comment"
   */
  content: string;
  /**
   * Tagged Users
   * @example ["john_doe@email.com"]
   */
  tagged_users: any[];
}

/** AssumedRoleUser */
export interface AssumedRoleUser {
  /** Arn */
  arn?: string;
  /** Assumedroleid */
  assumedRoleId?: string;
}

/**
 * BasicUser
 * Schema for BasicUser
 */
export interface BasicUser {
  /** Id */
  id: number;
  /** Username */
  username: string;
  /** First Name */
  first_name?: string;
  /** Last Name */
  last_name?: string;
  /** Email */
  email: string;
}

/** Body_create_integration_v1_integrations__post */
export interface BodyCreateIntegrationV1IntegrationsPost {
  /** Scope */
  scope: string;
  /**
   * File
   * @format binary
   */
  file: File;
}

/** Body_sign_in_users_sign_in_post */
export interface BodySignInUsersSignInPost {
  /**
   * Grant Type
   * @pattern password
   */
  grant_type?: string;
  /** Username */
  username: string;
  /** Password */
  password: string;
  /**
   * Scope
   * @default ""
   */
  scope?: string;
  /** Client Id */
  client_id?: string;
  /** Client Secret */
  client_secret?: string;
}

/** Body_update_organization_image_organizations_image__organization_id__patch */
export interface BodyUpdateOrganizationImageOrganizationsImageOrganizationIdPatch {
  /**
   * Image
   * @format binary
   */
  image: File;
}

/** Body_update_user_image_users_image__user_id__patch */
export interface BodyUpdateUserImageUsersImageUserIdPatch {
  /**
   * Image
   * @format binary
   */
  image: File;
}

/** Body_upload_enrichment_file_v1_pipelines_upload_csv_post */
export interface BodyUploadEnrichmentFileV1PipelinesUploadCsvPost {
  /**
   * File
   * @format binary
   */
  file: File;
}

/**
 * CategoricalFieldStats
 * Stats for Top-n values of a field
 */
export interface CategoricalFieldStats {
  /** Field Value */
  field_value: boolean | number | number[] | string;
  /** Count */
  count: number;
  /** Coverage */
  coverage: number;
}

/**
 * Category
 * An enumeration.
 */
export enum Category {
  Collection = 'collection',
  Environment = 'environment',
  Detection = 'detection'
}

/**
 * CommanStreamViewOut
 * Comman Response model for stream view.
 */
export interface CommanStreamViewOut {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at?: string;
  /** Created By */
  created_by: string;
  /** Updated By */
  updated_by?: string;
}

/** Comment */
export interface Comment {
  /** Id */
  id: string;
  /** Insight Id */
  insight_id: string;
  /** User */
  user: string;
  /**
   * Content
   * @example "This is a comment"
   */
  content: string;
  /**
   * Tagged Users
   * @default []
   */
  tagged_users?: any[];
  /**
   * Created Date
   * @format date-time
   */
  created_date: string;
  /**
   * Modified Date
   * @format date-time
   */
  modified_date: string;
  /**
   * Reactions
   * @default []
   */
  reactions?: any[];
}

/** CommentDetail */
export interface CommentDetail {
  /** Id */
  id: string;
  /** Insight Id */
  insight_id: string;
  /** User */
  user: string;
  /**
   * Content
   * @example "This is a comment"
   */
  content: string;
  /**
   * Tagged Users
   * @default []
   */
  tagged_users?: any[];
  /**
   * Created Date
   * @format date-time
   */
  created_date: string;
  /**
   * Modified Date
   * @format date-time
   */
  modified_date: string;
  /**
   * Reactions
   * @default []
   */
  reactions?: any[];
  /** First Name */
  first_name: string;
  /** Last Name */
  last_name: string;
}

/**
 * CommonFieldSet
 * Response model for field set
 */
export interface CommonFieldSet {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Tags */
  tags: string[];
  /** Share Level */
  share_level: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at?: string;
  /** Created By */
  created_by: string;
  /** Updated By */
  updated_by?: string;
}

/** CommunityInvitation */
export interface CommunityInvitation {
  /** Id */
  id?: number;
  /** Nanoid */
  nanoid?: string;
  /**
   * Created At
   * @format date-time
   */
  created_at?: string;
  /** User Id */
  user_id?: number;
  /** Community Id */
  community_id?: number;
  /**
   * Is Approved
   * @default false
   */
  is_approved?: boolean;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /**
   * Token
   * @format uuid
   */
  token: string;
}

/**
 * Condition
 * Condition Model for Get Events.
 */
export interface Condition {
  /** ACS basic types Enum. */
  field_type: TypeEnum;
  /** ACS stream viewer supported operations Enum. */
  operation: OperationsEnum;
  /**
   * Value
   * @default ""
   */
  value?: string;
  /**
   * Values
   * @default []
   */
  values?: string[];
  /**
   * From Value
   * @default ""
   */
  from_value?: string;
  /**
   * To Value
   * @default ""
   */
  to_value?: string;
  /**
   * Case Sensitive
   * @default false
   */
  case_sensitive?: boolean;
  sub_operation?: SubOperation;
  /** ACS Fields Enum. */
  field: FieldEnum;
}

/**
 * ConditionGroup
 * ConditionGroup Model for Get Events.
 */
export interface ConditionGroup {
  /** Condition operator enum. */
  operator: ConditionOperatorEnum;
  /**
   * Conditions
   * @default []
   */
  conditions?: Condition[];
  /**
   * Groups
   * @default []
   */
  groups?: ConditionGroup[];
}

/**
 * ConditionOperatorEnum
 * Condition operator enum.
 */
export enum ConditionOperatorEnum {
  And = 'and',
  Or = 'or'
}

/**
 * ConfigurationCreate
 * Schema for creating integration configuration.
 */
export interface ConfigurationCreate {
  /** Vendor Account Id */
  vendor_account_id: string;
  /** Name */
  name: string;
  /** Integration Id */
  integration_id: string;
  /** Parameters */
  parameters: object;
  /** Interval */
  interval?: number;
  /** Ecs Pipelines */
  ecs_pipelines: object;
  /**
   * Store Raw Event
   * @default false
   */
  store_raw_event?: boolean;
  /** Active */
  active: boolean;
}

/**
 * ConfigurationOut
 * Schema for Configuration Response.
 */
export interface ConfigurationOut {
  /** Id */
  id: string;
  /** Vendor Account Name */
  vendor_account_name?: string;
  /** Vendor Account Id */
  vendor_account_id?: string;
  /** Integration Id */
  integration_id: string;
  /** Name */
  name: string;
  /** Active */
  active: boolean;
  /** Integration type enum. */
  type: IntegrationTypeEnum;
  category: IntegrationCategoryEnum[];
  /** Interval */
  interval?: number;
  /**
   * Last Run At
   * @format date-time
   */
  last_run_at?: string;
  /** Statistics */
  statistics?: object;
  /** Checkpoint */
  checkpoint?: object;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Created By */
  created_by: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at?: string;
  /** Updated By */
  updated_by?: string;
  /** Status type enum. */
  status?: StatusTypeEnum;
  /**
   * Pipeline
   * @default {}
   */
  pipeline?: RoutePipelineOut;
  /**
   * Icon
   * @format binary
   */
  icon?: File;
  /**
   * Metrics
   * @default []
   */
  metrics?: object[];
}

/**
 * ConfigurationUpdate
 * Schema for updating integration configuration.
 */
export interface ConfigurationUpdate {
  /** Vendor Account Id */
  vendor_account_id: string;
  /** Checkpoint */
  checkpoint?: object;
  /** Active */
  active?: boolean;
  /** Interval */
  interval?: number;
  /** Ecs Pipelines */
  ecs_pipelines?: object;
  /** Parameters */
  parameters?: object;
  /** Store Raw Event */
  store_raw_event?: boolean;
}

/** ConfirmUser */
export interface ConfirmUser {
  /** Is Tpa */
  is_tpa?: boolean;
  /**
   * Email
   * @format email
   */
  email: string;
  /** Confirmation Code */
  confirmation_code: string;
}

/** CountMetrics */
export interface CountMetrics {
  /** Collection */
  collection: number;
  /** Environment */
  environment: number;
  /** Detection */
  detection: number;
}

/** CreateAPIKey */
export interface CreateAPIKey {
  /** Name */
  name: string;
  /**
   * Days To Expire
   * @min 1
   * @max 365
   * @default 90
   */
  days_to_expire?: number;
}

/** CreateAPIKeyResponse */
export interface CreateAPIKeyResponse {
  /** Key Id */
  key_id: number;
  /** Name */
  name: string;
  /** Key Value */
  key_value: string;
  /** Organization Name */
  organization_name: string;
  /**
   * Expiration Date
   * @format date-time
   */
  expiration_date: string;
}

/**
 * CreateAccountOut
 * Response model for create account.
 */
export interface CreateAccountOut {
  /** Message */
  message: string;
}

/**
 * CreateFieldSet
 * Request model for field set
 */
export interface CreateFieldSet {
  /** Name */
  name: string;
  fields: FieldEnum[];
  /** Description */
  description?: string;
  /** Tags */
  tags?: string[];
  /**
   * Share Level
   * @default "private"
   */
  share_level?: string;
}

/**
 * CreateFunctionIn
 * Request model for function.
 */
export interface CreateFunctionIn {
  /** Name */
  name: string;
  /**
   * Tags
   * @default []
   */
  tags?: string[];
  /** Description */
  description?: string;
  /** Enum for different function operation name. */
  field_operation_type: FuncOperationTypeEnum;
  /**
   * Block
   * @default {}
   */
  block?: object;
  /** New Csv File Id */
  new_csv_file_id?: string;
}

/**
 * CreateFunctionOut
 * Response model for function.
 */
export interface CreateFunctionOut {
  /** Id */
  id: string;
  /** Is Shared */
  is_shared: boolean;
  /** Description */
  description?: string;
  /** Name */
  name: string;
  /**
   * Tags
   * @default []
   */
  tags?: string[];
  /** Enum for different function operation name. */
  field_operation_type: FuncOperationTypeEnum;
  /** Block */
  block: object;
}

/** CreateInsightRequest */
export interface CreateInsightRequest {
  /**
   * Title
   * @example "Insight title"
   */
  title: string;
  /**
   * Assignees
   * @example ["john-doe@example.com"]
   */
  assignees: string[];
  /** @example "open" */
  status: Status;
  /** @example "low" */
  severity: Severity;
  /**
   * Content
   * @example "Detailed investigation description"
   */
  content: string;
  /** @example ["collection"] */
  category: Category[];
  /**
   * Mitre Attack Techniques
   * @example [{"id":"T1001","name":"Data Obfuscation","sub_id":""}]
   */
  mitre_attack_techniques: MitreAttackTechnique[];
}

/** CreateOrg */
export interface CreateOrg {
  /** Name */
  name: string;
  /** Domains */
  domains: string[];
}

/** CreateRole */
export interface CreateRole {
  /** Name */
  name: string;
  /** Permissions */
  permissions: string[];
  /** Organization Id */
  organization_id: number;
}

/** CreateView */
export interface CreateView {
  /** Name */
  name: string;
  /** Query */
  query: object[];
  time_selection: TimeSelection;
  /** Fieldset Ids */
  fieldset_ids?: string[];
  fields?: FieldEnum[];
}

/** Credentials */
export interface Credentials {
  /** Accesskeyid */
  accessKeyId?: string;
  /** Expiration */
  expiration?: string;
  /** Sessiontoken */
  sessionToken?: string;
}

/**
 * CurrentUser
 * This model is used to return the current user.
 *
 * Attributes:
 *     id (int): The user's id
 *     email (str): The user's email
 *     access_token (str): The user's access token
 *     current_organization_id (int): The user's current org id
 *     username (str): The user's username
 */
export interface CurrentUser {
  /** Is Tpa */
  is_tpa?: boolean;
  /** Id */
  id: number;
  /** Email */
  email: string;
  /** Access Token */
  access_token?: string;
  /** Current Organization Id */
  current_organization_id?: number;
  /** Current Organization Name */
  current_organization_name?: string;
  /** Username */
  username: string;
  /** First Name */
  first_name?: string;
  /** Last Name */
  last_name?: string;
  /** Is Active */
  is_active: boolean;
}

/**
 * DashboardMetricsOut
 * Response schema for dashboard metrics.
 */
export interface DashboardMetricsOut {
  /**
   * Dashboard Metrics
   * @default {}
   */
  dashboard_metrics?: MetricsData;
}

/**
 * DeleteAccountOut
 * Response model for create account.
 */
export interface DeleteAccountOut {
  /** Message */
  message: string;
}

/**
 * DeleteCSVOut
 * Response model for delete csv.
 */
export interface DeleteCSVOut {
  /** Message */
  message: string;
  /**
   * Pipeline List
   * @default []
   */
  pipeline_list?: string[];
  /**
   * Function List
   * @default []
   */
  function_list?: string[];
}

/**
 * DeleteConfigurationOut
 * Schema for deleted configuration response.
 */
export interface DeleteConfigurationOut {
  /** Message */
  message: string;
}

/**
 * DeleteFieldSetOut
 * Response model for delete fieldset.
 */
export interface DeleteFieldSetOut {
  /** Message */
  message: string;
  /**
   * Views
   * @default []
   */
  views?: string[];
}

/**
 * DeleteFunctionOut
 * Response model for delete function.
 */
export interface DeleteFunctionOut {
  /** Message */
  message: string;
  /**
   * Pipeline List
   * @default []
   */
  pipeline_list?: string[];
}

/**
 * DeleteIntegrationOut
 * Response model for delete integration.
 */
export interface DeleteIntegrationOut {
  /** Message */
  message: string;
}

/**
 * DeleteStreamViewOut
 * Response model for delete stream view
 */
export interface DeleteStreamViewOut {
  /** Message */
  message: string;
}

/**
 * DetailUserOut
 * Response model for detailed user information.
 */
export interface DetailUserOut {
  /** Schema for DetailUserOut.user_db */
  user_db: UserDetail;
  /**
   * Email
   * @format email
   */
  email: string;
  /** Schema for DetailUserOut.current_organization */
  current_organization: UserCurrentOrganization;
  /** Permissions */
  permissions: Permission[];
}

/** ECSEventFull */
export interface ECSEventFull {
  /** Abstract Id */
  abstract_id?: string;
  /** Timestamp */
  timestamp?: string;
  /** Aws Cloudtrail Event Type */
  aws_cloudtrail_event_type?: string;
  /** Aws Cloudtrail Event Version */
  aws_cloudtrail_event_version?: string;
  aws_cloudtrail_flattened_request_parameters?: FlattenedRequestParameters;
  aws_cloudtrail_flattened_response_elements?: FlattenedResponseElements;
  /** Aws Cloudtrail Recipient Account Id */
  aws_cloudtrail_recipient_account_id?: string;
  /** Aws Cloudtrail Request Id */
  aws_cloudtrail_request_id?: string;
  aws_cloudtrail_user_identity?: UserIdentity;
  /** Cloud Account Id */
  cloud_account_id?: string;
  /** Cloud Region */
  cloud_region?: string;
  /** Event Action */
  event_action?: string;
  /** Event Category */
  event_category?: string[];
  /** Event Dataset */
  event_dataset?: string;
  /** Event Id */
  event_id?: string;
  /** Event Kind */
  event_kind?: string;
  /** Event Module */
  event_module?: string;
  /** Event Outcome */
  event_outcome?: string;
  /** Event Provider */
  event_provider?: string;
  /** Event Type */
  event_type?: string[];
  /** Fileset Name */
  fileset_name?: string;
  /** Input Type */
  input_type?: string;
  /** Log Offset */
  log_offset?: number;
  /** Service Type */
  service_type?: string;
  /** Source Address */
  source_address?: string;
  /** Source Geo City Name */
  source_geo_city_name?: string;
  /** Source Geo Continent Name */
  source_geo_continent_name?: string;
  /** Source Geo Country Iso Code */
  source_geo_country_iso_code?: string;
  /** Source Geo Country Name */
  source_geo_country_name?: string;
  source_geo_location?: SourceGeoLocation;
  /** Source Geo Region Iso Code */
  source_geo_region_iso_code?: string;
  /** Source Geo Region Name */
  source_geo_region_name?: string;
  /** Source Ip */
  source_ip?: string;
  /** Tags */
  tags?: string[];
  /** User Id */
  user_id?: string;
  /** User Name */
  user_name?: string;
  /** User Agent Device Name */
  user_agent_device_name?: string;
  /** User Agent Name */
  user_agent_name?: string;
  /** User Agent Original */
  user_agent_original?: string;
  /** User Agent Os Full */
  user_agent_os_full?: string;
  /** User Agent Os Name */
  user_agent_os_name?: string;
  /** User Agent Os Version */
  user_agent_os_version?: string;
  /** User Agent Version */
  user_agent_version?: string;
}

/** Event */
export interface Event {
  /** Event */
  event: object | string;
}

/**
 * Events
 * Response Model for Events.
 */
export interface Events {
  /** Events */
  events: object[];
  /** Response Model for Pagination Info. */
  metadata: AppStreamviewerSchemasPaginationInfo;
}

/**
 * FieldAnalytic
 * Analytics for a field
 */
export interface FieldAnalytic {
  /** Total Count */
  total_count: number;
  /** Stats for numeric field */
  numeric?: NumericFieldStats;
  /** Categorical */
  categorical: CategoricalFieldStats[];
}

/**
 * FieldAnalyticsOut
 * Response Model for field analytics
 */
export interface FieldAnalyticsOut {
  /** ACS Fields Enum. */
  field: FieldEnum;
  /** ACS basic types Enum. */
  field_type: TypeEnum;
  /** Coverage */
  coverage: number;
  /** Analytics for a field */
  analytics: FieldAnalytic;
}

/**
 * FieldEnum
 * ACS Fields Enum.
 */
export enum FieldEnum {
  Id = 'id',
  Abstract = 'abstract',
  AbstractAggregationCount = 'abstract.aggregation_count',
  AbstractAggregationStart = 'abstract.aggregation_start',
  AbstractAggregationEnd = 'abstract.aggregation_end',
  AbstractRelatedEvents = 'abstract.related_events',
  AbstractMatchedRules = 'abstract.matched_rules',
  AbstractRiskScore = 'abstract.risk_score',
  AbstractCorrelatedCount = 'abstract.correlated_count',
  AbstractSeverity = 'abstract.severity',
  ValueTimestamp = '@timestamp',
  Labels = 'labels',
  Message = 'message',
  Tags = 'tags',
  Agent = 'agent',
  AgentBuild = 'agent.build',
  AgentBuildOriginal = 'agent.build.original',
  AgentEphemeralId = 'agent.ephemeral_id',
  AgentId = 'agent.id',
  AgentName = 'agent.name',
  AgentType = 'agent.type',
  AgentVersion = 'agent.version',
  Cloud = 'cloud',
  CloudAccount = 'cloud.account',
  CloudAccountId = 'cloud.account.id',
  CloudAccountName = 'cloud.account.name',
  CloudAvailabilityZone = 'cloud.availability_zone',
  CloudInstance = 'cloud.instance',
  CloudInstanceId = 'cloud.instance.id',
  CloudInstanceName = 'cloud.instance.name',
  CloudMachine = 'cloud.machine',
  CloudMachineType = 'cloud.machine.type',
  CloudOrigin = 'cloud.origin',
  CloudOriginAccount = 'cloud.origin.account',
  CloudOriginAccountId = 'cloud.origin.account.id',
  CloudOriginAccountName = 'cloud.origin.account.name',
  CloudOriginAvailabilityZone = 'cloud.origin.availability_zone',
  CloudOriginInstance = 'cloud.origin.instance',
  CloudOriginInstanceId = 'cloud.origin.instance.id',
  CloudOriginInstanceName = 'cloud.origin.instance.name',
  CloudOriginMachine = 'cloud.origin.machine',
  CloudOriginMachineType = 'cloud.origin.machine.type',
  CloudOriginProject = 'cloud.origin.project',
  CloudOriginProjectId = 'cloud.origin.project.id',
  CloudOriginProjectName = 'cloud.origin.project.name',
  CloudOriginProvider = 'cloud.origin.provider',
  CloudOriginRegion = 'cloud.origin.region',
  CloudOriginService = 'cloud.origin.service',
  CloudOriginServiceName = 'cloud.origin.service.name',
  CloudProject = 'cloud.project',
  CloudProjectId = 'cloud.project.id',
  CloudProjectName = 'cloud.project.name',
  CloudProvider = 'cloud.provider',
  CloudRegion = 'cloud.region',
  CloudService = 'cloud.service',
  CloudServiceName = 'cloud.service.name',
  CloudTarget = 'cloud.target',
  CloudTargetAccount = 'cloud.target.account',
  CloudTargetAccountId = 'cloud.target.account.id',
  CloudTargetAccountName = 'cloud.target.account.name',
  CloudTargetAvailabilityZone = 'cloud.target.availability_zone',
  CloudTargetInstance = 'cloud.target.instance',
  CloudTargetInstanceId = 'cloud.target.instance.id',
  CloudTargetInstanceName = 'cloud.target.instance.name',
  CloudTargetMachine = 'cloud.target.machine',
  CloudTargetMachineType = 'cloud.target.machine.type',
  CloudTargetProject = 'cloud.target.project',
  CloudTargetProjectId = 'cloud.target.project.id',
  CloudTargetProjectName = 'cloud.target.project.name',
  CloudTargetProvider = 'cloud.target.provider',
  CloudTargetRegion = 'cloud.target.region',
  CloudTargetService = 'cloud.target.service',
  CloudTargetServiceName = 'cloud.target.service.name',
  Container = 'container',
  ContainerCpu = 'container.cpu',
  ContainerCpuUsage = 'container.cpu.usage',
  ContainerDisk = 'container.disk',
  ContainerDiskRead = 'container.disk.read',
  ContainerDiskReadBytes = 'container.disk.read.bytes',
  ContainerDiskWrite = 'container.disk.write',
  ContainerDiskWriteBytes = 'container.disk.write.bytes',
  ContainerId = 'container.id',
  ContainerImage = 'container.image',
  ContainerImageHash = 'container.image.hash',
  ContainerImageHashAll = 'container.image.hash.all',
  ContainerImageName = 'container.image.name',
  ContainerImageTag = 'container.image.tag',
  ContainerLabels = 'container.labels',
  ContainerMemory = 'container.memory',
  ContainerMemoryUsage = 'container.memory.usage',
  ContainerName = 'container.name',
  ContainerNetwork = 'container.network',
  ContainerNetworkEgress = 'container.network.egress',
  ContainerNetworkEgressBytes = 'container.network.egress.bytes',
  ContainerNetworkIngress = 'container.network.ingress',
  ContainerNetworkIngressBytes = 'container.network.ingress.bytes',
  ContainerRuntime = 'container.runtime',
  DataStream = 'data_stream',
  DataStreamDataset = 'data_stream.dataset',
  DataStreamNamespace = 'data_stream.namespace',
  DataStreamType = 'data_stream.type',
  Destination = 'destination',
  DestinationAddress = 'destination.address',
  DestinationAs = 'destination.as',
  DestinationAsNumber = 'destination.as.number',
  DestinationAsOrganization = 'destination.as.organization',
  DestinationAsOrganizationName = 'destination.as.organization.name',
  DestinationBytes = 'destination.bytes',
  DestinationDomain = 'destination.domain',
  DestinationGeo = 'destination.geo',
  DestinationGeoCityName = 'destination.geo.city_name',
  DestinationGeoContinentCode = 'destination.geo.continent_code',
  DestinationGeoContinentName = 'destination.geo.continent_name',
  DestinationGeoCountryIsoCode = 'destination.geo.country_iso_code',
  DestinationGeoCountryName = 'destination.geo.country_name',
  DestinationGeoLocation = 'destination.geo.location',
  DestinationGeoName = 'destination.geo.name',
  DestinationGeoPostalCode = 'destination.geo.postal_code',
  DestinationGeoRegionIsoCode = 'destination.geo.region_iso_code',
  DestinationGeoRegionName = 'destination.geo.region_name',
  DestinationGeoTimezone = 'destination.geo.timezone',
  DestinationIpv4 = 'destination.ipv4',
  DestinationIpv6 = 'destination.ipv6',
  DestinationMac = 'destination.mac',
  DestinationNat = 'destination.nat',
  DestinationNatIpv4 = 'destination.nat.ipv4',
  DestinationNatIpv6 = 'destination.nat.ipv6',
  DestinationNatPort = 'destination.nat.port',
  DestinationPackets = 'destination.packets',
  DestinationPort = 'destination.port',
  DestinationRegisteredDomain = 'destination.registered_domain',
  DestinationSubdomain = 'destination.subdomain',
  DestinationTopLevelDomain = 'destination.top_level_domain',
  DestinationUser = 'destination.user',
  DestinationUserDomain = 'destination.user.domain',
  DestinationUserEmail = 'destination.user.email',
  DestinationUserFullName = 'destination.user.full_name',
  DestinationUserGroup = 'destination.user.group',
  DestinationUserGroupDomain = 'destination.user.group.domain',
  DestinationUserGroupId = 'destination.user.group.id',
  DestinationUserGroupName = 'destination.user.group.name',
  DestinationUserHash = 'destination.user.hash',
  DestinationUserId = 'destination.user.id',
  DestinationUserName = 'destination.user.name',
  DestinationUserRoles = 'destination.user.roles',
  Device = 'device',
  DeviceId = 'device.id',
  DeviceManufacturer = 'device.manufacturer',
  DeviceModel = 'device.model',
  DeviceModelIdentifier = 'device.model.identifier',
  DeviceModelName = 'device.model.name',
  Dns = 'dns',
  DnsAnswers = 'dns.answers',
  DnsAnswersClass = 'dns.answers.class',
  DnsAnswersData = 'dns.answers.data',
  DnsAnswersName = 'dns.answers.name',
  DnsAnswersTtl = 'dns.answers.ttl',
  DnsAnswersType = 'dns.answers.type',
  DnsHeaderFlags = 'dns.header_flags',
  DnsId = 'dns.id',
  DnsOpCode = 'dns.op_code',
  DnsQuestion = 'dns.question',
  DnsQuestionClass = 'dns.question.class',
  DnsQuestionName = 'dns.question.name',
  DnsQuestionRegisteredDomain = 'dns.question.registered_domain',
  DnsQuestionSubdomain = 'dns.question.subdomain',
  DnsQuestionTopLevelDomain = 'dns.question.top_level_domain',
  DnsQuestionType = 'dns.question.type',
  DnsResolvedIpv4 = 'dns.resolved_ipv4',
  DnsResolvedIpv6 = 'dns.resolved_ipv6',
  DnsResponseCode = 'dns.response_code',
  DnsType = 'dns.type',
  Ecs = 'ecs',
  EcsVersion = 'ecs.version',
  Email = 'email',
  EmailAttachments = 'email.attachments',
  EmailAttachmentsFile = 'email.attachments.file',
  EmailAttachmentsFileExtension = 'email.attachments.file.extension',
  EmailAttachmentsFileHash = 'email.attachments.file.hash',
  EmailAttachmentsFileHashMd5 = 'email.attachments.file.hash.md5',
  EmailAttachmentsFileHashSha1 = 'email.attachments.file.hash.sha1',
  EmailAttachmentsFileHashSha256 = 'email.attachments.file.hash.sha256',
  EmailAttachmentsFileHashSha384 = 'email.attachments.file.hash.sha384',
  EmailAttachmentsFileHashSha512 = 'email.attachments.file.hash.sha512',
  EmailAttachmentsFileHashSsdeep = 'email.attachments.file.hash.ssdeep',
  EmailAttachmentsFileHashTlsh = 'email.attachments.file.hash.tlsh',
  EmailAttachmentsFileMimeType = 'email.attachments.file.mime_type',
  EmailAttachmentsFileName = 'email.attachments.file.name',
  EmailAttachmentsFileSize = 'email.attachments.file.size',
  EmailBcc = 'email.bcc',
  EmailBccAddress = 'email.bcc.address',
  EmailCc = 'email.cc',
  EmailCcAddress = 'email.cc.address',
  EmailContentType = 'email.content_type',
  EmailDeliveryTimestamp = 'email.delivery_timestamp',
  EmailDirection = 'email.direction',
  EmailFrom = 'email.from',
  EmailFromAddress = 'email.from.address',
  EmailLocalId = 'email.local_id',
  EmailMessageId = 'email.message_id',
  EmailOriginationTimestamp = 'email.origination_timestamp',
  EmailReplyTo = 'email.reply_to',
  EmailReplyToAddress = 'email.reply_to.address',
  EmailSender = 'email.sender',
  EmailSenderAddress = 'email.sender.address',
  EmailSubject = 'email.subject',
  EmailTo = 'email.to',
  EmailToAddress = 'email.to.address',
  EmailXMailer = 'email.x_mailer',
  Error = 'error',
  ErrorCode = 'error.code',
  ErrorId = 'error.id',
  ErrorMessage = 'error.message',
  ErrorStackTrace = 'error.stack_trace',
  ErrorType = 'error.type',
  Event = 'event',
  EventAction = 'event.action',
  EventAgentIdStatus = 'event.agent_id_status',
  EventCategory = 'event.category',
  EventCode = 'event.code',
  EventCreated = 'event.created',
  EventCustomerName = 'event.customer_name',
  EventDataset = 'event.dataset',
  EventDuration = 'event.duration',
  EventEnd = 'event.end',
  EventHash = 'event.hash',
  EventId = 'event.id',
  EventIngested = 'event.ingested',
  EventKind = 'event.kind',
  EventModule = 'event.module',
  EventOriginal = 'event.original',
  EventOutcome = 'event.outcome',
  EventProvider = 'event.provider',
  EventReason = 'event.reason',
  EventReference = 'event.reference',
  EventRiskScore = 'event.risk_score',
  EventRiskScoreNorm = 'event.risk_score_norm',
  EventSequence = 'event.sequence',
  EventSeverity = 'event.severity',
  EventStart = 'event.start',
  EventTimezone = 'event.timezone',
  EventType = 'event.type',
  EventUrl = 'event.url',
  File = 'file',
  FileAccessed = 'file.accessed',
  FileAttributes = 'file.attributes',
  FileCodeSignature = 'file.code_signature',
  FileCodeSignatureDigestAlgorithm = 'file.code_signature.digest_algorithm',
  FileCodeSignatureExists = 'file.code_signature.exists',
  FileCodeSignatureSigningId = 'file.code_signature.signing_id',
  FileCodeSignatureStatus = 'file.code_signature.status',
  FileCodeSignatureSubjectName = 'file.code_signature.subject_name',
  FileCodeSignatureTeamId = 'file.code_signature.team_id',
  FileCodeSignatureTimestamp = 'file.code_signature.timestamp',
  FileCodeSignatureTrusted = 'file.code_signature.trusted',
  FileCodeSignatureValid = 'file.code_signature.valid',
  FileCreated = 'file.created',
  FileCtime = 'file.ctime',
  FileDevice = 'file.device',
  FileDirectory = 'file.directory',
  FileDriveLetter = 'file.drive_letter',
  FileElf = 'file.elf',
  FileElfArchitecture = 'file.elf.architecture',
  FileElfByteOrder = 'file.elf.byte_order',
  FileElfCpuType = 'file.elf.cpu_type',
  FileElfCreationDate = 'file.elf.creation_date',
  FileElfExports = 'file.elf.exports',
  FileElfGoImportHash = 'file.elf.go_import_hash',
  FileElfGoImports = 'file.elf.go_imports',
  FileElfGoImportsNamesEntropy = 'file.elf.go_imports_names_entropy',
  FileElfGoImportsNamesVarEntropy = 'file.elf.go_imports_names_var_entropy',
  FileElfGoStripped = 'file.elf.go_stripped',
  FileElfHeader = 'file.elf.header',
  FileElfHeaderAbiVersion = 'file.elf.header.abi_version',
  FileElfHeaderClass = 'file.elf.header.class',
  FileElfHeaderData = 'file.elf.header.data',
  FileElfHeaderEntrypoint = 'file.elf.header.entrypoint',
  FileElfHeaderObjectVersion = 'file.elf.header.object_version',
  FileElfHeaderOsAbi = 'file.elf.header.os_abi',
  FileElfHeaderType = 'file.elf.header.type',
  FileElfHeaderVersion = 'file.elf.header.version',
  FileElfImportHash = 'file.elf.import_hash',
  FileElfImports = 'file.elf.imports',
  FileElfImportsNamesEntropy = 'file.elf.imports_names_entropy',
  FileElfImportsNamesVarEntropy = 'file.elf.imports_names_var_entropy',
  FileElfSections = 'file.elf.sections',
  FileElfSectionsChi2 = 'file.elf.sections.chi2',
  FileElfSectionsEntropy = 'file.elf.sections.entropy',
  FileElfSectionsFlags = 'file.elf.sections.flags',
  FileElfSectionsName = 'file.elf.sections.name',
  FileElfSectionsPhysicalOffset = 'file.elf.sections.physical_offset',
  FileElfSectionsPhysicalSize = 'file.elf.sections.physical_size',
  FileElfSectionsType = 'file.elf.sections.type',
  FileElfSectionsVarEntropy = 'file.elf.sections.var_entropy',
  FileElfSectionsVirtualAddress = 'file.elf.sections.virtual_address',
  FileElfSectionsVirtualSize = 'file.elf.sections.virtual_size',
  FileElfSegments = 'file.elf.segments',
  FileElfSegmentsSections = 'file.elf.segments.sections',
  FileElfSegmentsType = 'file.elf.segments.type',
  FileElfSharedLibraries = 'file.elf.shared_libraries',
  FileElfTelfhash = 'file.elf.telfhash',
  FileExtension = 'file.extension',
  FileForkName = 'file.fork_name',
  FileGid = 'file.gid',
  FileGroup = 'file.group',
  FileHash = 'file.hash',
  FileHashMd5 = 'file.hash.md5',
  FileHashSha1 = 'file.hash.sha1',
  FileHashSha256 = 'file.hash.sha256',
  FileHashSha384 = 'file.hash.sha384',
  FileHashSha512 = 'file.hash.sha512',
  FileHashSsdeep = 'file.hash.ssdeep',
  FileHashTlsh = 'file.hash.tlsh',
  FileInode = 'file.inode',
  FileMacho = 'file.macho',
  FileMachoGoImportHash = 'file.macho.go_import_hash',
  FileMachoGoImports = 'file.macho.go_imports',
  FileMachoGoImportsNamesEntropy = 'file.macho.go_imports_names_entropy',
  FileMachoGoImportsNamesVarEntropy = 'file.macho.go_imports_names_var_entropy',
  FileMachoGoStripped = 'file.macho.go_stripped',
  FileMachoImportHash = 'file.macho.import_hash',
  FileMachoImports = 'file.macho.imports',
  FileMachoImportsNamesEntropy = 'file.macho.imports_names_entropy',
  FileMachoImportsNamesVarEntropy = 'file.macho.imports_names_var_entropy',
  FileMachoSections = 'file.macho.sections',
  FileMachoSectionsEntropy = 'file.macho.sections.entropy',
  FileMachoSectionsName = 'file.macho.sections.name',
  FileMachoSectionsPhysicalSize = 'file.macho.sections.physical_size',
  FileMachoSectionsVarEntropy = 'file.macho.sections.var_entropy',
  FileMachoSectionsVirtualSize = 'file.macho.sections.virtual_size',
  FileMachoSymhash = 'file.macho.symhash',
  FileMimeType = 'file.mime_type',
  FileMode = 'file.mode',
  FileMtime = 'file.mtime',
  FileName = 'file.name',
  FileOwner = 'file.owner',
  FilePath = 'file.path',
  FilePe = 'file.pe',
  FilePeArchitecture = 'file.pe.architecture',
  FilePeCompany = 'file.pe.company',
  FilePeDescription = 'file.pe.description',
  FilePeFileVersion = 'file.pe.file_version',
  FilePeGoImportHash = 'file.pe.go_import_hash',
  FilePeGoImports = 'file.pe.go_imports',
  FilePeGoImportsNamesEntropy = 'file.pe.go_imports_names_entropy',
  FilePeGoImportsNamesVarEntropy = 'file.pe.go_imports_names_var_entropy',
  FilePeGoStripped = 'file.pe.go_stripped',
  FilePeImphash = 'file.pe.imphash',
  FilePeImportHash = 'file.pe.import_hash',
  FilePeImports = 'file.pe.imports',
  FilePeImportsNamesEntropy = 'file.pe.imports_names_entropy',
  FilePeImportsNamesVarEntropy = 'file.pe.imports_names_var_entropy',
  FilePeOriginalFileName = 'file.pe.original_file_name',
  FilePePehash = 'file.pe.pehash',
  FilePeProduct = 'file.pe.product',
  FilePeSections = 'file.pe.sections',
  FilePeSectionsEntropy = 'file.pe.sections.entropy',
  FilePeSectionsName = 'file.pe.sections.name',
  FilePeSectionsPhysicalSize = 'file.pe.sections.physical_size',
  FilePeSectionsVarEntropy = 'file.pe.sections.var_entropy',
  FilePeSectionsVirtualSize = 'file.pe.sections.virtual_size',
  FileSize = 'file.size',
  FileTargetPath = 'file.target_path',
  FileType = 'file.type',
  FileUid = 'file.uid',
  FileX509 = 'file.x509',
  FileX509AlternativeNames = 'file.x509.alternative_names',
  FileX509Issuer = 'file.x509.issuer',
  FileX509IssuerCommonName = 'file.x509.issuer.common_name',
  FileX509IssuerCountry = 'file.x509.issuer.country',
  FileX509IssuerDistinguishedName = 'file.x509.issuer.distinguished_name',
  FileX509IssuerLocality = 'file.x509.issuer.locality',
  FileX509IssuerOrganization = 'file.x509.issuer.organization',
  FileX509IssuerOrganizationalUnit = 'file.x509.issuer.organizational_unit',
  FileX509IssuerStateOrProvince = 'file.x509.issuer.state_or_province',
  FileX509NotAfter = 'file.x509.not_after',
  FileX509NotBefore = 'file.x509.not_before',
  FileX509PublicKeyAlgorithm = 'file.x509.public_key_algorithm',
  FileX509PublicKeyCurve = 'file.x509.public_key_curve',
  FileX509PublicKeyExponent = 'file.x509.public_key_exponent',
  FileX509PublicKeySize = 'file.x509.public_key_size',
  FileX509SerialNumber = 'file.x509.serial_number',
  FileX509SignatureAlgorithm = 'file.x509.signature_algorithm',
  FileX509Subject = 'file.x509.subject',
  FileX509SubjectCommonName = 'file.x509.subject.common_name',
  FileX509SubjectCountry = 'file.x509.subject.country',
  FileX509SubjectDistinguishedName = 'file.x509.subject.distinguished_name',
  FileX509SubjectLocality = 'file.x509.subject.locality',
  FileX509SubjectOrganization = 'file.x509.subject.organization',
  FileX509SubjectOrganizationalUnit = 'file.x509.subject.organizational_unit',
  FileX509SubjectStateOrProvince = 'file.x509.subject.state_or_province',
  FileX509VersionNumber = 'file.x509.version_number',
  Group = 'group',
  GroupDomain = 'group.domain',
  GroupId = 'group.id',
  GroupName = 'group.name',
  Host = 'host',
  HostArchitecture = 'host.architecture',
  HostBoot = 'host.boot',
  HostBootId = 'host.boot.id',
  HostCpu = 'host.cpu',
  HostCpuUsage = 'host.cpu.usage',
  HostDisk = 'host.disk',
  HostDiskRead = 'host.disk.read',
  HostDiskReadBytes = 'host.disk.read.bytes',
  HostDiskWrite = 'host.disk.write',
  HostDiskWriteBytes = 'host.disk.write.bytes',
  HostDomain = 'host.domain',
  HostGeo = 'host.geo',
  HostGeoCityName = 'host.geo.city_name',
  HostGeoContinentCode = 'host.geo.continent_code',
  HostGeoContinentName = 'host.geo.continent_name',
  HostGeoCountryIsoCode = 'host.geo.country_iso_code',
  HostGeoCountryName = 'host.geo.country_name',
  HostGeoLocation = 'host.geo.location',
  HostGeoName = 'host.geo.name',
  HostGeoPostalCode = 'host.geo.postal_code',
  HostGeoRegionIsoCode = 'host.geo.region_iso_code',
  HostGeoRegionName = 'host.geo.region_name',
  HostGeoTimezone = 'host.geo.timezone',
  HostHostname = 'host.hostname',
  HostId = 'host.id',
  HostIpv4 = 'host.ipv4',
  HostIpv6 = 'host.ipv6',
  HostMac = 'host.mac',
  HostName = 'host.name',
  HostNetwork = 'host.network',
  HostNetworkEgress = 'host.network.egress',
  HostNetworkEgressBytes = 'host.network.egress.bytes',
  HostNetworkEgressPackets = 'host.network.egress.packets',
  HostNetworkIngress = 'host.network.ingress',
  HostNetworkIngressBytes = 'host.network.ingress.bytes',
  HostNetworkIngressPackets = 'host.network.ingress.packets',
  HostOs = 'host.os',
  HostOsFamily = 'host.os.family',
  HostOsFull = 'host.os.full',
  HostOsKernel = 'host.os.kernel',
  HostOsName = 'host.os.name',
  HostOsPlatform = 'host.os.platform',
  HostOsType = 'host.os.type',
  HostOsVersion = 'host.os.version',
  HostPidNsIno = 'host.pid_ns_ino',
  HostRisk = 'host.risk',
  HostRiskCalculatedLevel = 'host.risk.calculated_level',
  HostRiskCalculatedScore = 'host.risk.calculated_score',
  HostRiskCalculatedScoreNorm = 'host.risk.calculated_score_norm',
  HostRiskStaticLevel = 'host.risk.static_level',
  HostRiskStaticScore = 'host.risk.static_score',
  HostRiskStaticScoreNorm = 'host.risk.static_score_norm',
  HostType = 'host.type',
  HostUptime = 'host.uptime',
  Http = 'http',
  HttpRequest = 'http.request',
  HttpRequestBody = 'http.request.body',
  HttpRequestBodyBytes = 'http.request.body.bytes',
  HttpRequestBodyContent = 'http.request.body.content',
  HttpRequestBytes = 'http.request.bytes',
  HttpRequestId = 'http.request.id',
  HttpRequestMethod = 'http.request.method',
  HttpRequestMimeType = 'http.request.mime_type',
  HttpRequestReferrer = 'http.request.referrer',
  HttpResponse = 'http.response',
  HttpResponseBody = 'http.response.body',
  HttpResponseBodyBytes = 'http.response.body.bytes',
  HttpResponseBodyContent = 'http.response.body.content',
  HttpResponseBytes = 'http.response.bytes',
  HttpResponseMimeType = 'http.response.mime_type',
  HttpResponseStatusCode = 'http.response.status_code',
  HttpVersion = 'http.version',
  Log = 'log',
  LogFile = 'log.file',
  LogFilePath = 'log.file.path',
  LogLevel = 'log.level',
  LogLogger = 'log.logger',
  LogOrigin = 'log.origin',
  LogOriginFile = 'log.origin.file',
  LogOriginFileLine = 'log.origin.file.line',
  LogOriginFileName = 'log.origin.file.name',
  LogOriginFunction = 'log.origin.function',
  LogSyslog = 'log.syslog',
  LogSyslogAppname = 'log.syslog.appname',
  LogSyslogFacility = 'log.syslog.facility',
  LogSyslogFacilityCode = 'log.syslog.facility.code',
  LogSyslogFacilityName = 'log.syslog.facility.name',
  LogSyslogHostname = 'log.syslog.hostname',
  LogSyslogMsgid = 'log.syslog.msgid',
  LogSyslogPriority = 'log.syslog.priority',
  LogSyslogProcid = 'log.syslog.procid',
  LogSyslogSeverity = 'log.syslog.severity',
  LogSyslogSeverityCode = 'log.syslog.severity.code',
  LogSyslogSeverityName = 'log.syslog.severity.name',
  LogSyslogStructuredData = 'log.syslog.structured_data',
  LogSyslogVersion = 'log.syslog.version',
  Network = 'network',
  NetworkApplication = 'network.application',
  NetworkBytes = 'network.bytes',
  NetworkCommunityId = 'network.community_id',
  NetworkDirection = 'network.direction',
  NetworkForwardedIpv4 = 'network.forwarded_ipv4',
  NetworkForwardedIpv6 = 'network.forwarded_ipv6',
  NetworkIanaNumber = 'network.iana_number',
  NetworkInner = 'network.inner',
  NetworkInnerVlan = 'network.inner.vlan',
  NetworkInnerVlanId = 'network.inner.vlan.id',
  NetworkInnerVlanName = 'network.inner.vlan.name',
  NetworkName = 'network.name',
  NetworkPackets = 'network.packets',
  NetworkProtocol = 'network.protocol',
  NetworkTransport = 'network.transport',
  NetworkType = 'network.type',
  NetworkVlan = 'network.vlan',
  NetworkVlanId = 'network.vlan.id',
  NetworkVlanName = 'network.vlan.name',
  Observer = 'observer',
  ObserverEgress = 'observer.egress',
  ObserverEgressInterface = 'observer.egress.interface',
  ObserverEgressInterfaceAlias = 'observer.egress.interface.alias',
  ObserverEgressInterfaceId = 'observer.egress.interface.id',
  ObserverEgressInterfaceName = 'observer.egress.interface.name',
  ObserverEgressVlan = 'observer.egress.vlan',
  ObserverEgressVlanId = 'observer.egress.vlan.id',
  ObserverEgressVlanName = 'observer.egress.vlan.name',
  ObserverEgressZone = 'observer.egress.zone',
  ObserverGeo = 'observer.geo',
  ObserverGeoCityName = 'observer.geo.city_name',
  ObserverGeoContinentCode = 'observer.geo.continent_code',
  ObserverGeoContinentName = 'observer.geo.continent_name',
  ObserverGeoCountryIsoCode = 'observer.geo.country_iso_code',
  ObserverGeoCountryName = 'observer.geo.country_name',
  ObserverGeoLocation = 'observer.geo.location',
  ObserverGeoName = 'observer.geo.name',
  ObserverGeoPostalCode = 'observer.geo.postal_code',
  ObserverGeoRegionIsoCode = 'observer.geo.region_iso_code',
  ObserverGeoRegionName = 'observer.geo.region_name',
  ObserverGeoTimezone = 'observer.geo.timezone',
  ObserverHostname = 'observer.hostname',
  ObserverIngress = 'observer.ingress',
  ObserverIngressInterface = 'observer.ingress.interface',
  ObserverIngressInterfaceAlias = 'observer.ingress.interface.alias',
  ObserverIngressInterfaceId = 'observer.ingress.interface.id',
  ObserverIngressInterfaceName = 'observer.ingress.interface.name',
  ObserverIngressVlan = 'observer.ingress.vlan',
  ObserverIngressVlanId = 'observer.ingress.vlan.id',
  ObserverIngressVlanName = 'observer.ingress.vlan.name',
  ObserverIngressZone = 'observer.ingress.zone',
  ObserverIpv4 = 'observer.ipv4',
  ObserverIpv6 = 'observer.ipv6',
  ObserverMac = 'observer.mac',
  ObserverName = 'observer.name',
  ObserverOs = 'observer.os',
  ObserverOsFamily = 'observer.os.family',
  ObserverOsFull = 'observer.os.full',
  ObserverOsKernel = 'observer.os.kernel',
  ObserverOsName = 'observer.os.name',
  ObserverOsPlatform = 'observer.os.platform',
  ObserverOsType = 'observer.os.type',
  ObserverOsVersion = 'observer.os.version',
  ObserverProduct = 'observer.product',
  ObserverSerialNumber = 'observer.serial_number',
  ObserverType = 'observer.type',
  ObserverVendor = 'observer.vendor',
  ObserverVersion = 'observer.version',
  Orchestrator = 'orchestrator',
  OrchestratorApiVersion = 'orchestrator.api_version',
  OrchestratorCluster = 'orchestrator.cluster',
  OrchestratorClusterId = 'orchestrator.cluster.id',
  OrchestratorClusterName = 'orchestrator.cluster.name',
  OrchestratorClusterUrl = 'orchestrator.cluster.url',
  OrchestratorClusterVersion = 'orchestrator.cluster.version',
  OrchestratorNamespace = 'orchestrator.namespace',
  OrchestratorOrganization = 'orchestrator.organization',
  OrchestratorResource = 'orchestrator.resource',
  OrchestratorResourceAnnotation = 'orchestrator.resource.annotation',
  OrchestratorResourceId = 'orchestrator.resource.id',
  OrchestratorResourceIpv4 = 'orchestrator.resource.ipv4',
  OrchestratorResourceIpv6 = 'orchestrator.resource.ipv6',
  OrchestratorResourceLabel = 'orchestrator.resource.label',
  OrchestratorResourceName = 'orchestrator.resource.name',
  OrchestratorResourceParent = 'orchestrator.resource.parent',
  OrchestratorResourceParentType = 'orchestrator.resource.parent.type',
  OrchestratorResourceType = 'orchestrator.resource.type',
  OrchestratorType = 'orchestrator.type',
  Organization = 'organization',
  OrganizationId = 'organization.id',
  OrganizationName = 'organization.name',
  Package = 'package',
  PackageArchitecture = 'package.architecture',
  PackageBuildVersion = 'package.build_version',
  PackageChecksum = 'package.checksum',
  PackageDescription = 'package.description',
  PackageInstallScope = 'package.install_scope',
  PackageInstalled = 'package.installed',
  PackageLicense = 'package.license',
  PackageName = 'package.name',
  PackagePath = 'package.path',
  PackageReference = 'package.reference',
  PackageSize = 'package.size',
  PackageType = 'package.type',
  PackageVersion = 'package.version',
  Process = 'process',
  ProcessArgs = 'process.args',
  ProcessArgsCount = 'process.args_count',
  ProcessCodeSignature = 'process.code_signature',
  ProcessCodeSignatureDigestAlgorithm = 'process.code_signature.digest_algorithm',
  ProcessCodeSignatureExists = 'process.code_signature.exists',
  ProcessCodeSignatureSigningId = 'process.code_signature.signing_id',
  ProcessCodeSignatureStatus = 'process.code_signature.status',
  ProcessCodeSignatureSubjectName = 'process.code_signature.subject_name',
  ProcessCodeSignatureTeamId = 'process.code_signature.team_id',
  ProcessCodeSignatureTimestamp = 'process.code_signature.timestamp',
  ProcessCodeSignatureTrusted = 'process.code_signature.trusted',
  ProcessCodeSignatureValid = 'process.code_signature.valid',
  ProcessCommandLine = 'process.command_line',
  ProcessElf = 'process.elf',
  ProcessElfArchitecture = 'process.elf.architecture',
  ProcessElfByteOrder = 'process.elf.byte_order',
  ProcessElfCpuType = 'process.elf.cpu_type',
  ProcessElfCreationDate = 'process.elf.creation_date',
  ProcessElfExports = 'process.elf.exports',
  ProcessElfGoImportHash = 'process.elf.go_import_hash',
  ProcessElfGoImports = 'process.elf.go_imports',
  ProcessElfGoImportsNamesEntropy = 'process.elf.go_imports_names_entropy',
  ProcessElfGoImportsNamesVarEntropy = 'process.elf.go_imports_names_var_entropy',
  ProcessElfGoStripped = 'process.elf.go_stripped',
  ProcessElfHeader = 'process.elf.header',
  ProcessElfHeaderAbiVersion = 'process.elf.header.abi_version',
  ProcessElfHeaderClass = 'process.elf.header.class',
  ProcessElfHeaderData = 'process.elf.header.data',
  ProcessElfHeaderEntrypoint = 'process.elf.header.entrypoint',
  ProcessElfHeaderObjectVersion = 'process.elf.header.object_version',
  ProcessElfHeaderOsAbi = 'process.elf.header.os_abi',
  ProcessElfHeaderType = 'process.elf.header.type',
  ProcessElfHeaderVersion = 'process.elf.header.version',
  ProcessElfImportHash = 'process.elf.import_hash',
  ProcessElfImports = 'process.elf.imports',
  ProcessElfImportsNamesEntropy = 'process.elf.imports_names_entropy',
  ProcessElfImportsNamesVarEntropy = 'process.elf.imports_names_var_entropy',
  ProcessElfSections = 'process.elf.sections',
  ProcessElfSectionsChi2 = 'process.elf.sections.chi2',
  ProcessElfSectionsEntropy = 'process.elf.sections.entropy',
  ProcessElfSectionsFlags = 'process.elf.sections.flags',
  ProcessElfSectionsName = 'process.elf.sections.name',
  ProcessElfSectionsPhysicalOffset = 'process.elf.sections.physical_offset',
  ProcessElfSectionsPhysicalSize = 'process.elf.sections.physical_size',
  ProcessElfSectionsType = 'process.elf.sections.type',
  ProcessElfSectionsVarEntropy = 'process.elf.sections.var_entropy',
  ProcessElfSectionsVirtualAddress = 'process.elf.sections.virtual_address',
  ProcessElfSectionsVirtualSize = 'process.elf.sections.virtual_size',
  ProcessElfSegments = 'process.elf.segments',
  ProcessElfSegmentsSections = 'process.elf.segments.sections',
  ProcessElfSegmentsType = 'process.elf.segments.type',
  ProcessElfSharedLibraries = 'process.elf.shared_libraries',
  ProcessElfTelfhash = 'process.elf.telfhash',
  ProcessEnd = 'process.end',
  ProcessEntityId = 'process.entity_id',
  ProcessEntryLeader = 'process.entry_leader',
  ProcessEntryLeaderArgs = 'process.entry_leader.args',
  ProcessEntryLeaderArgsCount = 'process.entry_leader.args_count',
  ProcessEntryLeaderAttestedGroups = 'process.entry_leader.attested_groups',
  ProcessEntryLeaderAttestedGroupsName = 'process.entry_leader.attested_groups.name',
  ProcessEntryLeaderAttestedUser = 'process.entry_leader.attested_user',
  ProcessEntryLeaderAttestedUserId = 'process.entry_leader.attested_user.id',
  ProcessEntryLeaderAttestedUserName = 'process.entry_leader.attested_user.name',
  ProcessEntryLeaderCommandLine = 'process.entry_leader.command_line',
  ProcessEntryLeaderEntityId = 'process.entry_leader.entity_id',
  ProcessEntryLeaderEntryMeta = 'process.entry_leader.entry_meta',
  ProcessEntryLeaderEntryMetaSource = 'process.entry_leader.entry_meta.source',
  ProcessEntryLeaderEntryMetaSourceIpv4 = 'process.entry_leader.entry_meta.source.ipv4',
  ProcessEntryLeaderEntryMetaSourceIpv6 = 'process.entry_leader.entry_meta.source.ipv6',
  ProcessEntryLeaderEntryMetaType = 'process.entry_leader.entry_meta.type',
  ProcessEntryLeaderExecutable = 'process.entry_leader.executable',
  ProcessEntryLeaderGroup = 'process.entry_leader.group',
  ProcessEntryLeaderGroupId = 'process.entry_leader.group.id',
  ProcessEntryLeaderGroupName = 'process.entry_leader.group.name',
  ProcessEntryLeaderInteractive = 'process.entry_leader.interactive',
  ProcessEntryLeaderName = 'process.entry_leader.name',
  ProcessEntryLeaderParent = 'process.entry_leader.parent',
  ProcessEntryLeaderParentEntityId = 'process.entry_leader.parent.entity_id',
  ProcessEntryLeaderParentPid = 'process.entry_leader.parent.pid',
  ProcessEntryLeaderParentSessionLeader = 'process.entry_leader.parent.session_leader',
  ProcessEntryLeaderParentSessionLeaderEntityId = 'process.entry_leader.parent.session_leader.entity_id',
  ProcessEntryLeaderParentSessionLeaderPid = 'process.entry_leader.parent.session_leader.pid',
  ProcessEntryLeaderParentSessionLeaderStart = 'process.entry_leader.parent.session_leader.start',
  ProcessEntryLeaderParentSessionLeaderVpid = 'process.entry_leader.parent.session_leader.vpid',
  ProcessEntryLeaderParentStart = 'process.entry_leader.parent.start',
  ProcessEntryLeaderParentVpid = 'process.entry_leader.parent.vpid',
  ProcessEntryLeaderPid = 'process.entry_leader.pid',
  ProcessEntryLeaderRealGroup = 'process.entry_leader.real_group',
  ProcessEntryLeaderRealGroupId = 'process.entry_leader.real_group.id',
  ProcessEntryLeaderRealGroupName = 'process.entry_leader.real_group.name',
  ProcessEntryLeaderRealUser = 'process.entry_leader.real_user',
  ProcessEntryLeaderRealUserId = 'process.entry_leader.real_user.id',
  ProcessEntryLeaderRealUserName = 'process.entry_leader.real_user.name',
  ProcessEntryLeaderSameAsProcess = 'process.entry_leader.same_as_process',
  ProcessEntryLeaderSavedGroup = 'process.entry_leader.saved_group',
  ProcessEntryLeaderSavedGroupId = 'process.entry_leader.saved_group.id',
  ProcessEntryLeaderSavedGroupName = 'process.entry_leader.saved_group.name',
  ProcessEntryLeaderSavedUser = 'process.entry_leader.saved_user',
  ProcessEntryLeaderSavedUserId = 'process.entry_leader.saved_user.id',
  ProcessEntryLeaderSavedUserName = 'process.entry_leader.saved_user.name',
  ProcessEntryLeaderStart = 'process.entry_leader.start',
  ProcessEntryLeaderSupplementalGroups = 'process.entry_leader.supplemental_groups',
  ProcessEntryLeaderSupplementalGroupsId = 'process.entry_leader.supplemental_groups.id',
  ProcessEntryLeaderSupplementalGroupsName = 'process.entry_leader.supplemental_groups.name',
  ProcessEntryLeaderTty = 'process.entry_leader.tty',
  ProcessEntryLeaderTtyCharDevice = 'process.entry_leader.tty.char_device',
  ProcessEntryLeaderTtyCharDeviceMajor = 'process.entry_leader.tty.char_device.major',
  ProcessEntryLeaderTtyCharDeviceMinor = 'process.entry_leader.tty.char_device.minor',
  ProcessEntryLeaderUser = 'process.entry_leader.user',
  ProcessEntryLeaderUserId = 'process.entry_leader.user.id',
  ProcessEntryLeaderUserName = 'process.entry_leader.user.name',
  ProcessEntryLeaderVpid = 'process.entry_leader.vpid',
  ProcessEntryLeaderWorkingDirectory = 'process.entry_leader.working_directory',
  ProcessEnvVars = 'process.env_vars',
  ProcessExecutable = 'process.executable',
  ProcessExitCode = 'process.exit_code',
  ProcessGroupLeader = 'process.group_leader',
  ProcessGroupLeaderArgs = 'process.group_leader.args',
  ProcessGroupLeaderArgsCount = 'process.group_leader.args_count',
  ProcessGroupLeaderCommandLine = 'process.group_leader.command_line',
  ProcessGroupLeaderEntityId = 'process.group_leader.entity_id',
  ProcessGroupLeaderExecutable = 'process.group_leader.executable',
  ProcessGroupLeaderGroup = 'process.group_leader.group',
  ProcessGroupLeaderGroupId = 'process.group_leader.group.id',
  ProcessGroupLeaderGroupName = 'process.group_leader.group.name',
  ProcessGroupLeaderInteractive = 'process.group_leader.interactive',
  ProcessGroupLeaderName = 'process.group_leader.name',
  ProcessGroupLeaderPid = 'process.group_leader.pid',
  ProcessGroupLeaderRealGroup = 'process.group_leader.real_group',
  ProcessGroupLeaderRealGroupId = 'process.group_leader.real_group.id',
  ProcessGroupLeaderRealGroupName = 'process.group_leader.real_group.name',
  ProcessGroupLeaderRealUser = 'process.group_leader.real_user',
  ProcessGroupLeaderRealUserId = 'process.group_leader.real_user.id',
  ProcessGroupLeaderRealUserName = 'process.group_leader.real_user.name',
  ProcessGroupLeaderSameAsProcess = 'process.group_leader.same_as_process',
  ProcessGroupLeaderSavedGroup = 'process.group_leader.saved_group',
  ProcessGroupLeaderSavedGroupId = 'process.group_leader.saved_group.id',
  ProcessGroupLeaderSavedGroupName = 'process.group_leader.saved_group.name',
  ProcessGroupLeaderSavedUser = 'process.group_leader.saved_user',
  ProcessGroupLeaderSavedUserId = 'process.group_leader.saved_user.id',
  ProcessGroupLeaderSavedUserName = 'process.group_leader.saved_user.name',
  ProcessGroupLeaderStart = 'process.group_leader.start',
  ProcessGroupLeaderSupplementalGroups = 'process.group_leader.supplemental_groups',
  ProcessGroupLeaderSupplementalGroupsId = 'process.group_leader.supplemental_groups.id',
  ProcessGroupLeaderSupplementalGroupsName = 'process.group_leader.supplemental_groups.name',
  ProcessGroupLeaderTty = 'process.group_leader.tty',
  ProcessGroupLeaderTtyCharDevice = 'process.group_leader.tty.char_device',
  ProcessGroupLeaderTtyCharDeviceMajor = 'process.group_leader.tty.char_device.major',
  ProcessGroupLeaderTtyCharDeviceMinor = 'process.group_leader.tty.char_device.minor',
  ProcessGroupLeaderUser = 'process.group_leader.user',
  ProcessGroupLeaderUserId = 'process.group_leader.user.id',
  ProcessGroupLeaderUserName = 'process.group_leader.user.name',
  ProcessGroupLeaderVpid = 'process.group_leader.vpid',
  ProcessGroupLeaderWorkingDirectory = 'process.group_leader.working_directory',
  ProcessHash = 'process.hash',
  ProcessHashMd5 = 'process.hash.md5',
  ProcessHashSha1 = 'process.hash.sha1',
  ProcessHashSha256 = 'process.hash.sha256',
  ProcessHashSha384 = 'process.hash.sha384',
  ProcessHashSha512 = 'process.hash.sha512',
  ProcessHashSsdeep = 'process.hash.ssdeep',
  ProcessHashTlsh = 'process.hash.tlsh',
  ProcessInteractive = 'process.interactive',
  ProcessIo = 'process.io',
  ProcessIoBytesSkipped = 'process.io.bytes_skipped',
  ProcessIoBytesSkippedLength = 'process.io.bytes_skipped.length',
  ProcessIoBytesSkippedOffset = 'process.io.bytes_skipped.offset',
  ProcessIoMaxBytesPerProcessExceeded = 'process.io.max_bytes_per_process_exceeded',
  ProcessIoText = 'process.io.text',
  ProcessIoTotalBytesCaptured = 'process.io.total_bytes_captured',
  ProcessIoTotalBytesSkipped = 'process.io.total_bytes_skipped',
  ProcessIoType = 'process.io.type',
  ProcessMacho = 'process.macho',
  ProcessMachoGoImportHash = 'process.macho.go_import_hash',
  ProcessMachoGoImports = 'process.macho.go_imports',
  ProcessMachoGoImportsNamesEntropy = 'process.macho.go_imports_names_entropy',
  ProcessMachoGoImportsNamesVarEntropy = 'process.macho.go_imports_names_var_entropy',
  ProcessMachoGoStripped = 'process.macho.go_stripped',
  ProcessMachoImportHash = 'process.macho.import_hash',
  ProcessMachoImports = 'process.macho.imports',
  ProcessMachoImportsNamesEntropy = 'process.macho.imports_names_entropy',
  ProcessMachoImportsNamesVarEntropy = 'process.macho.imports_names_var_entropy',
  ProcessMachoSections = 'process.macho.sections',
  ProcessMachoSectionsEntropy = 'process.macho.sections.entropy',
  ProcessMachoSectionsName = 'process.macho.sections.name',
  ProcessMachoSectionsPhysicalSize = 'process.macho.sections.physical_size',
  ProcessMachoSectionsVarEntropy = 'process.macho.sections.var_entropy',
  ProcessMachoSectionsVirtualSize = 'process.macho.sections.virtual_size',
  ProcessMachoSymhash = 'process.macho.symhash',
  ProcessName = 'process.name',
  ProcessParent = 'process.parent',
  ProcessParentArgs = 'process.parent.args',
  ProcessParentArgsCount = 'process.parent.args_count',
  ProcessParentCodeSignature = 'process.parent.code_signature',
  ProcessParentCodeSignatureDigestAlgorithm = 'process.parent.code_signature.digest_algorithm',
  ProcessParentCodeSignatureExists = 'process.parent.code_signature.exists',
  ProcessParentCodeSignatureSigningId = 'process.parent.code_signature.signing_id',
  ProcessParentCodeSignatureStatus = 'process.parent.code_signature.status',
  ProcessParentCodeSignatureSubjectName = 'process.parent.code_signature.subject_name',
  ProcessParentCodeSignatureTeamId = 'process.parent.code_signature.team_id',
  ProcessParentCodeSignatureTimestamp = 'process.parent.code_signature.timestamp',
  ProcessParentCodeSignatureTrusted = 'process.parent.code_signature.trusted',
  ProcessParentCodeSignatureValid = 'process.parent.code_signature.valid',
  ProcessParentCommandLine = 'process.parent.command_line',
  ProcessParentElf = 'process.parent.elf',
  ProcessParentElfArchitecture = 'process.parent.elf.architecture',
  ProcessParentElfByteOrder = 'process.parent.elf.byte_order',
  ProcessParentElfCpuType = 'process.parent.elf.cpu_type',
  ProcessParentElfCreationDate = 'process.parent.elf.creation_date',
  ProcessParentElfExports = 'process.parent.elf.exports',
  ProcessParentElfGoImportHash = 'process.parent.elf.go_import_hash',
  ProcessParentElfGoImports = 'process.parent.elf.go_imports',
  ProcessParentElfGoImportsNamesEntropy = 'process.parent.elf.go_imports_names_entropy',
  ProcessParentElfGoImportsNamesVarEntropy = 'process.parent.elf.go_imports_names_var_entropy',
  ProcessParentElfGoStripped = 'process.parent.elf.go_stripped',
  ProcessParentElfHeader = 'process.parent.elf.header',
  ProcessParentElfHeaderAbiVersion = 'process.parent.elf.header.abi_version',
  ProcessParentElfHeaderClass = 'process.parent.elf.header.class',
  ProcessParentElfHeaderData = 'process.parent.elf.header.data',
  ProcessParentElfHeaderEntrypoint = 'process.parent.elf.header.entrypoint',
  ProcessParentElfHeaderObjectVersion = 'process.parent.elf.header.object_version',
  ProcessParentElfHeaderOsAbi = 'process.parent.elf.header.os_abi',
  ProcessParentElfHeaderType = 'process.parent.elf.header.type',
  ProcessParentElfHeaderVersion = 'process.parent.elf.header.version',
  ProcessParentElfImportHash = 'process.parent.elf.import_hash',
  ProcessParentElfImports = 'process.parent.elf.imports',
  ProcessParentElfImportsNamesEntropy = 'process.parent.elf.imports_names_entropy',
  ProcessParentElfImportsNamesVarEntropy = 'process.parent.elf.imports_names_var_entropy',
  ProcessParentElfSections = 'process.parent.elf.sections',
  ProcessParentElfSectionsChi2 = 'process.parent.elf.sections.chi2',
  ProcessParentElfSectionsEntropy = 'process.parent.elf.sections.entropy',
  ProcessParentElfSectionsFlags = 'process.parent.elf.sections.flags',
  ProcessParentElfSectionsName = 'process.parent.elf.sections.name',
  ProcessParentElfSectionsPhysicalOffset = 'process.parent.elf.sections.physical_offset',
  ProcessParentElfSectionsPhysicalSize = 'process.parent.elf.sections.physical_size',
  ProcessParentElfSectionsType = 'process.parent.elf.sections.type',
  ProcessParentElfSectionsVarEntropy = 'process.parent.elf.sections.var_entropy',
  ProcessParentElfSectionsVirtualAddress = 'process.parent.elf.sections.virtual_address',
  ProcessParentElfSectionsVirtualSize = 'process.parent.elf.sections.virtual_size',
  ProcessParentElfSegments = 'process.parent.elf.segments',
  ProcessParentElfSegmentsSections = 'process.parent.elf.segments.sections',
  ProcessParentElfSegmentsType = 'process.parent.elf.segments.type',
  ProcessParentElfSharedLibraries = 'process.parent.elf.shared_libraries',
  ProcessParentElfTelfhash = 'process.parent.elf.telfhash',
  ProcessParentEnd = 'process.parent.end',
  ProcessParentEntityId = 'process.parent.entity_id',
  ProcessParentExecutable = 'process.parent.executable',
  ProcessParentExitCode = 'process.parent.exit_code',
  ProcessParentGroup = 'process.parent.group',
  ProcessParentGroupId = 'process.parent.group.id',
  ProcessParentGroupName = 'process.parent.group.name',
  ProcessParentGroupLeader = 'process.parent.group_leader',
  ProcessParentGroupLeaderEntityId = 'process.parent.group_leader.entity_id',
  ProcessParentGroupLeaderPid = 'process.parent.group_leader.pid',
  ProcessParentGroupLeaderStart = 'process.parent.group_leader.start',
  ProcessParentGroupLeaderVpid = 'process.parent.group_leader.vpid',
  ProcessParentHash = 'process.parent.hash',
  ProcessParentHashMd5 = 'process.parent.hash.md5',
  ProcessParentHashSha1 = 'process.parent.hash.sha1',
  ProcessParentHashSha256 = 'process.parent.hash.sha256',
  ProcessParentHashSha384 = 'process.parent.hash.sha384',
  ProcessParentHashSha512 = 'process.parent.hash.sha512',
  ProcessParentHashSsdeep = 'process.parent.hash.ssdeep',
  ProcessParentHashTlsh = 'process.parent.hash.tlsh',
  ProcessParentInteractive = 'process.parent.interactive',
  ProcessParentMacho = 'process.parent.macho',
  ProcessParentMachoGoImportHash = 'process.parent.macho.go_import_hash',
  ProcessParentMachoGoImports = 'process.parent.macho.go_imports',
  ProcessParentMachoGoImportsNamesEntropy = 'process.parent.macho.go_imports_names_entropy',
  ProcessParentMachoGoImportsNamesVarEntropy = 'process.parent.macho.go_imports_names_var_entropy',
  ProcessParentMachoGoStripped = 'process.parent.macho.go_stripped',
  ProcessParentMachoImportHash = 'process.parent.macho.import_hash',
  ProcessParentMachoImports = 'process.parent.macho.imports',
  ProcessParentMachoImportsNamesEntropy = 'process.parent.macho.imports_names_entropy',
  ProcessParentMachoImportsNamesVarEntropy = 'process.parent.macho.imports_names_var_entropy',
  ProcessParentMachoSections = 'process.parent.macho.sections',
  ProcessParentMachoSectionsEntropy = 'process.parent.macho.sections.entropy',
  ProcessParentMachoSectionsName = 'process.parent.macho.sections.name',
  ProcessParentMachoSectionsPhysicalSize = 'process.parent.macho.sections.physical_size',
  ProcessParentMachoSectionsVarEntropy = 'process.parent.macho.sections.var_entropy',
  ProcessParentMachoSectionsVirtualSize = 'process.parent.macho.sections.virtual_size',
  ProcessParentMachoSymhash = 'process.parent.macho.symhash',
  ProcessParentName = 'process.parent.name',
  ProcessParentPe = 'process.parent.pe',
  ProcessParentPeArchitecture = 'process.parent.pe.architecture',
  ProcessParentPeCompany = 'process.parent.pe.company',
  ProcessParentPeDescription = 'process.parent.pe.description',
  ProcessParentPeFileVersion = 'process.parent.pe.file_version',
  ProcessParentPeGoImportHash = 'process.parent.pe.go_import_hash',
  ProcessParentPeGoImports = 'process.parent.pe.go_imports',
  ProcessParentPeGoImportsNamesEntropy = 'process.parent.pe.go_imports_names_entropy',
  ProcessParentPeGoImportsNamesVarEntropy = 'process.parent.pe.go_imports_names_var_entropy',
  ProcessParentPeGoStripped = 'process.parent.pe.go_stripped',
  ProcessParentPeImphash = 'process.parent.pe.imphash',
  ProcessParentPeImportHash = 'process.parent.pe.import_hash',
  ProcessParentPeImports = 'process.parent.pe.imports',
  ProcessParentPeImportsNamesEntropy = 'process.parent.pe.imports_names_entropy',
  ProcessParentPeImportsNamesVarEntropy = 'process.parent.pe.imports_names_var_entropy',
  ProcessParentPeOriginalFileName = 'process.parent.pe.original_file_name',
  ProcessParentPePehash = 'process.parent.pe.pehash',
  ProcessParentPeProduct = 'process.parent.pe.product',
  ProcessParentPeSections = 'process.parent.pe.sections',
  ProcessParentPeSectionsEntropy = 'process.parent.pe.sections.entropy',
  ProcessParentPeSectionsName = 'process.parent.pe.sections.name',
  ProcessParentPeSectionsPhysicalSize = 'process.parent.pe.sections.physical_size',
  ProcessParentPeSectionsVarEntropy = 'process.parent.pe.sections.var_entropy',
  ProcessParentPeSectionsVirtualSize = 'process.parent.pe.sections.virtual_size',
  ProcessParentPgid = 'process.parent.pgid',
  ProcessParentPid = 'process.parent.pid',
  ProcessParentRealGroup = 'process.parent.real_group',
  ProcessParentRealGroupId = 'process.parent.real_group.id',
  ProcessParentRealGroupName = 'process.parent.real_group.name',
  ProcessParentRealUser = 'process.parent.real_user',
  ProcessParentRealUserId = 'process.parent.real_user.id',
  ProcessParentRealUserName = 'process.parent.real_user.name',
  ProcessParentSavedGroup = 'process.parent.saved_group',
  ProcessParentSavedGroupId = 'process.parent.saved_group.id',
  ProcessParentSavedGroupName = 'process.parent.saved_group.name',
  ProcessParentSavedUser = 'process.parent.saved_user',
  ProcessParentSavedUserId = 'process.parent.saved_user.id',
  ProcessParentSavedUserName = 'process.parent.saved_user.name',
  ProcessParentStart = 'process.parent.start',
  ProcessParentSupplementalGroups = 'process.parent.supplemental_groups',
  ProcessParentSupplementalGroupsId = 'process.parent.supplemental_groups.id',
  ProcessParentSupplementalGroupsName = 'process.parent.supplemental_groups.name',
  ProcessParentThread = 'process.parent.thread',
  ProcessParentThreadId = 'process.parent.thread.id',
  ProcessParentThreadName = 'process.parent.thread.name',
  ProcessParentTitle = 'process.parent.title',
  ProcessParentTty = 'process.parent.tty',
  ProcessParentTtyCharDevice = 'process.parent.tty.char_device',
  ProcessParentTtyCharDeviceMajor = 'process.parent.tty.char_device.major',
  ProcessParentTtyCharDeviceMinor = 'process.parent.tty.char_device.minor',
  ProcessParentUptime = 'process.parent.uptime',
  ProcessParentUser = 'process.parent.user',
  ProcessParentUserId = 'process.parent.user.id',
  ProcessParentUserName = 'process.parent.user.name',
  ProcessParentVpid = 'process.parent.vpid',
  ProcessParentWorkingDirectory = 'process.parent.working_directory',
  ProcessPe = 'process.pe',
  ProcessPeArchitecture = 'process.pe.architecture',
  ProcessPeCompany = 'process.pe.company',
  ProcessPeDescription = 'process.pe.description',
  ProcessPeFileVersion = 'process.pe.file_version',
  ProcessPeGoImportHash = 'process.pe.go_import_hash',
  ProcessPeGoImports = 'process.pe.go_imports',
  ProcessPeGoImportsNamesEntropy = 'process.pe.go_imports_names_entropy',
  ProcessPeGoImportsNamesVarEntropy = 'process.pe.go_imports_names_var_entropy',
  ProcessPeGoStripped = 'process.pe.go_stripped',
  ProcessPeImphash = 'process.pe.imphash',
  ProcessPeImportHash = 'process.pe.import_hash',
  ProcessPeImports = 'process.pe.imports',
  ProcessPeImportsNamesEntropy = 'process.pe.imports_names_entropy',
  ProcessPeImportsNamesVarEntropy = 'process.pe.imports_names_var_entropy',
  ProcessPeOriginalFileName = 'process.pe.original_file_name',
  ProcessPePehash = 'process.pe.pehash',
  ProcessPeProduct = 'process.pe.product',
  ProcessPeSections = 'process.pe.sections',
  ProcessPeSectionsEntropy = 'process.pe.sections.entropy',
  ProcessPeSectionsName = 'process.pe.sections.name',
  ProcessPeSectionsPhysicalSize = 'process.pe.sections.physical_size',
  ProcessPeSectionsVarEntropy = 'process.pe.sections.var_entropy',
  ProcessPeSectionsVirtualSize = 'process.pe.sections.virtual_size',
  ProcessPgid = 'process.pgid',
  ProcessPid = 'process.pid',
  ProcessPrevious = 'process.previous',
  ProcessPreviousArgs = 'process.previous.args',
  ProcessPreviousArgsCount = 'process.previous.args_count',
  ProcessPreviousExecutable = 'process.previous.executable',
  ProcessRealGroup = 'process.real_group',
  ProcessRealGroupId = 'process.real_group.id',
  ProcessRealGroupName = 'process.real_group.name',
  ProcessRealUser = 'process.real_user',
  ProcessRealUserId = 'process.real_user.id',
  ProcessRealUserName = 'process.real_user.name',
  ProcessSavedGroup = 'process.saved_group',
  ProcessSavedGroupId = 'process.saved_group.id',
  ProcessSavedGroupName = 'process.saved_group.name',
  ProcessSavedUser = 'process.saved_user',
  ProcessSavedUserId = 'process.saved_user.id',
  ProcessSavedUserName = 'process.saved_user.name',
  ProcessSessionLeader = 'process.session_leader',
  ProcessSessionLeaderArgs = 'process.session_leader.args',
  ProcessSessionLeaderArgsCount = 'process.session_leader.args_count',
  ProcessSessionLeaderCommandLine = 'process.session_leader.command_line',
  ProcessSessionLeaderEntityId = 'process.session_leader.entity_id',
  ProcessSessionLeaderExecutable = 'process.session_leader.executable',
  ProcessSessionLeaderGroup = 'process.session_leader.group',
  ProcessSessionLeaderGroupId = 'process.session_leader.group.id',
  ProcessSessionLeaderGroupName = 'process.session_leader.group.name',
  ProcessSessionLeaderInteractive = 'process.session_leader.interactive',
  ProcessSessionLeaderName = 'process.session_leader.name',
  ProcessSessionLeaderParent = 'process.session_leader.parent',
  ProcessSessionLeaderParentEntityId = 'process.session_leader.parent.entity_id',
  ProcessSessionLeaderParentPid = 'process.session_leader.parent.pid',
  ProcessSessionLeaderParentSessionLeader = 'process.session_leader.parent.session_leader',
  ProcessSessionLeaderParentSessionLeaderEntityId = 'process.session_leader.parent.session_leader.entity_id',
  ProcessSessionLeaderParentSessionLeaderPid = 'process.session_leader.parent.session_leader.pid',
  ProcessSessionLeaderParentSessionLeaderStart = 'process.session_leader.parent.session_leader.start',
  ProcessSessionLeaderParentSessionLeaderVpid = 'process.session_leader.parent.session_leader.vpid',
  ProcessSessionLeaderParentStart = 'process.session_leader.parent.start',
  ProcessSessionLeaderParentVpid = 'process.session_leader.parent.vpid',
  ProcessSessionLeaderPid = 'process.session_leader.pid',
  ProcessSessionLeaderRealGroup = 'process.session_leader.real_group',
  ProcessSessionLeaderRealGroupId = 'process.session_leader.real_group.id',
  ProcessSessionLeaderRealGroupName = 'process.session_leader.real_group.name',
  ProcessSessionLeaderRealUser = 'process.session_leader.real_user',
  ProcessSessionLeaderRealUserId = 'process.session_leader.real_user.id',
  ProcessSessionLeaderRealUserName = 'process.session_leader.real_user.name',
  ProcessSessionLeaderSameAsProcess = 'process.session_leader.same_as_process',
  ProcessSessionLeaderSavedGroup = 'process.session_leader.saved_group',
  ProcessSessionLeaderSavedGroupId = 'process.session_leader.saved_group.id',
  ProcessSessionLeaderSavedGroupName = 'process.session_leader.saved_group.name',
  ProcessSessionLeaderSavedUser = 'process.session_leader.saved_user',
  ProcessSessionLeaderSavedUserId = 'process.session_leader.saved_user.id',
  ProcessSessionLeaderSavedUserName = 'process.session_leader.saved_user.name',
  ProcessSessionLeaderStart = 'process.session_leader.start',
  ProcessSessionLeaderSupplementalGroups = 'process.session_leader.supplemental_groups',
  ProcessSessionLeaderSupplementalGroupsId = 'process.session_leader.supplemental_groups.id',
  ProcessSessionLeaderSupplementalGroupsName = 'process.session_leader.supplemental_groups.name',
  ProcessSessionLeaderTty = 'process.session_leader.tty',
  ProcessSessionLeaderTtyCharDevice = 'process.session_leader.tty.char_device',
  ProcessSessionLeaderTtyCharDeviceMajor = 'process.session_leader.tty.char_device.major',
  ProcessSessionLeaderTtyCharDeviceMinor = 'process.session_leader.tty.char_device.minor',
  ProcessSessionLeaderUser = 'process.session_leader.user',
  ProcessSessionLeaderUserId = 'process.session_leader.user.id',
  ProcessSessionLeaderUserName = 'process.session_leader.user.name',
  ProcessSessionLeaderVpid = 'process.session_leader.vpid',
  ProcessSessionLeaderWorkingDirectory = 'process.session_leader.working_directory',
  ProcessStart = 'process.start',
  ProcessSupplementalGroups = 'process.supplemental_groups',
  ProcessSupplementalGroupsId = 'process.supplemental_groups.id',
  ProcessSupplementalGroupsName = 'process.supplemental_groups.name',
  ProcessThread = 'process.thread',
  ProcessThreadId = 'process.thread.id',
  ProcessThreadName = 'process.thread.name',
  ProcessTitle = 'process.title',
  ProcessTty = 'process.tty',
  ProcessTtyCharDevice = 'process.tty.char_device',
  ProcessTtyCharDeviceMajor = 'process.tty.char_device.major',
  ProcessTtyCharDeviceMinor = 'process.tty.char_device.minor',
  ProcessTtyColumns = 'process.tty.columns',
  ProcessTtyRows = 'process.tty.rows',
  ProcessUptime = 'process.uptime',
  ProcessUser = 'process.user',
  ProcessUserId = 'process.user.id',
  ProcessUserName = 'process.user.name',
  ProcessVpid = 'process.vpid',
  ProcessWorkingDirectory = 'process.working_directory',
  Registry = 'registry',
  RegistryData = 'registry.data',
  RegistryDataBytes = 'registry.data.bytes',
  RegistryDataStrings = 'registry.data.strings',
  RegistryDataType = 'registry.data.type',
  RegistryHive = 'registry.hive',
  RegistryKey = 'registry.key',
  RegistryPath = 'registry.path',
  RegistryValue = 'registry.value',
  Related = 'related',
  RelatedHash = 'related.hash',
  RelatedHosts = 'related.hosts',
  RelatedIpv4 = 'related.ipv4',
  RelatedIpv6 = 'related.ipv6',
  RelatedUser = 'related.user',
  Rule = 'rule',
  RuleAuthor = 'rule.author',
  RuleCategory = 'rule.category',
  RuleDescription = 'rule.description',
  RuleId = 'rule.id',
  RuleLicense = 'rule.license',
  RuleName = 'rule.name',
  RuleReference = 'rule.reference',
  RuleRuleset = 'rule.ruleset',
  RuleUuid = 'rule.uuid',
  RuleVersion = 'rule.version',
  Service = 'service',
  ServiceAddress = 'service.address',
  ServiceEnvironment = 'service.environment',
  ServiceEphemeralId = 'service.ephemeral_id',
  ServiceId = 'service.id',
  ServiceName = 'service.name',
  ServiceNode = 'service.node',
  ServiceNodeName = 'service.node.name',
  ServiceNodeRole = 'service.node.role',
  ServiceNodeRoles = 'service.node.roles',
  ServiceOrigin = 'service.origin',
  ServiceOriginAddress = 'service.origin.address',
  ServiceOriginEnvironment = 'service.origin.environment',
  ServiceOriginEphemeralId = 'service.origin.ephemeral_id',
  ServiceOriginId = 'service.origin.id',
  ServiceOriginName = 'service.origin.name',
  ServiceOriginNode = 'service.origin.node',
  ServiceOriginNodeName = 'service.origin.node.name',
  ServiceOriginNodeRole = 'service.origin.node.role',
  ServiceOriginNodeRoles = 'service.origin.node.roles',
  ServiceOriginState = 'service.origin.state',
  ServiceOriginType = 'service.origin.type',
  ServiceOriginVersion = 'service.origin.version',
  ServiceState = 'service.state',
  ServiceTarget = 'service.target',
  ServiceTargetAddress = 'service.target.address',
  ServiceTargetEnvironment = 'service.target.environment',
  ServiceTargetEphemeralId = 'service.target.ephemeral_id',
  ServiceTargetId = 'service.target.id',
  ServiceTargetName = 'service.target.name',
  ServiceTargetNode = 'service.target.node',
  ServiceTargetNodeName = 'service.target.node.name',
  ServiceTargetNodeRole = 'service.target.node.role',
  ServiceTargetNodeRoles = 'service.target.node.roles',
  ServiceTargetState = 'service.target.state',
  ServiceTargetType = 'service.target.type',
  ServiceTargetVersion = 'service.target.version',
  ServiceType = 'service.type',
  ServiceVersion = 'service.version',
  Source = 'source',
  SourceAddress = 'source.address',
  SourceAs = 'source.as',
  SourceAsNumber = 'source.as.number',
  SourceAsOrganization = 'source.as.organization',
  SourceAsOrganizationName = 'source.as.organization.name',
  SourceBytes = 'source.bytes',
  SourceDomain = 'source.domain',
  SourceGeo = 'source.geo',
  SourceGeoCityName = 'source.geo.city_name',
  SourceGeoContinentCode = 'source.geo.continent_code',
  SourceGeoContinentName = 'source.geo.continent_name',
  SourceGeoCountryIsoCode = 'source.geo.country_iso_code',
  SourceGeoCountryName = 'source.geo.country_name',
  SourceGeoLocation = 'source.geo.location',
  SourceGeoName = 'source.geo.name',
  SourceGeoPostalCode = 'source.geo.postal_code',
  SourceGeoRegionIsoCode = 'source.geo.region_iso_code',
  SourceGeoRegionName = 'source.geo.region_name',
  SourceGeoTimezone = 'source.geo.timezone',
  SourceIpv4 = 'source.ipv4',
  SourceIpv6 = 'source.ipv6',
  SourceMac = 'source.mac',
  SourceNat = 'source.nat',
  SourceNatIpv4 = 'source.nat.ipv4',
  SourceNatIpv6 = 'source.nat.ipv6',
  SourceNatPort = 'source.nat.port',
  SourcePackets = 'source.packets',
  SourcePort = 'source.port',
  SourceRegisteredDomain = 'source.registered_domain',
  SourceSubdomain = 'source.subdomain',
  SourceTopLevelDomain = 'source.top_level_domain',
  SourceUser = 'source.user',
  SourceUserDomain = 'source.user.domain',
  SourceUserEmail = 'source.user.email',
  SourceUserFullName = 'source.user.full_name',
  SourceUserGroup = 'source.user.group',
  SourceUserGroupDomain = 'source.user.group.domain',
  SourceUserGroupId = 'source.user.group.id',
  SourceUserGroupName = 'source.user.group.name',
  SourceUserHash = 'source.user.hash',
  SourceUserId = 'source.user.id',
  SourceUserName = 'source.user.name',
  SourceUserRoles = 'source.user.roles',
  Span = 'span',
  SpanId = 'span.id',
  Threat = 'threat',
  ThreatEnrichments = 'threat.enrichments',
  ThreatEnrichmentsIndicator = 'threat.enrichments.indicator',
  ThreatEnrichmentsIndicatorAs = 'threat.enrichments.indicator.as',
  ThreatEnrichmentsIndicatorAsNumber = 'threat.enrichments.indicator.as.number',
  ThreatEnrichmentsIndicatorAsOrganization = 'threat.enrichments.indicator.as.organization',
  ThreatEnrichmentsIndicatorAsOrganizationName = 'threat.enrichments.indicator.as.organization.name',
  ThreatEnrichmentsIndicatorConfidence = 'threat.enrichments.indicator.confidence',
  ThreatEnrichmentsIndicatorDescription = 'threat.enrichments.indicator.description',
  ThreatEnrichmentsIndicatorEmail = 'threat.enrichments.indicator.email',
  ThreatEnrichmentsIndicatorEmailAddress = 'threat.enrichments.indicator.email.address',
  ThreatEnrichmentsIndicatorFile = 'threat.enrichments.indicator.file',
  ThreatEnrichmentsIndicatorFileAccessed = 'threat.enrichments.indicator.file.accessed',
  ThreatEnrichmentsIndicatorFileAttributes = 'threat.enrichments.indicator.file.attributes',
  ThreatEnrichmentsIndicatorFileCodeSignature = 'threat.enrichments.indicator.file.code_signature',
  ThreatEnrichmentsIndicatorFileCodeSignatureDigestAlgorithm = 'threat.enrichments.indicator.file.code_signature.digest_algorithm',
  ThreatEnrichmentsIndicatorFileCodeSignatureExists = 'threat.enrichments.indicator.file.code_signature.exists',
  ThreatEnrichmentsIndicatorFileCodeSignatureSigningId = 'threat.enrichments.indicator.file.code_signature.signing_id',
  ThreatEnrichmentsIndicatorFileCodeSignatureStatus = 'threat.enrichments.indicator.file.code_signature.status',
  ThreatEnrichmentsIndicatorFileCodeSignatureSubjectName = 'threat.enrichments.indicator.file.code_signature.subject_name',
  ThreatEnrichmentsIndicatorFileCodeSignatureTeamId = 'threat.enrichments.indicator.file.code_signature.team_id',
  ThreatEnrichmentsIndicatorFileCodeSignatureTimestamp = 'threat.enrichments.indicator.file.code_signature.timestamp',
  ThreatEnrichmentsIndicatorFileCodeSignatureTrusted = 'threat.enrichments.indicator.file.code_signature.trusted',
  ThreatEnrichmentsIndicatorFileCodeSignatureValid = 'threat.enrichments.indicator.file.code_signature.valid',
  ThreatEnrichmentsIndicatorFileCreated = 'threat.enrichments.indicator.file.created',
  ThreatEnrichmentsIndicatorFileCtime = 'threat.enrichments.indicator.file.ctime',
  ThreatEnrichmentsIndicatorFileDevice = 'threat.enrichments.indicator.file.device',
  ThreatEnrichmentsIndicatorFileDirectory = 'threat.enrichments.indicator.file.directory',
  ThreatEnrichmentsIndicatorFileDriveLetter = 'threat.enrichments.indicator.file.drive_letter',
  ThreatEnrichmentsIndicatorFileElf = 'threat.enrichments.indicator.file.elf',
  ThreatEnrichmentsIndicatorFileElfArchitecture = 'threat.enrichments.indicator.file.elf.architecture',
  ThreatEnrichmentsIndicatorFileElfByteOrder = 'threat.enrichments.indicator.file.elf.byte_order',
  ThreatEnrichmentsIndicatorFileElfCpuType = 'threat.enrichments.indicator.file.elf.cpu_type',
  ThreatEnrichmentsIndicatorFileElfCreationDate = 'threat.enrichments.indicator.file.elf.creation_date',
  ThreatEnrichmentsIndicatorFileElfExports = 'threat.enrichments.indicator.file.elf.exports',
  ThreatEnrichmentsIndicatorFileElfGoImportHash = 'threat.enrichments.indicator.file.elf.go_import_hash',
  ThreatEnrichmentsIndicatorFileElfGoImports = 'threat.enrichments.indicator.file.elf.go_imports',
  ThreatEnrichmentsIndicatorFileElfGoImportsNamesEntropy = 'threat.enrichments.indicator.file.elf.go_imports_names_entropy',
  ThreatEnrichmentsIndicatorFileElfGoImportsNamesVarEntropy = 'threat.enrichments.indicator.file.elf.go_imports_names_var_entropy',
  ThreatEnrichmentsIndicatorFileElfGoStripped = 'threat.enrichments.indicator.file.elf.go_stripped',
  ThreatEnrichmentsIndicatorFileElfHeader = 'threat.enrichments.indicator.file.elf.header',
  ThreatEnrichmentsIndicatorFileElfHeaderAbiVersion = 'threat.enrichments.indicator.file.elf.header.abi_version',
  ThreatEnrichmentsIndicatorFileElfHeaderClass = 'threat.enrichments.indicator.file.elf.header.class',
  ThreatEnrichmentsIndicatorFileElfHeaderData = 'threat.enrichments.indicator.file.elf.header.data',
  ThreatEnrichmentsIndicatorFileElfHeaderEntrypoint = 'threat.enrichments.indicator.file.elf.header.entrypoint',
  ThreatEnrichmentsIndicatorFileElfHeaderObjectVersion = 'threat.enrichments.indicator.file.elf.header.object_version',
  ThreatEnrichmentsIndicatorFileElfHeaderOsAbi = 'threat.enrichments.indicator.file.elf.header.os_abi',
  ThreatEnrichmentsIndicatorFileElfHeaderType = 'threat.enrichments.indicator.file.elf.header.type',
  ThreatEnrichmentsIndicatorFileElfHeaderVersion = 'threat.enrichments.indicator.file.elf.header.version',
  ThreatEnrichmentsIndicatorFileElfImportHash = 'threat.enrichments.indicator.file.elf.import_hash',
  ThreatEnrichmentsIndicatorFileElfImports = 'threat.enrichments.indicator.file.elf.imports',
  ThreatEnrichmentsIndicatorFileElfImportsNamesEntropy = 'threat.enrichments.indicator.file.elf.imports_names_entropy',
  ThreatEnrichmentsIndicatorFileElfImportsNamesVarEntropy = 'threat.enrichments.indicator.file.elf.imports_names_var_entropy',
  ThreatEnrichmentsIndicatorFileElfSections = 'threat.enrichments.indicator.file.elf.sections',
  ThreatEnrichmentsIndicatorFileElfSectionsChi2 = 'threat.enrichments.indicator.file.elf.sections.chi2',
  ThreatEnrichmentsIndicatorFileElfSectionsEntropy = 'threat.enrichments.indicator.file.elf.sections.entropy',
  ThreatEnrichmentsIndicatorFileElfSectionsFlags = 'threat.enrichments.indicator.file.elf.sections.flags',
  ThreatEnrichmentsIndicatorFileElfSectionsName = 'threat.enrichments.indicator.file.elf.sections.name',
  ThreatEnrichmentsIndicatorFileElfSectionsPhysicalOffset = 'threat.enrichments.indicator.file.elf.sections.physical_offset',
  ThreatEnrichmentsIndicatorFileElfSectionsPhysicalSize = 'threat.enrichments.indicator.file.elf.sections.physical_size',
  ThreatEnrichmentsIndicatorFileElfSectionsType = 'threat.enrichments.indicator.file.elf.sections.type',
  ThreatEnrichmentsIndicatorFileElfSectionsVarEntropy = 'threat.enrichments.indicator.file.elf.sections.var_entropy',
  ThreatEnrichmentsIndicatorFileElfSectionsVirtualAddress = 'threat.enrichments.indicator.file.elf.sections.virtual_address',
  ThreatEnrichmentsIndicatorFileElfSectionsVirtualSize = 'threat.enrichments.indicator.file.elf.sections.virtual_size',
  ThreatEnrichmentsIndicatorFileElfSegments = 'threat.enrichments.indicator.file.elf.segments',
  ThreatEnrichmentsIndicatorFileElfSegmentsSections = 'threat.enrichments.indicator.file.elf.segments.sections',
  ThreatEnrichmentsIndicatorFileElfSegmentsType = 'threat.enrichments.indicator.file.elf.segments.type',
  ThreatEnrichmentsIndicatorFileElfSharedLibraries = 'threat.enrichments.indicator.file.elf.shared_libraries',
  ThreatEnrichmentsIndicatorFileElfTelfhash = 'threat.enrichments.indicator.file.elf.telfhash',
  ThreatEnrichmentsIndicatorFileExtension = 'threat.enrichments.indicator.file.extension',
  ThreatEnrichmentsIndicatorFileForkName = 'threat.enrichments.indicator.file.fork_name',
  ThreatEnrichmentsIndicatorFileGid = 'threat.enrichments.indicator.file.gid',
  ThreatEnrichmentsIndicatorFileGroup = 'threat.enrichments.indicator.file.group',
  ThreatEnrichmentsIndicatorFileHash = 'threat.enrichments.indicator.file.hash',
  ThreatEnrichmentsIndicatorFileHashMd5 = 'threat.enrichments.indicator.file.hash.md5',
  ThreatEnrichmentsIndicatorFileHashSha1 = 'threat.enrichments.indicator.file.hash.sha1',
  ThreatEnrichmentsIndicatorFileHashSha256 = 'threat.enrichments.indicator.file.hash.sha256',
  ThreatEnrichmentsIndicatorFileHashSha384 = 'threat.enrichments.indicator.file.hash.sha384',
  ThreatEnrichmentsIndicatorFileHashSha512 = 'threat.enrichments.indicator.file.hash.sha512',
  ThreatEnrichmentsIndicatorFileHashSsdeep = 'threat.enrichments.indicator.file.hash.ssdeep',
  ThreatEnrichmentsIndicatorFileHashTlsh = 'threat.enrichments.indicator.file.hash.tlsh',
  ThreatEnrichmentsIndicatorFileInode = 'threat.enrichments.indicator.file.inode',
  ThreatEnrichmentsIndicatorFileMimeType = 'threat.enrichments.indicator.file.mime_type',
  ThreatEnrichmentsIndicatorFileMode = 'threat.enrichments.indicator.file.mode',
  ThreatEnrichmentsIndicatorFileMtime = 'threat.enrichments.indicator.file.mtime',
  ThreatEnrichmentsIndicatorFileName = 'threat.enrichments.indicator.file.name',
  ThreatEnrichmentsIndicatorFileOwner = 'threat.enrichments.indicator.file.owner',
  ThreatEnrichmentsIndicatorFilePath = 'threat.enrichments.indicator.file.path',
  ThreatEnrichmentsIndicatorFilePe = 'threat.enrichments.indicator.file.pe',
  ThreatEnrichmentsIndicatorFilePeArchitecture = 'threat.enrichments.indicator.file.pe.architecture',
  ThreatEnrichmentsIndicatorFilePeCompany = 'threat.enrichments.indicator.file.pe.company',
  ThreatEnrichmentsIndicatorFilePeDescription = 'threat.enrichments.indicator.file.pe.description',
  ThreatEnrichmentsIndicatorFilePeFileVersion = 'threat.enrichments.indicator.file.pe.file_version',
  ThreatEnrichmentsIndicatorFilePeGoImportHash = 'threat.enrichments.indicator.file.pe.go_import_hash',
  ThreatEnrichmentsIndicatorFilePeGoImports = 'threat.enrichments.indicator.file.pe.go_imports',
  ThreatEnrichmentsIndicatorFilePeGoImportsNamesEntropy = 'threat.enrichments.indicator.file.pe.go_imports_names_entropy',
  ThreatEnrichmentsIndicatorFilePeGoImportsNamesVarEntropy = 'threat.enrichments.indicator.file.pe.go_imports_names_var_entropy',
  ThreatEnrichmentsIndicatorFilePeGoStripped = 'threat.enrichments.indicator.file.pe.go_stripped',
  ThreatEnrichmentsIndicatorFilePeImphash = 'threat.enrichments.indicator.file.pe.imphash',
  ThreatEnrichmentsIndicatorFilePeImportHash = 'threat.enrichments.indicator.file.pe.import_hash',
  ThreatEnrichmentsIndicatorFilePeImports = 'threat.enrichments.indicator.file.pe.imports',
  ThreatEnrichmentsIndicatorFilePeImportsNamesEntropy = 'threat.enrichments.indicator.file.pe.imports_names_entropy',
  ThreatEnrichmentsIndicatorFilePeImportsNamesVarEntropy = 'threat.enrichments.indicator.file.pe.imports_names_var_entropy',
  ThreatEnrichmentsIndicatorFilePeOriginalFileName = 'threat.enrichments.indicator.file.pe.original_file_name',
  ThreatEnrichmentsIndicatorFilePePehash = 'threat.enrichments.indicator.file.pe.pehash',
  ThreatEnrichmentsIndicatorFilePeProduct = 'threat.enrichments.indicator.file.pe.product',
  ThreatEnrichmentsIndicatorFilePeSections = 'threat.enrichments.indicator.file.pe.sections',
  ThreatEnrichmentsIndicatorFilePeSectionsEntropy = 'threat.enrichments.indicator.file.pe.sections.entropy',
  ThreatEnrichmentsIndicatorFilePeSectionsName = 'threat.enrichments.indicator.file.pe.sections.name',
  ThreatEnrichmentsIndicatorFilePeSectionsPhysicalSize = 'threat.enrichments.indicator.file.pe.sections.physical_size',
  ThreatEnrichmentsIndicatorFilePeSectionsVarEntropy = 'threat.enrichments.indicator.file.pe.sections.var_entropy',
  ThreatEnrichmentsIndicatorFilePeSectionsVirtualSize = 'threat.enrichments.indicator.file.pe.sections.virtual_size',
  ThreatEnrichmentsIndicatorFileSize = 'threat.enrichments.indicator.file.size',
  ThreatEnrichmentsIndicatorFileTargetPath = 'threat.enrichments.indicator.file.target_path',
  ThreatEnrichmentsIndicatorFileType = 'threat.enrichments.indicator.file.type',
  ThreatEnrichmentsIndicatorFileUid = 'threat.enrichments.indicator.file.uid',
  ThreatEnrichmentsIndicatorFileX509 = 'threat.enrichments.indicator.file.x509',
  ThreatEnrichmentsIndicatorFileX509AlternativeNames = 'threat.enrichments.indicator.file.x509.alternative_names',
  ThreatEnrichmentsIndicatorFileX509Issuer = 'threat.enrichments.indicator.file.x509.issuer',
  ThreatEnrichmentsIndicatorFileX509IssuerCommonName = 'threat.enrichments.indicator.file.x509.issuer.common_name',
  ThreatEnrichmentsIndicatorFileX509IssuerCountry = 'threat.enrichments.indicator.file.x509.issuer.country',
  ThreatEnrichmentsIndicatorFileX509IssuerDistinguishedName = 'threat.enrichments.indicator.file.x509.issuer.distinguished_name',
  ThreatEnrichmentsIndicatorFileX509IssuerLocality = 'threat.enrichments.indicator.file.x509.issuer.locality',
  ThreatEnrichmentsIndicatorFileX509IssuerOrganization = 'threat.enrichments.indicator.file.x509.issuer.organization',
  ThreatEnrichmentsIndicatorFileX509IssuerOrganizationalUnit = 'threat.enrichments.indicator.file.x509.issuer.organizational_unit',
  ThreatEnrichmentsIndicatorFileX509IssuerStateOrProvince = 'threat.enrichments.indicator.file.x509.issuer.state_or_province',
  ThreatEnrichmentsIndicatorFileX509NotAfter = 'threat.enrichments.indicator.file.x509.not_after',
  ThreatEnrichmentsIndicatorFileX509NotBefore = 'threat.enrichments.indicator.file.x509.not_before',
  ThreatEnrichmentsIndicatorFileX509PublicKeyAlgorithm = 'threat.enrichments.indicator.file.x509.public_key_algorithm',
  ThreatEnrichmentsIndicatorFileX509PublicKeyCurve = 'threat.enrichments.indicator.file.x509.public_key_curve',
  ThreatEnrichmentsIndicatorFileX509PublicKeyExponent = 'threat.enrichments.indicator.file.x509.public_key_exponent',
  ThreatEnrichmentsIndicatorFileX509PublicKeySize = 'threat.enrichments.indicator.file.x509.public_key_size',
  ThreatEnrichmentsIndicatorFileX509SerialNumber = 'threat.enrichments.indicator.file.x509.serial_number',
  ThreatEnrichmentsIndicatorFileX509SignatureAlgorithm = 'threat.enrichments.indicator.file.x509.signature_algorithm',
  ThreatEnrichmentsIndicatorFileX509Subject = 'threat.enrichments.indicator.file.x509.subject',
  ThreatEnrichmentsIndicatorFileX509SubjectCommonName = 'threat.enrichments.indicator.file.x509.subject.common_name',
  ThreatEnrichmentsIndicatorFileX509SubjectCountry = 'threat.enrichments.indicator.file.x509.subject.country',
  ThreatEnrichmentsIndicatorFileX509SubjectDistinguishedName = 'threat.enrichments.indicator.file.x509.subject.distinguished_name',
  ThreatEnrichmentsIndicatorFileX509SubjectLocality = 'threat.enrichments.indicator.file.x509.subject.locality',
  ThreatEnrichmentsIndicatorFileX509SubjectOrganization = 'threat.enrichments.indicator.file.x509.subject.organization',
  ThreatEnrichmentsIndicatorFileX509SubjectOrganizationalUnit = 'threat.enrichments.indicator.file.x509.subject.organizational_unit',
  ThreatEnrichmentsIndicatorFileX509SubjectStateOrProvince = 'threat.enrichments.indicator.file.x509.subject.state_or_province',
  ThreatEnrichmentsIndicatorFileX509VersionNumber = 'threat.enrichments.indicator.file.x509.version_number',
  ThreatEnrichmentsIndicatorFirstSeen = 'threat.enrichments.indicator.first_seen',
  ThreatEnrichmentsIndicatorGeo = 'threat.enrichments.indicator.geo',
  ThreatEnrichmentsIndicatorGeoCityName = 'threat.enrichments.indicator.geo.city_name',
  ThreatEnrichmentsIndicatorGeoContinentCode = 'threat.enrichments.indicator.geo.continent_code',
  ThreatEnrichmentsIndicatorGeoContinentName = 'threat.enrichments.indicator.geo.continent_name',
  ThreatEnrichmentsIndicatorGeoCountryIsoCode = 'threat.enrichments.indicator.geo.country_iso_code',
  ThreatEnrichmentsIndicatorGeoCountryName = 'threat.enrichments.indicator.geo.country_name',
  ThreatEnrichmentsIndicatorGeoLocation = 'threat.enrichments.indicator.geo.location',
  ThreatEnrichmentsIndicatorGeoName = 'threat.enrichments.indicator.geo.name',
  ThreatEnrichmentsIndicatorGeoPostalCode = 'threat.enrichments.indicator.geo.postal_code',
  ThreatEnrichmentsIndicatorGeoRegionIsoCode = 'threat.enrichments.indicator.geo.region_iso_code',
  ThreatEnrichmentsIndicatorGeoRegionName = 'threat.enrichments.indicator.geo.region_name',
  ThreatEnrichmentsIndicatorGeoTimezone = 'threat.enrichments.indicator.geo.timezone',
  ThreatEnrichmentsIndicatorIpv4 = 'threat.enrichments.indicator.ipv4',
  ThreatEnrichmentsIndicatorIpv6 = 'threat.enrichments.indicator.ipv6',
  ThreatEnrichmentsIndicatorLastSeen = 'threat.enrichments.indicator.last_seen',
  ThreatEnrichmentsIndicatorMarking = 'threat.enrichments.indicator.marking',
  ThreatEnrichmentsIndicatorMarkingTlp = 'threat.enrichments.indicator.marking.tlp',
  ThreatEnrichmentsIndicatorMarkingTlpVersion = 'threat.enrichments.indicator.marking.tlp_version',
  ThreatEnrichmentsIndicatorModifiedAt = 'threat.enrichments.indicator.modified_at',
  ThreatEnrichmentsIndicatorName = 'threat.enrichments.indicator.name',
  ThreatEnrichmentsIndicatorPort = 'threat.enrichments.indicator.port',
  ThreatEnrichmentsIndicatorProvider = 'threat.enrichments.indicator.provider',
  ThreatEnrichmentsIndicatorReference = 'threat.enrichments.indicator.reference',
  ThreatEnrichmentsIndicatorRegistry = 'threat.enrichments.indicator.registry',
  ThreatEnrichmentsIndicatorRegistryData = 'threat.enrichments.indicator.registry.data',
  ThreatEnrichmentsIndicatorRegistryDataBytes = 'threat.enrichments.indicator.registry.data.bytes',
  ThreatEnrichmentsIndicatorRegistryDataStrings = 'threat.enrichments.indicator.registry.data.strings',
  ThreatEnrichmentsIndicatorRegistryDataType = 'threat.enrichments.indicator.registry.data.type',
  ThreatEnrichmentsIndicatorRegistryHive = 'threat.enrichments.indicator.registry.hive',
  ThreatEnrichmentsIndicatorRegistryKey = 'threat.enrichments.indicator.registry.key',
  ThreatEnrichmentsIndicatorRegistryPath = 'threat.enrichments.indicator.registry.path',
  ThreatEnrichmentsIndicatorRegistryValue = 'threat.enrichments.indicator.registry.value',
  ThreatEnrichmentsIndicatorScannerStats = 'threat.enrichments.indicator.scanner_stats',
  ThreatEnrichmentsIndicatorSightings = 'threat.enrichments.indicator.sightings',
  ThreatEnrichmentsIndicatorType = 'threat.enrichments.indicator.type',
  ThreatEnrichmentsIndicatorUrl = 'threat.enrichments.indicator.url',
  ThreatEnrichmentsIndicatorUrlDomain = 'threat.enrichments.indicator.url.domain',
  ThreatEnrichmentsIndicatorUrlExtension = 'threat.enrichments.indicator.url.extension',
  ThreatEnrichmentsIndicatorUrlFragment = 'threat.enrichments.indicator.url.fragment',
  ThreatEnrichmentsIndicatorUrlFull = 'threat.enrichments.indicator.url.full',
  ThreatEnrichmentsIndicatorUrlOriginal = 'threat.enrichments.indicator.url.original',
  ThreatEnrichmentsIndicatorUrlPassword = 'threat.enrichments.indicator.url.password',
  ThreatEnrichmentsIndicatorUrlPath = 'threat.enrichments.indicator.url.path',
  ThreatEnrichmentsIndicatorUrlPort = 'threat.enrichments.indicator.url.port',
  ThreatEnrichmentsIndicatorUrlQuery = 'threat.enrichments.indicator.url.query',
  ThreatEnrichmentsIndicatorUrlRegisteredDomain = 'threat.enrichments.indicator.url.registered_domain',
  ThreatEnrichmentsIndicatorUrlScheme = 'threat.enrichments.indicator.url.scheme',
  ThreatEnrichmentsIndicatorUrlSubdomain = 'threat.enrichments.indicator.url.subdomain',
  ThreatEnrichmentsIndicatorUrlTopLevelDomain = 'threat.enrichments.indicator.url.top_level_domain',
  ThreatEnrichmentsIndicatorUrlUsername = 'threat.enrichments.indicator.url.username',
  ThreatEnrichmentsIndicatorX509 = 'threat.enrichments.indicator.x509',
  ThreatEnrichmentsIndicatorX509AlternativeNames = 'threat.enrichments.indicator.x509.alternative_names',
  ThreatEnrichmentsIndicatorX509Issuer = 'threat.enrichments.indicator.x509.issuer',
  ThreatEnrichmentsIndicatorX509IssuerCommonName = 'threat.enrichments.indicator.x509.issuer.common_name',
  ThreatEnrichmentsIndicatorX509IssuerCountry = 'threat.enrichments.indicator.x509.issuer.country',
  ThreatEnrichmentsIndicatorX509IssuerDistinguishedName = 'threat.enrichments.indicator.x509.issuer.distinguished_name',
  ThreatEnrichmentsIndicatorX509IssuerLocality = 'threat.enrichments.indicator.x509.issuer.locality',
  ThreatEnrichmentsIndicatorX509IssuerOrganization = 'threat.enrichments.indicator.x509.issuer.organization',
  ThreatEnrichmentsIndicatorX509IssuerOrganizationalUnit = 'threat.enrichments.indicator.x509.issuer.organizational_unit',
  ThreatEnrichmentsIndicatorX509IssuerStateOrProvince = 'threat.enrichments.indicator.x509.issuer.state_or_province',
  ThreatEnrichmentsIndicatorX509NotAfter = 'threat.enrichments.indicator.x509.not_after',
  ThreatEnrichmentsIndicatorX509NotBefore = 'threat.enrichments.indicator.x509.not_before',
  ThreatEnrichmentsIndicatorX509PublicKeyAlgorithm = 'threat.enrichments.indicator.x509.public_key_algorithm',
  ThreatEnrichmentsIndicatorX509PublicKeyCurve = 'threat.enrichments.indicator.x509.public_key_curve',
  ThreatEnrichmentsIndicatorX509PublicKeyExponent = 'threat.enrichments.indicator.x509.public_key_exponent',
  ThreatEnrichmentsIndicatorX509PublicKeySize = 'threat.enrichments.indicator.x509.public_key_size',
  ThreatEnrichmentsIndicatorX509SerialNumber = 'threat.enrichments.indicator.x509.serial_number',
  ThreatEnrichmentsIndicatorX509SignatureAlgorithm = 'threat.enrichments.indicator.x509.signature_algorithm',
  ThreatEnrichmentsIndicatorX509Subject = 'threat.enrichments.indicator.x509.subject',
  ThreatEnrichmentsIndicatorX509SubjectCommonName = 'threat.enrichments.indicator.x509.subject.common_name',
  ThreatEnrichmentsIndicatorX509SubjectCountry = 'threat.enrichments.indicator.x509.subject.country',
  ThreatEnrichmentsIndicatorX509SubjectDistinguishedName = 'threat.enrichments.indicator.x509.subject.distinguished_name',
  ThreatEnrichmentsIndicatorX509SubjectLocality = 'threat.enrichments.indicator.x509.subject.locality',
  ThreatEnrichmentsIndicatorX509SubjectOrganization = 'threat.enrichments.indicator.x509.subject.organization',
  ThreatEnrichmentsIndicatorX509SubjectOrganizationalUnit = 'threat.enrichments.indicator.x509.subject.organizational_unit',
  ThreatEnrichmentsIndicatorX509SubjectStateOrProvince = 'threat.enrichments.indicator.x509.subject.state_or_province',
  ThreatEnrichmentsIndicatorX509VersionNumber = 'threat.enrichments.indicator.x509.version_number',
  ThreatEnrichmentsMatched = 'threat.enrichments.matched',
  ThreatEnrichmentsMatchedAtomic = 'threat.enrichments.matched.atomic',
  ThreatEnrichmentsMatchedField = 'threat.enrichments.matched.field',
  ThreatEnrichmentsMatchedId = 'threat.enrichments.matched.id',
  ThreatEnrichmentsMatchedIndex = 'threat.enrichments.matched.index',
  ThreatEnrichmentsMatchedOccurred = 'threat.enrichments.matched.occurred',
  ThreatEnrichmentsMatchedType = 'threat.enrichments.matched.type',
  ThreatFeed = 'threat.feed',
  ThreatFeedDashboardId = 'threat.feed.dashboard_id',
  ThreatFeedDescription = 'threat.feed.description',
  ThreatFeedName = 'threat.feed.name',
  ThreatFeedReference = 'threat.feed.reference',
  ThreatFramework = 'threat.framework',
  ThreatGroup = 'threat.group',
  ThreatGroupAlias = 'threat.group.alias',
  ThreatGroupId = 'threat.group.id',
  ThreatGroupName = 'threat.group.name',
  ThreatGroupReference = 'threat.group.reference',
  ThreatIndicator = 'threat.indicator',
  ThreatIndicatorAs = 'threat.indicator.as',
  ThreatIndicatorAsNumber = 'threat.indicator.as.number',
  ThreatIndicatorAsOrganization = 'threat.indicator.as.organization',
  ThreatIndicatorAsOrganizationName = 'threat.indicator.as.organization.name',
  ThreatIndicatorConfidence = 'threat.indicator.confidence',
  ThreatIndicatorDescription = 'threat.indicator.description',
  ThreatIndicatorEmail = 'threat.indicator.email',
  ThreatIndicatorEmailAddress = 'threat.indicator.email.address',
  ThreatIndicatorFile = 'threat.indicator.file',
  ThreatIndicatorFileAccessed = 'threat.indicator.file.accessed',
  ThreatIndicatorFileAttributes = 'threat.indicator.file.attributes',
  ThreatIndicatorFileCodeSignature = 'threat.indicator.file.code_signature',
  ThreatIndicatorFileCodeSignatureDigestAlgorithm = 'threat.indicator.file.code_signature.digest_algorithm',
  ThreatIndicatorFileCodeSignatureExists = 'threat.indicator.file.code_signature.exists',
  ThreatIndicatorFileCodeSignatureSigningId = 'threat.indicator.file.code_signature.signing_id',
  ThreatIndicatorFileCodeSignatureStatus = 'threat.indicator.file.code_signature.status',
  ThreatIndicatorFileCodeSignatureSubjectName = 'threat.indicator.file.code_signature.subject_name',
  ThreatIndicatorFileCodeSignatureTeamId = 'threat.indicator.file.code_signature.team_id',
  ThreatIndicatorFileCodeSignatureTimestamp = 'threat.indicator.file.code_signature.timestamp',
  ThreatIndicatorFileCodeSignatureTrusted = 'threat.indicator.file.code_signature.trusted',
  ThreatIndicatorFileCodeSignatureValid = 'threat.indicator.file.code_signature.valid',
  ThreatIndicatorFileCreated = 'threat.indicator.file.created',
  ThreatIndicatorFileCtime = 'threat.indicator.file.ctime',
  ThreatIndicatorFileDevice = 'threat.indicator.file.device',
  ThreatIndicatorFileDirectory = 'threat.indicator.file.directory',
  ThreatIndicatorFileDriveLetter = 'threat.indicator.file.drive_letter',
  ThreatIndicatorFileElf = 'threat.indicator.file.elf',
  ThreatIndicatorFileElfArchitecture = 'threat.indicator.file.elf.architecture',
  ThreatIndicatorFileElfByteOrder = 'threat.indicator.file.elf.byte_order',
  ThreatIndicatorFileElfCpuType = 'threat.indicator.file.elf.cpu_type',
  ThreatIndicatorFileElfCreationDate = 'threat.indicator.file.elf.creation_date',
  ThreatIndicatorFileElfExports = 'threat.indicator.file.elf.exports',
  ThreatIndicatorFileElfGoImportHash = 'threat.indicator.file.elf.go_import_hash',
  ThreatIndicatorFileElfGoImports = 'threat.indicator.file.elf.go_imports',
  ThreatIndicatorFileElfGoImportsNamesEntropy = 'threat.indicator.file.elf.go_imports_names_entropy',
  ThreatIndicatorFileElfGoImportsNamesVarEntropy = 'threat.indicator.file.elf.go_imports_names_var_entropy',
  ThreatIndicatorFileElfGoStripped = 'threat.indicator.file.elf.go_stripped',
  ThreatIndicatorFileElfHeader = 'threat.indicator.file.elf.header',
  ThreatIndicatorFileElfHeaderAbiVersion = 'threat.indicator.file.elf.header.abi_version',
  ThreatIndicatorFileElfHeaderClass = 'threat.indicator.file.elf.header.class',
  ThreatIndicatorFileElfHeaderData = 'threat.indicator.file.elf.header.data',
  ThreatIndicatorFileElfHeaderEntrypoint = 'threat.indicator.file.elf.header.entrypoint',
  ThreatIndicatorFileElfHeaderObjectVersion = 'threat.indicator.file.elf.header.object_version',
  ThreatIndicatorFileElfHeaderOsAbi = 'threat.indicator.file.elf.header.os_abi',
  ThreatIndicatorFileElfHeaderType = 'threat.indicator.file.elf.header.type',
  ThreatIndicatorFileElfHeaderVersion = 'threat.indicator.file.elf.header.version',
  ThreatIndicatorFileElfImportHash = 'threat.indicator.file.elf.import_hash',
  ThreatIndicatorFileElfImports = 'threat.indicator.file.elf.imports',
  ThreatIndicatorFileElfImportsNamesEntropy = 'threat.indicator.file.elf.imports_names_entropy',
  ThreatIndicatorFileElfImportsNamesVarEntropy = 'threat.indicator.file.elf.imports_names_var_entropy',
  ThreatIndicatorFileElfSections = 'threat.indicator.file.elf.sections',
  ThreatIndicatorFileElfSectionsChi2 = 'threat.indicator.file.elf.sections.chi2',
  ThreatIndicatorFileElfSectionsEntropy = 'threat.indicator.file.elf.sections.entropy',
  ThreatIndicatorFileElfSectionsFlags = 'threat.indicator.file.elf.sections.flags',
  ThreatIndicatorFileElfSectionsName = 'threat.indicator.file.elf.sections.name',
  ThreatIndicatorFileElfSectionsPhysicalOffset = 'threat.indicator.file.elf.sections.physical_offset',
  ThreatIndicatorFileElfSectionsPhysicalSize = 'threat.indicator.file.elf.sections.physical_size',
  ThreatIndicatorFileElfSectionsType = 'threat.indicator.file.elf.sections.type',
  ThreatIndicatorFileElfSectionsVarEntropy = 'threat.indicator.file.elf.sections.var_entropy',
  ThreatIndicatorFileElfSectionsVirtualAddress = 'threat.indicator.file.elf.sections.virtual_address',
  ThreatIndicatorFileElfSectionsVirtualSize = 'threat.indicator.file.elf.sections.virtual_size',
  ThreatIndicatorFileElfSegments = 'threat.indicator.file.elf.segments',
  ThreatIndicatorFileElfSegmentsSections = 'threat.indicator.file.elf.segments.sections',
  ThreatIndicatorFileElfSegmentsType = 'threat.indicator.file.elf.segments.type',
  ThreatIndicatorFileElfSharedLibraries = 'threat.indicator.file.elf.shared_libraries',
  ThreatIndicatorFileElfTelfhash = 'threat.indicator.file.elf.telfhash',
  ThreatIndicatorFileExtension = 'threat.indicator.file.extension',
  ThreatIndicatorFileForkName = 'threat.indicator.file.fork_name',
  ThreatIndicatorFileGid = 'threat.indicator.file.gid',
  ThreatIndicatorFileGroup = 'threat.indicator.file.group',
  ThreatIndicatorFileHash = 'threat.indicator.file.hash',
  ThreatIndicatorFileHashMd5 = 'threat.indicator.file.hash.md5',
  ThreatIndicatorFileHashSha1 = 'threat.indicator.file.hash.sha1',
  ThreatIndicatorFileHashSha256 = 'threat.indicator.file.hash.sha256',
  ThreatIndicatorFileHashSha384 = 'threat.indicator.file.hash.sha384',
  ThreatIndicatorFileHashSha512 = 'threat.indicator.file.hash.sha512',
  ThreatIndicatorFileHashSsdeep = 'threat.indicator.file.hash.ssdeep',
  ThreatIndicatorFileHashTlsh = 'threat.indicator.file.hash.tlsh',
  ThreatIndicatorFileInode = 'threat.indicator.file.inode',
  ThreatIndicatorFileMimeType = 'threat.indicator.file.mime_type',
  ThreatIndicatorFileMode = 'threat.indicator.file.mode',
  ThreatIndicatorFileMtime = 'threat.indicator.file.mtime',
  ThreatIndicatorFileName = 'threat.indicator.file.name',
  ThreatIndicatorFileOwner = 'threat.indicator.file.owner',
  ThreatIndicatorFilePath = 'threat.indicator.file.path',
  ThreatIndicatorFilePe = 'threat.indicator.file.pe',
  ThreatIndicatorFilePeArchitecture = 'threat.indicator.file.pe.architecture',
  ThreatIndicatorFilePeCompany = 'threat.indicator.file.pe.company',
  ThreatIndicatorFilePeDescription = 'threat.indicator.file.pe.description',
  ThreatIndicatorFilePeFileVersion = 'threat.indicator.file.pe.file_version',
  ThreatIndicatorFilePeGoImportHash = 'threat.indicator.file.pe.go_import_hash',
  ThreatIndicatorFilePeGoImports = 'threat.indicator.file.pe.go_imports',
  ThreatIndicatorFilePeGoImportsNamesEntropy = 'threat.indicator.file.pe.go_imports_names_entropy',
  ThreatIndicatorFilePeGoImportsNamesVarEntropy = 'threat.indicator.file.pe.go_imports_names_var_entropy',
  ThreatIndicatorFilePeGoStripped = 'threat.indicator.file.pe.go_stripped',
  ThreatIndicatorFilePeImphash = 'threat.indicator.file.pe.imphash',
  ThreatIndicatorFilePeImportHash = 'threat.indicator.file.pe.import_hash',
  ThreatIndicatorFilePeImports = 'threat.indicator.file.pe.imports',
  ThreatIndicatorFilePeImportsNamesEntropy = 'threat.indicator.file.pe.imports_names_entropy',
  ThreatIndicatorFilePeImportsNamesVarEntropy = 'threat.indicator.file.pe.imports_names_var_entropy',
  ThreatIndicatorFilePeOriginalFileName = 'threat.indicator.file.pe.original_file_name',
  ThreatIndicatorFilePePehash = 'threat.indicator.file.pe.pehash',
  ThreatIndicatorFilePeProduct = 'threat.indicator.file.pe.product',
  ThreatIndicatorFilePeSections = 'threat.indicator.file.pe.sections',
  ThreatIndicatorFilePeSectionsEntropy = 'threat.indicator.file.pe.sections.entropy',
  ThreatIndicatorFilePeSectionsName = 'threat.indicator.file.pe.sections.name',
  ThreatIndicatorFilePeSectionsPhysicalSize = 'threat.indicator.file.pe.sections.physical_size',
  ThreatIndicatorFilePeSectionsVarEntropy = 'threat.indicator.file.pe.sections.var_entropy',
  ThreatIndicatorFilePeSectionsVirtualSize = 'threat.indicator.file.pe.sections.virtual_size',
  ThreatIndicatorFileSize = 'threat.indicator.file.size',
  ThreatIndicatorFileTargetPath = 'threat.indicator.file.target_path',
  ThreatIndicatorFileType = 'threat.indicator.file.type',
  ThreatIndicatorFileUid = 'threat.indicator.file.uid',
  ThreatIndicatorFileX509 = 'threat.indicator.file.x509',
  ThreatIndicatorFileX509AlternativeNames = 'threat.indicator.file.x509.alternative_names',
  ThreatIndicatorFileX509Issuer = 'threat.indicator.file.x509.issuer',
  ThreatIndicatorFileX509IssuerCommonName = 'threat.indicator.file.x509.issuer.common_name',
  ThreatIndicatorFileX509IssuerCountry = 'threat.indicator.file.x509.issuer.country',
  ThreatIndicatorFileX509IssuerDistinguishedName = 'threat.indicator.file.x509.issuer.distinguished_name',
  ThreatIndicatorFileX509IssuerLocality = 'threat.indicator.file.x509.issuer.locality',
  ThreatIndicatorFileX509IssuerOrganization = 'threat.indicator.file.x509.issuer.organization',
  ThreatIndicatorFileX509IssuerOrganizationalUnit = 'threat.indicator.file.x509.issuer.organizational_unit',
  ThreatIndicatorFileX509IssuerStateOrProvince = 'threat.indicator.file.x509.issuer.state_or_province',
  ThreatIndicatorFileX509NotAfter = 'threat.indicator.file.x509.not_after',
  ThreatIndicatorFileX509NotBefore = 'threat.indicator.file.x509.not_before',
  ThreatIndicatorFileX509PublicKeyAlgorithm = 'threat.indicator.file.x509.public_key_algorithm',
  ThreatIndicatorFileX509PublicKeyCurve = 'threat.indicator.file.x509.public_key_curve',
  ThreatIndicatorFileX509PublicKeyExponent = 'threat.indicator.file.x509.public_key_exponent',
  ThreatIndicatorFileX509PublicKeySize = 'threat.indicator.file.x509.public_key_size',
  ThreatIndicatorFileX509SerialNumber = 'threat.indicator.file.x509.serial_number',
  ThreatIndicatorFileX509SignatureAlgorithm = 'threat.indicator.file.x509.signature_algorithm',
  ThreatIndicatorFileX509Subject = 'threat.indicator.file.x509.subject',
  ThreatIndicatorFileX509SubjectCommonName = 'threat.indicator.file.x509.subject.common_name',
  ThreatIndicatorFileX509SubjectCountry = 'threat.indicator.file.x509.subject.country',
  ThreatIndicatorFileX509SubjectDistinguishedName = 'threat.indicator.file.x509.subject.distinguished_name',
  ThreatIndicatorFileX509SubjectLocality = 'threat.indicator.file.x509.subject.locality',
  ThreatIndicatorFileX509SubjectOrganization = 'threat.indicator.file.x509.subject.organization',
  ThreatIndicatorFileX509SubjectOrganizationalUnit = 'threat.indicator.file.x509.subject.organizational_unit',
  ThreatIndicatorFileX509SubjectStateOrProvince = 'threat.indicator.file.x509.subject.state_or_province',
  ThreatIndicatorFileX509VersionNumber = 'threat.indicator.file.x509.version_number',
  ThreatIndicatorFirstSeen = 'threat.indicator.first_seen',
  ThreatIndicatorGeo = 'threat.indicator.geo',
  ThreatIndicatorGeoCityName = 'threat.indicator.geo.city_name',
  ThreatIndicatorGeoContinentCode = 'threat.indicator.geo.continent_code',
  ThreatIndicatorGeoContinentName = 'threat.indicator.geo.continent_name',
  ThreatIndicatorGeoCountryIsoCode = 'threat.indicator.geo.country_iso_code',
  ThreatIndicatorGeoCountryName = 'threat.indicator.geo.country_name',
  ThreatIndicatorGeoLocation = 'threat.indicator.geo.location',
  ThreatIndicatorGeoName = 'threat.indicator.geo.name',
  ThreatIndicatorGeoPostalCode = 'threat.indicator.geo.postal_code',
  ThreatIndicatorGeoRegionIsoCode = 'threat.indicator.geo.region_iso_code',
  ThreatIndicatorGeoRegionName = 'threat.indicator.geo.region_name',
  ThreatIndicatorGeoTimezone = 'threat.indicator.geo.timezone',
  ThreatIndicatorIpv4 = 'threat.indicator.ipv4',
  ThreatIndicatorIpv6 = 'threat.indicator.ipv6',
  ThreatIndicatorLastSeen = 'threat.indicator.last_seen',
  ThreatIndicatorMarking = 'threat.indicator.marking',
  ThreatIndicatorMarkingTlp = 'threat.indicator.marking.tlp',
  ThreatIndicatorMarkingTlpVersion = 'threat.indicator.marking.tlp_version',
  ThreatIndicatorModifiedAt = 'threat.indicator.modified_at',
  ThreatIndicatorName = 'threat.indicator.name',
  ThreatIndicatorPort = 'threat.indicator.port',
  ThreatIndicatorProvider = 'threat.indicator.provider',
  ThreatIndicatorReference = 'threat.indicator.reference',
  ThreatIndicatorRegistry = 'threat.indicator.registry',
  ThreatIndicatorRegistryData = 'threat.indicator.registry.data',
  ThreatIndicatorRegistryDataBytes = 'threat.indicator.registry.data.bytes',
  ThreatIndicatorRegistryDataStrings = 'threat.indicator.registry.data.strings',
  ThreatIndicatorRegistryDataType = 'threat.indicator.registry.data.type',
  ThreatIndicatorRegistryHive = 'threat.indicator.registry.hive',
  ThreatIndicatorRegistryKey = 'threat.indicator.registry.key',
  ThreatIndicatorRegistryPath = 'threat.indicator.registry.path',
  ThreatIndicatorRegistryValue = 'threat.indicator.registry.value',
  ThreatIndicatorScannerStats = 'threat.indicator.scanner_stats',
  ThreatIndicatorSightings = 'threat.indicator.sightings',
  ThreatIndicatorType = 'threat.indicator.type',
  ThreatIndicatorUrl = 'threat.indicator.url',
  ThreatIndicatorUrlDomain = 'threat.indicator.url.domain',
  ThreatIndicatorUrlExtension = 'threat.indicator.url.extension',
  ThreatIndicatorUrlFragment = 'threat.indicator.url.fragment',
  ThreatIndicatorUrlFull = 'threat.indicator.url.full',
  ThreatIndicatorUrlOriginal = 'threat.indicator.url.original',
  ThreatIndicatorUrlPassword = 'threat.indicator.url.password',
  ThreatIndicatorUrlPath = 'threat.indicator.url.path',
  ThreatIndicatorUrlPort = 'threat.indicator.url.port',
  ThreatIndicatorUrlQuery = 'threat.indicator.url.query',
  ThreatIndicatorUrlRegisteredDomain = 'threat.indicator.url.registered_domain',
  ThreatIndicatorUrlScheme = 'threat.indicator.url.scheme',
  ThreatIndicatorUrlSubdomain = 'threat.indicator.url.subdomain',
  ThreatIndicatorUrlTopLevelDomain = 'threat.indicator.url.top_level_domain',
  ThreatIndicatorUrlUsername = 'threat.indicator.url.username',
  ThreatIndicatorX509 = 'threat.indicator.x509',
  ThreatIndicatorX509AlternativeNames = 'threat.indicator.x509.alternative_names',
  ThreatIndicatorX509Issuer = 'threat.indicator.x509.issuer',
  ThreatIndicatorX509IssuerCommonName = 'threat.indicator.x509.issuer.common_name',
  ThreatIndicatorX509IssuerCountry = 'threat.indicator.x509.issuer.country',
  ThreatIndicatorX509IssuerDistinguishedName = 'threat.indicator.x509.issuer.distinguished_name',
  ThreatIndicatorX509IssuerLocality = 'threat.indicator.x509.issuer.locality',
  ThreatIndicatorX509IssuerOrganization = 'threat.indicator.x509.issuer.organization',
  ThreatIndicatorX509IssuerOrganizationalUnit = 'threat.indicator.x509.issuer.organizational_unit',
  ThreatIndicatorX509IssuerStateOrProvince = 'threat.indicator.x509.issuer.state_or_province',
  ThreatIndicatorX509NotAfter = 'threat.indicator.x509.not_after',
  ThreatIndicatorX509NotBefore = 'threat.indicator.x509.not_before',
  ThreatIndicatorX509PublicKeyAlgorithm = 'threat.indicator.x509.public_key_algorithm',
  ThreatIndicatorX509PublicKeyCurve = 'threat.indicator.x509.public_key_curve',
  ThreatIndicatorX509PublicKeyExponent = 'threat.indicator.x509.public_key_exponent',
  ThreatIndicatorX509PublicKeySize = 'threat.indicator.x509.public_key_size',
  ThreatIndicatorX509SerialNumber = 'threat.indicator.x509.serial_number',
  ThreatIndicatorX509SignatureAlgorithm = 'threat.indicator.x509.signature_algorithm',
  ThreatIndicatorX509Subject = 'threat.indicator.x509.subject',
  ThreatIndicatorX509SubjectCommonName = 'threat.indicator.x509.subject.common_name',
  ThreatIndicatorX509SubjectCountry = 'threat.indicator.x509.subject.country',
  ThreatIndicatorX509SubjectDistinguishedName = 'threat.indicator.x509.subject.distinguished_name',
  ThreatIndicatorX509SubjectLocality = 'threat.indicator.x509.subject.locality',
  ThreatIndicatorX509SubjectOrganization = 'threat.indicator.x509.subject.organization',
  ThreatIndicatorX509SubjectOrganizationalUnit = 'threat.indicator.x509.subject.organizational_unit',
  ThreatIndicatorX509SubjectStateOrProvince = 'threat.indicator.x509.subject.state_or_province',
  ThreatIndicatorX509VersionNumber = 'threat.indicator.x509.version_number',
  ThreatSoftware = 'threat.software',
  ThreatSoftwareAlias = 'threat.software.alias',
  ThreatSoftwareId = 'threat.software.id',
  ThreatSoftwareName = 'threat.software.name',
  ThreatSoftwarePlatforms = 'threat.software.platforms',
  ThreatSoftwareReference = 'threat.software.reference',
  ThreatSoftwareType = 'threat.software.type',
  ThreatTactic = 'threat.tactic',
  ThreatTacticId = 'threat.tactic.id',
  ThreatTacticName = 'threat.tactic.name',
  ThreatTacticReference = 'threat.tactic.reference',
  ThreatTechnique = 'threat.technique',
  ThreatTechniqueId = 'threat.technique.id',
  ThreatTechniqueName = 'threat.technique.name',
  ThreatTechniqueReference = 'threat.technique.reference',
  ThreatTechniqueSubtechnique = 'threat.technique.subtechnique',
  ThreatTechniqueSubtechniqueId = 'threat.technique.subtechnique.id',
  ThreatTechniqueSubtechniqueName = 'threat.technique.subtechnique.name',
  ThreatTechniqueSubtechniqueReference = 'threat.technique.subtechnique.reference',
  Tls = 'tls',
  TlsCipher = 'tls.cipher',
  TlsClient = 'tls.client',
  TlsClientCertificate = 'tls.client.certificate',
  TlsClientCertificateChain = 'tls.client.certificate_chain',
  TlsClientHash = 'tls.client.hash',
  TlsClientHashMd5 = 'tls.client.hash.md5',
  TlsClientHashSha1 = 'tls.client.hash.sha1',
  TlsClientHashSha256 = 'tls.client.hash.sha256',
  TlsClientIssuer = 'tls.client.issuer',
  TlsClientJa3 = 'tls.client.ja3',
  TlsClientNotAfter = 'tls.client.not_after',
  TlsClientNotBefore = 'tls.client.not_before',
  TlsClientServerName = 'tls.client.server_name',
  TlsClientSubject = 'tls.client.subject',
  TlsClientSupportedCiphers = 'tls.client.supported_ciphers',
  TlsClientX509 = 'tls.client.x509',
  TlsClientX509AlternativeNames = 'tls.client.x509.alternative_names',
  TlsClientX509Issuer = 'tls.client.x509.issuer',
  TlsClientX509IssuerCommonName = 'tls.client.x509.issuer.common_name',
  TlsClientX509IssuerCountry = 'tls.client.x509.issuer.country',
  TlsClientX509IssuerDistinguishedName = 'tls.client.x509.issuer.distinguished_name',
  TlsClientX509IssuerLocality = 'tls.client.x509.issuer.locality',
  TlsClientX509IssuerOrganization = 'tls.client.x509.issuer.organization',
  TlsClientX509IssuerOrganizationalUnit = 'tls.client.x509.issuer.organizational_unit',
  TlsClientX509IssuerStateOrProvince = 'tls.client.x509.issuer.state_or_province',
  TlsClientX509NotAfter = 'tls.client.x509.not_after',
  TlsClientX509NotBefore = 'tls.client.x509.not_before',
  TlsClientX509PublicKeyAlgorithm = 'tls.client.x509.public_key_algorithm',
  TlsClientX509PublicKeyCurve = 'tls.client.x509.public_key_curve',
  TlsClientX509PublicKeyExponent = 'tls.client.x509.public_key_exponent',
  TlsClientX509PublicKeySize = 'tls.client.x509.public_key_size',
  TlsClientX509SerialNumber = 'tls.client.x509.serial_number',
  TlsClientX509SignatureAlgorithm = 'tls.client.x509.signature_algorithm',
  TlsClientX509Subject = 'tls.client.x509.subject',
  TlsClientX509SubjectCommonName = 'tls.client.x509.subject.common_name',
  TlsClientX509SubjectCountry = 'tls.client.x509.subject.country',
  TlsClientX509SubjectDistinguishedName = 'tls.client.x509.subject.distinguished_name',
  TlsClientX509SubjectLocality = 'tls.client.x509.subject.locality',
  TlsClientX509SubjectOrganization = 'tls.client.x509.subject.organization',
  TlsClientX509SubjectOrganizationalUnit = 'tls.client.x509.subject.organizational_unit',
  TlsClientX509SubjectStateOrProvince = 'tls.client.x509.subject.state_or_province',
  TlsClientX509VersionNumber = 'tls.client.x509.version_number',
  TlsCurve = 'tls.curve',
  TlsEstablished = 'tls.established',
  TlsNextProtocol = 'tls.next_protocol',
  TlsResumed = 'tls.resumed',
  TlsServer = 'tls.server',
  TlsServerCertificate = 'tls.server.certificate',
  TlsServerCertificateChain = 'tls.server.certificate_chain',
  TlsServerHash = 'tls.server.hash',
  TlsServerHashMd5 = 'tls.server.hash.md5',
  TlsServerHashSha1 = 'tls.server.hash.sha1',
  TlsServerHashSha256 = 'tls.server.hash.sha256',
  TlsServerIssuer = 'tls.server.issuer',
  TlsServerJa3S = 'tls.server.ja3s',
  TlsServerNotAfter = 'tls.server.not_after',
  TlsServerNotBefore = 'tls.server.not_before',
  TlsServerSubject = 'tls.server.subject',
  TlsServerX509 = 'tls.server.x509',
  TlsServerX509AlternativeNames = 'tls.server.x509.alternative_names',
  TlsServerX509Issuer = 'tls.server.x509.issuer',
  TlsServerX509IssuerCommonName = 'tls.server.x509.issuer.common_name',
  TlsServerX509IssuerCountry = 'tls.server.x509.issuer.country',
  TlsServerX509IssuerDistinguishedName = 'tls.server.x509.issuer.distinguished_name',
  TlsServerX509IssuerLocality = 'tls.server.x509.issuer.locality',
  TlsServerX509IssuerOrganization = 'tls.server.x509.issuer.organization',
  TlsServerX509IssuerOrganizationalUnit = 'tls.server.x509.issuer.organizational_unit',
  TlsServerX509IssuerStateOrProvince = 'tls.server.x509.issuer.state_or_province',
  TlsServerX509NotAfter = 'tls.server.x509.not_after',
  TlsServerX509NotBefore = 'tls.server.x509.not_before',
  TlsServerX509PublicKeyAlgorithm = 'tls.server.x509.public_key_algorithm',
  TlsServerX509PublicKeyCurve = 'tls.server.x509.public_key_curve',
  TlsServerX509PublicKeyExponent = 'tls.server.x509.public_key_exponent',
  TlsServerX509PublicKeySize = 'tls.server.x509.public_key_size',
  TlsServerX509SerialNumber = 'tls.server.x509.serial_number',
  TlsServerX509SignatureAlgorithm = 'tls.server.x509.signature_algorithm',
  TlsServerX509Subject = 'tls.server.x509.subject',
  TlsServerX509SubjectCommonName = 'tls.server.x509.subject.common_name',
  TlsServerX509SubjectCountry = 'tls.server.x509.subject.country',
  TlsServerX509SubjectDistinguishedName = 'tls.server.x509.subject.distinguished_name',
  TlsServerX509SubjectLocality = 'tls.server.x509.subject.locality',
  TlsServerX509SubjectOrganization = 'tls.server.x509.subject.organization',
  TlsServerX509SubjectOrganizationalUnit = 'tls.server.x509.subject.organizational_unit',
  TlsServerX509SubjectStateOrProvince = 'tls.server.x509.subject.state_or_province',
  TlsServerX509VersionNumber = 'tls.server.x509.version_number',
  TlsVersion = 'tls.version',
  TlsVersionProtocol = 'tls.version_protocol',
  Trace = 'trace',
  TraceId = 'trace.id',
  Transaction = 'transaction',
  TransactionId = 'transaction.id',
  Url = 'url',
  UrlDomain = 'url.domain',
  UrlExtension = 'url.extension',
  UrlFragment = 'url.fragment',
  UrlFull = 'url.full',
  UrlOriginal = 'url.original',
  UrlPassword = 'url.password',
  UrlPath = 'url.path',
  UrlPort = 'url.port',
  UrlQuery = 'url.query',
  UrlRegisteredDomain = 'url.registered_domain',
  UrlScheme = 'url.scheme',
  UrlSubdomain = 'url.subdomain',
  UrlTopLevelDomain = 'url.top_level_domain',
  UrlUsername = 'url.username',
  User = 'user',
  UserChanges = 'user.changes',
  UserChangesDomain = 'user.changes.domain',
  UserChangesEmail = 'user.changes.email',
  UserChangesFullName = 'user.changes.full_name',
  UserChangesGroup = 'user.changes.group',
  UserChangesGroupDomain = 'user.changes.group.domain',
  UserChangesGroupId = 'user.changes.group.id',
  UserChangesGroupName = 'user.changes.group.name',
  UserChangesHash = 'user.changes.hash',
  UserChangesId = 'user.changes.id',
  UserChangesName = 'user.changes.name',
  UserChangesRoles = 'user.changes.roles',
  UserDomain = 'user.domain',
  UserEffective = 'user.effective',
  UserEffectiveDomain = 'user.effective.domain',
  UserEffectiveEmail = 'user.effective.email',
  UserEffectiveFullName = 'user.effective.full_name',
  UserEffectiveGroup = 'user.effective.group',
  UserEffectiveGroupDomain = 'user.effective.group.domain',
  UserEffectiveGroupId = 'user.effective.group.id',
  UserEffectiveGroupName = 'user.effective.group.name',
  UserEffectiveHash = 'user.effective.hash',
  UserEffectiveId = 'user.effective.id',
  UserEffectiveName = 'user.effective.name',
  UserEffectiveRoles = 'user.effective.roles',
  UserEmail = 'user.email',
  UserFullName = 'user.full_name',
  UserGroup = 'user.group',
  UserGroupDomain = 'user.group.domain',
  UserGroupId = 'user.group.id',
  UserGroupName = 'user.group.name',
  UserHash = 'user.hash',
  UserId = 'user.id',
  UserName = 'user.name',
  UserRisk = 'user.risk',
  UserRiskCalculatedLevel = 'user.risk.calculated_level',
  UserRiskCalculatedScore = 'user.risk.calculated_score',
  UserRiskCalculatedScoreNorm = 'user.risk.calculated_score_norm',
  UserRiskStaticLevel = 'user.risk.static_level',
  UserRiskStaticScore = 'user.risk.static_score',
  UserRiskStaticScoreNorm = 'user.risk.static_score_norm',
  UserRoles = 'user.roles',
  UserTarget = 'user.target',
  UserTargetDomain = 'user.target.domain',
  UserTargetEmail = 'user.target.email',
  UserTargetFullName = 'user.target.full_name',
  UserTargetGroup = 'user.target.group',
  UserTargetGroupDomain = 'user.target.group.domain',
  UserTargetGroupId = 'user.target.group.id',
  UserTargetGroupName = 'user.target.group.name',
  UserTargetHash = 'user.target.hash',
  UserTargetId = 'user.target.id',
  UserTargetName = 'user.target.name',
  UserTargetRoles = 'user.target.roles',
  UserAgent = 'user_agent',
  UserAgentDevice = 'user_agent.device',
  UserAgentDeviceName = 'user_agent.device.name',
  UserAgentName = 'user_agent.name',
  UserAgentOriginal = 'user_agent.original',
  UserAgentOs = 'user_agent.os',
  UserAgentOsFamily = 'user_agent.os.family',
  UserAgentOsFull = 'user_agent.os.full',
  UserAgentOsKernel = 'user_agent.os.kernel',
  UserAgentOsName = 'user_agent.os.name',
  UserAgentOsPlatform = 'user_agent.os.platform',
  UserAgentOsType = 'user_agent.os.type',
  UserAgentOsVersion = 'user_agent.os.version',
  UserAgentVersion = 'user_agent.version',
  Vulnerability = 'vulnerability',
  VulnerabilityCategory = 'vulnerability.category',
  VulnerabilityClassification = 'vulnerability.classification',
  VulnerabilityDescription = 'vulnerability.description',
  VulnerabilityEnumeration = 'vulnerability.enumeration',
  VulnerabilityId = 'vulnerability.id',
  VulnerabilityReference = 'vulnerability.reference',
  VulnerabilityReportId = 'vulnerability.report_id',
  VulnerabilityScanner = 'vulnerability.scanner',
  VulnerabilityScannerVendor = 'vulnerability.scanner.vendor',
  VulnerabilityScore = 'vulnerability.score',
  VulnerabilityScoreBase = 'vulnerability.score.base',
  VulnerabilityScoreEnvironmental = 'vulnerability.score.environmental',
  VulnerabilityScoreTemporal = 'vulnerability.score.temporal',
  VulnerabilityScoreVersion = 'vulnerability.score.version',
  VulnerabilitySeverity = 'vulnerability.severity'
}

/** FlattenedRequestParameters */
export interface FlattenedRequestParameters {
  /** Durationseconds */
  durationSeconds?: number;
  /** Incomingtransitivetags */
  incomingTransitiveTags?: object;
  /** Rolearn */
  roleArn?: string;
  /** Rolesessionname */
  roleSessionName?: string;
  /** Tags */
  tags?: Tags[];
  /** Transitivetagkeys */
  transitiveTagKeys?: string[];
}

/** FlattenedResponseElements */
export interface FlattenedResponseElements {
  assumedRoleUser?: AssumedRoleUser;
  credentials?: Credentials;
}

/** ForgotPassword */
export interface ForgotPassword {
  /**
   * Email
   * @format email
   */
  email: string;
}

/**
 * Frequency
 * An enumeration.
 */
export enum Frequency {
  Hourly = 'hourly',
  Daily = 'daily',
  Weekly = 'weekly',
  Monthly = 'monthly'
}

/**
 * FuncOperationTypeEnum
 * Enum for different function operation name.
 */
export enum FuncOperationTypeEnum {
  FILTER = 'FILTER',
  ENRICHMENT = 'ENRICHMENT',
  TRANSFORMATION = 'TRANSFORMATION',
  AGGREGATION = 'AGGREGATION'
}

/**
 * FunctionCategoryEnum
 * Enum for different function category.
 */
export enum FunctionCategoryEnum {
  FOUNDATIONAL = 'FOUNDATIONAL',
  CUSTOM = 'CUSTOM',
  OOTB = 'OOTB'
}

/**
 * GetConfigurationOut
 * Schema for Get Configuration Response.
 */
export interface GetConfigurationOut {
  /** Id */
  id: string;
  /** Vendor Account Name */
  vendor_account_name?: string;
  /** Vendor Account Id */
  vendor_account_id?: string;
  /** Integration Id */
  integration_id: string;
  /** Name */
  name: string;
  /** Active */
  active: boolean;
  /** Integration type enum. */
  type: IntegrationTypeEnum;
  category: IntegrationCategoryEnum[];
  /** Interval */
  interval?: number;
  /**
   * Last Run At
   * @format date-time
   */
  last_run_at?: string;
  /** Statistics */
  statistics?: object;
  /** Checkpoint */
  checkpoint?: object;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Created By */
  created_by: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at?: string;
  /** Updated By */
  updated_by?: string;
  /** Status type enum. */
  status?: StatusTypeEnum;
  /**
   * Pipeline
   * @default {}
   */
  pipeline?: RoutePipelineOut;
  /** Parameters */
  parameters: object;
  /** Ecs Pipelines */
  ecs_pipelines?: object;
  /** Store Raw Event */
  store_raw_event: boolean;
}

/**
 * GetEvents
 * Request Model for Get Events.
 */
export interface GetEvents {
  /**
   * Start Time
   * @format date-time
   */
  start_time: string;
  /**
   * End Time
   * @format date-time
   */
  end_time: string;
  /**
   * Page Number
   * @min 1
   * @default 1
   */
  page_number?: number;
  /**
   * Page Size
   * @exclusiveMin 0
   * @max 1000
   * @default 30
   */
  page_size?: number;
  /** @default "@timestamp" */
  order_by?: FieldEnum;
  /** ConditionGroup Model for Get Events. */
  condition?: ConditionGroup;
  /** @default "DESC" */
  order_type?: OrderTypeEnum;
  /** @minItems 1 */
  selected_fields: FieldEnum[];
  /** Vendor Account Id */
  vendor_account_id: string;
}

/**
 * GetEventsTimeline
 * Request Model for Get Events' Timeline.
 */
export interface GetEventsTimeline {
  /**
   * Start Time
   * @format date-time
   */
  start_time: string;
  /**
   * End Time
   * @format date-time
   */
  end_time: string;
  /** ConditionGroup Model for Get Events. */
  condition?: ConditionGroup;
  /**
   * Desired Chunks
   * @exclusiveMin 0
   * @max 300
   * @default 50
   */
  desired_chunks?: number;
  /** Vendor Account Id */
  vendor_account_id: string;
}

/**
 * GetFielSetOut
 * Response model for get fieldset.
 */
export interface GetFielSetOut {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Tags */
  tags: string[];
  /** Share Level */
  share_level: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at?: string;
  /** Created By */
  created_by: string;
  /** Updated By */
  updated_by?: string;
  fields: FieldEnum[];
  /** Description */
  description: string;
}

/**
 * GetFieldAnalytics
 * Request Model for Get field analytics.
 */
export interface GetFieldAnalytics {
  /**
   * Start Time
   * @format date-time
   */
  start_time: string;
  /**
   * End Time
   * @format date-time
   */
  end_time: string;
  /** ACS Fields Enum. */
  field: FieldEnum;
  /** ConditionGroup Model for Get Events. */
  condition?: ConditionGroup;
  /** Vendor Account Id */
  vendor_account_id: string;
  /**
   * Limit
   * @min 1
   * @max 10
   * @default 5
   */
  limit?: number;
}

/**
 * GetGithubRunnerTokenOut
 * Request model for get GitHub runner token.
 */
export interface GetGithubRunnerTokenOut {
  /** Token */
  token: string;
}

/**
 * GetIntegrationExecutionHistory
 * Schema for integration execution history response.
 */
export interface GetIntegrationExecutionHistory {
  /** Workflow Run Id */
  workflow_run_id: string;
  /** Status type enum. */
  status: StatusTypeEnum;
  /** Count */
  count?: number;
  /** Message */
  message?: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/**
 * GetPipelineFunctions
 * Schemas of function for pipeline get.
 */
export interface GetPipelineFunctions {
  /** Function Id */
  function_id: string;
  /** Name */
  name: string;
  /** Description */
  description?: string;
  /**
   * Tags
   * @default []
   */
  tags?: string[];
  /** Enum for different function operation name. */
  field_operation_type: FuncOperationTypeEnum;
  /**
   * Block
   * @default {}
   */
  block?: object;
  /** Priority */
  priority: number;
  /** Is Shared */
  is_shared: boolean;
}

/**
 * GetPipelineOut
 * Response model for route staus.
 */
export interface GetPipelineOut {
  /** Pipeline Id */
  pipeline_id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Is Passthrough */
  is_passthrough: boolean;
  /**
   * Tags
   * @default []
   */
  tags?: string[];
  /** Enum for different pipeline category. */
  category: PipelineCategoryEnum;
  /** Functions */
  functions: GetPipelineFunctions[];
  /**
   * Created At
   * @format date-time
   */
  created_at?: string;
  /** Created By */
  created_by?: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at?: string;
  /** Updated By */
  updated_by?: string;
}

/**
 * GetRuleOut
 * Response model for get rule by id.
 */
export interface GetRuleOut {
  /** Rule Details */
  rule_details: object;
}

/**
 * GetStackUrlOut
 * Response model for get stack url.
 */
export interface GetStackUrlOut {
  /** Stack Url */
  stack_url: string;
}

/**
 * GetStreamViewOut
 * Response model for get stream view.
 */
export interface GetStreamViewOut {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at?: string;
  /** Created By */
  created_by: string;
  /** Updated By */
  updated_by?: string;
  /** Query */
  query: object[];
  /** Time Selection */
  time_selection: object;
  /** Fieldset Ids */
  fieldset_ids?: string[];
  /** Fields */
  fields?: string[];
}

/** HTTPValidationError */
export interface HTTPValidationError {
  /** Detail */
  detail?: ValidationError[];
}

/**
 * InsightList
 * Response model for insight list.
 */
export interface InsightList {
  /** Insights */
  insights: InsightOut[];
  /** Response Model for Pagination Info. */
  metadata: AppInsightsSchemasPaginationInfo;
}

/**
 * InsightOut
 * Response model for insight.
 */
export interface InsightOut {
  /** Id */
  id: string;
  /**
   * Title
   * @example "Insight title"
   */
  title: string;
  /** @example "open" */
  status: Status;
  /**
   * Created Date
   * @format date-time
   */
  created_date?: string;
  /**
   * Modified Date
   * @format date-time
   */
  modified_date?: string;
  /** Created By */
  created_by: string;
  /** Modified By */
  modified_by?: string;
  /**
   * Assignees
   * @default []
   */
  assignees?: string[];
  /** @example "low" */
  severity: Severity;
  /**
   * Content
   * @example "Detailed investigation description"
   */
  content: string;
  /** @example ["collection"] */
  category: Category[];
  /**
   * Mitre Attack Techniques
   * @default []
   */
  mitre_attack_techniques?: MitreAttackTechnique[];
  /** Count Events */
  count_events?: number;
  /** Organization Id */
  organization_id?: number;
}

/**
 * InsightsMetrics
 * Response model for insight metrics.
 */
export interface InsightsMetrics {
  last_metrics: CountMetrics;
  previous_metrics: CountMetrics;
  percentage_change: PercentageChange;
  /** Reduction Percentage */
  reduction_percentage: number;
  /** Total Insights */
  total_insights: number;
}

/**
 * Integration
 * Integration DB Model.
 */
export interface Integration {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /**
   * Default
   * @default false
   */
  default?: boolean;
  /** Version */
  version: string;
  /** Description */
  description: string;
  /**
   * Scope
   * @default "default"
   */
  scope?: string;
  /**
   * Icon
   * @format binary
   */
  icon: File;
  /** Integration type enum. */
  type: IntegrationTypeEnum;
  /** Integration mode enum. */
  mode: IntegrationModeEnum;
  category: IntegrationCategoryEnum[];
  /**
   * Parameters
   * @default {}
   */
  parameters?: object[];
  /** Redpanda Topic */
  redpanda_topic?: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Ecs Pipelines
   * @default {}
   */
  ecs_pipelines?: object;
  /** Created By */
  created_by?: number;
  /**
   * Archived
   * @default false
   */
  archived?: boolean;
}

/**
 * IntegrationCategoryEnum
 * Integration Category enum.
 */
export enum IntegrationCategoryEnum {
  Api = 'api',
  Authentication = 'authentication',
  Configuration = 'configuration',
  Database = 'database',
  Driver = 'driver',
  Email = 'email',
  File = 'file',
  Host = 'host',
  Iam = 'iam',
  IntrusionDetection = 'intrusion_detection',
  Library = 'library',
  Malware = 'malware',
  Network = 'network',
  Package = 'package',
  Process = 'process',
  Registry = 'registry',
  Session = 'session',
  Threat = 'threat',
  Vulnerability = 'vulnerability',
  Web = 'web',
  Other = 'other'
}

/**
 * IntegrationModeEnum
 * Integration mode enum.
 */
export enum IntegrationModeEnum {
  PULL = 'PULL',
  LISTEN = 'LISTEN',
  TCP = 'TCP',
  UDP = 'UDP'
}

/**
 * IntegrationOut
 * Response model for integration.
 */
export interface IntegrationOut {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Version */
  version: string;
  /** Description */
  description: string;
  /** Scope */
  scope: string;
  /**
   * Icon
   * @format binary
   */
  icon: File;
  /** Integration type enum. */
  type: IntegrationTypeEnum;
  category: IntegrationCategoryEnum[];
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Created By */
  created_by: string;
}

/**
 * IntegrationTypeEnum
 * Integration type enum.
 */
export enum IntegrationTypeEnum {
  EventSource = 'Event Source',
  EventDestination = 'Event Destination',
  AlertForward = 'Alert Forward',
  DataEnrichment = 'Data Enrichment'
}

/** JSONEvent */
export interface JSONEvent {
  /** Event */
  event: object;
}

/** LeaveOrganization */
export interface LeaveOrganization {
  /** Organization Id */
  organization_id: number;
}

/** ListAPIKeysResponse */
export interface ListAPIKeysResponse {
  /** Key Id */
  key_id: number;
  /** Name */
  name: string;
  /** Schema for BasicUser */
  user: BasicUser;
  /**
   * Expiration Date
   * @format date-time
   */
  expiration_date: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/**
 * ListCSVOut
 * Response model for list csv.
 */
export interface ListCSVOut {
  /** File List */
  file_list: UploadCSVOut[];
  /** Response Model for Pagination Info. */
  metadata: AppPipelinesSchemasPaginationInfo;
}

/**
 * ListConfigurationOut
 * Schema for List Configuration Response.
 */
export interface ListConfigurationOut {
  /** Data */
  data?: ConfigurationOut[];
  /** Errors */
  errors?: VendorAccountErrorOut[];
}

/**
 * ListFieldsetsOut
 * Response Model for Events.
 */
export interface ListFieldsetsOut {
  /** Fieldsets */
  fieldsets: CommonFieldSet[];
  /** Response Model for Pagination Info. */
  metadata: AppStreamviewerSchemasPaginationInfo;
}

/**
 * ListFunctionOut
 * Response model for function.
 */
export interface ListFunctionOut {
  /** Function Id */
  function_id: string;
  /** Name */
  name: string;
  /** Description */
  description?: string;
  /** Enum for different function category. */
  category: FunctionCategoryEnum;
  /**
   * Tags
   * @default []
   */
  tags?: string[];
  /** Enum for different function operation name. */
  field_operation_type: FuncOperationTypeEnum;
  /** Block */
  block: object;
  /** Is Shared */
  is_shared?: boolean;
}

/**
 * ListIntegrationOut
 * Response model for list integration.
 */
export interface ListIntegrationOut {
  /** Integrations */
  integrations: IntegrationOut[];
  /** Response Model for Pagination Info. */
  metadata: AppIntegrationsSchemasPaginationInfo;
}

/**
 * ListPipelineOut
 * Response model for list pipelines.
 */
export interface ListPipelineOut {
  /** Pipelines */
  pipelines: PipelineOut[];
  /** Response Model for Pagination Info. */
  metadata: AppPipelinesSchemasPaginationInfo;
}

/**
 * ListStreamViewOut
 * Response model for list stream view
 */
export interface ListStreamViewOut {
  /** Views */
  views: CommanStreamViewOut[];
  /** Response Model for Pagination Info. */
  metadata: AppStreamviewerSchemasPaginationInfo;
}

/** LoginForm */
export interface LoginForm {
  /**
   * Email
   * @default ""
   */
  email?: string;
}

/**
 * MetricsData
 * Schema for dashboard metrics data.
 */
export interface MetricsData {
  /** Schema for dashboard metrics data field. */
  data_reduction: MetricsDataFields;
  /** Schema for dashboard metrics data field. */
  total_findings: MetricsDataFields;
  /** Schema for dashboard metrics data field. */
  data_volume: MetricsDataFields;
}

/**
 * MetricsDataFields
 * Schema for dashboard metrics data field.
 */
export interface MetricsDataFields {
  /**
   * Value
   * @default []
   */
  value?: MetricsDataValueField[];
  /** Rate */
  rate: number;
  /** Total */
  total: number;
}

/**
 * MetricsDataValueField
 * Schema for dashboard metrics data value field.
 */
export interface MetricsDataValueField {
  /** Id */
  id: string;
  /** Type */
  type: string;
  /** Key */
  key: string;
  /** Data */
  data: number;
}

/** MitreAttackTechnique */
export interface MitreAttackTechnique {
  /**
   * Id
   * @example "T1001"
   */
  id: string;
  /**
   * Name
   * @example "Data Obfuscation"
   */
  name: string;
  /**
   * Sub Id
   * @example ".001"
   */
  sub_id: string;
}

/** NewInsightsSettings */
export interface NewInsightsSettings {
  /** Insigth Id */
  insigth_id: string;
  /** @default "hourly" */
  frecuency?: Frequency;
  /** Is Active */
  is_active: boolean;
}

/**
 * NewInvitation
 * Schema for invitations to a new organization.
 *
 * Attributes:
 *     email (str): Email of the user who was invited
 */
export interface NewInvitation {
  /** Email */
  email: string;
}

/**
 * NumericFieldStats
 * Stats for numeric field
 */
export interface NumericFieldStats {
  /** Min */
  min: number;
  /** Max */
  max: number;
  /** Avg */
  avg: number;
}

/** OTP */
export interface OTP {
  /** Code */
  code: string;
}

/**
 * OperationsEnum
 * ACS stream viewer supported operations Enum.
 */
export enum OperationsEnum {
  AFTER = 'AFTER',
  ALL = 'ALL',
  ANY = 'ANY',
  BEFORE = 'BEFORE',
  CONTAINS = 'CONTAINS',
  CONTAINS_KEY = 'CONTAINS_KEY',
  DOES_NOT_CONTAIN = 'DOES_NOT_CONTAIN',
  DOES_NOT_CONTAIN_KEY = 'DOES_NOT_CONTAIN_KEY',
  END_WITH = 'END_WITH',
  EQUALS = 'EQUALS',
  EXTRACT_BOOLEAN = 'EXTRACT_BOOLEAN',
  EXTRACT_FLOAT = 'EXTRACT_FLOAT',
  EXTRACT_STRING = 'EXTRACT_STRING',
  FUZZY_MATCH = 'FUZZY_MATCH',
  GREATER_THAN = 'GREATER_THAN',
  GREATER_THAN_OR_EQUAL = 'GREATER_THAN_OR_EQUAL',
  IN_LIST = 'IN_LIST',
  IN_RANGE = 'IN_RANGE',
  IN_SUBNET = 'IN_SUBNET',
  IS_FALSE = 'IS_FALSE',
  ISRFC1918 = 'IS_RFC1918',
  IS_TRUE = 'IS_TRUE',
  LENGTH = 'LENGTH',
  LESS_THAN = 'LESS_THAN',
  LESS_THAN_OR_EQUAL = 'LESS_THAN_OR_EQUAL',
  NOT_EQUALS = 'NOT_EQUALS',
  NOT_IN_LIST = 'NOT_IN_LIST',
  NOT_IN_SUBNET = 'NOT_IN_SUBNET',
  OUTSIDE_RANGE = 'OUTSIDE_RANGE',
  REGEX = 'REGEX',
  START_WITH = 'START_WITH'
}

/**
 * OrderTypeEnum
 * Order type enum, ASC describes ascending order and DESC describes descending order.
 */
export enum OrderTypeEnum {
  ASC = 'ASC',
  DESC = 'DESC'
}

/** OrganizationDetail */
export interface OrganizationDetail {
  /** Id */
  id: number;
  /** Name */
  name: string;
  /** Nanoid */
  nanoid: string;
  /** Domains */
  domains?: string[];
  /** Picture Url */
  picture_url?: string;
}

/** OrganizationDetailWithUsers */
export interface OrganizationDetailWithUsers {
  organization: OrganizationDetail;
  /** Users */
  users: UserDetailWithRole[];
  /** Invitations */
  invitations: OrganizationInvitationDetail[];
}

/** OrganizationInvitationDetail */
export interface OrganizationInvitationDetail {
  /** Email */
  email: string;
  /** Schema for DetailUserOut.user_db */
  invited_by_user: UserDetail;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Is Active */
  is_active: boolean;
}

/** PasscodeRequest */
export interface PasscodeRequest {
  /** Email */
  email: string;
  /** Org Name */
  org_name: string;
}

/** PercentageChange */
export interface PercentageChange {
  /** Collection */
  collection: number;
  /** Environment */
  environment: number;
  /** Detection */
  detection: number;
}

/** Permission */
export interface Permission {
  /** Id */
  id?: number;
  /** Nanoid */
  nanoid?: string;
  /** Name */
  name: string;
  /** An enumeration. */
  type: PermissionType;
}

/**
 * PermissionType
 * An enumeration.
 */
export enum PermissionType {
  ORGANIZATION = 'ORGANIZATION',
  COMMUNITY = 'COMMUNITY'
}

/**
 * PipelineCategoryEnum
 * Enum for different pipeline category.
 */
export enum PipelineCategoryEnum {
  SOURCE = 'SOURCE',
  DESTINATION = 'DESTINATION',
  ROUTE = 'ROUTE'
}

/**
 * PipelineFunctionStateEnum
 * Enum for different function operation name.
 */
export enum PipelineFunctionStateEnum {
  CREATE = 'CREATE',
  UPDATE = 'UPDATE',
  DELETE = 'DELETE',
  NONE = 'NONE'
}

/**
 * PipelineOut
 * Response model for pipelines.
 */
export interface PipelineOut {
  /** Pipeline Id */
  pipeline_id: string;
  /** Name */
  name: string;
  /**
   * Tags
   * @default []
   */
  tags?: string[];
  /** Description */
  description?: string;
  /** Is Passthrough */
  is_passthrough: boolean;
  /** Enum for different pipeline category. */
  category: PipelineCategoryEnum;
  /** Route Id */
  route_id?: string;
  /**
   * Metrics
   * @default []
   */
  metrics?: object[];
  /**
   * Metrics Io Data
   * @default {}
   */
  metrics_io_data?: object;
}

/** Query */
export interface Query {
  /** Query */
  query: string;
}

/** Reaction */
export interface Reaction {
  /** Reaction Id */
  reaction_id: string;
}

/** RefreshToken */
export interface RefreshToken {
  /** Refresh Token */
  refresh_token: string;
}

/** ResetPassword */
export interface ResetPassword {
  /** Is Tpa */
  is_tpa?: boolean;
  /** Confirmation Code */
  confirmation_code: string;
  /**
   * Password
   * @minLength 8
   * @pattern ^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).*$
   */
  password: string;
}

/**
 * ResponseMessage
 * Schema for response message.
 */
export interface ResponseMessage {
  /** Message */
  message: string;
}

/** RoleDetail */
export interface RoleDetail {
  /** Id */
  id: string;
  /** Nanoid */
  nanoid: string;
  /** Organization Id */
  organization_id: number;
  /** Name */
  name: string;
}

/**
 * RouteIn
 * Request model for create route.
 */
export interface RouteIn {
  /** Source Integration Id */
  source_integration_id: string;
  /** Destination Integration Id */
  destination_integration_id: string;
  /** Vendor Account Id */
  vendor_account_id: string;
  /** Source Configuration Id */
  source_configuration_id: string;
  /** Destination Configuration Id */
  destination_configuration_id: string;
  /** Source Configuration Name */
  source_configuration_name: string;
  /** Destination Configuration Name */
  destination_configuration_name: string;
}

/**
 * RouteOut
 * Response model for create route.
 */
export interface RouteOut {
  /** Route Id */
  route_id: string;
  /** Integration Id */
  integration_id: string;
  /** Source Configuration Id */
  source_configuration_id: string;
  /** Destination Configuration Id */
  destination_configuration_id: string;
  /** Route Pipeline response. */
  source_pipeline: RoutePipelineOut;
  /** Route Pipeline response. */
  route_pipeline: RoutePipelineOut;
  /** Route Pipeline response. */
  destination_pipeline: RoutePipelineOut;
}

/**
 * RoutePipelineOut
 * Route Pipeline response.
 */
export interface RoutePipelineOut {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Is Passthrough */
  is_passthrough: boolean;
  /** Tags */
  tags: string[];
}

/**
 * RuleActionEnum
 * Enum for the rules action type.
 */
export enum RuleActionEnum {
  Realtime = 'realtime',
  Batch = 'batch'
}

/**
 * RuleEventCategories
 * Enum for rules event categories.
 */
export enum RuleEventCategories {
  Api = 'api',
  Authentication = 'authentication',
  Configuration = 'configuration',
  Database = 'database',
  Driver = 'driver',
  Email = 'email',
  File = 'file',
  Host = 'host',
  Iam = 'iam',
  IntrusionDetection = 'intrusion_detection',
  Library = 'library',
  Malware = 'malware',
  Network = 'network',
  Package = 'package',
  Process = 'process',
  Registry = 'registry',
  Session = 'session',
  Threat = 'threat',
  Vulnerability = 'vulnerability',
  Web = 'web'
}

/**
 * RuleIn
 * Request Model for rule creation.
 */
export interface RuleIn {
  /** Name */
  name: string;
  /** Description */
  description?: string;
  /** Tags */
  tags: any[];
  /** Enum for the rule type. */
  type: RuleTypeEnum;
  /** Enum for the rules action type. */
  action: RuleActionEnum;
  /** Enum for the severity. */
  severity: SeverityTypeEnum;
  /** Enum for rule state. */
  state?: RuleStateEnum;
  /** @default [] */
  event_categories?: RuleEventCategories[];
  /**
   * Mitre Attack Techniques
   * @default []
   */
  mitre_attack_techniques?: RuleMitreAttackTechnique[];
  /** Query */
  query: object;
  /** Query Snapshot */
  query_snapshot: any[];
  /** Is Enabled */
  is_enabled: boolean;
}

/** RuleMitreAttackTechnique */
export interface RuleMitreAttackTechnique {
  /** Id */
  id: string;
  /** Name */
  name: string;
}

/**
 * RuleOut
 * Response model for create account.
 */
export interface RuleOut {
  /** Message */
  message: string;
}

/**
 * RuleStateEnum
 * Enum for rule state.
 */
export enum RuleStateEnum {
  Development = 'development',
  Production = 'production'
}

/**
 * RuleTypeEnum
 * Enum for the rule type.
 */
export enum RuleTypeEnum {
  Conditional = 'conditional',
  Sequence = 'sequence'
}

/**
 * RuleUpdateIn
 * Request Model for rule creation.
 */
export interface RuleUpdateIn {
  /** Name */
  name?: string;
  /** Description */
  description?: string;
  /** Tags */
  tags?: any[];
  /** Enum for the rule type. */
  type?: RuleTypeEnum;
  /** Enum for the rules action type. */
  action?: RuleActionEnum;
  /** Enum for the severity. */
  severity?: SeverityTypeEnum;
  /** Enum for rule state. */
  state?: RuleStateEnum;
  event_categories?: RuleEventCategories[];
  /** Mitre Attack Techniques */
  mitre_attack_techniques?: RuleMitreAttackTechnique[];
  /** Query Json */
  query_json?: object;
  /** Query Snapshot */
  query_snapshot?: any[];
  /** Is Enabled */
  is_enabled?: boolean;
}

/**
 * RulesListOut
 * Response model for list rules.
 */
export interface RulesListOut {
  /** Rules */
  rules: any[];
  /** Response Model for Pagination Info. */
  metadata: AppRulesengineSchemasPaginationInfo;
}

/** SessionContext */
export interface SessionContext {
  /** Creation Date */
  creation_date?: string;
  /** Mfa Authenticated */
  mfa_authenticated?: string;
  session_issuer?: SessionIssuer;
}

/** SessionIssuer */
export interface SessionIssuer {
  /** Account Id */
  account_id?: string;
  /** Arn */
  arn?: string;
  /** Principal Id */
  principal_id?: string;
  /** Type */
  type?: string;
}

/**
 * Severity
 * An enumeration.
 */
export enum Severity {
  Info = 'info',
  Low = 'low',
  Medium = 'medium',
  High = 'high',
  Critical = 'critical'
}

/**
 * SeverityTypeEnum
 * Enum for the severity.
 */
export enum SeverityTypeEnum {
  Low = 'low',
  Info = 'info',
  Medium = 'medium',
  High = 'high',
  Critical = 'critical'
}

/** SignUpUser */
export interface SignUpUser {
  /** First Name */
  first_name: string;
  /** Last Name */
  last_name: string;
  /**
   * Email
   * @format email
   */
  email: string;
}

/** SignupForm */
export interface SignupForm {
  /** First Name */
  first_name: string;
  /** Last Name */
  last_name: string;
  /**
   * Email
   * @default ""
   */
  email?: string;
}

/** SourceGeoLocation */
export interface SourceGeoLocation {
  /** Lat */
  lat?: number;
  /** Lon */
  lon?: number;
}

/**
 * Status
 * An enumeration.
 */
export enum Status {
  Closed = 'closed',
  InProgress = 'in-progress',
  Open = 'open'
}

/**
 * StatusEnum
 * Enum for status.
 */
export enum StatusEnum {
  Initiated = 'initiated',
  RunnerInitiated = 'runner_initiated',
  Queued = 'queued',
  InProgress = 'in_progress',
  Completed = 'completed',
  Failure = 'failure'
}

/**
 * StatusTypeEnum
 * Status type enum.
 */
export enum StatusTypeEnum {
  SUCCESSFUL = 'SUCCESSFUL',
  FAILED = 'FAILED'
}

/** SubOperation */
export interface SubOperation {
  /** ACS basic types Enum. */
  field_type: TypeEnum;
  /** ACS stream viewer supported operations Enum. */
  operation: OperationsEnum;
  /**
   * Value
   * @default ""
   */
  value?: string;
  /**
   * Values
   * @default []
   */
  values?: string[];
  /**
   * From Value
   * @default ""
   */
  from_value?: string;
  /**
   * To Value
   * @default ""
   */
  to_value?: string;
  /**
   * Case Sensitive
   * @default false
   */
  case_sensitive?: boolean;
  sub_operation?: SubOperation;
}

/**
 * TagOut
 * Response model for list tags.
 */
export interface TagOut {
  /** Id */
  id: string;
  /** Name */
  name: string;
}

/**
 * TagType
 * Type of tag for organization.
 */
export enum TagType {
  Pipeline = 'pipeline',
  Rule = 'rule',
  Fieldset = 'fieldset'
}

/** Tags */
export interface Tags {
  /** Key */
  key?: string;
  /** Value */
  value?: string;
}

/** TimeSelection */
export interface TimeSelection {
  /** Type */
  type: string;
  /** Numeric Value */
  numeric_value?: number;
  /** Option Selected */
  option_selected?: string;
  /**
   * Start Date
   * @format date-time
   */
  start_date?: string;
  /**
   * End Date
   * @format date-time
   */
  end_date?: string;
  /** From Now Toggle */
  from_now_toggle?: boolean;
}

/**
 * Timeframe
 * Enum for different timeframe of the dashboard.
 */
export enum Timeframe {
  Value1D = '1D',
  Value1W = '1W',
  Value1M = '1M',
  Value3M = '3M',
  Value1Y = '1Y'
}

/**
 * TypeEnum
 * ACS basic types Enum.
 */
export enum TypeEnum {
  Boolean = 'Boolean',
  Coordinate = 'Coordinate',
  Date = 'Date',
  Float64 = 'Float64',
  Ipv4 = 'Ipv4',
  Ipv6 = 'Ipv6',
  String = 'String',
  Nested = 'Nested',
  Object = 'Object',
  StringifyJSON = 'StringifyJSON',
  ListIpv4 = 'List(Ipv4)',
  ListIpv6 = 'List(Ipv6)',
  ListString = 'List(String)'
}

/** UpdateCommentRequest */
export interface UpdateCommentRequest {
  /**
   * Content
   * @example "This is a comment"
   */
  content: string;
}

/** UpdateCurrentOrganization */
export interface UpdateCurrentOrganization {
  /** Organization Id */
  organization_id: number;
}

/**
 * UpdateFieldSet
 * Request model for field set
 */
export interface UpdateFieldSet {
  /** Name */
  name?: string;
  fields?: FieldEnum[];
  /** Description */
  description?: string;
  /** Tags */
  tags?: string[];
  /** Share Level */
  share_level?: string;
}

/**
 * UpdateFunctionIn
 * Request model for update function.
 */
export interface UpdateFunctionIn {
  /** Name */
  name: string;
  /** Description */
  description?: string;
  /**
   * Tags
   * @default []
   */
  tags?: string[];
  /** Enum for different function operation name. */
  field_operation_type: FuncOperationTypeEnum;
  /**
   * Block
   * @default {}
   */
  block?: object;
  /** Old Csv File Id */
  old_csv_file_id?: string;
  /** New Csv File Id */
  new_csv_file_id?: string;
}

/**
 * UpdateFunctionOut
 * Response model for update function.
 */
export interface UpdateFunctionOut {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description?: string;
  /** Tags */
  tags: string[];
  /** Enum for different function operation name. */
  field_operation_type: FuncOperationTypeEnum;
  /** Block */
  block: object;
}

/** UpdateInsightAssigneesRequest */
export interface UpdateInsightAssigneesRequest {
  /**
   * Assignee
   * @example "john_doe@email"
   */
  assignee: string;
}

/** UpdateInsightCategoryRequest */
export interface UpdateInsightCategoryRequest {
  /** @example ["collection"] */
  names: Category[];
}

/** UpdateInsightRequest */
export interface UpdateInsightRequest {
  /**
   * Title
   * @example "Insight title"
   */
  title: string;
  /** @example "low" */
  severity: Severity;
  /**
   * Content
   * @example "Detailed investigation description"
   */
  content: string;
  /** @example "open" */
  status: Status;
}

/** UpdateInsightsSettings */
export interface UpdateInsightsSettings {
  /** An enumeration. */
  frecuency: Frequency;
  /** Is Active */
  is_active: boolean;
}

/**
 * UpdatePipelineFunction
 * Schemas of function for pipeline update.
 */
export interface UpdatePipelineFunction {
  /** Name */
  name: string;
  /**
   * Tags
   * @default []
   */
  tags?: string[];
  /** Description */
  description?: string;
  /** Enum for different function operation name. */
  field_operation_type: FuncOperationTypeEnum;
  /**
   * Block
   * @default {}
   */
  block?: object;
  /** New Csv File Id */
  new_csv_file_id?: string;
  /** Function Id */
  function_id?: string;
  /** Priority */
  priority: number;
  /** Enum for different function operation name. */
  state: PipelineFunctionStateEnum;
  /** Is Shared */
  is_shared: boolean;
  /** Old Csv File Id */
  old_csv_file_id?: string;
}

/**
 * UpdatePipelineIn
 * Request model for pipeline update.
 */
export interface UpdatePipelineIn {
  /** Name */
  name: string;
  /** Description */
  description?: string;
  /** Is Passthrough */
  is_passthrough: boolean;
  /**
   * Tags
   * @default []
   */
  tags?: string[];
  /** Functions */
  functions: UpdatePipelineFunction[];
}

/** UpdateRole */
export interface UpdateRole {
  /** Role Id */
  role_id: number;
  /** Name */
  name: string;
  /** Permissions */
  permissions: string[];
  /** Organization Id */
  organization_id: number;
}

/** UpdateRoleUser */
export interface UpdateRoleUser {
  /** Role Id */
  role_id: number;
  /** Email */
  email: string;
  /** Organization Id */
  organization_id: number;
}

/**
 * UpdateUser
 * Request and response model for updating user profile information .
 */
export interface UpdateUser {
  /** First Name */
  first_name: string;
  /** Last Name */
  last_name: string;
  /** Username */
  username: string;
}

/** UpdateView */
export interface UpdateView {
  /** Name */
  name?: string;
  /** Query */
  query?: object[];
  time_selection?: TimeSelection;
  /** Fieldset Ids */
  fieldset_ids?: string[];
  fields?: FieldEnum[];
}

/**
 * UpdateWorkflowRunIdIn
 * Request model for update run_id for workflow.
 */
export interface UpdateWorkflowRunIdIn {
  /** Run Identifier */
  run_identifier: string;
  /** Run Id */
  run_id: string;
}

/**
 * UploadCSVOut
 * Schema for upload csv response.
 */
export interface UploadCSVOut {
  /** Id */
  id: string;
  /** File Name */
  file_name: string;
}

/** UserApproval */
export interface UserApproval {
  /** Id */
  id: number;
  /** Approved */
  approved: boolean;
  /**
   * Timestamp
   * @format date-time
   */
  timestamp: string;
  /** Requesting User Email */
  requesting_user_email: string;
  /** Approving Admin Email */
  approving_admin_email: string;
}

/**
 * UserCurrentOrganization
 * Schema for DetailUserOut.current_organization
 */
export interface UserCurrentOrganization {
  /** Id */
  id: number;
  /** Name */
  name: string;
  /** Domains */
  domains: string[];
  /** Schema for UserCurrentOrganization.role */
  role: UserRole;
  /** Picture Url */
  picture_url?: string;
}

/**
 * UserDetail
 * Schema for DetailUserOut.user_db
 */
export interface UserDetail {
  /** Id */
  id: number;
  /** Username */
  username: string;
  /** First Name */
  first_name?: string;
  /** Last Name */
  last_name?: string;
  /** Picture Url */
  picture_url?: string;
  /** Is Active */
  is_active: boolean;
  /** Email */
  email: string;
}

/**
 * UserDetailWithRole
 * Schema for UserDetailWithRole
 */
export interface UserDetailWithRole {
  /** Schema for DetailUserOut.user_db */
  user: UserDetail;
  role: RoleDetail;
  /** Enabled */
  enabled: boolean;
}

/** UserIdentity */
export interface UserIdentity {
  /** Access Key Id */
  access_key_id?: string;
  /** Arn */
  arn?: string;
  session_context?: SessionContext;
  /** Type */
  type?: string;
}

/**
 * UserRole
 * Schema for UserCurrentOrganization.role
 */
export interface UserRole {
  /** Id */
  id: number;
  /** Name */
  name: string;
}

/**
 * ValidateConfiguration
 * Schema for validate configuration request.
 */
export interface ValidateConfiguration {
  /** Vendor Account Id */
  vendor_account_id: string;
  /** Name */
  name: string;
  /** Integration Id */
  integration_id: string;
  /** Parameters */
  parameters: object;
}

/**
 * ValidateConfigurationOut
 * Schema for Validate configuration response.
 */
export interface ValidateConfigurationOut {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
}

/** ValidationError */
export interface ValidationError {
  /** Location */
  loc: (string | number)[];
  /** Message */
  msg: string;
  /** Error Type */
  type: string;
}

/**
 * VendorAccountErrorOut
 * Schema for Common Vendor Account error Response.
 */
export interface VendorAccountErrorOut {
  /** Vendor Account Name */
  vendor_account_name: string;
  /** Status Code */
  status_code: number;
  /** Error */
  error: string;
}

/**
 * VendorAccountIn
 * Request model for get stack url.
 *
 * account_id: required for the AWS Cloud Provider
 * azure_tenant_id, subscription_id: required for the Azure Cloud Provider
 */
export interface VendorAccountIn {
  /** Cloud Provider */
  cloud_provider: 'AWS' | 'Azure';
  /** Region */
  region: string;
  /** Tenant Name */
  tenant_name: string;
  /** Account Id */
  account_id?: string;
  /**
   * Tenant Size
   * @default "small"
   */
  tenant_size?: 'xsmall' | 'small' | 'medium' | 'large' | 'xlarge';
  /** Azure Tenant Id */
  azure_tenant_id?: string;
  /** Subscription Id */
  subscription_id?: string;
}

/**
 * VendorAccountOut
 * Response model for list vendor account.
 */
export interface VendorAccountOut {
  /** Id */
  id: number;
  /** Nanoid */
  nanoid: string;
  /** Name */
  name?: string;
  /** Size */
  size?: string;
  /** Organization Id */
  organization_id?: number;
  /** Account Details */
  account_details?: object;
  /** Apply Latest Release */
  apply_latest_release?: boolean;
  /** Current Commit Id */
  current_commit_id?: string;
  /** Current Ava Version */
  current_ava_version?: string;
  /** Stack Details */
  stack_details?: object;
  /** Vendor Id */
  vendor_id?: number;
  /**
   * Created At
   * @format date-time
   */
  created_at?: string;
  /** Created By */
  created_by?: number;
  /**
   * Updated At
   * @format date-time
   */
  updated_at?: string;
  /** Updated By */
  updated_by?: number;
  /**
   * Status
   * @default []
   */
  status?: VendorAccountStatus[];
  /** Data Stored */
  data_stored?: string;
}

/**
 * VendorAccountStatus
 * Response model for get list tenant account.
 */
export interface VendorAccountStatus {
  /** Vendor Account Id */
  vendor_account_id?: string;
  /** Enum for different workflows. */
  workflow?: WorkflowTypeEnum;
  /** Workflow Run Id */
  workflow_run_id?: string;
  /** Enum for status. */
  status?: StatusEnum;
  /** Error Details */
  error_details?: object;
}

/**
 * VendorAccountStatusOut
 * Response model for get list tenant account.
 */
export interface VendorAccountStatusOut {
  /** Status */
  status: object;
}

/**
 * WorkflowTypeEnum
 * Enum for different workflows.
 */
export enum WorkflowTypeEnum {
  Onboard = 'onboard',
  Upgrade = 'upgrade',
  Offboard = 'offboard'
}

/**
 * PaginationInfo
 * Response Model for Pagination Info.
 */
export interface AppInsightsSchemasPaginationInfo {
  /** Total Count */
  total_count: number;
  /** Page Size */
  page_size: number;
  /** Page Number */
  page_number: number;
}

/**
 * PaginationInfo
 * Response Model for Pagination Info.
 */
export interface AppIntegrationsSchemasPaginationInfo {
  /** Total Count */
  total_count: number;
  /** Page Size */
  page_size: number;
  /** Page Number */
  page_number: number;
}

/**
 * GetFilterValuesOut
 * Response model for filters Values.
 */
export interface AppPipelinesSchemasGetFilterValuesOut {
  /**
   * Tags
   * @default []
   */
  tags?: string[];
}

/**
 * PaginationInfo
 * Response Model for Pagination Info.
 */
export interface AppPipelinesSchemasPaginationInfo {
  /** Total Count */
  total_count: number;
  /** Page Size */
  page_size: number;
  /** Page Number */
  page_number: number;
}

/**
 * GetFilterValuesOut
 * Response model for get filter values.
 */
export interface AppRulesengineSchemasGetFilterValuesOut {
  /** Types */
  types: any[];
  /** Tags */
  tags: any[];
  /** Severity */
  severity: any[];
  /** Mitre Attack Techniques */
  mitre_attack_techniques?: object;
  /** State */
  state?: any[];
  /** Event Categories */
  event_categories?: any[];
}

/**
 * PaginationInfo
 * Response Model for Pagination Info.
 */
export interface AppRulesengineSchemasPaginationInfo {
  /** Total Count */
  total_count: number;
  /** Page Size */
  page_size: number;
  /** Page Number */
  page_number: number;
}

/**
 * PaginationInfo
 * Response Model for Pagination Info.
 */
export interface AppStreamviewerSchemasPaginationInfo {
  /** Total Count */
  total_count: number;
  /** Page Size */
  page_size: number;
  /** Page Number */
  page_number: number;
}
