import axios, { AxiosResponse } from 'axios';

// This is to allow cookies to be sent with the request
axios.defaults.withCredentials = true;

const AUTH = '/v2/auth';

export type MessageType = {
  message: string;
};

export const BASE_URL = import.meta.env.VITE_API_URL;

export const api = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

export const refreshApi = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

export const frontEggAuthRefreshToken = (): Promise<AxiosResponse> => {
  return refreshApi.get(`${AUTH}/refresh`);
};

export const validateErrorDetails = [
  'Not authenticated',
  'Expired token',
  'Invalid Token',
  'Invalid refresh token',
  'Refresh token error'
];

export const USER_NOT_ACTIVE = 'Inactive user';

api.interceptors.response.use(
  response => {
    return response;
  },
  async error => {
    if (
      error.response?.status === 401 &&
      validateErrorDetails.includes(error.response?.data?.detail)
    ) {
      // Call here googleAuth & MicrosoftAuth to refresh token
      try {
        const refreshResponse = await frontEggAuthRefreshToken();
        if (refreshResponse?.status === 200) {
          try {
            return await axios.request({
              baseURL: error.config.baseURL,
              method: error.config.method,
              url: error.config.url,
              data: error.config.data
            });
          } catch (e) {
            return Promise.reject(e);
          }
        } else {
          // should not reach here.
          return refreshResponse;
        }
      } catch (e) {
        return Promise.reject(e);
      }
    }
    return Promise.reject(error);
  }
);
