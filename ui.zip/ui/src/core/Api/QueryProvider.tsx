import { FC, useMemo, PropsWithChildren } from 'react';
import { useNavigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';

export const QueryProvider: FC<PropsWithChildren> = ({ children }) => {
  const navigate = useNavigate();

  const client = useMemo(() => {
    const queryClient = new QueryClient({
      defaultOptions: {
        queries: {
          refetchOnWindowFocus: false,
          onError: (error: any) => {
            // TODO: Handle w/ notification
            console.error(`Query error: ${error.message}`);
          }
        },
        mutations: {
          onError: (error: any) => {
            // TODO: Handle w/ notification
            console.error(`Mutation error: ${error.message}`);
          }
        }
      }
    });

    return queryClient;
  }, []);

  return <QueryClientProvider client={client}>{children}</QueryClientProvider>;
};
