import { EventsData } from 'App/Views/View.type';
import { api } from './BaseApi';

const AI_BASE_URL = 'ai';

export type Query = { query: string };

export enum AIJobStatus {
  IN_PROGRESS = 'in_progress',
  COMPLETE = 'complete',
  CANCELLED = 'cancelled',
  ERROR = 'error'
}

export type AIJobResponse = {
  status: AIJobStatus;
  job_id: string;
  data: any;
};

export const queryListPipelines = async (
  query: Query
): Promise<AIJobResponse> => {
  const response = await api.post(`${AI_BASE_URL}/query/list-pipelines`, query);
  return response.data;
};

export const queryListStreams = async (
  query: Query
): Promise<AIJobResponse> => {
  const response = await api.post(`${AI_BASE_URL}/query/list-streams`, query);
  return response.data;
};

export const queryListRules = async (query: Query): Promise<AIJobResponse> => {
  const response = await api.post(`${AI_BASE_URL}/query/list-rules`, query);
  return response.data;
};

export const jobStatus = async (job_id: string): Promise<AIJobResponse> => {
  const response = await api.get(`${AI_BASE_URL}/status/${job_id}`);
  return response.data;
};

export const describeEvent = async (
  event: EventsData
): Promise<AIJobResponse> => {
  const response = await api.post(`${AI_BASE_URL}/describe-event`, event);
  return response.data;
};
