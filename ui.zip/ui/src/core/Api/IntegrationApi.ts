import { api } from './BaseApi';
import { DeleteIntegrationOut, Integration } from './types';

import { formatDuration } from 'reablocks';

import { ListIntegrationType } from 'App/Integrations/Integration.types';

const INTEGRATION_BASE_URL = '/v1/integrations';

export interface Field {
  key: string;
  type: string;
  label: string;
  default: string;
  mandatory: boolean;
  description: string;
  min?: number;
  max?: number;
}

export interface DynamicStepTypes {
  name: string;
  type: string;
  label: string;
  fields: Field[];
  description: string;
}

export interface IntegrationDynamicSteps extends Integration {
  // needs to be extended since OpenAPI doesn't support and declared as generic object[] type
  parameters?: DynamicStepTypes[];
}

// Services
export const getAvailableIntegration = async (
  constructedUrl: string
): Promise<ListIntegrationType> => {
  const response = await api.get(`${INTEGRATION_BASE_URL}/${constructedUrl}`);
  return response.data;
};

export const getIntegrationById = async (
  id: string
): Promise<IntegrationDynamicSteps> => {
  const response = await api.get(`${INTEGRATION_BASE_URL}/${id}`);
  return response.data;
};

export const downloadIntegration = async (id: string): Promise<Blob> => {
  const response = await api.get(`${INTEGRATION_BASE_URL}/export/${id}`, {
    responseType: 'blob'
  });
  return response.data;
};

export const deleteIntegration = async (
  id: string
): Promise<DeleteIntegrationOut> => {
  const response = await api.delete(`${INTEGRATION_BASE_URL}/${id}`);
  return response.data;
};

export const postIntegration = async (file, callBackProgress) => {
  const startTime = Date.now(); // Record the start time of the upload

  const config = {
    onUploadProgress: progressEvent => {
      const { loaded, total } = progressEvent;

      // Calculate the progress percentage
      const percentage = (loaded * 100) / total;

      // Calculate the progress duration
      const timeElapsed = Date.now() - startTime;
      const uploadSpeed = loaded / timeElapsed;
      const duration = (total - loaded) / uploadSpeed;

      callBackProgress({
        estimatedTimeRemaining: formatDuration(duration, '0 s'),
        percentage: percentage.toFixed(2)
      });
    },
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  };
  const response = await api.post(`${INTEGRATION_BASE_URL}/`, file, config);
  return response.data;
};
