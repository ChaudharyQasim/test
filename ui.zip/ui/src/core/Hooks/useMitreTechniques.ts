import { useQuery } from 'react-query';

// Core
import { getMITRETechniques } from 'core/Api/InsightsApi';

// Types
import { MitreTechniqueType } from 'shared/data/MitreTechniques/MitreTechniques.types';

export const useMitreTechniques = () => {
  const { data: techniques, isLoading } = useQuery(
    'techniques',
    () => getMITRETechniques(),
    {
      initialData: {
        enterprise: [],
        ics: [],
        mobile: []
      }
    }
  );

  /**
   * @description Group techniques by id and add checked property
   */
  const groupTechniques = (
    type: string = 'enterprise'
  ): MitreTechniqueType[] => {
    return techniques[type].reduce(
      (acc: MitreTechniqueType[], technique: MitreTechniqueType) => {
        const { id } = technique;
        if (!acc[id]) {
          acc[id] = [];
        }
        acc[id].push({ ...technique, checked: false });
        return acc;
      },
      {} as { [key: string]: any }
    );
  };

  /**
   * @description Format techniques to add subgroups
   * like this: { id: 'T1234', name: 'Technique', subgroups: [{ id: '.001', name: 'Subgroup' }] }
   */
  const formatTechniques = (type: string): MitreTechniqueType[] => {
    const groupedTechniques = groupTechniques(type);
    return Object.keys(groupedTechniques).map(key => {
      const mainTechnique = groupedTechniques[key].find(
        (technique: any) => !technique.sub_id
      );
      const subgroups = groupedTechniques[key].filter(
        (technique: any) => technique.sub_id
      );
      return {
        ...mainTechnique,
        subgroups
      };
    });
  };

  if (isLoading) {
    return {
      techniques: () => [],
      isLoading: isLoading
    };
  }

  return {
    techniques: formatTechniques,
    isLoading: isLoading
  };
};
