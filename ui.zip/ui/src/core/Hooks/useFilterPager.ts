import { useRef } from 'react';
import {
  NumberParam,
  StringParam,
  useQueryParam,
  withDefault
} from 'use-query-params';
import rison from 'rison';
import isEqual from 'react-fast-compare';
import { useUpdateEffect } from 'react-use';

export interface FilterPagerResult {
  page: number;
  setPage: (page: number) => void;
  keyword: string;
  setKeyword: (keyword: string) => void;
  filter: any;
  setFilter: (filter: any) => void;
}

/**
 * @description This hook is used to manage the filter and pager state
 * in the URL. It uses the use-query-params library to manage the state
 */
export const useFilterPager = () => {
  const [page, setPage] = useQueryParam('page', withDefault(NumberParam, 0));
  const mounted = useRef<boolean>(false);

  const [keyword, setKeyword] = useQueryParam(
    'keyword',
    withDefault(StringParam, '')
  );

  /**
   * @description This is the filter state. It uses rison to encode/decode
   * the state into the URL, and uses react-fast-compare to compare the
   * state to prevent unnecessary re-renders
   */
  const [filter, setFilter] = useQueryParam<any>('filter', {
    equals: isEqual,
    encode(value: any) {
      if (value) {
        return rison.encode(value);
      }
    },
    decode(strValue?: any) {
      if (strValue) {
        return rison.decode(strValue);
      }
    }
  });

  // useUpdateEffect skips the first render so if page is passed in
  // it will keep the page set instead of resetting to 0
  useUpdateEffect(() => {
    // If the user changes the filter,
    // we should reset the page to 0
    if (mounted.current) {
      setPage(0);
    } else {
      mounted.current = true;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  return {
    page,
    setPage,
    keyword,
    setKeyword,
    filter,
    setFilter
  } as FilterPagerResult;
};
