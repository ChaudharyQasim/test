import { useCallback, useEffect, useState } from 'react';
import {
  AIJobStatus,
  AIJobResponse,
  queryListPipelines,
  queryListRules,
  queryListStreams,
  jobStatus
} from 'core/Api/AIApi';
import { useNotification } from 'reablocks';

export enum SmartFilterEnum {
  PIPELINES = 'pipelines',
  RULES = 'rules',
  STREAMS = 'streams'
}

type SmartFilterParams = {
  smartFilterType: SmartFilterEnum;
  query: string;
  submitJob: boolean;
};

const filterApiMap = {
  [SmartFilterEnum.PIPELINES]: queryListPipelines,
  [SmartFilterEnum.RULES]: queryListRules,
  [SmartFilterEnum.STREAMS]: queryListStreams
};

const initialState: AIJobResponse = {
  status: AIJobStatus.IN_PROGRESS,
  data: null,
  job_id: null
};

type useFilterType = {
  isAiJobInProgress: boolean;
  smartFilterState: AIJobResponse;
};

export const useSmartFilter = (params: SmartFilterParams): useFilterType => {
  const [smartFilterState, setSmartFilterState] =
    useState<AIJobResponse>(initialState);
  const [isAiJobInProgress, setIsAiJobInProgress] = useState<boolean>(false);
  const { notifyError } = useNotification();

  const getFilter = useCallback(async () => {
    try {
      const initialResponse: AIJobResponse = await filterApiMap[
        params.smartFilterType
      ]({ query: params.query });
      const jobId = initialResponse.job_id;
      let isCancelled: boolean = false;

      while (!isCancelled) {
        const statusResponse: AIJobResponse = await jobStatus(jobId);
        if (statusResponse.status === AIJobStatus.CANCELLED) {
          isCancelled = true;
          setIsAiJobInProgress(false);
          setSmartFilterState(statusResponse);
          break;
        }
        if (statusResponse.status !== AIJobStatus.IN_PROGRESS) {
          if (
            typeof statusResponse.data === 'string' &&
            statusResponse.status === AIJobStatus.ERROR
          ) {
            notifyError('Query could not be resolved');
          } else {
            setSmartFilterState(statusResponse);
          }

          setIsAiJobInProgress(false);
          break;
        }
        await new Promise(res => setTimeout(res, 1000));
      }
    } catch (error) {
      if (smartFilterState.status !== AIJobStatus.CANCELLED) {
        return error as Error;
      }
    }
  }, [
    params.query,
    params.smartFilterType,
    smartFilterState,
    notifyError,
    setIsAiJobInProgress,
    setSmartFilterState
  ]);

  useEffect(() => {
    if (params.submitJob && params.query !== '') {
      setIsAiJobInProgress(true);
      setSmartFilterState(initialState);
      getFilter();
    }
  }, [params.submitJob, params.query, getFilter]);

  return { smartFilterState, isAiJobInProgress };
};
