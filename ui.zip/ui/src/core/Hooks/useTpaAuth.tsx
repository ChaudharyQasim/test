import { SocialAuthProviders } from '../Api/AuthApi';

/**
 * @description This hook is used to handle the authentication for the TPA's
 * it returns a function that handles the Google & Microsoft authentication
 * through the FrontEgg API
 */
export const useTpaAuth = (): {
  microsoftAuth: () => void;
  googleAuth: () => void;
} => {
  const microsoftInstanceHandler = async () => {
    const MICROSOFT_URL = new URL(
      `${import.meta.env.VITE_API_URL}/v2/auth/social`
    );
    MICROSOFT_URL.searchParams.append(
      'provider',
      SocialAuthProviders.MICROSOFT
    );
    window.location.href = MICROSOFT_URL.toString();
  };

  const googleInstanceHandler = async (): Promise<void> => {
    const GOOGLE_URL = new URL(
      `${import.meta.env.VITE_API_URL}/v2/auth/social`
    );
    GOOGLE_URL.searchParams.append('provider', SocialAuthProviders.GOOGLE);
    window.location.href = GOOGLE_URL.toString();
  };

  return {
    microsoftAuth: microsoftInstanceHandler,
    googleAuth: googleInstanceHandler
  };
};
