import { useEffect, type RefObject } from 'react';

export function useResizeObserver(
  ref: RefObject<HTMLElement | null>,
  onResize: ([width, height]: [number, number]) => any
) {
  useEffect(() => {
    const element = ref.current;

    if (!element) {
      return console.warn('ResizeObserver instantiation error.');
    }

    const observer = new ResizeObserver(
      ([
        {
          contentRect: { width, height }
        }
      ]) => {
        onResize?.([width, height]);
      }
    );

    observer.observe(element);

    return () => {
      if (element) {
        observer?.unobserve(element);
      }

      observer?.disconnect();
    };
  }, [onResize, ref]);
}
