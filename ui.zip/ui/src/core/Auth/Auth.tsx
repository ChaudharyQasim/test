import React, {
  FC,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState
} from 'react';
import Cookies from 'js-cookie';

// Context
import { AuthProvider, LoginParams } from './AuthContext';

// Api service
import { isAxiosError } from 'axios';
import { api, refreshApi, validateErrorDetails } from 'core/Api';
import { getSignOut, getVerifyAuth } from 'core/Api/AuthApi';
import { getUser } from 'core/Api/UserApi';

// Hooks
import { useTpaAuth } from 'core/Hooks/useTpaAuth';

const SESSION_LENGTH = 24 * 60 * 60 * 1000; // Session duration in milliseconds

export const Auth: FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<any>(null);
  const [isLoggingOut, setIsLoggingOut] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  const timerIdRef = useRef<NodeJS.Timeout | null>(null);

  const { microsoftAuth, googleAuth } = useTpaAuth();

  refreshApi.interceptors.response.use(
    response => {
      return response;
    },
    async error => {
      removeCredentials();
      return Promise.reject(error);
    }
  );

  /**
   * @description This function is used to check if the user exists in the database
   * if the user doesn't exist it will create it
   */
  const onCheckTpaUser = useCallback(
    async (email: string, firstName: string, lastName: string) => {
      try {
        await api.post('/users/sign-tpa', {
          email: email,
          first_name: firstName,
          last_name: lastName
        });
      } catch (error) {
        console.error('Failed to check TPA', error);
      }
    },
    []
  );

  /**
   * @description This object is used to handle the different types of authentication
   */
  const onHandlerAuth = useMemo(
    () => ({
      microsoft: async function () {
        microsoftAuth();
      },
      google: function () {
        googleAuth();
      },
      frontEgg: async () => {
        await getUserDetails();
        setIsAuthenticated(true);
      }
    }),
    [googleAuth, microsoftAuth]
  );

  const login = useCallback(
    ({ type }: LoginParams): void => {
      const authType = onHandlerAuth[type];
      authType();
      localStorage.setItem('tokenType', type);
    },
    [onHandlerAuth]
  );

  /**
   * @description Used when using getSignOut() is not available due to expired credentials
   *  and have to force logout on UI side
   */
  const removeCredentials = useCallback(() => {
    setUser(null);
    setIsAuthenticated(false);
    setIsLoading(false);
  }, []);

  const logout = useCallback(async () => {
    setIsLoggingOut(true);
    try {
      await getSignOut();
      removeCredentials();
      setIsLoggingOut(false);
    } catch (error) {
      setIsLoggingOut(false);
      removeCredentials();
    }
  }, [removeCredentials]);

  const filterTokenError = useCallback(
    (error: any) => {
      if (
        isAxiosError(error) &&
        validateErrorDetails.includes(error?.response?.data?.detail)
      ) {
        return;
      }
      removeCredentials();
    },
    [removeCredentials]
  );

  const getUserDetails = useCallback(async () => {
    setIsLoading(true);
    try {
      const loggedUser = await getVerifyAuth();
      setUser(loggedUser.data);
      setIsLoading(false);
      setIsAuthenticated(true);
    } catch (error) {
      filterTokenError(error);
    }
  }, [filterTokenError]);

  const refreshUser = useCallback(async () => {
    try {
      const userLogged = await getUser();
      setUser(userLogged);
    } catch (error) {
      filterTokenError(error);
    }
  }, [filterTokenError]);

  const resetSessionTimer = useCallback(() => {
    const storedTimeStamp = Cookies.get('lastInteractionTimestamp');

    if (!storedTimeStamp) {
      removeCredentials();
      return;
    }

    const remainingTime =
      SESSION_LENGTH - (Date.now() - parseInt(storedTimeStamp, 10));

    if (remainingTime <= 0) {
      removeCredentials();
    } else {
      startSessionTimer(remainingTime);
    }
  }, [removeCredentials]); // eslint-disable-line react-hooks/exhaustive-deps

  const startSessionTimer = useCallback(
    (remainingTime: number = SESSION_LENGTH) => {
      if (timerIdRef.current !== null) {
        clearTimeout(timerIdRef.current);
      }
      timerIdRef.current = setTimeout(resetSessionTimer, remainingTime);
    },
    [timerIdRef, resetSessionTimer]
  );

  /**
   * @description Sets the user's last interaction timestamp in a cookie
   */
  const handleUserInteraction = useCallback(() => {
    const now = Date.now().toString();
    document.cookie = `lastInteractionTimestamp=${now};max-age=${
      SESSION_LENGTH / 1000
    }`;
  }, []);

  const cleanUpSession = useCallback(() => {
    clearTimeout(timerIdRef.current);
    document.cookie = `lastInteractionTimestamp=;max-age=${0}`;
    document.removeEventListener('keydown', handleUserInteraction);
    document.removeEventListener('click', handleUserInteraction);
  }, [timerIdRef, handleUserInteraction]);

  useEffect(() => {
    if (isAuthenticated) {
      const now = Date.now().toString();
      document.cookie = `lastInteractionTimestamp=${now};max-age=${
        SESSION_LENGTH / 1000
      }`;

      document.addEventListener('keydown', handleUserInteraction);
      document.addEventListener('click', handleUserInteraction);

      startSessionTimer();
    } else {
      cleanUpSession();
    }

    return () => {
      cleanUpSession();
    };
  }, [
    isAuthenticated,
    handleUserInteraction,
    cleanUpSession,
    startSessionTimer
  ]);

  useEffect(() => {
    async function setupUser() {
      if (import.meta.env.PROD) {
        // Put things like sentry/fullstory boot here
      }
    }

    if (user === null && !isAuthenticated) {
      getUserDetails();
    }

    // If we got the auth0 user, and we are not already loading the user
    if (user) {
      setupUser();
    }
  }, [isAuthenticated, user]);

  const values = useMemo(
    () => ({
      user,
      login,
      isLoading,
      isAuthenticated,
      logout,
      refreshUser,
      isLoggingOut
    }),
    [isAuthenticated, isLoading, login, logout, user, refreshUser, isLoggingOut]
  );

  return <AuthProvider value={values}>{children}</AuthProvider>;
};
