import { FC, useEffect } from 'react';
import {
  Navigate,
  Outlet,
  RouteProps,
  useLocation,
  useNavigate
} from 'react-router-dom';
import { useAuth } from './AuthContext';
import { Loader } from 'shared/elements/Loader';

export const paths = ['', '/', '/login', '/logout', '/pending-approval'];
export const PREV_ROUTE = 'PREV_ROUTE';

export const AuthRoute: FC<RouteProps> = () => {
  const { isAuthenticated, isLoading, user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const prevRoute = window.localStorage.getItem(PREV_ROUTE);
  const pathname = location.pathname + location.search;
  const isOauthRoute = pathname.includes('/oauth');

  const shouldSavePrevRoute =
    pathname &&
    prevRoute !== pathname &&
    !paths.includes(pathname) &&
    !isOauthRoute;

  useEffect(() => {
    if (
      isAuthenticated &&
      user?.current_organization?.name !== 'default' &&
      prevRoute &&
      pathname !== prevRoute
    ) {
      window.localStorage.removeItem(PREV_ROUTE);
      navigate(prevRoute);
    }
  }, [isAuthenticated, user, prevRoute, pathname, navigate]);

  if (!isAuthenticated && !isLoading) {
    if (shouldSavePrevRoute) {
      window.localStorage.setItem(PREV_ROUTE, pathname);
    }

    return <Navigate to="/login" replace />;
  }

  if (isLoading) {
    return <Loader />;
  }

  return <Outlet />;
};
