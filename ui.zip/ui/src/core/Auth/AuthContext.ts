import { createContext, useContext } from 'react';

// Types
export type LoginParams = {
  type: 'google' | 'microsoft' | 'frontEgg';
};

export interface AuthContextProps {
  user: any | null;
  isAuthenticated?: boolean;
  isLoading?: boolean;
  login: ({ type }: LoginParams) => void;
  logout: () => void;
  refreshUser: () => void;
  isLoggingOut?: boolean;
}

export const AuthContext = createContext<AuthContextProps>({
  user: null,
  login: () => undefined,
  logout: async () => undefined,
  refreshUser: async () => undefined,
  isLoggingOut: false
});

export const { Provider: AuthProvider, Consumer: AuthConsumer } = AuthContext;

export const useAuth = () => {
  const context = useContext(AuthContext);

  if (context === undefined) {
    throw new Error(
      '`useAuth` hook must be used within a `AuthProvider` component'
    );
  }

  return context;
};
