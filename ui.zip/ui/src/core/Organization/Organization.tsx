import React, { FC, useCallback, useMemo } from 'react';
import { useNotification } from 'reablocks';
import { useNavigate } from 'react-router-dom';
import { useQuery } from 'react-query';

// Context
import { OrganizationProvider } from './OrganizationContext';

// Core
import { useAuth } from 'core/Auth';
import {
  getUserOrganizations,
  PermissionObjectType,
  getPermissions,
  updateCurrentOrganization,
  getOrganizationById
} from 'core/Api/OrganizationApi';
import { Permission } from 'core/Api';

// Shared
import { errorHandler } from 'shared/utils/Helper';

export const Organization: FC<{ children: React.ReactNode }> = ({
  children
}) => {
  const { user } = useAuth();

  const navigate = useNavigate();

  const { notifyError } = useNotification();

  const {
    data: organizationList,
    refetch: refetchUserOrganizations,
    isLoading: isOrganizationLoading
  } = useQuery(
    ['organizationList', user],
    () => getUserOrganizations({ id: user.id }),
    {
      enabled: !!user && user.is_active
    }
  );

  const { data: permissions } = useQuery(
    ['permissions', user],
    getPermissions,
    {
      enabled: !!user && user.is_active
    }
  );

  const { data: currentOrganization } = useQuery(
    'organizationbyid',
    () => getOrganizationById(user.current_organization.id),
    {
      enabled: !!user && user.is_active
    }
  );

  const fetchCurrentOrganization = useCallback(
    async (organization_id: number): Promise<void> => {
      if (!user) {
        return;
      }
      try {
        await updateCurrentOrganization({
          patchData: {
            organization_id: organization_id
          }
        });
        navigate('/dashboard', { replace: true });
        window.location.reload();
      } catch (error) {
        notifyError(errorHandler(error));
      }
    },
    [user, navigate, notifyError]
  );

  const getPermissionsFormarted = useCallback(
    (permissions: Permission[]): PermissionObjectType => {
      if (!user || !permissions) {
        return {};
      }
      const orgPermissions = user.permissions.map(
        (permission: Permission) => permission.name
      );

      const formatPermissions = permissions.reduce((acc, permission) => {
        acc[permission.name] = orgPermissions.includes(permission.name);
        return acc;
      }, {});

      formatPermissions['is_admin'] =
        user.current_organization.role.name === 'admin';
      return formatPermissions;
    },
    [user]
  );

  const values = useMemo(
    () => ({
      organizationList,
      permissions: getPermissionsFormarted(permissions),
      isOrganizationLoading,
      currentOrganization,
      fetchOrganizationList: refetchUserOrganizations,
      fetchCurrentOrganization
    }),
    [
      isOrganizationLoading,
      fetchCurrentOrganization,
      refetchUserOrganizations,
      organizationList,
      permissions,
      currentOrganization,
      getPermissionsFormarted
    ]
  );

  return <OrganizationProvider value={values}>{children}</OrganizationProvider>;
};
