import { createContext, useContext } from 'react';

// Types
import {
  OrganizationDetailType,
  PermissionObjectType,
  UserOrganizationType
} from 'core/Api/OrganizationApi';
import {
  QueryObserverResult,
  RefetchOptions,
  RefetchQueryFilters
} from 'react-query';

export interface OrganizationContextProps {
  organizationList: UserOrganizationType[] | null;
  permissions: PermissionObjectType | null;
  isOrganizationLoading?: boolean;
  fetchOrganizationList: <TPageData>(
    options?: RefetchOptions & RefetchQueryFilters<TPageData>
  ) => Promise<QueryObserverResult<UserOrganizationType[], unknown>>;
  fetchCurrentOrganization: (org_id: number) => Promise<void>;
  currentOrganization: OrganizationDetailType | null;
}

export const OrganizationContext = createContext<OrganizationContextProps>({
  organizationList: null,
  permissions: null,
  isOrganizationLoading: false,
  currentOrganization: null,
  fetchCurrentOrganization: async () => undefined,
  fetchOrganizationList: async () => undefined
});

export const {
  Provider: OrganizationProvider,
  Consumer: OrganizationConsumer
} = OrganizationContext;

export const useOrganization = () => {
  const context = useContext(OrganizationContext);

  if (context === undefined) {
    throw new Error(
      '`useOrganization` hook must be used within a `AuthProvider` component'
    );
  }

  return context;
};
