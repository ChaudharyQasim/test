import { FC, useState } from 'react';
import { Button, MotionGroup, MotionItem } from 'reablocks';

// Components
import { Pager } from 'shared/data/Pager';
import { EmptyState } from 'shared/elements/EmptyState';
import { Loader } from 'shared/elements/Loader';
import { ConfirmationDialog } from 'shared/layers/ConfirmationDialog';

import { AvailableIntegrationType } from '../Integration.types';
import { AvailableIntegrationCard } from './AvailableIntegrationCard';

import css from './AvailableIntegration.module.css';

import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import { ReactComponent as EmptyIllustration } from 'assets/illustrations/empty-list.svg';
import classNames from 'classnames';
import { useNavigate } from 'react-router-dom';

export const AvailableIntegration: FC<AvailableIntegrationType> = ({
  tabLoader,
  availableIntegration,
  currentPage,
  isFilterApplied,
  isTenantAvailable,
  setPage,
  downloadIntegrationMutation,
  handleUploadIntegration,
  fetchIntegrationById,
  configureIntegration,
  handleChipClick,
  deleteIntegrationMutation
}) => {
  const { integrations, metadata } = availableIntegration || {};

  const navigate = useNavigate();

  const [idToDelete, setIdToDelete] = useState<string>('');
  const [openConfirmationDialog, setOpenConfirmationDialog] =
    useState<boolean>(false);
  const [integrationActionLoading, setIntegrationActionLoading] = useState<{
    [key: string]: boolean;
  }>({});

  const integrationActions = async ({ id, isDownload = true }) => {
    try {
      setIntegrationActionLoading(prev => ({ ...prev, [id]: true }));
      if (isDownload) {
        await downloadIntegrationMutation(id);
      } else {
        await deleteIntegrationMutation(id);
      }
    } finally {
      setIntegrationActionLoading(prev => ({ ...prev, [id]: false }));
    }
  };

  const availableActions = (
    menuOptionIndex: number,
    payload: { id: string }
  ) => {
    const { id } = payload;
    if (menuOptionIndex === 0) {
      integrationActions({ id });
    } else if (menuOptionIndex === 1) {
      setIdToDelete(id);
      setOpenConfirmationDialog(true);
    }
  };

  if (tabLoader) {
    return <Loader />;
  }

  if (!integrations?.length || !isTenantAvailable) {
    return (
      <EmptyState
        illustration={<EmptyIllustration />}
        title={
          isTenantAvailable ? 'No Marketplace found' : 'No Instance onboarded'
        }
        actions={
          <Button
            color="primary"
            onClick={() =>
              isTenantAvailable
                ? handleUploadIntegration()
                : navigate('/settings/instances')
            }
          >
            <PlusIcon />
            {isTenantAvailable ? 'New Marketplace' : 'New Instance'}
          </Button>
        }
      />
    );
  }

  return (
    <>
      <div>
        <MotionGroup
          className={classNames(css.integrations, {
            [css.filterIntegrationApplied]: isFilterApplied
          })}
        >
          {integrations?.map(integration => (
            <MotionItem key={integration.id} layout>
              <AvailableIntegrationCard
                integration={integration}
                cardLoader={integrationActionLoading[integration?.id] ?? false}
                configureIntegration={configureIntegration}
                handleApplyMenuOption={availableActions}
                fetchIntegrationById={fetchIntegrationById}
                handleChipClick={handleChipClick}
              />
            </MotionItem>
          ))}
        </MotionGroup>
        <Pager
          total={metadata.total_count}
          page={currentPage}
          size={metadata.page_size}
          onPageChange={setPage}
        />
      </div>
      <ConfirmationDialog
        open={openConfirmationDialog}
        dialogType="DELETE"
        confirmationButtonName="Delete Integration"
        confirmationHeading="Delete Confirmation"
        confirmationMessage="Are you sure you want to delete this marketplace? Deleting this will automatically remove all the associated configurations and routes."
        onConfirm={() => {
          integrationActions({ id: idToDelete, isDownload: false });
          setOpenConfirmationDialog(false);
        }}
        onCancel={() => setOpenConfirmationDialog(false)}
      />
    </>
  );
};
