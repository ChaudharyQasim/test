import { FC } from 'react';
import {
  Button,
  Card,
  Chip,
  SmallHeading,
  Stack,
  VerticalSpacer
} from 'reablocks';

// Components
import { ListMenu } from 'shared/elements/ListMenu/ListMenu';

// API Service
import { AvailableIntegrationCardProps } from '../Integration.types';

import css from './AvailableIntegrationCard.module.css';

import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as ExportIcon } from 'assets/icons/export.svg';
import classNames from 'classnames';

const AVAILABLE_ACTION = [
  {
    icon: <ExportIcon />,
    iconName: 'Export',
    iconId: 0
  },
  {
    icon: <DeleteIcon />,
    iconName: 'Delete',
    iconId: 1
  }
];

export const AVAILABLE_ACTION_ORG_INTEGRATION = [
  {
    icon: <ExportIcon />,
    iconName: 'Export',
    iconId: 0
  }
];

export const AvailableIntegrationCard: FC<AvailableIntegrationCardProps> = ({
  cardLoader,
  integration,
  configureIntegration,
  handleApplyMenuOption,
  handleChipClick
}) => {
  const { id, name, type, description, icon, version, scope } =
    integration || {};
  const base64Icon = `data:image/png;base64, ${icon}`;

  return (
    <>
      <Card
        key={id}
        className={css.card}
        contentClassName={css.cardContent}
        disablePadding
      >
        <Stack direction="column">
          <div className={css.cardHeader}>
            <img height={58} width={58} src={base64Icon} />
            <div className={css.details}>
              <SmallHeading
                className={css.integrationName}
                title={name}
                disableMargins
              >
                {name}
              </SmallHeading>
              <Chip
                variant="outline"
                className={css.chipClass}
                onClick={() => handleChipClick('type', type)}
              >
                {type}
              </Chip>
              {scope === 'default' && (
                <Chip variant="outline" className={css.chipClass}>
                  Global
                </Chip>
              )}

              <Chip
                variant="outline"
                className={classNames(css.chipClass, css.versionChip)}
              >
                {version}
              </Chip>
            </div>
            <ListMenu
              listItems={
                scope === 'default'
                  ? AVAILABLE_ACTION_ORG_INTEGRATION
                  : AVAILABLE_ACTION
              }
              disableOptions={cardLoader}
              onItemClick={(menuId: number) =>
                handleApplyMenuOption(menuId, {
                  id
                })
              }
            />
          </div>
          <div className={css.description}>{description}</div>
          <VerticalSpacer space="md" />
          <Button
            variant="outline"
            onClick={() => configureIntegration(integration)}
            fullWidth
          >
            Add Marketplace
          </Button>
        </Stack>
      </Card>
    </>
  );
};
