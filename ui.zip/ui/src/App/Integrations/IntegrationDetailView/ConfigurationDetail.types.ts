import { GetConfigurationOut } from 'core/Api';
import { IntegrationDynamicSteps } from 'core/Api/IntegrationApi';
import {
  UpdateConfigMutationType,
  ValidateConfigMutationType
} from '../Integration.types';

export type ConfigurationUpdateViewProps = {
  tabLoader: boolean;
  integrationDetails: IntegrationDynamicSteps;
  configurationDetails: GetConfigurationOut;
  validateConfigMutation: ValidateConfigMutationType;
  updateConfigMutation: UpdateConfigMutationType;
};
