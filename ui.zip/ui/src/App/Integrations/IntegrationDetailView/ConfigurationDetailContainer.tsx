import { FC } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  useInfiniteQuery,
  useMutation,
  useQuery,
  useQueryClient
} from 'react-query';
import { useNotification } from 'reablocks';

import { ConfigurationDetail } from './ConfigurationDetail';
import { Loader } from 'shared/elements/Loader';

import {
  deleteConfiguration,
  getConfigurationById,
  getConfigurationLogs,
  getEnabledIntegration,
  updateConfiguration,
  validateConfiguration
} from 'core/Api/ConfigurationApi';
import { getIntegrationById } from 'core/Api/IntegrationApi';
import { ConfigurationUpdate, ValidateConfiguration } from 'core/Api';
import { useQueryParams } from 'core/Hooks/useQueryParams';
import { useQueryParam, StringParam, withDefault } from 'use-query-params';

import {
  createRoute,
  deleteRoute,
  getRouteByConfigurationId
} from 'core/Api/PipelineApi';

import { CONFIGURATION_TYPE } from 'shared/utils/Constants';
import { errorHandler, constructQueryParams } from 'shared/utils/Helper';
import { AxiosError } from 'axios';
import {
  ErrorResponseMessage,
  UpdateConfigMutationType,
  ValidateConfigMutationType
} from '../Integration.types';

const { SOURCE, DESTINATION } = CONFIGURATION_TYPE;

export const ConfigurationDetailContainer: FC = () => {
  const { id: configurationId } = useParams();

  const { vendor_account_id } = useQueryParams();

  const [selectedTab, setSelectedTab] = useQueryParam(
    'selectedTab',
    withDefault(StringParam, '0')
  );

  const { notifySuccess, notifyError } = useNotification();

  const navigate = useNavigate();

  const queryClient = useQueryClient();

  const { data: configurationDetails, isFetching: pageLoader } = useQuery(
    ['configurationDetails', configurationId, vendor_account_id],
    () => getConfigurationById(configurationId, vendor_account_id),
    {
      enabled: !!vendor_account_id,
      onError(error: AxiosError<ErrorResponseMessage> | any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { data: integrationDetails, isFetching: isFetchingIntegration } =
    useQuery(
      ['integrationDetails', configurationDetails?.integration_id],
      () => getIntegrationById(configurationDetails?.integration_id),
      {
        enabled: !!configurationDetails?.integration_id,
        onError(error: AxiosError<ErrorResponseMessage> | any) {
          notifyError(errorHandler(error));
        }
      }
    );

  // Fetching associated routes using configuration Id
  const {
    data: routes,
    isLoading: isLoadingRoutes,
    refetch: refetchRoutes
  } = useQuery(
    ['configurationRoute', configurationId],
    () => getRouteByConfigurationId(configurationId, vendor_account_id),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      },
      enabled: configurationId !== null && vendor_account_id !== null
    }
  );

  const { data: nodes, isFetching: isLoadingConfiguredList } = useQuery(
    ['configurationList', vendor_account_id],
    () =>
      /***
       *
       * fetching source and destination configurations for connector in configuration detail view.
       *
       */
      getEnabledIntegration(
        constructQueryParams(
          null,
          {
            type: [DESTINATION, SOURCE],
            vendor_account_ids: [vendor_account_id]
          },
          null
        ),
        true
      ),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      },
      enabled: vendor_account_id !== null
    }
  );

  const { mutateAsync: createRouteMutation } = useMutation(
    'createRoute',
    createRoute,
    {
      onSuccess() {
        refetchRoutes();
        notifySuccess('Route created successfully.');
      },
      onError(error: any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { mutate: deleteRouteMutation } = useMutation(
    'deleteRoute',
    deleteRoute,
    {
      onSuccess() {
        refetchRoutes();
        notifySuccess('Route deleted successfully.');
      },
      onError(error: any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const updateConfigMutation: UpdateConfigMutationType = useMutation(
    ({ payload }: { payload: ConfigurationUpdate }) =>
      updateConfiguration(configurationId, payload),
    {
      onSuccess(_data, variables) {
        queryClient.setQueryData(
          ['configurationDetails', configurationId, vendor_account_id],
          (prevData: object) => ({ ...prevData, ...variables.payload })
        );
        notifySuccess(
          `Configuration ${configurationDetails.name} is updated successfully.`
        );
      },
      onError(error: AxiosError<ErrorResponseMessage> | any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { isLoading: deleteMutationInProgress, mutate: deleteMutation } =
    useMutation(
      () => deleteConfiguration(configurationId, { vendor_account_id }),
      {
        onSuccess() {
          notifySuccess(
            `Configuration ${configurationDetails.name} is deleted successfully.`
          );
          navigate('/marketplace');
        },
        onError(error: AxiosError<ErrorResponseMessage> | any) {
          notifyError(errorHandler(error));
        }
      }
    );

  const validateConfigMutation: ValidateConfigMutationType = useMutation(
    'validateConfig',
    (configurationData: ValidateConfiguration) =>
      validateConfiguration(configurationData),
    {
      onSuccess() {
        notifySuccess(`Configuration validated successfully.`);
      },
      onError(error: AxiosError<ErrorResponseMessage> | any) {
        notifyError(`Error validating configuration: ${errorHandler(error)}`);
      }
    }
  );

  const {
    data: configurationLogs,
    hasNextPage,
    isFetchingNextPage,
    fetchNextPage
  } = useInfiniteQuery(
    'configurationLogs',
    ({ pageParam = 1 }) =>
      vendor_account_id
        ? getConfigurationLogs(configurationId, vendor_account_id, pageParam)
        : [],
    {
      getNextPageParam: (lastPage, allPages) =>
        vendor_account_id && lastPage.length !== 0
          ? allPages.length + 1
          : undefined,
      enabled: false,
      onError(error: AxiosError<ErrorResponseMessage> | any) {
        notifyError(errorHandler(error));
      }
    }
  );

  if (pageLoader) {
    return <Loader />;
  }

  return (
    <ConfigurationDetail
      selectedTab={selectedTab}
      onTabChange={setSelectedTab}
      isFetchingLogs={isFetchingNextPage}
      isFetchingIntegration={isFetchingIntegration}
      hasNextPage={hasNextPage}
      integrationDetails={integrationDetails}
      configurationDetails={configurationDetails}
      configurationActionInProgress={
        updateConfigMutation.isLoading || deleteMutationInProgress
      }
      configurationLogs={configurationLogs}
      nodes={nodes?.data ?? []}
      edges={routes ?? []}
      fetchingConfigurationRoutes={isLoadingConfiguredList || isLoadingRoutes}
      onAddConnection={createRouteMutation}
      onDeleteConnection={deleteRouteMutation}
      fetchConfigurationLogs={fetchNextPage}
      validateConfigMutation={validateConfigMutation}
      isValidateConfigSuccess={validateConfigMutation.isSuccess}
      updateConfigMutation={updateConfigMutation}
      deleteConfiguration={deleteMutation}
    />
  );
};
