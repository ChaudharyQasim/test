import { FC, useMemo, useState } from 'react';
import {
  Chip,
  DateFormat,
  PrimaryHeading,
  Stack,
  Sub,
  Text,
  Toggle
} from 'reablocks';
import { Helmet } from 'react-helmet-async';
import { createSearchParams, useNavigate } from 'react-router-dom';

import {
  InfiniteData,
  UseMutateAsyncFunction,
  UseMutateFunction
} from 'react-query';

import { Tab, TabList, TabPanel, Tabs } from 'shared/layout/Tabs';
import { StatusIndicator } from 'shared/elements/StatusIndicator';
import { ListItem, ListMenu } from 'shared/elements/ListMenu/ListMenu';

import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as DisableIcon } from 'assets/icons/minus.svg';
import { ReactComponent as Calendar } from 'assets/icons/calendar.svg';

import { IntegrationLogs } from './ConfigurationLogs/ConfigurationLogs';

import css from './ConfigurationDetail.module.css';

import {
  ConfigurationOut,
  DeleteConfigurationOut,
  GetConfigurationOut,
  GetIntegrationExecutionHistory,
  IntegrationTypeEnum,
  RouteIn,
  RouteOut
} from 'core/Api';
import { CONFIGURATION_TYPE, DATE_FORMAT } from 'shared/utils/Constants';
import { ConfigurationUpdateView } from './ConfigurationUpdateView/ConfigurationUpdateView';
import { IntegrationDynamicSteps } from 'core/Api/IntegrationApi';
import {
  UpdateConfigMutationType,
  ValidateConfigMutationType
} from '../Integration.types';
import { Breadcrumb, BreadcrumbItem } from 'shared/elements/Breadcrumb';
import { PipelineRoute } from 'App/DataConfig/PipelineManager/PipelineRoute/PipelineRoute';
import classNames from 'classnames';

const { SOURCE, DESTINATION } = CONFIGURATION_TYPE;

interface ConfigurationDetailProps {
  selectedTab: string;
  onTabChange: (newValue: string) => void;
  isFetchingLogs: boolean;
  isFetchingIntegration: boolean;
  hasNextPage: boolean;
  integrationDetails: IntegrationDynamicSteps;
  configurationDetails: GetConfigurationOut;
  configurationActionInProgress: boolean;
  configurationLogs: InfiniteData<GetIntegrationExecutionHistory[]>;
  nodes: ConfigurationOut[];
  edges: RouteOut[];
  fetchingConfigurationRoutes: boolean;
  isValidateConfigSuccess: boolean;
  updateConfigMutation: UpdateConfigMutationType;
  validateConfigMutation: ValidateConfigMutationType;
  onAddConnection: UseMutateAsyncFunction<RouteOut, any, RouteIn, unknown>;
  onDeleteConnection: UseMutateFunction<any, any, string, unknown>;
  fetchConfigurationLogs: () => void;
  deleteConfiguration: UseMutateFunction<
    DeleteConfigurationOut,
    unknown,
    void,
    unknown
  >;
}

export const ConfigurationDetail: FC<ConfigurationDetailProps> = ({
  selectedTab,
  onTabChange,
  nodes,
  edges,
  isFetchingLogs,
  isFetchingIntegration,
  hasNextPage,
  fetchingConfigurationRoutes,
  integrationDetails,
  configurationDetails,
  configurationActionInProgress,
  configurationLogs,
  validateConfigMutation,
  isValidateConfigSuccess,
  updateConfigMutation,
  onAddConnection,
  onDeleteConnection,
  fetchConfigurationLogs,
  deleteConfiguration
}) => {
  const { active, name, last_run_at, vendor_account_id, status, id, type } =
    configurationDetails || {};

  const navigate = useNavigate();

  const computedActionList: ListItem[] = [
    {
      icon: <DisableIcon />,
      iconName: active ? 'Disable' : 'Enable',
      iconId: 0
    },
    {
      icon: <DeleteIcon />,
      iconName: 'Delete',
      iconId: 1
    }
  ];

  const sourceNodes = nodes.filter(
    configuration => configuration.type === SOURCE
  );
  const destinationNodes = nodes.filter(
    configuration => configuration.type === DESTINATION
  );
  const currentNode = nodes.filter(configuration => configuration.id === id);

  const configurationDetailActions = (menuId: number) => {
    if (menuId === 0) {
      updateConfigMutation.mutate({
        payload: {
          active: !active,
          vendor_account_id
        }
      });
    } else {
      deleteConfiguration();
    }
  };

  const tagText = useMemo(() => {
    let currentStatus = 'Inactive';
    if (active) {
      currentStatus = status === null ? 'Running' : 'Active';
    }
    return currentStatus;
  }, [status, active]);

  const sourceConfigurations = useMemo(
    () => (type === SOURCE ? currentNode : sourceNodes),
    [currentNode, sourceNodes, type]
  );

  const destinationConfigurations = useMemo(
    () => (type === SOURCE ? destinationNodes : currentNode),
    [destinationNodes, currentNode, type]
  );

  const handleChangeTab = (selectedTab: string) => {
    onTabChange(selectedTab);
  };

  return (
    <>
      <div className={css.root}>
        <Helmet>
          <title>Integrations Details</title>
        </Helmet>
        <header className={css.header}>
          <PrimaryHeading className={css.primaryHeader}>
            <Breadcrumb>
              <BreadcrumbItem href="/marketplace">Marketplace</BreadcrumbItem>
              <BreadcrumbItem>{name}</BreadcrumbItem>
            </Breadcrumb>
          </PrimaryHeading>
          <div className={css.push} />
          <ListMenu
            listItems={computedActionList}
            disableOptions={configurationActionInProgress}
            onItemClick={configurationDetailActions}
          />
        </header>
        <Stack className={css.subHeader}>
          <Sub className={css.statusText}>STATUS</Sub>
          <Chip
            variant="outline"
            className={css.chip}
            start={<StatusIndicator status={active ? 'Active' : 'Disabled'} />}
          >
            {tagText}
          </Chip>
        </Stack>
        {last_run_at && (
          <Stack direction="row" className={css.calender}>
            <Calendar />
            <Text className={css.disabledHeader}>
              Last checked on{' '}
              <DateFormat date={new Date(last_run_at)} format={DATE_FORMAT} />
            </Text>
          </Stack>
        )}
        <Tabs selectedIndex={Number(selectedTab)} onSelect={handleChangeTab}>
          <TabList>
            <Tab>Integration Config</Tab>
            <Tab>Data Routing</Tab>
            <Tab>Integration Logs</Tab>
          </TabList>
          <TabPanel>
            <ConfigurationUpdateView
              tabLoader={isFetchingIntegration}
              isSourceType={type === IntegrationTypeEnum.EventSource}
              integrationDetails={integrationDetails}
              configurationDetails={configurationDetails}
              isValidateConfigSuccess={isValidateConfigSuccess}
              validateConfigMutation={validateConfigMutation}
              updateConfigMutation={updateConfigMutation}
            />
          </TabPanel>
          <TabPanel>
            <>
              <div
                className={classNames(css.background, {
                  [css.reducedBackground]: last_run_at
                })}
              >
                <div className={css.sourceCol} />
                <div className={css.routeCol} />
                <div className={css.destCol} />
              </div>
              <PipelineRoute
                sourceConfigurations={sourceConfigurations}
                destinationConfigurations={destinationConfigurations}
                selectedVendorId={vendor_account_id}
                isLoadingPipeline={fetchingConfigurationRoutes}
                routes={edges}
                canvasClassName={css.canvasClassName}
                onAddConnection={onAddConnection}
                onEditConnection={routeId =>
                  navigate({
                    pathname: `/pipeline/details/${routeId}`,
                    search: createSearchParams({
                      pipelineView: 'ConfigurationDetail',
                      configurationId: id,
                      configurationVendorId: vendor_account_id
                    }).toString()
                  })
                }
                onDeleteConnection={onDeleteConnection}
              />
            </>
          </TabPanel>
          <TabPanel>
            <IntegrationLogs
              configurationLogs={configurationLogs}
              tabLoader={isFetchingLogs}
              hasNextPage={hasNextPage}
              fetchConfigurationLogs={fetchConfigurationLogs}
            />
          </TabPanel>
        </Tabs>
      </div>
    </>
  );
};
