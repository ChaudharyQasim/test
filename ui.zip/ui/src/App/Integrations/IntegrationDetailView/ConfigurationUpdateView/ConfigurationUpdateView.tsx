import { ChangeEvent, FC, useEffect, useMemo, useState } from 'react';
import { Button, Card, Divider } from 'reablocks';

import { GetConfigurationOut, ConfigurationUpdate } from 'core/Api';
import { IntegrationDynamicSteps } from 'core/Api/IntegrationApi';

import css from './ConfigurationUpdateView.module.css';
import { NameInstanceStep } from '../../NewIntegration/NameInstanceStep';
import { DynamicStep } from '../../NewIntegration/DynamicStep';
import { ValidationStep } from '../../NewIntegration/ValidationStep';
import {
  UpdateConfigMutationType,
  ValidateConfigMutationType
} from '../../Integration.types';
import { Loader } from 'shared/elements/Loader';

interface ConfigurationUpdateViewProps {
  tabLoader: boolean;
  isSourceType: boolean;
  integrationDetails: IntegrationDynamicSteps;
  configurationDetails: GetConfigurationOut;
  validateConfigMutation: ValidateConfigMutationType;
  isValidateConfigSuccess: boolean;
  updateConfigMutation: UpdateConfigMutationType;
}

export const ConfigurationUpdateView: FC<ConfigurationUpdateViewProps> = ({
  tabLoader,
  isSourceType,
  integrationDetails,
  configurationDetails,
  validateConfigMutation,
  isValidateConfigSuccess,
  updateConfigMutation
}) => {
  const { name, vendor_account_id, vendor_account_name, integration_id } =
    configurationDetails || {};
  const {
    isLoading: updateMutationInProgress,
    mutateAsync: updateConfiguration
  } = updateConfigMutation;

  const [configPatchData, setConfigPatchData] = useState<ConfigurationUpdate>({
    vendor_account_id: '',
    active: null,
    interval: null,
    ecs_pipelines: {},
    parameters: {}
  });

  const [updateButtonDisabled, setUpdateButtonDisabled] =
    useState<boolean>(true);

  useEffect(() => {
    if (configurationDetails) {
      const {
        name,
        vendor_account_id,
        active,
        interval,
        ecs_pipelines,
        store_raw_event,
        parameters
      } = configurationDetails;

      setConfigPatchData(prevconfigurationDetails => ({
        ...prevconfigurationDetails,
        name,
        vendor_account_id,
        active,
        interval,
        ecs_pipelines,
        store_raw_event,
        parameters
      }));
    }
  }, [configurationDetails]);

  if (isValidateConfigSuccess && updateButtonDisabled) {
    setUpdateButtonDisabled(false);
  }

  const handleFormChange = (key: string, value: boolean | string) => {
    setConfigPatchData(prevconfigurationDetails => ({
      ...prevconfigurationDetails,
      [key]: value
    }));
    setUpdateButtonDisabled(true);
    validateConfigMutation.reset();
  };

  const handleParametersFormChange = (
    key: string,
    value: ChangeEvent<HTMLInputElement> | string | number
  ) => {
    setConfigPatchData(prevconfigurationDetails => ({
      ...prevconfigurationDetails,
      parameters: {
        ...prevconfigurationDetails.parameters,
        [key]: value
      }
    }));
    setUpdateButtonDisabled(true);
    validateConfigMutation.reset();
  };

  const handleUpdateConfig = async () => {
    const {
      vendor_account_id,
      active,
      interval,
      ecs_pipelines,
      parameters,
      store_raw_event
    } = configPatchData;
    setUpdateButtonDisabled(true);
    validateConfigMutation.reset();
    await updateConfiguration({
      payload: {
        vendor_account_id,
        active,
        interval,
        ecs_pipelines,
        parameters,
        store_raw_event
      }
    });
  };

  if (tabLoader) {
    return <Loader />;
  }

  return (
    <Card className={css.tabBody}>
      <NameInstanceStep
        configuredTenantList={[]}
        configurationData={configPatchData}
        handleFormChange={handleFormChange}
        vendor_account_name={vendor_account_name}
        isSourceType={isSourceType}
        mode="update"
      />
      <Divider />
      {integrationDetails &&
        integrationDetails.parameters &&
        integrationDetails.parameters.map((dynamicStep, idx) => (
          <DynamicStep
            key={idx}
            dynamicStep={dynamicStep}
            parameters={configPatchData.parameters}
            mode="update"
            handleParametersFormChange={handleParametersFormChange}
            emptyFields={[]}
          />
        ))}
      <Divider />
      <ValidationStep
        validateConfigMutation={validateConfigMutation}
        configurationData={{
          vendor_account_id,
          name,
          integration_id,
          parameters: configPatchData.parameters
        }}
      />
      <Divider />
      <div className={css.actions}>
        <Button
          color="primary"
          size="small"
          disabled={!isValidateConfigSuccess || updateButtonDisabled}
          onClick={() => handleUpdateConfig()}
        >
          {updateMutationInProgress
            ? 'Saving Configurations...'
            : `Update Configurations`}
        </Button>
      </div>
      <Divider />
    </Card>
  );
};
