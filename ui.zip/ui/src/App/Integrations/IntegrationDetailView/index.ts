export { ConfigurationDetailContainer as default } from './ConfigurationDetailContainer';
export * from './ConfigurationDetail.types';
