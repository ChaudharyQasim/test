import { FC, useCallback, useEffect, useMemo, useRef } from 'react';
import { Card, DateFormat, SmallHeading } from 'reablocks';
import { InfiniteData } from 'react-query';

import { Tooltip } from 'shared/layers/Tooltip';
import { Loader } from 'shared/elements/Loader';
import { NoDataState } from 'shared/elements/NoDataState';
import { Table } from 'shared/layout/Table';

import css from './ConfigurationLogs.module.css';
import classNames from 'classnames';

import { GetIntegrationExecutionHistory } from 'core/Api';
import { DATE_FORMAT } from 'shared/utils/Constants';

interface IntegrationLogsInterface {
  tabLoader: boolean;
  hasNextPage: boolean;
  configurationLogs: InfiniteData<GetIntegrationExecutionHistory[]>;
  fetchConfigurationLogs: () => void;
}

const option = { threshold: 0 };

export const IntegrationLogs: FC<IntegrationLogsInterface> = ({
  tabLoader,
  configurationLogs,
  hasNextPage,
  fetchConfigurationLogs
}) => {
  const observerTarget = useRef(null);

  const handleObserver = useCallback(
    entries => {
      const [target] = entries;
      if (target.isIntersecting) {
        fetchConfigurationLogs();
      }
    },
    [fetchConfigurationLogs]
  );

  useEffect(() => {
    const element = observerTarget.current;
    const observer = new IntersectionObserver(handleObserver, option);
    observer.observe(element);
    return () => observer.unobserve(element);
  }, [hasNextPage, handleObserver]);

  const logsColumns = useMemo(
    () => [
      {
        id: 'date',
        header: 'Date',
        accessor: 'created_at',
        cell: value => (
          <DateFormat
            date={new Date(value.getValue())}
            format={DATE_FORMAT}
            className={css.logsCell}
          />
        )
      },
      {
        id: 'status',
        header: 'Status',
        accessor: 'status',
        cell: value => (
          <Tooltip content={value.row.original.workflow_run_id}>
            <span
              className={classNames(css.logStatus, {
                [css.error]: value.getValue() !== 'SUCCESSFUL'
              })}
            >
              {value.getValue()}
            </span>
          </Tooltip>
        )
      },
      {
        id: 'Events',
        header: 'Event/s',
        accessor: 'count',
        cell: value => value.getValue()
      },
      {
        id: 'Message',
        header: 'Message',
        accessor: 'message',
        cell: value => value.getValue() || 'N/A'
      }
    ],
    []
  );

  const logsArray = useMemo(
    () =>
      configurationLogs?.pages ? [].concat(...configurationLogs.pages) : [],
    [configurationLogs?.pages]
  );

  const hasLogs = logsArray.length > 0;

  return (
    <>
      <SmallHeading>Integration Logs</SmallHeading>
      <Card
        className={classNames(css.card)}
        contentClassName={classNames(css.cardContent, {
          [css.noDataCard]: !hasLogs
        })}
        disablePadding
      >
        {hasLogs && (
          <Table
            data={logsArray}
            columns={logsColumns}
            className={css.logsTable}
          />
        )}
        {!hasLogs && !tabLoader && (
          <NoDataState
            message="No Logs Available"
            className={css.noLogsState}
          />
        )}
        {tabLoader && <Loader className={css.loaderClass} />}
        <div ref={observerTarget}></div>
      </Card>
    </>
  );
};
