import { FC, useMemo } from 'react';
import { binaryScale } from 'shared/utils/Constants/data';
import {
  Block,
  Card,
  Chip,
  SmallHeading,
  Stack,
  useTheme,
  Text,
  DataSize,
  formatSize,
  safeFormat
} from 'reablocks';
import {
  Bar,
  BarChart,
  BarSeries,
  ChartTooltip,
  Gridline,
  GridlineSeries,
  LinearAxisTickLabel,
  LinearAxisTickSeries,
  LinearXAxis,
  LinearXAxisTickLabel,
  LinearXAxisTickSeries,
  LinearYAxis,
  TooltipArea,
  TooltipTemplate
} from 'reaviz';
import { DATE_TIME_FORMAT, HOUR_MINUTE_FORMAT, INTEGRATION_STATUS } from 'shared/utils/Constants';
import { IntegrationCardProps } from '../Integration.types';
import { StatusIndicator } from 'shared/elements/StatusIndicator';
import { ListMenu } from 'shared/elements/ListMenu/ListMenu';
import { NoDataState } from 'shared/elements/NoDataState';
import css from './IntegrationCard.module.css';

import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as DisableIcon } from 'assets/icons/minus.svg';
import { ReactComponent as ExportIcon } from 'assets/icons/export.svg';
import { ReactComponent as DetailIcon } from 'assets/icons/details.svg';

type StatisticsType = {
  event_collected: number;
  total_data_ingested: number;
};

type MetricsType = {
  timestamp: string;
  data_ingested: number;
};

export const IntegrationCard: FC<IntegrationCardProps> = ({
  cardLoader,
  integration,
  handleApplyMenuOption,
  handleChipClick
}) => {
  const theme = useTheme();

  const icon = `data:image/png;base64, ${integration.icon}`;

  const actions = [
    {
      icon: <DisableIcon />,
      iconName: integration.active ? 'Disable' : 'Enable',
      iconId: 0
    },
    {
      icon: <DetailIcon />,
      iconName: 'View Details',
      iconId: 1
    },
    {
      icon: <ExportIcon />,
      iconName: 'Export',
      iconId: 2
    },
    {
      icon: <DeleteIcon />,
      iconName: 'Delete',
      iconId: 3
    }
  ];

  const {
    name,
    type,
    status,
    integration_id,
    vendor_account_name,
    vendor_account_id,
    active,
    id,
    metrics,
    statistics
  } = integration;

  const data_ingested =
    (statistics as StatisticsType)?.total_data_ingested ?? null;

  const modifiedMetrics = useMemo(() => {
    if (!metrics) {
      return [];
    }
    return (metrics as MetricsType[]).map(metric => ({
      key: metric.timestamp,
      data: metric?.data_ingested
    }));
  }, [metrics]);

  const tagText = useMemo(() => {
    let currentStatus = 'Inactive';
    if (active) {
      currentStatus = status === null ? 'Running' : 'Active';
    }
    return currentStatus;
  }, [status, active]);

  return (
    <Card
      className={css.card}
      contentClassName={css.cardContent}
      disablePadding
    >
      <Stack direction="column">
        <div className={css.cardHeader}>
          {integration.icon && <img height={58} width={58} src={icon} />}
          <div className={css.details}>
            <SmallHeading
              className={css.integrationName}
              title={name}
              disableMargins
            >
              {name}
            </SmallHeading>
            <Chip
              variant="outline"
              className={css.chipClass}
              onClick={() => handleChipClick('type', type)}
            >
              {type}
            </Chip>
            <Chip
              variant="outline"
              className={css.chipClass}
              start={
                <StatusIndicator
                  status={
                    active
                      ? INTEGRATION_STATUS[status ?? 'SUCCESSFUL']
                      : 'Disabled'
                  }
                />
              }
              onClick={() => handleChipClick('active', `${active}`)}
            >
              {tagText}
            </Chip>
          </div>
          <ListMenu
            listItems={actions}
            disableOptions={cardLoader}
            onItemClick={(menuId: number) =>
              handleApplyMenuOption(menuId, {
                integrationId: integration_id,
                vendor_account_id,
                active,
                id
              })
            }
          />
        </div>
        <div className={css.metadata}>
          <Block label="Tenant">
            <Text color="secondary" fontStyle="bold">
              {vendor_account_name}
            </Text>
          </Block>
          <Block label="Data Storage">
            <DataSize value={data_ingested} scale={binaryScale} />
          </Block>
        </div>
        <div className={css.chart}>
          <Block label="Data Ingested" labelClassName={css.graphLabel}>
            {metrics && metrics.length ? (
              <BarChart
                height={120}
                margins={0}
                data={modifiedMetrics}
                xAxis={
                  <LinearXAxis
                    axisLine={null}
                    type="category"
                    tickSeries={
                      <LinearXAxisTickSeries
                        line={null}
                        label={
                          <LinearXAxisTickLabel
                            rotation={false}
                            format={date =>
                              safeFormat(date, { format: HOUR_MINUTE_FORMAT }).formatted
                            }
                            align="center"
                            padding={10}
                          />
                        }
                      />
                    }
                  />
                }
                yAxis={
                  <LinearYAxis
                    axisLine={null}
                    tickSeries={
                      <LinearAxisTickSeries
                        line={null}
                        label={
                          <LinearAxisTickLabel
                            rotation={false}
                            format={storage =>
                              formatSize(storage, undefined, binaryScale)
                            }
                            position="start"
                            padding={10}
                          />
                        }
                      />
                    }
                  />
                }
                gridlines={
                  <GridlineSeries
                    line={
                      <Gridline
                        direction="y"
                        strokeDasharray="0"
                        strokeColor="rgba(255,255,255,0.1)"
                      />
                    }
                  />
                }
                series={
                  <BarSeries
                    colorScheme={[theme.palettes.primary.background]}
                    bar={<Bar width={4} gradient={null} rx={2} ry={2} />}
                    tooltip={
                      <TooltipArea
                        tooltip={
                          <ChartTooltip
                            followCursor
                            content={(data, color) => (
                              <TooltipTemplate
                                color={color}
                                value={{
                                  ...data,
                                  value: formatSize(
                                    data.value,
                                    undefined,
                                    binaryScale
                                  ),
                                  x: safeFormat(data.x, {
                                    format: DATE_TIME_FORMAT
                                  }).formatted,
                                  y: formatSize(data.y, undefined, binaryScale)
                                }}
                              />
                            )}
                          />
                        }
                      />
                    }
                  />
                }
              />
            ) : (
              <NoDataState />
            )}
          </Block>
        </div>
      </Stack>
    </Card>
  );
};
