import { FC, useCallback, useMemo, useState } from 'react';
import { useNotification } from 'reablocks';

import { useMutation, useQuery, useQueryClient } from 'react-query';
import { useAuth } from 'core/Auth';

import { Integrations } from './Integrations';

import { INTEGRATION_FILTER } from 'shared/utils/Constants';
import {
  getFileExtension,
  errorHandler,
  getUpdatedResponse
} from 'shared/utils/Helper';
import {
  ConfigurationCreate,
  Integration,
  StatusEnum,
  ValidateConfiguration
} from 'core/Api';
import { UppyFile } from '@uppy/core';
import {
  deleteIntegration,
  downloadIntegration,
  getAvailableIntegration,
  getIntegrationById,
  postIntegration
} from 'core/Api/IntegrationApi';
import {
  createConfiguration,
  deleteConfiguration,
  getEnabledIntegration,
  updateConfiguration,
  validateConfiguration
} from 'core/Api/ConfigurationApi';
import { getOrganizationUsers } from 'core/Api/UsersApi';
import {
  DeleteMutationType,
  ListConfigurationType,
  UpdateMutationType,
  ValidateConfigMutationType
} from './Integration.types';
import { getListTenantsAccounts } from 'core/Api/VendorApi';

export const IntegrationsContainer: FC = () => {
  const { user } = useAuth();

  const { notifySuccess, notifyError } = useNotification();

  // useState
  const [constructedUrl, setConstructedUrl] = useState<string>('');
  const [isConfigurationTab, setIsConfigurationTab] = useState<boolean>(true);
  const [cardLoader, setCardLoader] = useState<{ [key: string]: boolean }>({});
  const [activeIntegrationId, setActiveIntegrationId] = useState<string | null>(
    null
  );

  const queryClient = useQueryClient();

  // useQuery
  const { data: organizationUsers } = useQuery(
    'organizationUsers',
    () => getOrganizationUsers(user.current_organization.id),
    { initialData: [] }
  );

  const { data: configuredTenantList } = useQuery(
    'tenantList',
    () => getListTenantsAccounts(user.current_organization.id),
    { initialData: [] }
  );

  const successTenantList = useMemo(() => {
    if (configuredTenantList?.length === 0) {
      return [];
    }
    return configuredTenantList.filter(
      tenant =>
        tenant.status?.length > 0 &&
        tenant.status[0].status === StatusEnum.Completed
    );
  }, [configuredTenantList]);

  const { data: configuredIntegrations, isFetching: isLoadingConfiguredCard } =
    useQuery(
      ['configurationList', constructedUrl],
      () => getEnabledIntegration(constructedUrl),
      {
        enabled: isConfigurationTab,
        onError(error: any) {
          notifyError(errorHandler(error));
        },
        onSuccess(data) {
          if (data?.errors?.length) {
            const vendorNames = data.errors
              ?.map(error => error.vendor_account_name)
              .join(', ');
            notifyError(
              `Error occured while getting configurations for vendor account: ${vendorNames}`
            );
          }
        }
      }
    );

  const {
    data: availableIntegrations,
    isFetching: isLoadingAvailableCard,
    refetch: fetchAvailableIntegration
  } = useQuery(
    ['availableList', constructedUrl],
    () => getAvailableIntegration(constructedUrl),
    {
      enabled: !isConfigurationTab && configuredTenantList.length > 0,
      onError(error: any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { mutate: deleteConfigurationMutation } = useMutation(
    ({ id, vendor_account_id }: DeleteMutationType) =>
      deleteConfiguration(id, { vendor_account_id }),
    {
      onMutate(variables) {
        setCardLoader(prev => ({ ...prev, [variables.id]: true }));
      },
      onSuccess(data, variables) {
        queryClient.setQueryData(
          ['configurationList', constructedUrl],
          (prevData: ListConfigurationType) =>
            getUpdatedResponse(prevData, variables.id, data)
        );
        notifySuccess('Configuration is deleted successfully.');
      },
      onError(error: any) {
        notifyError(errorHandler(error));
      },
      onSettled(_data, _error, variables) {
        setCardLoader(prev => ({ ...prev, [variables.id]: false }));
      }
    }
  );

  const { mutate: updateConfigurationMutation } = useMutation(
    ({ id, payload }: UpdateMutationType) => updateConfiguration(id, payload),
    {
      onMutate(variables) {
        setCardLoader(prev => ({ ...prev, [variables.id]: true }));
      },
      onSuccess(data, variables) {
        queryClient.setQueryData(
          ['configurationList', constructedUrl],
          (prevData: ListConfigurationType) =>
            getUpdatedResponse(prevData, variables.id, data, true)
        );
        notifySuccess(`Configuration is updated successfully.`);
      },
      onError(error: any) {
        notifyError(errorHandler(error));
      },
      onSettled(_data, _error, variables) {
        setCardLoader(prev => ({ ...prev, [variables.id]: false }));
      }
    }
  );

  const integrationQuery = useQuery(
    ['integrationData', activeIntegrationId],
    () => getIntegrationById(activeIntegrationId),
    {
      enabled: !!activeIntegrationId
    }
  );

  const validateConfigMutation: ValidateConfigMutationType = useMutation(
    'validateConfig',
    (configurationData: ValidateConfiguration) =>
      validateConfiguration(configurationData),
    {
      onSuccess() {
        notifySuccess(`Configuration validated successfully.`);
      },
      onError(error: any) {
        notifyError(`Error validating configuration: ${errorHandler(error)}`);
      }
    }
  );

  const {
    isLoading: isCreateConfigurationLoading,
    mutateAsync: createConfigurationMutation
  } = useMutation(
    'createConfig',
    (configurationData: ConfigurationCreate) =>
      createConfiguration(configurationData),
    {
      onSuccess() {
        notifySuccess(`Configuration created successfully.`);
      },
      onError(error: any) {
        notifyError(`Error creating configuration: ${errorHandler(error)}`);
      }
    }
  );

  const {
    mutateAsync: deleteIntegrationMutation,
    isLoading: isDeleteIntegrationLoading
  } = useMutation((id: string) => deleteIntegration(id), {
    onSuccess() {
      fetchAvailableIntegration();
    },
    onError(error) {
      errorHandler(error);
    }
  });

  // useMemo
  const formattedUsersList = useMemo(() => {
    if (organizationUsers.length) {
      return {
        author: {
          label: 'Author',
          options: organizationUsers.map(filter => ({
            label: `${filter.first_name} ${filter.last_name}`,
            value: filter.username
          }))
        }
      };
    }
    return null;
  }, [organizationUsers]);

  const filterOptions = useMemo(() => {
    const availableFilterOptions = {
      ...INTEGRATION_FILTER,
      ...formattedUsersList
    };
    if (!isConfigurationTab) {
      return availableFilterOptions;
    }
    return {
      ...availableFilterOptions,
      ...(successTenantList.length && {
        vendor_account_ids: {
          label: 'Instance',
          options: successTenantList.map(instance => ({
            label: instance.name,
            value: instance.nanoid
          }))
        },
        active: {
          label: 'Active',
          options: [
            { value: 'true', label: 'Active' },
            { value: 'false', label: 'Inactive' }
          ]
        }
      })
    };
  }, [successTenantList, isConfigurationTab, formattedUsersList]);

  // Methods
  const handleFetchIntegration = useCallback(
    (isConfigTab: boolean, url: string) => {
      setIsConfigurationTab(isConfigTab);
      setConstructedUrl(url);
    },
    []
  );

  const { mutateAsync: downloadIntegrationMutation } = useMutation(
    (id: string) => downloadIntegration(id),
    {
      onSuccess(data, variables) {
        const fileExtension = getFileExtension(data);

        const blobUrl = URL.createObjectURL(new Blob([data]));

        // Create a temporary link element
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = `${variables}.${fileExtension}`;

        link.click();

        URL.revokeObjectURL(blobUrl);
      },
      onError(error: any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const handleIntegrationUpload = async (
    file: UppyFile<Record<string, unknown>, Record<string, unknown>>,
    setUploadProperties: React.Dispatch<
      React.SetStateAction<{
        estimatedTimeRemaining: string;
        percentage: string;
      }>
    >,
    onUploadComplete: (
      isApiSuccess: boolean,
      message: string,
      integration: Integration
    ) => void
  ) => {
    const formData = new FormData();
    formData.append('file', file.data, file.name);
    formData.append('scope', user?.current_organization?.name);
    try {
      const uploadedIntegration = await postIntegration(
        formData,
        setUploadProperties
      );
      onUploadComplete(true, 'Validation passed', uploadedIntegration);
    } catch (error: any) {
      onUploadComplete(false, error.response.data.message, null);
    }
  };

  return (
    <Integrations
      tabLoader={
        isConfigurationTab ? isLoadingConfiguredCard : isLoadingAvailableCard
      }
      filterOptions={filterOptions}
      integrations={availableIntegrations}
      configuration={configuredIntegrations?.data ?? []}
      cardLoader={cardLoader}
      configuredTenantList={successTenantList}
      validateConfigMutation={validateConfigMutation}
      isCreateConfigurationLoading={isCreateConfigurationLoading}
      createConfigurationMutation={createConfigurationMutation}
      isDeleteIntegrationLoading={isDeleteIntegrationLoading}
      handleFetchIntegration={handleFetchIntegration}
      fileUpload={handleIntegrationUpload}
      updateConfiguration={updateConfigurationMutation}
      deleteConfiguration={deleteConfigurationMutation}
      downloadIntegrationMutation={downloadIntegrationMutation}
      fetchIntegrationById={setActiveIntegrationId}
      deleteIntegrationMutation={deleteIntegrationMutation}
      integrationQuery={integrationQuery}
      fetchAvailableIntegration={fetchAvailableIntegration}
    />
  );
};
