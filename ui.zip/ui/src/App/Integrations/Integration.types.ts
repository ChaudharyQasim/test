import {
  QueryObserverResult,
  RefetchOptions,
  RefetchQueryFilters,
  UseMutateAsyncFunction,
  UseMutateFunction,
  UseMutationResult,
  UseQueryResult
} from 'react-query';
import {
  ConfigurationCreate,
  ConfigurationOut,
  ConfigurationUpdate,
  DeleteConfigurationOut,
  DeleteIntegrationOut,
  GetConfigurationOut,
  Integration,
  IntegrationOut,
  ListIntegrationOut,
  ValidateConfiguration,
  ValidateConfigurationOut,
  VendorAccountOut
} from 'core/Api';
import { FilterType } from 'shared/elements/Filters';
import { FileUploadCallBack } from './UploadIntegration';
import { AxiosError } from 'axios';
import { IntegrationDynamicSteps } from 'core/Api/IntegrationApi';

export type MenuActionPayload = {
  id: string;
  vendor_account_id: string;
  integrationId: string;
  active: boolean;
};

type MetricsType = {
  timestamp: string;
  data_ingested: string;
};

// TODO: Remove this Once we have updated type
type ErrorType = {
  vendor_account_name: string;
  status_code: number;
  error: string;
};

export type ErrorResponseMessage = {
  message?: string;
};

export type ListConfigurationType = {
  data: ConfigurationOut[];
  errors: ErrorType[];
};

type PaginationInfo = {
  total_count: number;
  page_size: number;
  page_number: number;
};

export type ListIntegrationType = {
  integrations: IntegrationOut[];
  metadata: PaginationInfo;
};

export type deleteIntegrationType = {
  deleteIntegrationMutation?: UseMutateAsyncFunction<
    DeleteIntegrationOut,
    unknown,
    string,
    unknown
  >;
};
interface ConfigurationActions extends deleteIntegrationType {
  updateConfiguration: UseMutateFunction<
    GetConfigurationOut,
    any,
    {
      id: string;
      payload: ConfigurationUpdate;
    },
    void
  >;
  deleteConfiguration: UseMutateFunction<
    DeleteConfigurationOut,
    unknown,
    {
      id: string;
      vendor_account_id: string;
    },
    void
  >;
  downloadIntegrationMutation: UseMutateAsyncFunction<
    Blob,
    any,
    string,
    unknown
  >;
}

export type ValidateConfigMutationType = UseMutationResult<
  ValidateConfigurationOut,
  AxiosError<ErrorResponseMessage> | unknown,
  ValidateConfiguration,
  unknown
>;

export type CreateConfigMutationType = UseMutationResult<
  ConfigurationOut,
  AxiosError<ErrorResponseMessage> | unknown,
  ConfigurationCreate,
  unknown
>;

export type UpdateConfigMutationType = UseMutationResult<
  GetConfigurationOut,
  AxiosError<ErrorResponseMessage> | unknown,
  { payload: ConfigurationUpdate },
  unknown
>;

export interface IntegrationsProps
  extends FileUploadCallBack,
    ConfigurationActions {
  integrations: ListIntegrationOut;
  configuration: ConfigurationOut[];
  tabLoader: boolean;
  filterOptions: FilterType;
  cardLoader: { [key: string]: boolean };
  integrationQuery: UseQueryResult<IntegrationDynamicSteps, unknown>;
  configuredTenantList: VendorAccountOut[];
  validateConfigMutation: ValidateConfigMutationType;
  isCreateConfigurationLoading: boolean;
  createConfigurationMutation: UseMutateAsyncFunction<
    any,
    any,
    ConfigurationCreate,
    unknown
  >;
  isDeleteIntegrationLoading: boolean;
  handleFetchIntegration: (
    isConfigurationTab: boolean,
    constructedUrl: string
  ) => void;
  fetchIntegrationById: (id: string) => void;
  fetchAvailableIntegration: <TPageData>(
    options?: RefetchOptions & RefetchQueryFilters<TPageData>
  ) => Promise<QueryObserverResult<ListIntegrationType, unknown>>;
}

export type IntegrationCardProps = {
  cardLoader: boolean;
  integration: ConfigurationOut;
  handleApplyMenuOption: (menuId: number, payload: MenuActionPayload) => void;
  handleChipClick: (key: string, value: string) => void;
};

export interface ConfiguredIntegrationType extends ConfigurationActions {
  tabLoader: boolean;
  cardLoader: { [key: string]: boolean };
  configuredIntegration: ConfigurationOut[];
  isFilterApplied: boolean;
  handleChipClick: (key: string, value: string) => void;
}

export type AvailableIntegrationType = {
  tabLoader: boolean;
  isTenantAvailable: boolean;
  availableIntegration: ListIntegrationOut;
  currentPage: number;
  isFilterApplied: boolean;
  setPage: (page: number) => void;
  deleteIntegrationMutation: UseMutateAsyncFunction<
    any,
    unknown,
    string,
    unknown
  >;
  downloadIntegrationMutation: UseMutateAsyncFunction<
    Blob,
    any,
    string,
    unknown
  >;
  handleUploadIntegration: () => void;
  fetchIntegrationById: (id: string) => void;
  configureIntegration: (integration: IntegrationOut) => void;
  handleChipClick: (key: string, value: string) => void;
};

export type AvailableIntegrationCardProps = {
  integration: IntegrationOut;
  cardLoader: boolean;
  configureIntegration: (integration: IntegrationOut) => void;
  handleApplyMenuOption: (menuId: number, payload: { id: string }) => void;
  fetchIntegrationById: (integrationId: IntegrationOut['id']) => void;
  handleChipClick: (key: string, value: string) => void;
};

export type NewIntegrationProps = {
  activeIntegrationId: Integration['id'];
  integrationQuery: UseQueryResult<IntegrationDynamicSteps, unknown>;
  configuredTenantList: VendorAccountOut[];
  validateConfigMutation: ValidateConfigMutationType;
  createConfigurationMutation: UseMutateAsyncFunction<
    any,
    any,
    ConfigurationCreate,
    unknown
  >;
  updateIfConfigurationDirty: (value: boolean) => void;
  navigateToConfigurationTab: () => void;
  onClose: () => void;
  isCreateConfigurationLoading: boolean;
};

export type DeleteMutationType = {
  id: string;
  vendor_account_id: string;
};

export type UpdateMutationType = {
  id: string;
  payload: ConfigurationUpdate;
};

export type KeyToListStringMap = {
  [key: string]: string[];
};
