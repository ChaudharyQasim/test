import { NameInstanceStep } from './NameInstanceStep';
import { VendorAccountOut } from 'core/Api/types';

export default {
  title: 'Layers/Dialog/NameInstanceStep',
  component: NameInstanceStep
};

const mockConfigData = {
  vendor_account_name: 'testVendor',
  name: 'Instance Corporation',
  integration_id: 'int1',
  interval: 30,
  parameters: {},
  ecs_pipelines: {},
  active: false
};

const mockTenants: VendorAccountOut[] = [
  {
    id: 1,
    nanoid: 'J6z8K9p7Q2',
    name: 'Tenant 1'
  },
  {
    id: 2,
    nanoid: 'L3z9F1p6R8',
    name: 'Tenant 2'
  },
  {
    id: 3,
    nanoid: 'M4z0G2p5S9',
    name: 'Tenant 3'
  }
];

export const CreateConfigMode = () => (
  <NameInstanceStep
    configurationData={mockConfigData}
    configuredTenantList={mockTenants}
    handleFormChange={() => {}}
    mode="create"
  />
);

export const EditConfigMode = () => (
  <NameInstanceStep
    configurationData={mockConfigData}
    configuredTenantList={[]}
    handleFormChange={() => {}}
    mode="update"
  />
);
