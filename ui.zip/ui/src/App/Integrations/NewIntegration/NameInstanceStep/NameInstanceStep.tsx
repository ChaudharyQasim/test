import { ChangeEvent, FC } from 'react';
import {
  Block,
  Input,
  Select,
  SelectOption,
  SmallHeading,
  Stack,
  Text,
  Toggle,
  Tooltip
} from 'reablocks';
import css from './NameInstanceStep.module.css';

import { ReactComponent as HelpIcon } from 'assets/icons/help.svg';

import { ConfigurationCreate, VendorAccountOut } from 'core/Api/types';
import classNames from 'classnames';

interface NameInstanceStepProps {
  configuredTenantList: VendorAccountOut[];
  configurationData: {
    name?: ConfigurationCreate['name'];
    interval?: ConfigurationCreate['interval'];
    vendor_account_id?: ConfigurationCreate['vendor_account_id'];
    store_raw_event?: ConfigurationCreate['store_raw_event'];
  };
  isSourceType?: boolean;
  mode: 'create' | 'update';
  vendor_account_name?: string;
  handleFormChange: (key: string, value: string | boolean) => void;
}

export const NameInstanceStep: FC<NameInstanceStepProps> = ({
  configuredTenantList,
  configurationData,
  mode,
  isSourceType,
  vendor_account_name,
  handleFormChange
}) => {
  const { name, interval, vendor_account_id, store_raw_event } =
    configurationData || {};
  const validateFieldValue = {
    interval: isNaN(Number(interval))
  };

  const handleChange = (
    event: ChangeEvent<HTMLInputElement>,
    field: string
  ) => {
    handleFormChange(field, event.target.value);
  };

  const handleVendorSelect = (
    value: VendorAccountOut['name'],
    field: string
  ) => {
    handleFormChange(field, value);
  };

  return (
    <>
      <SmallHeading>Name & Instance</SmallHeading>
      {mode === 'create' && (
        <Text>Fill the marketplace name and select an Abstract instance</Text>
      )}
      <div
        className={classNames(css.form, {
          [css.updateForm]: mode === 'update'
        })}
      >
        <Block label="Marketplace Name" />
        <Input
          placeholder="Marketplace Name"
          value={name}
          onChange={event => handleChange(event, 'name')}
          disabled={mode === 'update'}
        />
        <Block label="Poll Interval (seconds)">
          {validateFieldValue.interval && (
            <Text color="primary">Must be a number</Text>
          )}
        </Block>
        <Input
          placeholder="Poll Interval (seconds)"
          value={interval}
          onChange={event => handleChange(event, 'interval')}
        />
        <Block label="Abstract Instance" />
        {mode === 'create' && (
          <Select
            placeholder="Select an instance"
            value={vendor_account_id}
            clearable={false}
            onChange={value => handleVendorSelect(value, 'vendor_account_id')}
          >
            {configuredTenantList.map(vendor => (
              <SelectOption key={vendor.nanoid} value={vendor.nanoid}>
                {vendor.name}
              </SelectOption>
            ))}
          </Select>
        )}
        {mode === 'update' && (
          <Select
            placeholder={vendor_account_name}
            value={'vendor_account_name'}
            disabled={true}
          />
        )}
        {isSourceType && (
          <>
            <Block
              label={
                <Stack>
                  Store Raw Events
                  <Tooltip
                    content={
                      <>
                        Enabling &quot;Store Raw Event&quot; populates the
                        event.original field with the raw text of each event.
                        <br />
                        This will significantly increase storage/processing cost
                        for this data source.
                      </>
                    }
                  >
                    <HelpIcon className={css.helpIcon} />
                  </Tooltip>
                </Stack>
              }
              disableMargin
            />
            <Toggle
              size="small"
              checked={store_raw_event}
              onChange={toggleValue =>
                handleFormChange('store_raw_event', toggleValue)
              }
            />
          </>
        )}
      </div>
    </>
  );
};
