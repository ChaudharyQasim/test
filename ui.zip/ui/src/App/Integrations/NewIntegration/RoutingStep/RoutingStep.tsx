import { SmallHeading, Stack, Text, VerticalSpacer } from 'reablocks';
import css from './RoutingStep.module.css';

import { ReactComponent as InfoIcon } from 'assets/icons/report.svg';
import { errorHandler } from 'shared/utils/Helper';

export const RoutingStep = ({ configError }) => (
  <>
    <SmallHeading>Routing</SmallHeading>
    <Text>Configure Data Routes</Text>
    <VerticalSpacer space="lg" />
    <Stack className={css.info}>
      <InfoIcon />
      Your marketplace is configured and the data is ready to be fetched
    </Stack>
    <VerticalSpacer space="sm" />
    <Text>
      Configure the data routing for the marketplace in order to establish the
      data flow.
    </Text>
    {configError && (
      <>
        <VerticalSpacer space="md" />
        <Stack className={css.error}>
          An error occurred: {errorHandler(configError)}
        </Stack>
      </>
    )}
  </>
);
