import { AxiosError } from 'axios';
import { RoutingStep } from './RoutingStep';
import { ErrorResponseMessage } from '../../Integration.types';

export default {
  title: 'Layers/Dialog/RoutingStep',
  component: RoutingStep
};

export const Default = () => (
  <RoutingStep configError={{} as AxiosError<ErrorResponseMessage>} />
);

export const Error = () => (
  <RoutingStep
    configError={
      {
        response: { data: { message: 'Incorrect token' } }
      } as AxiosError<ErrorResponseMessage>
    }
  />
);
