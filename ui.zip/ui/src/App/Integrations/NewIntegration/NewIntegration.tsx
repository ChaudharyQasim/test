import { ChangeEvent, FC, useEffect, useState } from 'react';
import classNames from 'classnames';
import { useNavigate } from 'react-router';
import { Button, List, ListItem, Stack } from 'reablocks';
import { createSearchParams } from 'react-router-dom';

import { Loader } from 'shared/elements/Loader';
import { NameInstanceStep } from './NameInstanceStep';
import { DynamicStep } from './DynamicStep';
import { ValidationStep } from './ValidationStep';
import { RoutingStep } from './RoutingStep';
import css from './NewIntegration.module.css';

import { ConfigurationCreate, IntegrationTypeEnum } from 'core/Api/types';

import { NewIntegrationProps } from '../Integration.types';

export const NewIntegration: FC<NewIntegrationProps> = ({
  activeIntegrationId,
  configuredTenantList,
  integrationQuery,
  validateConfigMutation,
  isCreateConfigurationLoading,
  createConfigurationMutation,
  updateIfConfigurationDirty,
  navigateToConfigurationTab,
  onClose
}) => {
  const navigate = useNavigate();

  const { isLoading: isIntegrationLoading, data: integrationData } =
    integrationQuery;

  const [activeStep, setActiveStep] = useState<number>(0);
  const [emptyFields, setEmptyFields] = useState<string[]>([]);
  const [errorConfiguration, setErrorConfiguration] = useState<string | null>(
    null
  );
  const [configurationData, setConfigurationData] =
    useState<ConfigurationCreate>({
      vendor_account_id: '',
      name: '',
      integration_id: activeIntegrationId || '',
      interval: null,
      parameters: {},
      ecs_pipelines: {},
      active: false,
      store_raw_event: false
    });
  const [isSourceType, setIsSourceType] = useState<boolean>(false);

  useEffect(() => {
    setConfigurationData(prevConfigurationData => ({
      ...prevConfigurationData,
      ecs_pipelines:
        integrationData?.ecs_pipelines ?? prevConfigurationData.ecs_pipelines
    }));
    setIsSourceType(integrationData?.type === IntegrationTypeEnum.EventSource);
  }, [integrationData]);

  const handleFormChange = (
    key: string,
    value: string | boolean
  ) => {
    setConfigurationData(prevConfigurationData => {
      const updatedConfigurationData = {
        ...prevConfigurationData,
        [key]: value
      };
      const { vendor_account_id, name, interval } = updatedConfigurationData;
      updateIfConfigurationDirty(!!vendor_account_id || !!name || !!interval);
      return updatedConfigurationData;
    });

    validateConfigMutation.reset();
  };

  const handleParametersFormChange = (
    key: string,
    value: ChangeEvent<HTMLInputElement> | string | number
  ) => {
    setConfigurationData(prevConfigurationData => ({
      ...prevConfigurationData,
      parameters: {
        ...prevConfigurationData.parameters,
        [key]: value
      }
    }));
    validateConfigMutation.reset();
  };

  const handleCreateConfig = async (active: boolean) => {
    try {
      const { id } = await createConfigurationMutation({
        ...configurationData,
        active
      });
      if (active) {
        navigateToConfigurationTab();
      } else {
        navigate({
          pathname: `/marketplace/${id}`,
          search: createSearchParams({
            vendor_account_id: configurationData?.vendor_account_id,
            selectedTab: '1'
          }).toString()
        });
      }
      onClose();
    } catch (error: any) {
      setErrorConfiguration(error);
    }
  };

  if (isIntegrationLoading) {
    return (
      <div className={css.layout}>
        <Loader />
      </div>
    );
  }

  const { parameters: dynamicStepData } = integrationData;
  const dynamicStepLabels = dynamicStepData.map(({ label }) => label) || [];
  const stepLabels = [
    'Name & Instance',
    ...dynamicStepLabels,
    'Validation',
    'Routing'
  ];
  const currentStepIndex = activeStep - 1;
  const isDynamicStepsRange =
    activeStep > 0 && activeStep < stepLabels.length - 2;
  const isValidationStep = activeStep === stepLabels.length - 2;
  const isRoutingStep = activeStep === stepLabels.length - 1;
  const isNextStep = activeStep < stepLabels.length - 1;

  const isNextButtonDisabled = () => {
    const { name, vendor_account_id, interval } = configurationData;
    // prevent from proceeding Next if missing required fields or validation
    if (activeStep === 0) {
      return (
        !name || !vendor_account_id || !interval || isNaN(Number(interval))
      );
    } else if (activeStep === stepLabels.length - 2) {
      return !validateConfigMutation.isSuccess;
    }
    return false;
  };

  /**
   * @description Check if there are empty fields in dynamic steps before proceeding to next step
   */
  const checkEmptyDynamicFields = () => {
    const { fields } = dynamicStepData[currentStepIndex];
    const invalidFields = fields.filter(
      ({ key }) => !configurationData.parameters[key]
    );
    if (invalidFields.length > 0) {
      setEmptyFields(invalidFields.map(({ key }) => key));
    } else {
      setEmptyFields([]);
      setActiveStep(Math.min(stepLabels.length - 1, activeStep + 1));
    }
  };

  return (
    <div className={css.layout}>
      <Stack className={css.steps} alignItems="start">
        <List className={css.stepsList}>
          {stepLabels.map((step, idx) => (
            <ListItem
              key={idx}
              className={classNames(css.step, {
                [css.active]: idx === activeStep,
                [css.completed]: idx < activeStep
              })}
              onClick={() => {
                if (idx > activeStep) {
                  return null;
                } else {
                  setActiveStep(idx);
                }
                // reset validation state to disable Next button
                // if user navigate away from Validation step
                validateConfigMutation.reset();
              }}
              disabled={idx > activeStep}
            >
              <Stack>
                <div className={css.stepNumber}>{idx + 1}</div>
                {step}
              </Stack>
            </ListItem>
          ))}
        </List>
      </Stack>
      <Stack
        className={css.stepContent}
        direction="column"
        alignItems="start"
        justifyContent="spaceBetween"
      >
        <div className={css.main}>
          {activeStep === 0 && (
            <NameInstanceStep
              configuredTenantList={configuredTenantList}
              configurationData={configurationData}
              isSourceType={isSourceType}
              handleFormChange={handleFormChange}
              mode="create"
            />
          )}
          {isDynamicStepsRange && (
            <DynamicStep
              dynamicStep={dynamicStepData[currentStepIndex]}
              parameters={configurationData.parameters}
              handleParametersFormChange={handleParametersFormChange}
              emptyFields={emptyFields}
              mode="create"
            />
          )}
          {isValidationStep && (
            <ValidationStep
              configurationData={configurationData}
              validateConfigMutation={validateConfigMutation}
            />
          )}
          {isRoutingStep && <RoutingStep configError={errorConfiguration} />}
        </div>
        <div className={css.actions}>
          {isNextStep ? (
            <Button
              color="primary"
              size="small"
              disabled={isNextButtonDisabled()}
              onClick={
                isDynamicStepsRange
                  ? checkEmptyDynamicFields
                  : () => setActiveStep(activeStep + 1)
              }
            >
              Next
            </Button>
          ) : (
            <>
              <Button
                color="primary"
                size="small"
                disabled={isCreateConfigurationLoading}
                onClick={() => handleCreateConfig(false)}
              >
                {isCreateConfigurationLoading
                  ? 'Saving Configurations...'
                  : `Save & Configure Routes`}
              </Button>
              <Button
                variant="outline"
                size="small"
                disabled={isCreateConfigurationLoading}
                onClick={() => handleCreateConfig(true)}
              >
                {isCreateConfigurationLoading
                  ? 'Saving Configurations...'
                  : `Save & Close`}
              </Button>
            </>
          )}
          <Button
            variant="outline"
            size="small"
            disabled={isCreateConfigurationLoading}
            onClick={() => {
              setActiveStep(0);
              onClose();
            }}
          >
            Cancel
          </Button>
        </div>
      </Stack>
    </div>
  );
};
