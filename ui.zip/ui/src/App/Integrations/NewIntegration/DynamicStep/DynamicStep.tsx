import { ChangeEvent, FC, Fragment, useCallback } from 'react';
import { Block, Input, SmallHeading, Text } from 'reablocks';
import { Tooltip } from 'shared/layers/Tooltip';
import css from './DynamicStep.module.css';

import { ReactComponent as HelpIcon } from 'assets/icons/help.svg';

import { DynamicStepTypes, Field } from 'core/Api/IntegrationApi';
import { ConfigurationCreate } from 'core/Api/types';
import classNames from 'classnames';

type DynamicStepProps = {
  dynamicStep: DynamicStepTypes;
  parameters: ConfigurationCreate['parameters'];
  mode: 'create' | 'update';
  emptyFields: string[];
  handleParametersFormChange: (
    key: string,
    value: ChangeEvent<HTMLInputElement> | string | number
  ) => void;
};

export const DynamicStep: FC<DynamicStepProps> = ({
  dynamicStep,
  parameters,
  mode,
  emptyFields,
  handleParametersFormChange
}) => {
  const { label, description, fields } = dynamicStep;
  const isInRange = (value: number, min: number, max: number) =>
    value >= min && value <= max;

  const getValidationMessage = (field: Field) => {
    const { key, type, mandatory, min, max } = field;
    if (!parameters[key] && emptyFields.includes(key)) {
      return mandatory ? 'Missing required field' : 'Missing field value';
    }
    if (type === 'number') {
      if (isNaN(Number(parameters[key]))) {
        return 'Must be a number';
      }
      if (!isInRange(parameters[key], min, max)) {
        return `Must be between ${min} and ${max}`;
      }
    }
  };

  const handleChange = useCallback(
    (event: ChangeEvent<HTMLInputElement>, field: Field) => {
      const { key, type } = field;
      let value: string | number = event.target.value;
      if (type === 'number') {
        value = Number(value);
      }
      handleParametersFormChange(key, value);
    },
    [handleParametersFormChange]
  );

  const renderFieldLabel: FC<Field> = field => {
    const { description, key, label, mandatory } = field;
    const validationMessage = getValidationMessage(field);
    return (
      <Block
        key={key}
        label={
          <>
            {label} {mandatory && '*'}
            <Tooltip content={description}>
              <HelpIcon className={css.helpIcon} />
            </Tooltip>
          </>
        }
      >
        {validationMessage && <Text color="primary">{validationMessage}</Text>}
      </Block>
    );
  };

  const renderDynamicField: FC<Field> = field => {
    const { key, label, type, default: defaultValue } = field;
    const value =
      parameters[key] !== undefined ? parameters[key] : defaultValue;
    if (defaultValue !== undefined && parameters[key] === undefined) {
      handleParametersFormChange(key, defaultValue);
    }
    return (
      <Input
        key={key}
        placeholder={label}
        value={value}
        type={type}
        onChange={event => handleChange(event, field)}
      />
    );
  };

  return (
    <>
      <SmallHeading>{label}</SmallHeading>
      <Text>{description}</Text>
      <form
        className={classNames(css.form, {
          [css.updateForm]: mode === 'update'
        })}
      >
        {fields.map(field => (
          <Fragment key={field.label}>
            {renderFieldLabel(field)}
            {renderDynamicField(field)}
          </Fragment>
        ))}
      </form>
    </>
  );
};
