import { FC, useState } from 'react';
import { Button, SmallHeading, Stack, Text, VerticalSpacer } from 'reablocks';
import css from './ValidationStep.module.css';

import { ReactComponent as WarningIcon } from 'assets/icons/warning.svg';
import { ReactComponent as SucessIcon } from 'assets/icons/check-circle.svg';

import { ValidateConfiguration } from 'core/Api/types';
import {
  ErrorResponseMessage,
  ValidateConfigMutationType
} from '../../Integration.types';
import { AxiosError } from 'axios';

interface ValidationStepProps {
  validateConfigMutation: ValidateConfigMutationType;
  configurationData: ValidateConfiguration;
}

const ValidationSuccess = ({ validateConfigData }) => (
  <>
    <Stack className={css.success}>
      <SucessIcon />
      Validation Successful
    </Stack>
    <Text>Integration Validated successfully without any errors</Text>
    <VerticalSpacer space="sm" />
    {validateConfigData.message && <Text>{validateConfigData.message}</Text>}
  </>
);

const ValidationFail = ({ validateConfigError }) => (
  <>
    <Stack className={css.warning}>
      <WarningIcon />
      Validation Failed!
    </Stack>
    <VerticalSpacer space="sm" />
    <Text>
      An error occurred:{' '}
      {(validateConfigError as AxiosError<ErrorResponseMessage>)?.response?.data
        ?.message || validateConfigError.message}
    </Text>
  </>
);

export const ValidationStep: FC<ValidationStepProps> = ({
  validateConfigMutation,
  configurationData
}) => {
  const [isValidationTriggered, setIsValidationTriggered] = useState(false);
  const {
    isLoading: isValidateConfigLoading,
    error: validateConfigError,
    data: validateConfigData,
    mutateAsync: validateConfig
  } = validateConfigMutation;
  const { vendor_account_id, name, integration_id, parameters } =
    configurationData;
  const validationTriggeredStatus =
    isValidationTriggered && !isValidateConfigLoading;

  const configDataToValidate: ValidateConfiguration = {
    vendor_account_id,
    name,
    integration_id,
    parameters
  };

  const handleValidateClick = () => {
    validateConfig(configDataToValidate);
    setIsValidationTriggered(true);
  };

  return (
    <>
      <SmallHeading>Validation</SmallHeading>
      <Text>Validate the marketplace</Text>
      <VerticalSpacer space="lg" />
      <Button
        color="primary"
        onClick={handleValidateClick}
        disabled={isValidateConfigLoading}
      >
        {isValidateConfigLoading ? 'Validating...' : 'Validate'}
      </Button>
      <VerticalSpacer space="lg" />
      {validationTriggeredStatus && (
        <>
          {validateConfigError ? (
            <ValidationFail validateConfigError={validateConfigError} />
          ) : (
            <>
              {validateConfigData && (
                <ValidationSuccess validateConfigData={validateConfigData} />
              )}
            </>
          )}
        </>
      )}
    </>
  );
};

export default ValidationStep;
