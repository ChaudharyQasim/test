import {
  FC,
  useRef,
  useState,
  useMemo,
  useEffect,
  MutableRefObject
} from 'react';
import { Helmet } from 'react-helmet-async';
import { Button, PrimaryHeading, SmallHeading, Stack, Sub } from 'reablocks';
import { Chip } from 'shared/elements/Chip';
import { Count } from 'reaviz';

// Component
import { ConfirmationDialog } from 'shared/layers/ConfirmationDialog';
import { FilterPanel } from 'shared/elements/Filters';
import { Dialog } from 'shared/layers/Dialog';
import { SearchInput } from 'shared/form/Input/SearchInput';
import { Tab, TabList, TabPanel, Tabs } from 'shared/layout/Tabs';
import { ConfiguredIntegration } from './ConfiguredIntegration/ConfiguredIntegration';
import { AvailableIntegration } from './AvailableIntegration/AvailableIntegration';
import { UploadIntegration } from './UploadIntegration';
import { NewIntegration } from './NewIntegration';
import { useFilterPager } from 'core/Hooks/useFilterPager';

// API SERVICE
import { constructQueryParams } from 'shared/utils/Helper';
import { IntegrationsProps, KeyToListStringMap } from './Integration.types';

import css from './Integrations.module.css';

import { ReactComponent as FilterIcon } from 'assets/icons/filter.svg';
import { ReactComponent as UploadIcon } from 'assets/icons/upload.svg';
import { AppliedFilter } from 'shared/elements/AppliedFilter';
import { Integration, IntegrationOut } from 'core/Api';

type ModalType = 'UPLOAD' | 'NEW_CONFIGURATION';

export const Integrations: FC<IntegrationsProps> = ({
  integrations,
  integrationQuery,
  configuredTenantList,
  tabLoader,
  cardLoader,
  configuration,
  filterOptions,
  isDeleteIntegrationLoading,
  isCreateConfigurationLoading,
  fileUpload,
  deleteIntegrationMutation,
  updateConfiguration,
  deleteConfiguration,
  downloadIntegrationMutation,
  handleFetchIntegration,
  fetchIntegrationById,
  fetchAvailableIntegration,
  createConfigurationMutation,
  validateConfigMutation
}) => {
  // useRefs
  const filterBtnRef = useRef<HTMLButtonElement | null>(null);

  const { keyword, setKeyword, filter, setFilter, page, setPage } =
    useFilterPager();

  // useState
  const [currentRef, setCurrentRef] =
    useState<MutableRefObject<HTMLButtonElement>>(null);
  const [openFilter, setOpenFilter] = useState<boolean>(false);
  const [modalOpenState, setModalOpenState] = useState<ModalType>(null);
  const [currentSelectedTab, setCurrentSelectedTab] = useState<number>(0);
  const [activeIntegration, setActiveIntegration] = useState<
    Integration | IntegrationOut | null
  >(null);
  const [isModalDirty, setIsModalDirty] = useState<boolean>(false);
  const [isWarningDialogOpen, setIsWarningDialogOpen] =
    useState<boolean>(false);
  const [refetchIntegrations, setRefetchIntegrations] =
    useState<boolean>(false);

  const hasFilter = filter && Object.keys(filter).length > 0;
  const isConfigurationTab = currentSelectedTab === 0;
  const isUploadIntegrationModal = modalOpenState === 'UPLOAD';

  // useMemo

  const filteredConfiguration = useMemo(() => {
    if (isConfigurationTab) {
      return configuration.filter(item =>
        item.name.toLowerCase().includes(keyword.toLowerCase())
      );
    }
    return [];
  }, [keyword, isConfigurationTab, configuration]);

  const appliedFilter = useMemo(() => {
    if (!isConfigurationTab) {
      const { vendor_account_ids, active, ...availableFilter } = filter ?? {};
      return availableFilter;
    }
    return filter;
  }, [filter, isConfigurationTab]);

  const constructedUrl = useMemo(
    () =>
      constructQueryParams(
        isConfigurationTab ? null : { searchValue: keyword, searchKey: 'name' },
        appliedFilter,
        isConfigurationTab ? null : page + 1
      ),
    [appliedFilter, keyword, isConfigurationTab, page]
  );

  const setAppliedFilter = (appliedFilter: KeyToListStringMap) => {
    // When clearing the filter in integration tab then it should clear the common filters for integration and configuration tab,but it should maintain the filter which only available for configuration tab
    // Integration tab doesn't have vendor_account_names filter.
    const vendors_list =
      (isConfigurationTab
        ? appliedFilter?.vendor_account_ids
        : filter?.vendor_account_ids) ?? [];

    const enabled =
      (isConfigurationTab ? appliedFilter?.active : filter?.active) ?? [];

    const updateFilter = {
      ...(vendors_list.length > 0 && { vendor_account_ids: vendors_list }),
      ...(enabled.length && { active: enabled })
    };
    setFilter({ ...appliedFilter, ...updateFilter });
  };

  const handleChipClick = (key: string, value: string) => {
    const updatedFilter = { ...filter };
    if (!updatedFilter[key]) {
      updatedFilter[key] = [value];
    } else if (!updatedFilter[key].includes(value)) {
      updatedFilter[key].push(value);
    }
    setFilter(updatedFilter);
  };

  const handleConfirmationAction = (isDiscarded: boolean = false) => {
    if (isDiscarded) {
      setModalOpenState(null);
      setIsModalDirty(false);
    }
    setIsWarningDialogOpen(false);
  };

  const modalMessage = useMemo(() => {
    if (isUploadIntegrationModal) {
      return 'Please wait while the marketplace is being validated';
    }
    if (isCreateConfigurationLoading) {
      return 'Please wait while we are creating configuration';
    }
    return 'You have unsaved changes. Are you sure you want to discard these changes?';
  }, [isUploadIntegrationModal, isCreateConfigurationLoading]);

  const createNewConfiguration = (
    integration: Integration | IntegrationOut
  ) => {
    setModalOpenState('NEW_CONFIGURATION');
    setActiveIntegration(integration);
    fetchIntegrationById(integration?.id);
  };

  useEffect(() => {
    handleFetchIntegration(isConfigurationTab, constructedUrl);
  }, [constructedUrl, isConfigurationTab, handleFetchIntegration]);

  useEffect(() => {
    if (isConfigurationTab) {
      setPage(null);
    } else {
      setPage(0);
    }
  }, [isConfigurationTab, setPage]);

  return (
    <>
      <div className={css.root}>
        <Helmet>
          <title>Marketplace</title>
        </Helmet>
        <header className={css.header}>
          <PrimaryHeading>
            <Stack>
              <span>Marketplace</span>
              <Chip variant="outline" color="secondary">
                <div className={css.counter}>
                  <Count
                    to={
                      isConfigurationTab
                        ? configuration?.length
                        : integrations?.metadata?.total_count
                    }
                  />
                </div>
              </Chip>
            </Stack>
          </PrimaryHeading>
          <div className={css.push} />
          <SearchInput
            placeholder="Search by Name"
            debounce={500}
            value={keyword}
            onChange={e => setKeyword(e.target.value)}
          />
          <Button
            ref={filterBtnRef}
            className={css.newBtn}
            variant="outline"
            onClick={() => {
              setCurrentRef(filterBtnRef);
              setOpenFilter(!openFilter);
            }}
          >
            <FilterIcon />
            Filter
          </Button>
          <Button
            className={css.newBtn}
            variant="outline"
            onClick={() => setModalOpenState('UPLOAD')}
          >
            <UploadIcon />
            Upload
          </Button>
        </header>
        <AppliedFilter
          reference={currentRef}
          filter={appliedFilter}
          filterOptions={filterOptions}
          addFilter={addDropdown => {
            setCurrentRef(addDropdown);
            setOpenFilter(!openFilter);
          }}
          setFilter={setAppliedFilter}
        />
        <Tabs
          selectedIndex={currentSelectedTab}
          onSelect={setCurrentSelectedTab}
        >
          <TabList>
            <Tab>Configured</Tab>
            <Tab>Available</Tab>
          </TabList>
          <TabPanel>
            <ConfiguredIntegration
              isFilterApplied={hasFilter}
              tabLoader={tabLoader}
              cardLoader={cardLoader}
              configuredIntegration={filteredConfiguration}
              updateConfiguration={updateConfiguration}
              deleteConfiguration={deleteConfiguration}
              downloadIntegrationMutation={downloadIntegrationMutation}
              handleChipClick={handleChipClick}
            />
          </TabPanel>
          <TabPanel>
            <AvailableIntegration
              currentPage={page}
              tabLoader={tabLoader}
              isFilterApplied={hasFilter}
              availableIntegration={integrations}
              isTenantAvailable={configuredTenantList?.length > 0}
              deleteIntegrationMutation={deleteIntegrationMutation}
              downloadIntegrationMutation={downloadIntegrationMutation}
              handleUploadIntegration={() => setModalOpenState('UPLOAD')}
              setPage={setPage}
              configureIntegration={createNewConfiguration}
              fetchIntegrationById={fetchIntegrationById}
              handleChipClick={handleChipClick}
            />
          </TabPanel>
        </Tabs>
      </div>
      <FilterPanel
        reference={currentRef}
        open={openFilter}
        onClose={() => {
          setOpenFilter(false);
          setCurrentRef(null);
        }}
        filter={filter}
        filters={filterOptions}
        onFilterChange={setAppliedFilter}
      />
      <Dialog
        open={modalOpenState !== null}
        size={isUploadIntegrationModal ? '530px' : '780px'}
        onClose={() => {
          if (isModalDirty) {
            setIsWarningDialogOpen(true);
          } else {
            if (refetchIntegrations) {
              fetchAvailableIntegration();
              setRefetchIntegrations(false);
            }
            setModalOpenState(null);
          }
        }}
        header={
          isUploadIntegrationModal ? (
            <header>
              <SmallHeading>Upload Marketplace</SmallHeading>
              <Sub>
                Attachments that have been uploaded as part of this project
              </Sub>
            </header>
          ) : (
            `Configure ${activeIntegration?.name} Source`
          )
        }
        disablePadding={!isUploadIntegrationModal}
      >
        {() =>
          isUploadIntegrationModal ? (
            <UploadIntegration
              fileUpload={fileUpload}
              configureIntegration={integration => {
                createNewConfiguration(integration);
                fetchAvailableIntegration();
              }}
              isDeleteIntegrationLoading={isDeleteIntegrationLoading}
              updateIfUploadModalDirty={(isDirty, refetchIntegrations) => {
                setIsModalDirty(isDirty);
                setRefetchIntegrations(refetchIntegrations);
              }}
              fetchAvailableIntegration={fetchAvailableIntegration}
              deleteIntegrationMutation={deleteIntegrationMutation}
              onClose={() => {
                setModalOpenState(null);
              }}
            />
          ) : (
            <NewIntegration
              activeIntegrationId={activeIntegration?.id}
              integrationQuery={integrationQuery}
              configuredTenantList={configuredTenantList}
              validateConfigMutation={validateConfigMutation}
              createConfigurationMutation={createConfigurationMutation}
              navigateToConfigurationTab={() => setCurrentSelectedTab(0)}
              updateIfConfigurationDirty={setIsModalDirty}
              isCreateConfigurationLoading={isCreateConfigurationLoading}
              onClose={() => {
                if (isModalDirty) {
                  setIsWarningDialogOpen(true);
                  setModalOpenState(null);
                  setIsWarningDialogOpen(false);
                } else {
                  setIsModalDirty(false);
                  setModalOpenState(null);
                }
              }}
            />
          )
        }
      </Dialog>
      <ConfirmationDialog
        open={isWarningDialogOpen}
        dialogType="WARNING"
        confirmationMessage={modalMessage}
        showDiscardButton={
          !isUploadIntegrationModal && !isCreateConfigurationLoading
        }
        onConfirm={() => handleConfirmationAction(true)}
        onCancel={() => handleConfirmationAction(false)}
      />
    </>
  );
};
