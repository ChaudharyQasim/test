import { MotionGroup, MotionItem } from 'reablocks';
import { FC } from 'react';
import { useNavigate } from 'react-router-dom';

// Components
import { Loader } from 'shared/elements/Loader';

import css from './ConfiguredIntegration.module.css';
import { ReactComponent as EmptyIllustration } from 'assets/illustrations/empty-list.svg';

import { IntegrationCard } from '../IntegrationCard';
import { EmptyState } from 'shared/elements/EmptyState';

import {
  ConfiguredIntegrationType,
  MenuActionPayload
} from '../Integration.types';
import classNames from 'classnames';

export const ConfiguredIntegration: FC<ConfiguredIntegrationType> = ({
  tabLoader,
  cardLoader,
  isFilterApplied,
  configuredIntegration,
  updateConfiguration,
  deleteConfiguration,
  downloadIntegrationMutation,
  handleChipClick
}) => {
  const navigate = useNavigate();

  const configurationActions = (
    menuOptionIndex: number,
    payload: MenuActionPayload
  ) => {
    const { id, integrationId, active, vendor_account_id } = payload;
    switch (menuOptionIndex) {
      case 0:
        updateConfiguration({
          id,
          payload: { active: !active, vendor_account_id }
        });
        break;
      case 1:
        navigate({
          pathname: `/marketplace/${id}`,
          search: `?vendor_account_id=${vendor_account_id}`
        });
        break;
      case 2:
        downloadIntegrationMutation(integrationId);
        break;
      default:
        deleteConfiguration({
          id,
          vendor_account_id
        });
    }
  };

  if (tabLoader) {
    return <Loader />;
  }

  if (!configuredIntegration.length) {
    return (
      <EmptyState
        illustration={<EmptyIllustration />}
        title="No Configurations found"
      />
    );
  }
  return (
    <MotionGroup
      className={classNames(css.integrations, css.configurations, {
        [css.filterConfigurationApplied]: isFilterApplied
      })}
    >
      {configuredIntegration.map(integration => (
        <MotionItem key={integration.id} layout>
          <IntegrationCard
            integration={integration}
            cardLoader={cardLoader[integration.id] ?? false}
            handleApplyMenuOption={configurationActions}
            handleChipClick={handleChipClick}
          />
        </MotionItem>
      ))}
    </MotionGroup>
  );
};
