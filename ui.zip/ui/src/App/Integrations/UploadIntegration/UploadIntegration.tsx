import { FC, useState } from 'react';
import { UppyFile } from '@uppy/core';
import {
  Button,
  DataSize,
  Ellipsis,
  List,
  ListItem,
  MotionGroup,
  MotionItem,
  Stack,
  Sub,
  Text,
  VerticalSpacer
} from 'reablocks';

import { UploadInput } from 'shared/form/UploadInput';
import { ProgressBar } from 'shared/elements/ProgressBar';
import {
  FILE_UPLOAD_COMPLETE_PERCENTAGE,
  UPLOAD_FILE_SIZE
} from 'shared/utils/Constants';

import css from './UploadIntegration.module.css';

import { ReactComponent as DocumentIcon } from 'assets/icons/document.svg';
import { ReactComponent as RemoveIcon } from 'assets/icons/close.svg';

import { Integration } from 'core/Api';
import classNames from 'classnames';
import { RefetchOptions, RefetchQueryFilters } from 'react-query';
import { deleteIntegrationType } from '../Integration.types';

type UploadFileState = {
  isFileDropped: boolean;
  isFileUploading: boolean;
};

type UploadFileProperties = {
  estimatedTimeRemaining: string;
  percentage: string;
};

export interface FileUploadCallBack {
  fileUpload: (
    file: UppyFile<Record<string, unknown>, Record<string, unknown>>,
    setUploadProperties: React.Dispatch<
      React.SetStateAction<{
        estimatedTimeRemaining: string;
        percentage: string;
      }>
    >,
    onUploadComplete: (
      isApiSuccess: boolean,
      message: string,
      integration: Integration
    ) => void
  ) => void;
}
interface UploadIntegrationProps
  extends FileUploadCallBack,
    deleteIntegrationType {
  onClose: () => void;
  isDeleteIntegrationLoading: boolean;
  fetchAvailableIntegration: <TPageData>(
    options?: RefetchOptions & RefetchQueryFilters<TPageData>
  ) => void;
  updateIfUploadModalDirty: (isDirty: boolean, isErrorFile?: boolean) => void;
  configureIntegration: (integration: Integration) => void;
}

const defaultMessage =
  'Custom marketplace is now available in the Available Integrations section.';

const { tenMB } = UPLOAD_FILE_SIZE;

export const UploadIntegration: FC<UploadIntegrationProps> = ({
  onClose,
  fileUpload,
  fetchAvailableIntegration,
  updateIfUploadModalDirty,
  deleteIntegrationMutation,
  configureIntegration
}) => {
  const [fileState, setFileState] = useState<UploadFileState>({
    isFileDropped: false,
    isFileUploading: false
  });
  const [uploadProperties, setUploadProperties] =
    useState<UploadFileProperties>({
      estimatedTimeRemaining: '0',
      percentage: '0'
    });
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [isError, setIsError] = useState(false);
  const [integration, setIntegration] = useState<Integration>(null);

  const onUploadComplete = (
    isApiSuccess: boolean,
    message: string,
    integration: Integration
  ) => {
    setFileState(prev => ({
      ...prev,
      isFileUploading: false
    }));
    setIsError(!isApiSuccess);
    setMessage(message);
    setIntegration(integration);
    updateIfUploadModalDirty(false, isApiSuccess);
  };

  const handleFileUpload = async (uploadFileObject: {
    file: UppyFile<Record<string, unknown>, Record<string, unknown>>;
  }) => {
    const { file } = uploadFileObject;
    setMessage(null);
    setFileState({
      isFileDropped: true,
      isFileUploading: true
    });
    setUploadedFile(file.data as File);
    updateIfUploadModalDirty(true, false);
    fileUpload(file, setUploadProperties, onUploadComplete);
  };

  const deleteUploadedFile = () => {
    if (!isError) {
      deleteIntegrationMutation(integration?.id);
    }
    setFileState(prev => ({
      ...prev,
      isFileDropped: false
    }));
    setMessage(null);
    setUploadProperties(null);
    updateIfUploadModalDirty(false, false);
  };

  return (
    <>
      {!fileState.isFileDropped ? (
        <UploadInput
          type="local"
          options={{
            restrictions: {
              maxFileSize: tenMB,
              maxNumberOfFiles: 1,
              allowedFileTypes: ['.tar', '.zip', '.gz', '.tgz']
            },
            autoProceed: true
          }}
          note="10 MB max file size"
          avatar={fileState.isFileDropped}
          onUploadError={(_, error) => {
            setMessage(error.message);
            setIsError(true);
          }}
          onComplete={handleFileUpload}
        />
      ) : (
        <MotionGroup>
          <List>
            <MotionItem>
              <ListItem disableGutters>
                <div className={css.listItem}>
                  <Stack>
                    <div className={css.item}>
                      <Stack dense>
                        <DocumentIcon className={css.icon} />
                        <div className={css.fileInfo}>
                          <Ellipsis
                            className={css.fileName}
                            value={uploadedFile.name}
                            limit={40}
                          />

                          <br />
                          <DataSize
                            value={uploadedFile.size}
                            emptyValue="N/A"
                          />
                        </div>
                        <Sub className={css.progressInfo}>
                          {uploadProperties?.percentage}%
                          <div className={css.dotDivider} />
                          {uploadProperties?.estimatedTimeRemaining} left
                        </Sub>
                      </Stack>
                      <VerticalSpacer space="sm" />
                      <ProgressBar
                        progress={Number(uploadProperties?.percentage)}
                      />
                    </div>
                    <Button
                      variant="text"
                      disabled={fileState?.isFileUploading}
                      onClick={deleteUploadedFile}
                    >
                      <RemoveIcon />
                    </Button>
                  </Stack>
                </div>
              </ListItem>
            </MotionItem>
          </List>
        </MotionGroup>
      )}
      {uploadProperties?.percentage === FILE_UPLOAD_COMPLETE_PERCENTAGE &&
        uploadedFile &&
        !message && (
          <Text>Please wait while we are validating the marketplace </Text>
        )}
      {message && (
        <>
          <div
            className={classNames(isError ? css.errorText : css.successText, {
              [css.sizeError]: !fileState.isFileDropped
            })}
          >
            {isError ? 'Validation failed!' : 'Validation passed'}
          </div>
          {isError ? message : defaultMessage}
        </>
      )}
      <VerticalSpacer space="md" />
      {fileState.isFileDropped && (
        <div className={css.actions}>
          <Button
            color="primary"
            size="small"
            disabled={isError || fileState?.isFileUploading}
            onClick={() => configureIntegration(integration)}
          >
            Configure Now
          </Button>
          <Button
            variant="outline"
            size="small"
            disabled={fileState?.isFileUploading}
            onClick={() => {
              if (!isError) {
                fetchAvailableIntegration();
              }
              onClose();
            }}
          >
            Cancel
          </Button>
        </div>
      )}
    </>
  );
};
