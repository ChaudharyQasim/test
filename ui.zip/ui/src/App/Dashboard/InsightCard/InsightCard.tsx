import { FC, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Button,
  Card,
  Ellipsis,
  DateFormat,
  List,
  ListItem,
  Menu,
  Stack,
  Text
} from 'reablocks';
import { nanoid } from 'nanoid';
import css from './InsightCard.module.css';

import { ReactComponent as CollectionIssues } from 'assets/icons/collection.svg';
import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as DetectionEffectiveness } from 'assets/icons/detection-effectiveness.svg';
import { ReactComponent as Dot } from 'assets/icons/dot.svg';
import { ReactComponent as EnvironmentVisibilityGaps } from 'assets/icons/environment-visibility.svg';
import { ReactComponent as MenuIcon } from 'assets/icons/dots.svg';
import { ReactComponent as ReadIcon } from 'assets/icons/read.svg';
import { ReactComponent as ShareIcon } from 'assets/icons/share.svg';

import { InsightOut, Category } from 'core/Api';
import { DATE_FORMAT } from 'shared/utils/Constants';

export interface InsightSummary
  extends Pick<
    InsightOut,
    'id' | 'category' | 'created_date' | 'title' | 'assignees'
  > {}

interface InsightCardProps {
  insight: InsightSummary;
}

export const InsightCard: FC<InsightCardProps> = ({ insight }) => {
  const btnRef = useRef<HTMLButtonElement | null>(null);
  const [menuOpen, setMenuOpen] = useState<boolean>(false);

  const navigate = useNavigate();

  const { category, created_date, title, assignees } = insight;

  const renderType = (category: Category[]) => {
    return category.map((type, index) => {
      switch (type) {
        case Category.Collection:
          return (
            <span key={type} className={css.iconContainer}>
              <CollectionIssues className={css.insightIcon} />
              Collection
            </span>
          );
        case Category.Environment:
          return (
            <span key={type} className={css.iconContainer}>
              <EnvironmentVisibilityGaps className={css.insightIcon} />
              Environment
            </span>
          );
        case Category.Detection:
          return (
            <span key={type} className={css.iconContainer}>
              <DetectionEffectiveness className={css.insightIcon} />
              Detection
            </span>
          );
        default:
          return null;
      }
    });
  };

  const renderAssignees = (arr: string[]) => {
    if (!arr || arr.length === 0) {
      return <span className={css.firstAssignee}>Unassigned</span>;
    }

    const userList = arr.reduce((acc, item, index) => {
      if (index === 0) {
        acc.push(
          <Ellipsis
            key={nanoid()}
            className={css.firstAssignee}
            limit={30}
            expandable={false}
            value={item}
          />
        );
      } else {
        acc.push(<span>{' • '} </span>);
        acc.push(<Ellipsis limit={30} expandable={false} value={item} />);
      }
      return acc;
    }, []);

    return userList;
  };

  return (
    <Card
      className={css.insightCard}
      onClick={() => navigate(`/insights/${insight.id}`)}
    >
      <Stack className={css.insightHeader} alignItems="start">
        <Stack direction="column" alignItems="start">
          <div className={css.categoryContainer}>{renderType(category)}</div>

          <Text className={css.insightTitle} fontStyle="bold">
            {title}
          </Text>

          <div className={css.dateContainer}>
            <DateFormat date={created_date} format={DATE_FORMAT} />
          </div>
          <Text className={css.assigneeText}>
            Assignee :{renderAssignees(assignees)}
          </Text>
        </Stack>
      </Stack>
    </Card>
  );
};
