import { FC } from 'react';
import classNames from 'classnames';
import { binaryScale } from 'shared/utils/Constants/data';
import {
  DataSize,
  PrimaryHeading,
  Stack,
  Text,
  VerticalSpacer
} from 'reablocks';
import css from './Metric.module.css';

import { ReactComponent as ArrowUp } from 'assets/icons/arrow-up.svg';
import { ReactComponent as BarChart } from 'assets/icons/bar-chart.svg';
import { ReactComponent as CostReduction } from 'assets/icons/cost-reduction.svg';
import { ReactComponent as LineChart } from 'assets/icons/line-chart.svg';

type MetricProps = {
  metric: any;
};

export const Metric: FC<MetricProps> = ({ metric }) => {
  const { type, label, stat, suffix = '', change = '', lastWeek = '' } = metric;
  const showCostReduction = type === 'costReduction';
  const showBarChart = ['findings', 'insights'].includes(type);
  const showLineChart = ['dataVolume', 'dataReduction'].includes(type);
  const renderStat = () => {
    if (showCostReduction || showBarChart) {
      return stat?.toLocaleString();
    }
    return (
      <DataSize
        value={stat ? stat : null}
        emptyValue="No Data"
        scale={binaryScale}
      />
    );
  };

  return (
    <>
      <Stack className={classNames(css.metric, css[type])} dense>
        {showLineChart && <LineChart />}
        {showCostReduction && <CostReduction />}
        {showBarChart && <BarChart />}
        <Text fontStyle="bold">{label}</Text>
      </Stack>
      <Stack alignItems={suffix ? 'end' : 'start'} dense>
        <PrimaryHeading className={css.stat} disableMargins>
          {renderStat()}
        </PrimaryHeading>

        {change && (
          <Text color="success" fontStyle="bold" className={css.change}>
            <ArrowUp />
            {change}
          </Text>
        )}
        {suffix && <Text fontStyle="bold">{suffix}</Text>}
      </Stack>
      <VerticalSpacer space="md" />
      {lastWeek && (
        <Text className={css.comparedTo}>Compared to {lastWeek} last week</Text>
      )}
    </>
  );
};
