import { FC, useMemo } from 'react';
import classNames from 'classnames';
import {
  Button,
  MotionGroup,
  MotionItem,
  SmallHeading,
  Stack,
  Text,
  VerticalSpacer,
  DotsLoader
} from 'reablocks';
import { Count } from 'reaviz';
import { useNavigate } from 'react-router-dom';
import { EmptyState } from 'shared/elements/EmptyState';
import { Helmet } from 'react-helmet-async';
import { InsightCard } from './InsightCard';
import { Metric } from './Metric';
import { SemiCircleChart } from 'shared/data/SemiCircleChart';
import { Tab, TabList, TabPanel, Tabs } from 'shared/layout/Tabs';
import { BYTES_IN_ONE_GIGABYTE, TIMEFRAME_MAP } from 'shared/utils/Constants';
import { VIEWS } from './DashboardContainer';
import { useMeasure } from 'react-use';
import css from './Dashboard.module.css';

import { ReactComponent as CollectionIssues } from 'assets/icons/collection.svg';
import { ReactComponent as DetectionEffectiveness } from 'assets/icons/detection-effectiveness.svg';
import { ReactComponent as EmptyInsights } from 'assets/illustrations/empty-insights.svg';
import { ReactComponent as EnvironmentVisibilityGaps } from 'assets/icons/environment-visibility.svg';
import { ReactComponent as HeadIcon } from 'assets/icons/head.svg';
import { ReactComponent as Logo } from 'assets/brand/logo-color.svg';
import { ReactComponent as ReductionOfFindings } from 'assets/icons/reduction.svg';

import {
  InsightList,
  Category,
  DashboardMetricsOut,
  MetricsData,
  InsightsMetrics
} from 'core/Api';

type DashboardProps = {
  view: string;
  onViewChange: (view: string) => void;
  dashboardMetricsData: DashboardMetricsOut;
  insightsData: InsightList;
  insightMetricsData: InsightsMetrics;
  isInsightsLoading: boolean;
  pricePerGBPerYear: number;
};

const insightsFindingsData = [
  {
    key: 'Insights',
    data: []
  },
  {
    key: 'Findings',
    data: []
  }
];

const renderCountPercentage: FC<{
  countValue: number;
  percentageValue: number;
}> = ({ countValue, percentageValue }) => {
  const color = percentageValue && percentageValue < 0 ? 'error' : 'success';
  return (
    <>
      <Text fontStyle="bold">
        <Count from={0} to={countValue} />
      </Text>{' '}
      <Text color={color} fontStyle="bold">
        <Count from={0} to={percentageValue} suffix="%" />
      </Text>
    </>
  );
};

const renderLoader = () => (
  <div className={css.loading}>
    <DotsLoader />
  </div>
);

/**
 * @description Helper function to compute cost reduction based on data reduction total, timeframe and unit price per GB per year
 * @param {number} dataReductionTotal - Total data reduction in bytes
 * @param {number} timeframeByHours - Timeframe in hours (1D, 1W, 1M, 3M, 1Y)
 * @param {number} pricePerGBPerYear - Unit price per GB per year (Eg. $800/GB/year)
 * @returns {string} - Cost reduction in USD
 **/
const computeCostReduction = ({
  dataReductionTotal,
  timeframeByHours,
  pricePerGBPerYear
}: {
  dataReductionTotal: number;
  timeframeByHours: number;
  pricePerGBPerYear: number;
}) => {
  if (
    !dataReductionTotal ||
    typeof pricePerGBPerYear !== 'number' ||
    pricePerGBPerYear <= 0
  ) {
    return 'No Data';
  }
  /*
   * Convert unit price per GB per year to GB per hour
   * Estimate without an extra day in the leap year
   * Eg. $800/GB/year = $800/365/24 = $0.091/GB/hour
   */
  const pricePerGBPerHour = pricePerGBPerYear / 365 / 24;
  // Convert total data reduction (bytes) to GB
  const totalDataReductionInGB = dataReductionTotal / BYTES_IN_ONE_GIGABYTE;

  /*
   * Cost reduction = total data reduced (GB) * selected timeframe (hours) * price per GB per hour
   * Eg. In 1W timeframe, 100GB data reduced = 100 * 168 * $0.091 = $1,533.6
   * Eg. In 1Y timeframe, 100GB data reduced = 100 * 8760 * $0.091 = $79,896
   */
  const costReduction =
    totalDataReductionInGB * timeframeByHours * pricePerGBPerHour;

  return costReduction.toLocaleString(undefined, {
    style: 'currency',
    currency: 'USD'
  });
};

/**
 * @description Helper function to get observation metrics based on timeframe and metrics data type
 * @param {MetricsData} dashboardMetrics - Dashboard metrics data
 * @param {string} timeframe - Timeframe 1D, 1W, 1M, 3M, 1Y
 * @param {number} pricePerGBPerYear - Unit price per GB per hour
 * @returns {Array} - Array of observation metrics
 **/
const getObservationMetrics = ({
  dashboardMetrics,
  insightMetrics,
  timeframe,
  pricePerGBPerYear
}: {
  dashboardMetrics: MetricsData;
  insightMetrics: InsightsMetrics;
  timeframe: string;
  pricePerGBPerYear: number;
}) => {
  const { data_volume, data_reduction, total_findings } = dashboardMetrics;
  const costReductionStat = computeCostReduction({
    dataReductionTotal: data_reduction?.total,
    timeframeByHours: TIMEFRAME_MAP[timeframe].hours,
    pricePerGBPerYear: pricePerGBPerYear
  });
  const metrics = [
    {
      type: 'dataVolume',
      label: 'Data Volume',
      stat: data_volume?.rate || 0,
      suffix: `/hr`
    },
    {
      type: 'dataReduction',
      label: 'Data Reduction',
      stat: data_reduction?.rate || 0,
      suffix: `/hr`
    },
    { type: 'findings', label: 'Findings', stat: total_findings?.total || 0 },
    {
      type: 'insights',
      label: 'Insights',
      stat: insightMetrics?.total_insights || 0
    },
    {
      type: 'costReduction',
      label: 'Cost Reduction',
      stat: costReductionStat || 0,
      suffix: pricePerGBPerYear && `${TIMEFRAME_MAP[timeframe].perTimeSuffix}`
    }
  ];

  /**
   * @todo: Insights, percentage change and last week data are not available from the API yet.
   */
  return metrics.map(metric => ({ ...metric, change: null, lastWeek: null }));
};

/**
 * @description Helper function to convert item.key (string) as Date object needed for RadialAreaSeries usage
 * @param {DashboardMetricsOut} metrics - Dashboard metrics data
 * @returns {DashboardMetricsOut} - Updated dashboard metrics data with Date object
 */
const mapDashboardMetrics = (metrics: DashboardMetricsOut) => {
  const metricKeys = ['data_reduction', 'total_findings', 'data_volume'];
  const updatedMetrics = { ...metrics };

  metricKeys.forEach(metric => {
    const metricValues = updatedMetrics?.dashboard_metrics?.[metric]?.value;
    if (metricValues && metricValues.length > 0) {
      updatedMetrics.dashboard_metrics[metric].value = metricValues.map(
        ({ key, ...rest }) => ({
          key: new Date(key),
          ...rest
        })
      );
    }
  });

  return updatedMetrics;
};

export const Dashboard: FC<DashboardProps> = ({
  view = '1W',
  onViewChange,
  dashboardMetricsData,
  insightsData,
  insightMetricsData,
  isInsightsLoading,
  pricePerGBPerYear
}) => {
  const navigate = useNavigate();
  const [ref, { width, height }] = useMeasure();
  const { insights } = insightsData;
  const { dashboard_metrics: dashboardMetrics } =
    mapDashboardMetrics(dashboardMetricsData);
  const {
    data_volume: dataVolume,
    data_reduction: dataReduction,
    total_findings: totalFindings
  } = dashboardMetrics;
  const {
    last_metrics: lastMetrics,
    percentage_change: percentageChange,
    total_insights
  } = insightMetricsData;
  const findingsReduction =
    ((totalFindings.total - total_insights) / totalFindings.total) * 100;

  /**
   * @todo:Dashboard Metrics is not available for Insights yet.
   * @description InsightsFindingsData is an array of two objects
   */

  insightsFindingsData[1].data = totalFindings?.value ?? [];

  const observationMetrics = useMemo(
    () =>
      getObservationMetrics({
        dashboardMetrics: dashboardMetrics,
        insightMetrics: insightMetricsData,
        timeframe: view,
        pricePerGBPerYear: pricePerGBPerYear
      }),
    [dashboardMetrics, insightMetricsData, view, pricePerGBPerYear]
  );

  const hasInsights = insights.length > 0;
  const hasCollectionInsights = insights.some(
    insight => insight?.category?.includes(Category.Collection)
  );
  const hasEnvironmentInsights = insights.some(
    insight => insight?.category?.includes(Category.Environment)
  );
  const hasDetectionInsights = insights.some(
    insight => insight?.category?.includes(Category.Detection)
  );

  const renderEmpty = () => (
    <MotionItem className={css.empty}>
      <EmptyState
        illustration={<EmptyInsights />}
        title="No results found"
        subtitle="Looks like there's nothing here at the moment. We will begin adding information as it becomes available."
      />
    </MotionItem>
  );

  const renderInsights = (type?: Category) => (
    <Stack direction="column">
      {insights.map(insight =>
        !type || insight.category.includes(type) ? (
          <MotionItem className={css.insightsMotion} key={insight.id}>
            <InsightCard insight={insight} />
          </MotionItem>
        ) : null
      )}
    </Stack>
  );

  return (
    <>
      <Helmet>
        <title>Dashboard</title>
      </Helmet>
      <div className={css.root}>
        <Stack justifyContent="spaceBetween">
          <Logo />
          <Stack>
            <Stack className={css.dateRangePicker}>
              {VIEWS.map(viewOption => (
                <Button
                  key={viewOption}
                  variant="text"
                  className={classNames(css.dateRangeBtn, {
                    [css.activeView]: viewOption === view
                  })}
                  onClick={() => onViewChange(viewOption)}
                  title={TIMEFRAME_MAP[viewOption].label}
                >
                  {viewOption}
                </Button>
              ))}
            </Stack>
          </Stack>
        </Stack>
        <Stack className={css.main} alignItems="start">
          <Stack className={css.display} direction="column" alignItems="start">
            <Stack className={css.info}>
              <div>
                <HeadIcon />
              </div>
              <Stack className={css.infoItems}>
                <Stack className={css.infoItemContainer}>
                  <div className={css.infoIcon}>
                    <CollectionIssues />
                  </div>
                  <div>
                    <div className={css.infoLabel}>Collection Issues</div>
                    {renderCountPercentage({
                      countValue: lastMetrics.collection,
                      percentageValue: percentageChange.collection
                    })}
                  </div>
                </Stack>
                <Stack className={css.infoItemContainer}>
                  <div className={css.infoIcon}>
                    <EnvironmentVisibilityGaps />
                  </div>
                  <div>
                    <div className={css.infoLabel}>
                      Environment Visibility Gaps
                    </div>
                    {renderCountPercentage({
                      countValue: lastMetrics.environment,
                      percentageValue: percentageChange.environment
                    })}
                  </div>
                </Stack>
                <Stack className={css.infoItemContainer}>
                  <div className={css.infoIcon}>
                    <DetectionEffectiveness />
                  </div>
                  <div>
                    <div className={css.infoLabel}>Detection Effectiveness</div>
                    {renderCountPercentage({
                      countValue: lastMetrics.detection,
                      percentageValue: percentageChange.detection
                    })}
                  </div>
                </Stack>
                <Stack className={css.infoItemContainer}>
                  <div className={css.infoIcon}>
                    <ReductionOfFindings />
                  </div>
                  <div>
                    <div className={css.infoLabel}>
                      Reduction of Findings to Insights
                    </div>
                    <Text
                      color={findingsReduction < 0 ? 'error' : 'success'}
                      fontStyle="bold"
                    >
                      <Count
                        from={0}
                        decimalPlaces={2}
                        to={findingsReduction || 0}
                        suffix="%"
                      />
                    </Text>
                  </div>
                </Stack>
              </Stack>
            </Stack>
            <div ref={ref} className={css.chart}>
              <SemiCircleChart
                insightsFindingsData={insightsFindingsData}
                reductionData={dataReduction?.value}
                volumeData={dataVolume?.value}
                // accounting for the fact that the chart was
                // is being calculated as if it were a full
                // radial chart, the translate is off a bit
                margins={[height / 1.2, 0]}
                width={width}
                height={height * 1.4}
              />
            </div>
            <SmallHeading>
              {TIMEFRAME_MAP[view].label} Aggregated Observations
            </SmallHeading>
            <MotionGroup className={css.stats}>
              {observationMetrics.map(metric => (
                <MotionItem key={metric.type}>
                  <Metric metric={metric} />
                </MotionItem>
              ))}
            </MotionGroup>
          </Stack>
          <MotionGroup className={css.insights}>
            <Stack justifyContent="spaceBetween">
              <SmallHeading>Open Insights</SmallHeading>
              <Button
                size="small"
                variant="text"
                className={css.seeMore}
                onClick={() => navigate('/insights')}
                disableMargins
                disablePadding
              >
                See all
              </Button>
            </Stack>
            <VerticalSpacer space="lg" />
            <Tabs className={css.tabs}>
              <TabList disableBorder>
                <Tab size="small">All Insights</Tab>
                <Tab size="small">Collection</Tab>
                <Tab size="small">Environment</Tab>
                <Tab size="small">Detection</Tab>
              </TabList>
              <TabPanel className={css.tabPanel}>
                {isInsightsLoading && renderLoader()}
                {hasInsights ? renderInsights() : renderEmpty()}
              </TabPanel>
              <TabPanel className={css.tabPanel}>
                {isInsightsLoading && renderLoader()}
                {hasCollectionInsights
                  ? renderInsights(Category.Collection)
                  : renderEmpty()}
              </TabPanel>
              <TabPanel className={css.tabPanel}>
                {isInsightsLoading && renderLoader()}
                {hasEnvironmentInsights
                  ? renderInsights(Category.Environment)
                  : renderEmpty()}
              </TabPanel>
              <TabPanel className={css.tabPanel}>
                {isInsightsLoading && renderLoader()}
                {hasDetectionInsights
                  ? renderInsights(Category.Detection)
                  : renderEmpty()}
              </TabPanel>
            </Tabs>
          </MotionGroup>
        </Stack>
      </div>
    </>
  );
};
