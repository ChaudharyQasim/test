import { FC, useEffect } from 'react';
import { useQuery } from 'react-query';
import { useQueryParam, StringParam, withDefault } from 'use-query-params';

import { useAuth } from 'core/Auth';
import { useQueryParams } from 'core/Hooks/useQueryParams';
import { getDashboardMetrics } from 'core/Api/DashboardApi';
import { getInsightMetrics, getInsights } from 'core/Api/InsightsApi';

import { Loader } from 'shared/elements/Loader';

import { Dashboard } from './Dashboard';
import { PRICE_PER_GB_PER_YEAR } from 'shared/utils/Constants';
import { DashboardMetricsOut, InsightsMetrics } from 'core/Api';

export const VIEWS = ['1D', '1W', '1M', '3M', '1Y'];

export const DashboardContainer: FC = () => {
  const { user } = useAuth();
  const [view, setView] = useQueryParam('view', withDefault(StringParam, '1W'));
  const emptyDashboardData: DashboardMetricsOut = {
    dashboard_metrics: {
      data_reduction: {
        value: [],
        rate: 0,
        total: 0
      },
      total_findings: {
        value: [],
        rate: 0,
        total: 0
      },
      data_volume: {
        value: [],
        rate: 0,
        total: 0
      }
    }
  };
  const emptyInsightMetricsData: InsightsMetrics = {
    last_metrics: {
      collection: 0,
      environment: 0,
      detection: 0
    },
    previous_metrics: {
      collection: 0,
      environment: 0,
      detection: 0
    },
    percentage_change: {
      collection: 0,
      environment: 0,
      detection: 0
    },
    reduction_percentage: 0,
    total_insights: 0
  };

  useEffect(() => {
    if (!VIEWS.includes(view)) {
      setView('1W');
    }
  }, [view, setView]);

  const { page } = useQueryParams();

  const { data: dashboardMetricsData, isLoading: isDashboardMetricsLoading } =
    useQuery(
      ['dashboardMetrics', view],
      async () => {
        const data = await getDashboardMetrics({ timeframe: view });
        /**
         * @description Ensure dashboard_metrics always has the required base keys
         * This is to avoid the dashboard breaking
         * if the API returns a partial response
         */
        return {
          dashboard_metrics: {
            ...emptyDashboardData.dashboard_metrics,
            ...data.dashboard_metrics
          }
        };
      },
      {
        enabled: !!user,
        initialData: emptyDashboardData
      }
    );

  const { data: insights, isLoading: isInsightsLoading } = useQuery(
    'insights',
    () =>
      getInsights(user.email, {
        page_number: parseInt(page) || 1,
        page_size: 10
      }),
    {
      enabled: !!user,
      initialData: {
        insights: [],
        metadata: {
          page_number: 1,
          page_size: 10,
          total_count: 0
        }
      }
    }
  );

  const { data: insightMetricsData, isLoading: isInsightMetricsLoading } =
    useQuery(
      ['insightMetrics', view],

      async () => {
        const data = await getInsightMetrics({ timeframe: view });
        return {
          ...emptyInsightMetricsData,
          ...data
        };
      },
      {
        enabled: !!user,
        initialData: emptyInsightMetricsData
      }
    );

  if (
    isDashboardMetricsLoading ||
    isInsightsLoading ||
    isInsightMetricsLoading
  ) {
    return <Loader />;
  }

  return (
    <Dashboard
      view={view}
      onViewChange={setView}
      dashboardMetricsData={dashboardMetricsData}
      insightsData={insights}
      insightMetricsData={insightMetricsData}
      isInsightsLoading={isInsightsLoading}
      pricePerGBPerYear={PRICE_PER_GB_PER_YEAR}
    />
  );
};
