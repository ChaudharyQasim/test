export { DashboardContainer as default } from './DashboardContainer';
