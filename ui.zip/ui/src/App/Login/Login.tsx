import { FC } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import {
  Block,
  Button,
  Divider,
  Input,
  MotionGroup,
  MotionItem,
  PageTitle,
  SmallHeading
} from 'reablocks';

// Form lib validation
import * as Yup from 'yup';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

// Core
import { useAuth } from 'core/Auth';

// Icons
import { ReactComponent as LogoIcon } from 'assets/brand/logo-color.svg';
import { ReactComponent as GoogleIcon } from 'assets/icons/google.svg';
import { ReactComponent as MicrosoftIcon } from 'assets/icons/microsoft.svg';

// CSS
import css from './Login.module.css';

// Types
type LoginProps = {
  onRequestPasscode: (email: string) => Promise<void>;
};

const credentialsSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email').required('Required')
});

export const Login: FC<LoginProps> = ({ onRequestPasscode }) => {
  const { login } = useAuth();

  const navigate = useNavigate();

  const {
    control,
    handleSubmit,
    formState: { isSubmitting, isValid },
    getValues
  } = useForm({
    mode: 'onChange',
    reValidateMode: 'onChange',
    resolver: yupResolver(credentialsSchema),
    defaultValues: {
      email: ''
    }
  });

  return (
    <>
      <Helmet>
        <title>Login</title>
      </Helmet>
      <div className={css.root}>
        <MotionGroup>
          <MotionItem className={css.header}>
            <LogoIcon className={css.logo} />
          </MotionItem>
          <div className={css.content}>
            <MotionGroup className={css.box}>
              <MotionItem className={css.login}>
                <header className={css.loginHeader}>
                  <PageTitle disableMargins className={css.loginTitle}>
                    Welcome Back!
                  </PageTitle>
                  <SmallHeading className={css.tagline}>
                    Please fill in the details to access your account
                  </SmallHeading>
                </header>
                <form
                  onSubmit={handleSubmit(() =>
                    onRequestPasscode(getValues('email'))
                  )}
                >
                  <Block label="Email">
                    <Controller
                      name="email"
                      control={control}
                      render={({ field: { value, onBlur, onChange } }) => (
                        <Input
                          name="email"
                          disabled={isSubmitting}
                          autoFocus
                          type="email"
                          value={value}
                          onChange={onChange}
                          onBlur={onBlur}
                          placeholder="user@abstract.security"
                        />
                      )}
                    />
                  </Block>
                  <br />
                  <Button
                    type="submit"
                    fullWidth
                    variant="filled"
                    color="primary"
                    disabled={isSubmitting || !isValid}
                  >
                    {isSubmitting ? 'Sending...' : 'Request Passcode'}
                  </Button>
                </form>
              </MotionItem>
              <MotionItem className={css.login}>
                <span className={css.or}>
                  <Divider />
                  <span className={css.text}>OR</span>
                </span>
              </MotionItem>
              <MotionItem className={css.login}>
                <Button
                  fullWidth
                  variant="outline"
                  color="default"
                  disabled={isSubmitting}
                  className={css.tpaButton}
                  onClick={() => login({ type: 'google' })}
                >
                  <GoogleIcon />
                  Continue with Google
                </Button>
                <Button
                  fullWidth
                  variant="outline"
                  color="default"
                  disabled={isSubmitting}
                  className={css.tpaButton}
                  onClick={() => login({ type: 'microsoft' })}
                >
                  <MicrosoftIcon />
                  Continue with Microsoft
                </Button>
              </MotionItem>
              <MotionItem className={css.login}>
                <SmallHeading className={css.tagline}>
                  Don&rsquo;t have an account?{' '}
                  <Button
                    variant="text"
                    color="primary"
                    disableMargins
                    disablePadding
                    onClick={() => navigate('/signup')}
                  >
                    Sign up
                  </Button>
                </SmallHeading>
              </MotionItem>
            </MotionGroup>
          </div>
        </MotionGroup>
      </div>
    </>
  );
};
