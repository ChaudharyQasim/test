import { FC, useCallback } from 'react';
import { Login } from './Login';
import { useNotification } from 'reablocks';
import { useNavigate, Navigate } from 'react-router-dom';

// Hooks
import { useAuth } from 'core/Auth';

// Shared
import { Loader } from 'shared/elements/Loader';

// API Service
import { postLogin } from 'core/Api/AuthApi';

export const LoginContainer: FC = () => {
  const { user, isAuthenticated, isLoading } = useAuth();

  const { notifyError } = useNotification();

  const navigate = useNavigate();

  const onRequestPasscode = useCallback(
    async (email: string) => {
      try {
        await postLogin({
          email: decodeURIComponent(email)
        });

        navigate({
          pathname: '/passcode',
          search: `?email=${encodeURIComponent(email)}`
        });
      } catch (error: any) {
        notifyError(`Failed to resent a new passcode, error: ${error.message}`);
      }
    },
    [notifyError, navigate]
  );

  if (isLoading) {
    return <Loader />;
  }

  if (user && !user?.is_active) {
    return <Navigate to="/pending-approval" />;
  }

  if (isAuthenticated) {
    return <Navigate to="/user-onboarding" />;
  }

  return <Login onRequestPasscode={onRequestPasscode} />;
};
