import { FC } from 'react';
import { Helmet } from 'react-helmet-async';
import css from './NotFound.module.css';
import { ReactComponent as NotFoundIllustration } from 'assets/illustrations/not-found.svg';
import { PrimaryHeading, VerticalSpacer } from 'reablocks';

export const NotFound: FC = () => (
  <>
    <Helmet>
      <title>Not Found</title>
    </Helmet>
    <div className={css.container}>
      <div className={css.icon}>
        <NotFoundIllustration />
      </div>
      <VerticalSpacer space="lg" />
      <PrimaryHeading>404 - Page Missing</PrimaryHeading>
    </div>
  </>
);
