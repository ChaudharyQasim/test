export { NotFound as default } from './NotFound';
