import { FC, useMemo, useState } from 'react';
import { UseMutateAsyncFunction, UseMutateFunction } from 'react-query';
import { PipelineConnector } from 'App/PipelineManager/PipelineConnector';

// Shared
import { Loader } from 'shared/elements/Loader';
import { createNodes } from 'shared/utils/Helper';

// Types
import { ConfigurationOut, RouteIn, RouteOut } from 'core/Api';
import { nanoid } from 'nanoid';
import { ConfirmationDialog } from 'shared/layers/ConfirmationDialog';

enum ActionMenuId {
  Edit = 0,
  Delete = 1
}

type RoutePropsType = {
  sourceConfigurations: ConfigurationOut[];
  destinationConfigurations: ConfigurationOut[];
  routes: RouteOut[];
  isLoadingPipeline: boolean;
  selectedVendorId: string;
  canvasClassName?: string;
  onAddConnection: UseMutateAsyncFunction<RouteOut, any, RouteIn, unknown>;
  onDeleteConnection: UseMutateFunction<any, any, string, unknown>;
  onEditConnection: (id: string) => void;
};

type LoadRoutesType = {
  source_configuration_id: string;
  destination_configuration_id: string;
  route_id: string;
  isNodeLoading: boolean;
};

export const PipelineRoute: FC<RoutePropsType> = ({
  routes,
  selectedVendorId,
  sourceConfigurations,
  destinationConfigurations,
  isLoadingPipeline,
  canvasClassName,
  onAddConnection,
  onEditConnection,
  onDeleteConnection
}) => {
  const [isConnectingRoutes, setIsConnectingRoutes] = useState<
    LoadRoutesType[]
  >([]);

  const [openConfirmationDialog, setOpenConfirmationDialog] =
    useState<boolean>(false);

  const [routeIdToDelete, setRouteIdToDelete] = useState<string | null>(null);

  const routeNodes = useMemo(() => {
    const uniqueRoutesSet = new Set();
    const uniqueRoutesArray = [];

    routes.forEach(({ route_id: id, route_pipeline }) => {
      if (!uniqueRoutesSet.has(id)) {
        const {
          name: pipelineLabel,
          is_passthrough,
          id: pipelineId
        } = route_pipeline || {};
        uniqueRoutesSet.add(id);
        uniqueRoutesArray.push({
          id,
          label: null,
          pipelineLabel,
          is_passthrough,
          category: 'ROUTE',
          icon: null,
          pipelineId
        });
      }
    });
    return uniqueRoutesArray;
  }, [routes]);

  const loaderNodes = useMemo(
    () =>
      isConnectingRoutes.map(({ route_id, isNodeLoading }) => ({
        id: route_id,
        label: null,
        pipelineLabel: null,
        is_passthrough: false,
        category: 'ROUTE',
        icon: null,
        isNodeLoading
      })),
    [isConnectingRoutes]
  );

  // Formatting the source node (source configurations).
  const sourceNodes = useMemo(
    () => createNodes(sourceConfigurations, 'SOURCE'),
    [sourceConfigurations]
  );

  // Formatting the destination node (destination configurations).
  const destinationNodes = useMemo(
    () => createNodes(destinationConfigurations, 'DESTINATION'),
    [destinationConfigurations]
  );

  const confirmationDialogMessage = useMemo(() => {
    const deleteRouteName = routeNodes.find(
      route => route.id === routeIdToDelete
    )?.pipelineLabel;
    return `Are you sure you want to delete ${deleteRouteName}?`;
  }, [routeIdToDelete, routeNodes]);

  const edges = useMemo(() => {
    const uniqueEdgesSet = new Set();

    /**
     *
     * This function creates the edges between sorce -> route and route -> destination.
     * Each edge object returns source, destination, route (which connects the source to destination).
     * Each edge object represent source -> destination edge so dividing it into source -> route and route -> destination.
     *
     */
    const uniqueEdges = [...routes, ...isConnectingRoutes].flatMap(
      ({ source_configuration_id, route_id, destination_configuration_id }) => {
        const sourceToRouteId = `${source_configuration_id}-${route_id}`;
        const routeToDestId = `${route_id}-${destination_configuration_id}`;

        if (!uniqueEdgesSet.has(sourceToRouteId)) {
          uniqueEdgesSet.add(sourceToRouteId);
          return [
            {
              id: sourceToRouteId,
              start: `${source_configuration_id}`,
              end: `${route_id}`
            },
            {
              id: routeToDestId,
              start: `${route_id}`,
              end: `${destination_configuration_id}`
            }
          ];
        }

        return [];
      }
    );
    return uniqueEdges;
  }, [routes, isConnectingRoutes]);

  const actions = (menuId: number, id: string, pipelineId: string) => {
    if (menuId === ActionMenuId.Edit) {
      // navigate to edit pipeline
      onEditConnection(pipelineId);
    } else {
      // Deleting the route
      setRouteIdToDelete(id);
      setOpenConfirmationDialog(true);
    }
  };

  const handleAddConnection = async (
    source_configuration_id: string,
    destination_configuration_id: string
  ) => {
    // fetching source details needed for route creation
    const {
      integration_id: source_integration_id,
      name: source_configuration_name
    } = sourceConfigurations.find(
      configuration => configuration.id === source_configuration_id
    );

    // fetching destination details needed for route creation
    const {
      integration_id: destination_integration_id,
      name: destination_configuration_name
    } = destinationConfigurations.find(
      configuration => configuration.id === destination_configuration_id
    );

    const route_id = nanoid();

    // creating dummy route from source to destination to create loader node.
    const dummyNode = {
      source_configuration_id,
      destination_configuration_id,
      route_id,
      isNodeLoading: true
    };

    try {
      setIsConnectingRoutes(prev => [...prev, dummyNode]);

      await onAddConnection({
        source_integration_id,
        source_configuration_id,
        source_configuration_name,
        vendor_account_id: selectedVendorId,
        destination_integration_id,
        destination_configuration_id,
        destination_configuration_name
      });
    } finally {
      // Removing the loader Nodes.
      setIsConnectingRoutes(
        prev => prev?.filter(node => node.route_id !== route_id)
      );
    }
  };

  if (isLoadingPipeline) {
    return <Loader />;
  }

  return (
    <>
      <PipelineConnector
        nodes={
          sourceConfigurations.length && destinationConfigurations.length
            ? [
                ...sourceNodes,
                ...destinationNodes,
                ...routeNodes,
                ...loaderNodes
              ]
            : []
        }
        canvasClassName={canvasClassName}
        edges={edges}
        actions={actions}
        onAddConnection={handleAddConnection}
      />
      <ConfirmationDialog
        open={openConfirmationDialog}
        dialogType="DELETE"
        confirmationButtonName="Delete route"
        confirmationHeading="Want to delete route?"
        confirmationMessage={confirmationDialogMessage}
        onConfirm={() => {
          onDeleteConnection(routeIdToDelete);
          setOpenConfirmationDialog(false);
        }}
        onCancel={() => setOpenConfirmationDialog(false)}
      />
    </>
  );
};
