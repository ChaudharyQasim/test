import { FC, useState } from 'react';
import classNames from 'classnames';
import {
  Block,
  Button,
  Collapse,
  Divider,
  Kbd,
  List,
  ListItem,
  Popover,
  Select,
  SelectOption
} from 'reablocks';
import { AnimatePresence, motion } from 'framer-motion';
import { NavLink, useNavigate } from 'react-router-dom';
import { Tooltip } from 'shared/layers/Tooltip';
import { useHotkeys } from 'reakeys';
import { useLocalStorage } from 'react-use';
import css from './Nav.module.css';

import { useAuth } from 'core/Auth';

import { ReactComponent as Logo } from 'assets/brand/logo-color.svg';
import { ReactComponent as LogoCollapsed } from 'assets/brand/icon-color.svg';
import { ReactComponent as CollapseIcon } from 'assets/icons/chevron-right.svg';
import { ReactComponent as DashboardIcon } from 'assets/icons/dashboard.svg';
import { ReactComponent as ViewsIcon } from 'assets/icons/views.svg';
import { ReactComponent as AnalystIcon } from 'assets/icons/analyst.svg';
import { ReactComponent as DataIcon } from 'assets/icons/data-config.svg';
import { ReactComponent as InvestigationIcon } from 'assets/icons/investigations.svg';
import { ReactComponent as SettingsIcon } from 'assets/icons/settings.svg';
import { ReactComponent as LogoutIcon } from 'assets/icons/logout.svg';
import { ReactComponent as ArrowIcon } from 'assets/icons/filled-arrow-down.svg';
import { ReactComponent as PipelineIcon } from 'assets/icons/pipeline.svg';

import { useOrganization } from 'core/Organization';

export const Nav: FC = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { organizationList, fetchCurrentOrganization } = useOrganization();
  const [collapseNav, setCollapseNav] = useLocalStorage<boolean>(
    '@abs:nav-collapsed',
    false
  );

  const pathname = location.pathname + location.search;
  const isSettings = pathname.includes('/settings');

  const [settingsExpanded, setSettingsExpanded] = useState(isSettings);

  useHotkeys([
    {
      name: 'Dashboard',
      keys: 'd',
      category: 'Navigation',
      description: 'Navigate to the Dashboard',
      callback: () => navigate('/')
    },
    {
      name: 'Views',
      keys: 'v',
      category: 'Navigation',
      description: 'Navigate to Views',
      callback: () => navigate('/views')
    },
    {
      name: 'Pipelines',
      keys: 'p',
      category: 'Navigation',
      description: 'Navigate to Pipelines',
      callback: () => navigate('/pipeline')
    },
    {
      name: 'Rules',
      keys: 'r',
      category: 'Navigation',
      description: 'Navigate to Rules',
      callback: () => navigate('/rules')
    },
    {
      name: 'Insights',
      keys: 'i',
      category: 'Navigation',
      description: 'Navigate to Insights',
      callback: () => navigate('/insights')
    }
  ]);

  const renderLabel = (label: string) => {
    return (
      <motion.span
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        {label}
      </motion.span>
    );
  };

  return (
    <AnimatePresence>
      <motion.nav
        className={classNames(css.root, { [css.collapsed]: collapseNav })}
        initial={{ opacity: 0, left: -15 }}
        animate={{ opacity: 1, left: 0 }}
      >
        <div className={css.logoContainer}>
          <Button variant="text" onClick={() => navigate('/')} disablePadding>
            {collapseNav ? (
              <LogoCollapsed className={css.logoCollapsed} />
            ) : (
              <Logo className={css.logo} />
            )}
          </Button>
          <Button
            className={classNames(css.collapseToggle, {
              [css.collapsed]: collapseNav
            })}
            variant="text"
            disablePadding
            disableMargins
            onClick={() => setCollapseNav(!collapseNav)}
          >
            <CollapseIcon />
          </Button>
        </div>
        <Block>
          <Select
            clearable={false}
            placeholder="Select a role..."
            value={user.current_organization.id}
            onChange={value => {
              fetchCurrentOrganization(value);
            }}
          >
            {organizationList?.map(organization => (
              <SelectOption key={organization.id} value={organization.id}>
                {organization.name}
              </SelectOption>
            ))}
          </Select>
        </Block>
        <Tooltip
          content={
            <>
              Dashboard <Kbd variant="outline" keycode="d" />
            </>
          }
          placement="right"
          arrow
        >
          <NavLink
            to="/dashboard"
            className={({ isActive }) =>
              isActive ? classNames(css.navItem, css.active) : css.navItem
            }
          >
            <DashboardIcon /> {!collapseNav && renderLabel('Dashboard')}
          </NavLink>
        </Tooltip>
        <Tooltip
          content={
            <>
              Views <Kbd variant="outline" keycode="v" />
            </>
          }
          placement="right"
          arrow
        >
          <NavLink
            to="/views"
            className={({ isActive }) =>
              isActive ? classNames(css.navItem, css.active) : css.navItem
            }
          >
            <ViewsIcon /> {!collapseNav && renderLabel('Views')}
          </NavLink>
        </Tooltip>
        <Tooltip
          content={
            <>
              Pipelines <Kbd variant="outline" keycode="p" />
            </>
          }
          placement="right"
          arrow
        >
          <NavLink
            to="/pipeline"
            className={({ isActive }) =>
              isActive ? classNames(css.navItem, css.active) : css.navItem
            }
          >
            <PipelineIcon /> {!collapseNav && renderLabel('Pipelines')}
          </NavLink>
        </Tooltip>
        <Tooltip
          content={
            <>
              Rules <Kbd variant="outline" keycode="r" />
            </>
          }
          placement="right"
          arrow
        >
          <NavLink
            to="/rules"
            className={({ isActive }) =>
              isActive ? classNames(css.navItem, css.active) : css.navItem
            }
          >
            <AnalystIcon /> {!collapseNav && renderLabel('Rules')}
          </NavLink>
        </Tooltip>
        <Tooltip
          content={
            <>
              Insights <Kbd variant="outline" keycode="i" />
            </>
          }
          placement="right"
          arrow
        >
          <NavLink
            to="/insights"
            className={({ isActive }) =>
              isActive ? classNames(css.navItem, css.active) : css.navItem
            }
          >
            <InvestigationIcon /> {!collapseNav && renderLabel('Insights')}
          </NavLink>
        </Tooltip>
        <Divider />

        <Tooltip content="Marketplace" placement="right" arrow>
          <NavLink
            to="/marketplace"
            className={({ isActive }) =>
              isActive ? classNames(css.navItem, css.active) : css.navItem
            }
          >
            <DataIcon /> {!collapseNav && renderLabel('Marketplace')}
          </NavLink>
        </Tooltip>

        {collapseNav ? (
          <Popover
            placement="right-start"
            className={css.popover}
            closeOnClick
            content={() => (
              <List className={css.list}>
                <ListItem className={css.listItem} dense>
                  <NavLink
                    to="/settings/user-profile"
                    className={({ isActive }) =>
                      classNames(css.popoverItem, { [css.active]: isActive })
                    }
                  >
                    Profile
                  </NavLink>
                </ListItem>
                <ListItem className={css.listItem} dense>
                  <NavLink
                    to="/settings/organization"
                    className={({ isActive }) =>
                      classNames(css.popoverItem, { [css.active]: isActive })
                    }
                  >
                    Organization
                  </NavLink>
                </ListItem>
                <ListItem className={css.listItem} dense>
                  <NavLink
                    to="/settings/instances"
                    className={({ isActive }) =>
                      classNames(css.popoverItem, { [css.active]: isActive })
                    }
                  >
                    Instances
                  </NavLink>
                </ListItem>
                <ListItem className={css.listItem} dense>
                  <NavLink
                    to="/settings/logs"
                    className={({ isActive }) =>
                      classNames(css.popoverItem, { [css.active]: isActive })
                    }
                  >
                    Audit Logs
                  </NavLink>
                </ListItem>
              </List>
            )}
          >
            <Tooltip content="Settings" placement="right" arrow>
              <div className={css.navItem}>
                <SettingsIcon />
              </div>
            </Tooltip>
          </Popover>
        ) : (
          <>
            <Tooltip content="Settings" placement="right" arrow>
              <div>
                <NavLink
                  to="/settings/user-profile"
                  className={({ isActive }) =>
                    isActive ? classNames(css.navItem, css.active) : css.navItem
                  }
                  onClick={() => setSettingsExpanded(!settingsExpanded)}
                >
                  <SettingsIcon /> {!collapseNav && renderLabel('Settings')}
                  <div className={css.spacer} />
                  <motion.span
                    transition={{ delay: 0.3 }}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <ArrowIcon
                      className={settingsExpanded ? css.expanded : ''}
                    />
                  </motion.span>
                </NavLink>
              </div>
            </Tooltip>
            <Collapse expanded={settingsExpanded}>
              <List className={css.list}>
                <ListItem disablePadding>
                  <NavLink
                    to="/settings/user-profile"
                    className={({ isActive }) =>
                      classNames(css.navSubitem, { [css.active]: isActive })
                    }
                  >
                    Profile
                  </NavLink>
                </ListItem>
                <ListItem disablePadding>
                  <NavLink
                    to="/settings/organization"
                    className={({ isActive }) =>
                      classNames(css.navSubitem, { [css.active]: isActive })
                    }
                  >
                    Organization
                  </NavLink>
                </ListItem>
                <ListItem disablePadding>
                  <NavLink
                    to="/settings/instances"
                    className={({ isActive }) =>
                      classNames(css.navSubitem, { [css.active]: isActive })
                    }
                  >
                    Instances
                  </NavLink>
                </ListItem>
                <ListItem disablePadding>
                  <NavLink
                    to="/settings/logs"
                    className={({ isActive }) =>
                      classNames(css.navSubitem, { [css.active]: isActive })
                    }
                  >
                    Audit Logs
                  </NavLink>
                </ListItem>
              </List>
            </Collapse>
          </>
        )}
        <div className={css.spacer} />
        {/* Commenting out docs & support until we have these established */}
        {/*
      <Tooltip content="Documentation" placement="right" arrow>
        <Button
          variant="text"
          className={css.navItem}
          disablePadding
          disableMargins
        >
          <DocsIcon /> Documentation
        </Button>
      </Tooltip>
      <Tooltip content="Support" placement="right" arrow>
        <Button
          variant="text"
          className={css.navItem}
          disablePadding
          disableMargins
        >
          <HelpIcon /> Support
        </Button>
      </Tooltip>
      */}
        <Tooltip content="Logout" placement="right" arrow>
          <Button
            variant="text"
            className={css.navItem}
            disablePadding
            disableMargins
            onClick={logout}
          >
            <LogoutIcon /> {!collapseNav && renderLabel('Logout')}
          </Button>
        </Tooltip>
      </motion.nav>
    </AnimatePresence>
  );
};
