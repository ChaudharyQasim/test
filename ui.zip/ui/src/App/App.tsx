import { FC, lazy, Suspense, useCallback, useEffect } from 'react';
import {
  Navigate,
  Route,
  Routes,
  useNavigate,
  useLocation
} from 'react-router-dom';
import { Nav } from './Nav';
import { Explorer } from './Views/SchemaExplorer';
import { Loader } from 'shared/elements/Loader';
import { useAuth } from 'core/Auth';
import { HotkeyDialog } from 'shared/utils/Hotkeys';

const Dashboard = lazy(() => import('./Dashboard'));
const Rules = lazy(() => import('./Rules'));
const NewRule = lazy(() => import('./Rules/NewRule'));
const EditRule = lazy(() => import('./Rules/EditRule'));
const Views = lazy(() => import('./Views'));
const UserProfile = lazy(() => import('./Settings/UserProfile'));
const Organization = lazy(() => import('./Settings/Organization'));
const AuditLogs = lazy(() => import('./Settings/AuditLogs'));
const Integrations = lazy(() => import('./Integrations'));
const IntegrationDetailView = lazy(
  () => import('./Integrations/IntegrationDetailView')
);
const PipelineManager = lazy(() => import('./PipelineManager'));
const PipelineDetailManager = lazy(
  () => import('./PipelineManager/PipelineEdit')
);
const InstanceManager = lazy(() => import('./Settings/InstanceManager'));
const Insights = lazy(() => import('./Insights'));
const InsightDetailView = lazy(() => import('./Insights/InsightDetailView'));
const NotFound = lazy(() => import('./NotFound'));

import css from './App.module.css';

export const App: FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleUserRedirection = useCallback(() => {
    if (user && !user?.is_active) {
      navigate('/pending-approval');
      return;
    }
    if (user.current_organization.name === 'default') {
      const url = localStorage.getItem('PREV_ROUTE');
      const match = url?.match(/^\/user-onboarding(?=\?)/);
      if (match) {
        navigate(url);
      } else {
        navigate('/user-onboarding');
      }
    }
  }, [user, navigate]);

  useEffect(() => {
    handleUserRedirection();
  }, [handleUserRedirection]);

  return (
    <div className={css.root}>
      <HotkeyDialog />
      <Nav />
      {location.pathname === '/views' && <Explorer />}
      <div className={css.content}>
        <Suspense fallback={<Loader />}>
          <Routes>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/rules" element={<Rules />} />
            <Route path="/rules/new" element={<NewRule />} />
            <Route path="/rules/edit/:id" element={<EditRule />} />
            <Route path="/views" element={<Views />} />
            <Route path="/settings/user-profile" element={<UserProfile />} />
            <Route path="/settings/organization" element={<Organization />} />
            <Route path="/settings/instances" element={<InstanceManager />} />
            <Route path="/settings/logs" element={<AuditLogs />} />
            <Route path="/insights" element={<Insights />} />
            <Route path="/insights/:id" element={<InsightDetailView />} />
            <Route path="/marketplace" element={<Integrations />} />
            <Route
              path="/marketplace/:id"
              element={<IntegrationDetailView />}
            />
            <Route path="/pipeline" element={<PipelineManager />} />
            <Route
              path="/pipeline/details/:id"
              element={<PipelineDetailManager />}
            />
            <Route path="/" element={<Navigate to="dashboard" replace />} />
            <Route path="/404" element={<NotFound />} />
            <Route path="*" element={<Navigate to="/404" replace />} />
          </Routes>
        </Suspense>
      </div>
    </div>
  );
};
