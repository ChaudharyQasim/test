import { FC, useMemo } from 'react';
import { useNotification } from 'reablocks';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { useQueryParam, StringParam, withDefault } from 'use-query-params';

// Component
import { FilterType } from 'shared/elements/Filters/FilterPanel';
import { CONFIGURATION_TYPE, PIPELINE_FILTER } from 'shared/utils/Constants';
import { constructQueryParams, errorHandler } from 'shared/utils/Helper';

import { PipelineManager } from './PipelineManager';

// API Service
import { useAuth } from 'core/Auth';
import {
  createRoute,
  deletePipelineRoute,
  deleteRoute,
  getPipelineFilterTagValues,
  getPipelineList,
  getRouteByVendorId
} from 'core/Api/PipelineApi';
import { getListTenantsAccounts } from 'core/Api/VendorApi';
import { getOrganizationUsers } from 'core/Api/UsersApi';
import { ListPipelineOut } from './Pipeline.types';
import { getEnabledIntegration } from 'core/Api/ConfigurationApi';
import { RouteOut, StatusEnum } from 'core/Api';

const { SOURCE, DESTINATION } = CONFIGURATION_TYPE;

export const PipelineManagerContainer: FC = () => {
  const queryClient = useQueryClient();

  const { user } = useAuth();

  const { notifySuccess, notifyError } = useNotification();

  const [pipelineView, setPipelineView] = useQueryParam(
    'pipelineView',
    withDefault(StringParam, 'connector')
  );

  const [selectedVendorId, setSelectedVendorId] = useQueryParam(
    'selectedVendorId',
    withDefault(StringParam, null)
  );

  const userOrganizationId = user?.current_organization.id;

  const { data: organizationUserList } = useQuery(
    'organizationUserList',
    () => getOrganizationUsers(userOrganizationId),
    {
      initialData: [],
      onError(error: any) {
        notifyError(`Error fetching users: ${errorHandler(error)}`);
      }
    }
  );

  const { data: configuredTenantList, isLoading: isLoadingInstanceList } =
    useQuery('tenantList', () => getListTenantsAccounts(userOrganizationId), {
      initialData: [],
      onSuccess(data) {
        const completedStatusTenant = data?.filter(
          instance =>
            instance?.status?.length > 0 &&
            instance?.status[0].status === StatusEnum.Completed
        );

        if (completedStatusTenant?.length > 0) {
          setSelectedVendorId(completedStatusTenant[0]?.nanoid);
        }
      },
      onError(error: any) {
        notifyError(`Error fetching tenants: ${errorHandler(error)}`);
      }
    });

  const {
    data: routes,
    isLoading: isLoadingRoutes,
    refetch: refetchRoutes
  } = useQuery(
    ['pipelineRouteByVendorId', selectedVendorId],
    () => getRouteByVendorId(selectedVendorId),
    {
      enabled: selectedVendorId !== null,
      onError(error) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { data: filterTagList } = useQuery(
    'filterTagList',
    () => getPipelineFilterTagValues({ tagType: 'pipeline' }),
    {
      initialData: {
        tags: []
      },
      onError(error: any) {
        notifyError(`Error fetching filter tags: ${errorHandler(error)}`);
      }
    }
  );

  /**
   * @description Fetches the list of pipelines based on the constructed URL and abort controller signal
   */
  const {
    data: pipelineListData,
    isLoading: isPipelineListLoading,
    isSuccess: isPipelineListSuccess,
    mutate: updatePipelineFilters
  } = useMutation<ListPipelineOut, Error, any>(
    ['pipelines', userOrganizationId],
    ({ constructedUrl, abortController }) =>
      getPipelineList({
        organization_id: userOrganizationId,
        constructedUrl,
        signal: abortController?.signal
      }),
    {
      onError: error => {
        // Cancelled errors are expected since we are using an abort controller
        if (error.name !== 'CanceledError') {
          notifyError(`Error fetching pipelines: ${errorHandler(error)}`);
        }
      }
    }
  );

  const { data: nodes, isFetching: isLoadingConfigurationList } = useQuery(
    ['configurationList', selectedVendorId],
    () =>
      getEnabledIntegration(
        constructQueryParams(
          null,
          {
            type: [DESTINATION, SOURCE],
            vendor_account_ids: [selectedVendorId]
          },
          null
        ),
        true
      ),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      },
      enabled: selectedVendorId !== null
    }
  );

  const { mutateAsync: createRouteMutation } = useMutation(
    'createRoute',
    createRoute,
    {
      onSuccess(data) {
        queryClient.setQueryData(
          ['pipelineRouteByVendorId', selectedVendorId],
          (prev: RouteOut[]) => [...prev, data]
        );
        notifySuccess('Route created successfully.');
      },
      onError(error: any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { mutate: deleteRouteMutation } = useMutation(
    'deleteRoute',
    deleteRoute,
    {
      onSuccess() {
        refetchRoutes();
        notifySuccess('Route deleted successfully.');
      },
      onError(error: any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { mutateAsync: onDeleteListRoute } = useMutation(
    (route_id: string) => deletePipelineRoute(route_id),
    {
      onSuccess: data => {
        notifySuccess(`${data.message}`);
        queryClient.invalidateQueries('pipelines');
      },
      onError(error: any) {
        notifyError(`Error deleting pipeline route: ${errorHandler(error)}`);
      }
    }
  );

  // useMemo
  /**
   * @description Format key:value options to be used in FilterPanel
   */
  const formattedUsersList = useMemo(() => {
    if (organizationUserList.length) {
      return {
        author: {
          label: 'Author',
          options: organizationUserList.map(filter => ({
            // If a user does not have a first or last name
            // fallback with username to prevent empty undefined labels
            label: `${filter.first_name || filter.username} ${
              filter.last_name || ''
            }`,
            value: filter.username
          }))
        }
      };
    }
    return null;
  }, [organizationUserList]);

  const formattedInstanceList = useMemo(() => {
    return {
      instance: {
        label: 'Instance',
        options: configuredTenantList.map(filter => ({
          label: filter.name,
          value: filter.name
        }))
      }
    };
  }, [configuredTenantList]);

  const completedStatusTenantList = useMemo(
    () =>
      configuredTenantList.filter(
        instance =>
          instance?.status?.length > 0 &&
          instance?.status[0].status === StatusEnum.Completed
      ),
    [configuredTenantList]
  );

  const formattedFilterTagList = useMemo(() => {
    const { tags } = filterTagList;
    return {
      tags: {
        label: 'Tags',
        options: tags.map(tag => ({
          label: tag,
          value: tag
        }))
      }
    };
  }, [filterTagList]);

  const filterOptions: FilterType = useMemo(
    () => ({
      ...PIPELINE_FILTER,
      ...formattedUsersList,
      ...formattedInstanceList,
      ...formattedFilterTagList
    }),
    [formattedUsersList, formattedInstanceList, formattedFilterTagList]
  );

  return (
    <PipelineManager
      pipelineListData={pipelineListData}
      updatePipelineFilters={updatePipelineFilters}
      isPipelineListLoading={isPipelineListLoading}
      isPipelineListSuccess={isPipelineListSuccess}
      filterOptions={filterOptions}
      nodes={nodes?.data ?? []}
      edges={routes ?? []}
      isLoadingPipeline={
        isLoadingConfigurationList || isLoadingRoutes || isLoadingInstanceList
      }
      instanceList={completedStatusTenantList ?? []}
      selectedVendorId={selectedVendorId}
      onChangeVendorId={setSelectedVendorId}
      pipelineView={pipelineView}
      onViewChange={setPipelineView}
      onAddConnection={createRouteMutation}
      onDeleteConnection={deleteRouteMutation}
      onDeleteListRoute={onDeleteListRoute}
    />
  );
};
