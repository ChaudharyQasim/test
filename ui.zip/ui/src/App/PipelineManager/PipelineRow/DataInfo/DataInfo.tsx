import { FC } from 'react';
import { binaryScale } from 'shared/utils/Constants/data';
import { DataInfoType } from '../../Pipeline.types';
import { DataSize, SmallHeading, Stack, VerticalSpacer } from 'reablocks';
import css from './DataInfo.module.css';

import { ReactComponent as ArrowUp } from 'assets/icons/arrow-up.svg';
import { ReactComponent as ArrowDown } from 'assets/icons/arrow-down.svg';
import { ReactComponent as InputIcon } from 'assets/icons/download.svg';
import { ReactComponent as OutputIcon } from 'assets/icons/upload.svg';

type DataInfoProps = {
  data: DataInfoType;
};

type RateIndicatorProps = {
  rate: number;
};

const RateIndicator: FC<RateIndicatorProps> = ({ rate }) => {
  if (rate === 0) {
    return null;
  }

  const isPositive = rate > 0;
  const Icon = isPositive ? ArrowUp : ArrowDown;
  const iconClass = isPositive ? css.blueIcon : css.pinkIcon;

  return (
    <>
      <Icon className={iconClass} />
      {Number(rate).toFixed(2)}%
    </>
  );
};

export const DataInfo: FC<DataInfoProps> = ({ data }) => {
  const {
    total_bytes_in = 0,
    total_bytes_out = 0,
    last_hour_bytes_in_rate = 0,
    last_hour_bytes_out_rate = 0
  } = data;

  return (
    <Stack className={css.throughput} direction="column" alignItems="start">
      <Stack dense>
        <InputIcon className={css.pinkIcon} />
        <span className={css.label}>Input</span>
        {last_hour_bytes_in_rate && (
          <>
            <span className={css.change}>
              <RateIndicator rate={last_hour_bytes_in_rate} />
            </span>
            <span className={css.timeframe}>Last hour</span>
          </>
        )}
      </Stack>
      <SmallHeading>
        <DataSize value={total_bytes_in} scale={binaryScale} />
        /hr
      </SmallHeading>
      <VerticalSpacer space="xs" />
      <Stack dense>
        <OutputIcon className={css.blueIcon} />
        <span className={css.label}>Output</span>
        {last_hour_bytes_out_rate && (
          <>
            <span className={css.change}>
              <RateIndicator rate={last_hour_bytes_out_rate} />
            </span>
            <span className={css.timeframe}>Last hour</span>
          </>
        )}
      </Stack>
      <SmallHeading>
        <DataSize value={total_bytes_out} scale={binaryScale} />
        /hr
      </SmallHeading>
    </Stack>
  );
};
