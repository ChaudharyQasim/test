import { FC, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Card, List, ListItem, Menu } from 'reablocks';
import css from './RowActions.module.css';

import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as DotsIcon } from 'assets/icons/dots.svg';
import { ReactComponent as EditIcon } from 'assets/icons/pencil.svg';

import { RowActionsProps } from '../../Pipeline.types';

export const RowActions: FC<RowActionsProps> = ({ row, onDeleteListRoute }) => {
  const navigate = useNavigate();
  const btnRef = useRef<HTMLButtonElement | null>(null);
  const [menuOpen, setMenuOpen] = useState<boolean>(false);

  const { pipeline_id, route_id, category } = row;

  return (
    <div className={css.actions}>
      <Button
        variant="text"
        ref={btnRef}
        onClick={event => {
          event.stopPropagation();
          setMenuOpen(!menuOpen);
        }}
      >
        <DotsIcon />
      </Button>
      <Menu
        reference={btnRef}
        open={menuOpen}
        placement="bottom-end"
        onClose={() => setMenuOpen(false)}
      >
        <Card>
          <List>
            <ListItem
              start={<EditIcon />}
              onClick={() => {
                navigate(`/pipeline/details/${pipeline_id}?pipelineView=list`);
                setMenuOpen(false);
              }}
            >
              Edit
            </ListItem>
            {category === 'ROUTE' && route_id && (
              <ListItem
                start={<DeleteIcon />}
                onClick={() => {
                  onDeleteListRoute(route_id);
                  setMenuOpen(false);
                }}
              >
                Delete
              </ListItem>
            )}
          </List>
        </Card>
      </Menu>
    </div>
  );
};
