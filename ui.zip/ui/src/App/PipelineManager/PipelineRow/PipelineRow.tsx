import { FC, useMemo } from 'react';
import { Stack } from 'reablocks';
import { ChartNestedDataShape } from 'reaviz';
import { StyledCard } from 'shared/layout/Card';
import { Chip, LabelChip } from 'shared/elements/Chip';
import { NoDataState } from 'shared/elements/NoDataState';
import css from './PipelineRow.module.css';

import { DataInfo } from './DataInfo';
import { RowActions } from './RowActions';
import { PipelineChart } from '../PipelineChart';
import { DataInfoType } from '../Pipeline.types';

import { PipelineRowProps } from '../Pipeline.types';

import { ReactComponent as CheckIcon } from 'assets/icons/check.svg';

type HandleTagClickFunction = {
  (
    tag: string,
    tags: string[],
    setFilter: (filter: { tags: string[] }) => void
  ): void;
};

const isDataMetricsAvailable: FC<{
  metrics_io_data: DataInfoType;
  metrics: ChartNestedDataShape[];
}> = ({ metrics_io_data, metrics }) => {
  if (metrics.length === 0 || !metrics_io_data) {
    return <NoDataState message="No Data Available" />;
  }

  return (
    <>
      <DataInfo data={metrics_io_data} />
      <div className={css.chart}>
        <PipelineChart data={metrics} />
      </div>
    </>
  );
};
export const PipelineRow: FC<PipelineRowProps> = ({
  row,
  filter,
  onDeleteListRoute,
  setFilter
}) => {
  const {
    name,
    description,
    category,
    is_passthrough,
    tags,
    metrics,
    metrics_io_data
  } = row;
  const formatMetrics = useMemo(
    () => originalMetrics =>
      originalMetrics.map(metric => ({
        key: metric.timestamp,
        data: [
          {
            key: 'Input',
            data: metric.bytes_in
          },
          {
            key: 'Output',
            data: metric.bytes_out * -1
          }
        ]
      })),
    []
  );

  const formattedMetrics = formatMetrics(metrics);

  /**
   * @description Check if existing filter has the clicekd filter value,
   * if not add it when the chip is clicked
   * @param key Key of the filter
   * @param value Value of the filter
   * @param setFilter Function to set the updated filter using useFilterPager hook
   */
  const handleChipClick = (
    key: string,
    value: string,
    setFilter: (filter: any) => void
  ) => {
    const updatedFilter = { ...filter };
    if (!updatedFilter[key]) {
      updatedFilter[key] = [value];
    } else if (!updatedFilter[key].includes(value)) {
      updatedFilter[key].push(value);
    }
    setFilter(updatedFilter);
  };

  return (
    <StyledCard className={css.card}>
      <Stack className={css.row}>
        <Stack className={css.main} direction="column">
          <Stack className={css.name} dense>
            {name}
            <LabelChip
              variant="outline"
              onClick={() => handleChipClick('category', category, setFilter)}
            >
              {category}
            </LabelChip>
            {is_passthrough && (
              <LabelChip
                variant="outline"
                color="secondary"
                onClick={() =>
                  handleChipClick('is_passthrough', 'true', setFilter)
                }
              >
                <Stack dense>
                  <CheckIcon /> PASSTHROUGH ENABLED
                </Stack>
              </LabelChip>
            )}
          </Stack>
          <div className={css.description}>{description}</div>
          <Stack dense>
            {tags.map(tag => (
              <Chip
                key={tag}
                variant="outline"
                color="secondary"
                onClick={() => handleChipClick('tags', tag, setFilter)}
              >
                {tag}
              </Chip>
            ))}
          </Stack>
        </Stack>
        <Stack dense>
          {isDataMetricsAvailable({
            metrics_io_data: metrics_io_data as DataInfoType,
            metrics: formattedMetrics
          })}
        </Stack>
        <RowActions row={row} onDeleteListRoute={onDeleteListRoute} />
      </Stack>
    </StyledCard>
  );
};
