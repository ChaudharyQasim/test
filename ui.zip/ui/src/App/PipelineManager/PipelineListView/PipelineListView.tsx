import { FC, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, MotionGroup, MotionItem, Stack } from 'reablocks';

// Components
import { PipelineRow } from '../PipelineRow';
import css from './PipelineListView.module.css';

import { PipelineListViewProps } from '../Pipeline.types';
import { Loader } from 'shared/elements/Loader';
import { EmptyState } from 'shared/elements/EmptyState';

import { ReactComponent as EmptyPipeline } from 'assets/illustrations/empty-pipeline.svg';
import { ConfirmationDialog } from 'shared/layers/ConfirmationDialog';

export const PipelineListView: FC<PipelineListViewProps> = ({
  pipelineListData,
  isPipelineListLoading,
  isPipelineListSuccess,
  filter,
  onDeleteListRoute,
  setFilter
}) => {
  const navigate = useNavigate();
  const { pipelines = [] } = pipelineListData ?? {};

  const [idToDelete, setIdToDelete] = useState<string>(null);
  const [openConfirmationDialog, setOpenConfirmationDialog] =
    useState<boolean>(false);

  const confirmationDialogMessage = useMemo(() => {
    const deleteRouteName = pipelines.find(
      pipeline => pipeline.route_id === idToDelete
    )?.name;
    return `Are you sure you want to delete ${deleteRouteName}?`;
  }, [idToDelete, pipelines]);

  if (isPipelineListLoading) {
    return <Loader />;
  }

  return (
    isPipelineListSuccess && (
      <MotionGroup>
        {pipelines.length === 0 ? (
          <Stack className={css.emptyState}>
            <EmptyState
              illustration={<EmptyPipeline />}
              title="No Pipelines Found"
              subtitle="Configure a source marketplace to get started with pipelines."
              actions={
                <Button
                  color="primary"
                  onClick={() => navigate('/marketplace')}
                >
                  Configure a source marketplace
                </Button>
              }
            />
          </Stack>
        ) : (
          <Stack direction="column" className={css.pipelines}>
            {pipelines.map(pipeline => (
              <MotionItem key={pipeline.pipeline_id}>
                <PipelineRow
                  row={pipeline}
                  filter={filter}
                  onDeleteListRoute={route_id => {
                    setIdToDelete(route_id);
                    setOpenConfirmationDialog(true);
                  }}
                  setFilter={setFilter}
                />
              </MotionItem>
            ))}
          </Stack>
        )}
        <ConfirmationDialog
          open={openConfirmationDialog}
          dialogType="DELETE"
          confirmationButtonName="Delete route"
          confirmationHeading="Want to delete route?"
          confirmationMessage={confirmationDialogMessage}
          onConfirm={() => {
            onDeleteListRoute(idToDelete);
            setOpenConfirmationDialog(false);
          }}
          onCancel={() => setOpenConfirmationDialog(false)}
        />
      </MotionGroup>
    )
  );
};
