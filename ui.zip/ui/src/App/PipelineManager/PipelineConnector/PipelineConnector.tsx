import { FC } from 'react';
import {
  Pipeline,
  PipelineEdgeData,
  PipelineNodeData
} from 'shared/data/Pipeline';
import css from './PipelineConnector.module.css';

interface PipelineConnectorProps {
  nodes: PipelineNodeData[];
  edges: PipelineEdgeData[];
  canvasClassName?: string;
  actions: (menuId: number, id: string, pipelineId: string) => void;
  onAddConnection: (sourceId: string, destId: string) => void;
}

export const PipelineConnector: FC<PipelineConnectorProps> = ({
  nodes,
  edges,
  canvasClassName,
  actions,
  onAddConnection
}) => (
  <div className={css.root}>
    <Pipeline
      nodes={nodes}
      edges={edges}
      canvasClassName={canvasClassName}
      onAddConnection={onAddConnection}
      actions={actions}
    />
  </div>
);
