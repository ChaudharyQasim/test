import { FC } from 'react';
import {
  DateFormat,
  DeletableChip,
  Input,
  PrimaryHeading,
  Stack,
  Text
} from 'reablocks';

import css from './PipelineHeader.module.css';

import { LabelChip } from 'shared/elements/Chip';
import { Checkbox } from 'shared/form/Checkbox';
import { CreatableChip } from 'shared/elements/Chip/CreateableChip';

import { ReactComponent as DateIcon } from 'assets/icons/date.svg';
import { ReactComponent as UserIcon } from 'assets/icons/user.svg';

import { PipelineHeaderProps } from 'App/PipelineManager/Pipeline.types';
import { ToggleInputEdit } from 'shared/form/ToggleInputEdit';
import { DATE_FORMAT } from 'shared/utils/Constants';

type EditModeState = {
  isNameEditing: boolean;
  isDescriptionEditing: boolean;
};

export const PipelineHeader: FC<PipelineHeaderProps> = ({
  headerFields,
  pipelineDetails,
  setHeaderFields
}) => {
  const { name, description, is_passthrough, tags } = headerFields;

  const { created_at, created_by, updated_at, updated_by, category } =
    pipelineDetails || {};

  return (
    <Stack className={css.header} direction="column" alignItems="start" dense>
      <Stack className={css.heading} justifyContent="spaceBetween">
        <ToggleInputEdit
          toggleToComponent={
            <Input
              className={css.input}
              value={name}
              fullWidth
              onValueChange={value => {
                setHeaderFields(prev => ({
                  ...prev,
                  name: value
                }));
              }}
              maxLength={50}
            />
          }
        >
          <Stack>
            <PrimaryHeading>{name}</PrimaryHeading>
            <LabelChip variant="outline">{category}</LabelChip>
          </Stack>
        </ToggleInputEdit>
        <LabelChip
          variant="outline"
          color={is_passthrough ? 'secondary' : 'default'}
        >
          <Stack>
            <Text color={is_passthrough ? 'info' : 'secondary'}>
              PASSTHROUGH ENABLED
            </Text>
            <Checkbox
              onChange={(event: boolean) =>
                setHeaderFields(prev => ({ ...prev, is_passthrough: event }))
              }
              checked={is_passthrough}
            />
          </Stack>
        </LabelChip>
      </Stack>
      <ToggleInputEdit
        toggleToComponent={
          <Input
            className={css.input}
            value={description}
            fullWidth
            onValueChange={value => {
              setHeaderFields(prev => ({
                ...prev,
                description: value
              }));
            }}
            maxLength={100}
          />
        }
      >
        <div>{description}</div>
      </ToggleInputEdit>
      <Stack>
        {created_by && (
          <Stack className={css.attribute} dense>
            <UserIcon /> Created By - {created_by}
          </Stack>
        )}
        {created_at && (
          <Stack className={css.attribute} dense>
            <DateIcon /> Created On -{' '}
            <DateFormat date={new Date(created_at)} format={DATE_FORMAT} />
          </Stack>
        )}
        {updated_by && (
          <Stack className={css.attribute} dense>
            <UserIcon /> Updated By - {updated_by}
          </Stack>
        )}
        {updated_at && (
          <Stack className={css.attribute} dense>
            <DateIcon /> Updated On -{' '}
            <DateFormat date={new Date(updated_at)} format={DATE_FORMAT} />
          </Stack>
        )}
      </Stack>
      <Stack>
        {tags?.map((tag, idx) => (
          <DeletableChip
            key={tag}
            variant="outline"
            onDelete={() => {
              const update = [...tags];
              update.splice(idx, 1);
              setHeaderFields(prev => ({ ...prev, tags: update }));
            }}
          >
            {tag}
          </DeletableChip>
        ))}
        <CreatableChip
          onCreate={newTag =>
            setHeaderFields(prev => ({ ...prev, tags: [...tags, newTag] }))
          }
        />
      </Stack>
    </Stack>
  );
};
