import { FC, useCallback, useMemo } from 'react';
import { MotionItem, useNotification } from 'reablocks';
import { Reorder } from 'framer-motion';

// Module
import { PipelineBlock } from './PipelineBlock/PipelineBlock';

// CSS
import css from './PipelineBlockList.module.css';

// Shared
import { Alert } from 'shared/elements/Alert/Alert';
import { EmptyState } from 'shared/elements/EmptyState';

// Icons
import { ReactComponent as EmptyPipeline } from 'assets/icons/pipeline.svg';
import { ReactComponent as AlertIcon } from 'assets/icons/warning.svg';

// Types
import {
  BlockType,
  PipelineBlockListProps
} from 'App/PipelineManager/Pipeline.types';
import {
  FunctionCategoryEnum,
  GetPipelineFunctions,
  PipelineFunctionStateEnum
} from 'core/Api';
import { BLOCK_TYPE } from 'shared/utils/Constants';
import { blockType } from 'shared/utils/Helper/blockFormation';
import { validateBlock } from 'shared/utils/Helper/blockValidation';

// Constants
const { CREATE, UPDATE, DELETE } = PipelineFunctionStateEnum;
const { FOUNDATIONAL } = FunctionCategoryEnum;
const { ENRICHMENT } = BLOCK_TYPE;

export const PipelineBlockList: FC<PipelineBlockListProps> = ({
  acsFields,
  acsFieldOperations,
  blocks,
  dragBlock,
  isPassthrough,
  blockValidation,
  initialBlockList,
  enrichmentCSVList,
  startValidationSession,
  updateBlockList,
  onBlockValidation,
  setInitialBlockCopy,
  createFunctionMutation,
  updateFunctionMutation
}) => {
  const { notifyError } = useNotification();

  const { type, draggedBlock } = dragBlock || {};

  const isAnyBlockAvailable = useMemo(
    () => blocks?.filter(block => block.state !== DELETE).length > 0,
    [blocks]
  );

  const newPriority = useMemo(
    () =>
      blocks?.reduce(
        (max, block) => (block.priority > max ? block.priority : max),
        -1
      ) + 1,
    [blocks]
  );

  // Memoized update functions
  const handleUpdateBlock = useCallback(
    (index: number, block: any) => {
      const updatedBlocks = [...blocks];
      updatedBlocks[index] = block;
      updateBlockList(updatedBlocks);
    },
    [blocks, updateBlockList]
  );

  const addToOrganizationBlock = useCallback(
    async (index: number) => {
      const duplicateBlock = [...blocks];

      const {
        priority,
        state,
        block,
        field_operation_type,
        name,
        tags,
        description
      } = duplicateBlock[index];

      if (validateBlock({ field_operation_type, block, enrichmentCSVList })) {
        const isEnrichment =
          blockType(field_operation_type, block) === ENRICHMENT;

        // need to pass new_csv_file_id only if enrichment block
        const { id } = await createFunctionMutation({
          name,
          tags,
          description,
          block,
          ...(isEnrichment && {
            new_csv_file_id: (block as BlockType).current_csv
          }),
          field_operation_type
        });

        // Changing the is_shared as true.
        const orgBlock = {
          function_id: id,
          priority,
          state,
          name,
          description,
          tags,
          field_operation_type,
          block,
          is_shared: true
        };

        duplicateBlock[index] = orgBlock;
        updateBlockList(duplicateBlock);

        setInitialBlockCopy([...initialBlockList, orgBlock]);
      } else {
        // not allowing invalid block to save in org.
        notifyError(
          'Please resolve all errors before adding to the Organization'
        );
      }
    },
    [
      blocks,
      enrichmentCSVList,
      initialBlockList,
      setInitialBlockCopy,
      notifyError,
      createFunctionMutation,
      updateBlockList
    ]
  );

  const createDuplicateBlock = useCallback(
    (index: number) => {
      const { priority, block, field_operation_type, name, tags, description } =
        blocks[index];

      const isEnrichment =
        blockType(field_operation_type, block) === ENRICHMENT;

      const duplicateBlock = {
        name,
        tags,
        description,
        is_shared: false,
        priority: newPriority,
        state: CREATE,
        block,
        field_operation_type
      };

      // As creating duplicate block so state = CREATE then new_csv_file_id should exist but old_csv_file_id doesn't.
      // and new_csv_file_id is block current_csv.
      if (isEnrichment) {
        duplicateBlock['new_csv_file_id'] = (block as BlockType).current_csv;
      }

      blocks.splice(index + 1, 0, duplicateBlock);
      updateBlockList([...blocks]);
    },
    [blocks, newPriority, updateBlockList]
  );

  const deleteBlock = useCallback(
    (index: number) => {
      let updatedBlocks = [...blocks];
      const blockToDelete = { ...updatedBlocks[index] };

      const { field_operation_type, block, state, priority } = blockToDelete;

      const isEnrichment =
        blockType(field_operation_type, block) === ENRICHMENT;

      if (state === CREATE) {
        updatedBlocks = updatedBlocks.filter(
          (_block, indexToDelete) => indexToDelete !== index
        );
      } else if (isEnrichment) {
        blockToDelete.state = DELETE;
        blockToDelete.old_csv_file_id = (block as BlockType).current_csv;
        updatedBlocks[index] = blockToDelete;
      } else {
        // Mark the block for deletion
        blockToDelete.state = DELETE;
        updatedBlocks[index] = blockToDelete;
      }

      updateBlockList(updatedBlocks);

      // deleting the validation if key exists and block deleted.
      const deleteDuplicatedValidation = { ...blockValidation };
      delete deleteDuplicatedValidation[priority];
      onBlockValidation(deleteDuplicatedValidation);
    },
    [blocks, blockValidation, onBlockValidation, updateBlockList]
  );

  const syncLocalBlocksWithOrg = useCallback(
    (blockIndex: number) => {
      const blockToSyncWith = blocks[blockIndex];

      // Sync local block with organization block
      const updatedBlocks = blocks.map(block => {
        if (block.function_id === blockToSyncWith.function_id) {
          return { ...blockToSyncWith, priority: block.priority };
        } else {
          return block;
        }
      });

      updateBlockList(updatedBlocks);

      const orgBlockinitialCopyIndex = initialBlockList.findIndex(
        block => block.function_id === blockToSyncWith.function_id
      );

      const initialBlockDuplicate = [...initialBlockList];
      initialBlockDuplicate[orgBlockinitialCopyIndex] = blockToSyncWith;
      setInitialBlockCopy(initialBlockDuplicate);
    },
    [blocks, initialBlockList, setInitialBlockCopy, updateBlockList]
  );

  const createNewBlockOnDrop = () => {
    const {
      function_id,
      name,
      tags,
      description,
      field_operation_type,
      block
    } = draggedBlock || ({} as GetPipelineFunctions);
    const blockDetails = {
      name,
      tags,
      description,
      field_operation_type,
      block,
      is_shared: type !== FOUNDATIONAL,
      state: type === FOUNDATIONAL ? CREATE : UPDATE,
      ...(type === FOUNDATIONAL ? null : { function_id }),
      priority: newPriority
    };

    /**
     *
     * Only maintaining initial copy of already saved block and org block.
     * For new block doesn't needed.
     *
     * For org block initial copy needed because user after making changes, can revert as well.
     *
     * For already saved block helpful to detect state on every change.
     * Suppose user changed field so status NONE -> UPDATE, now user manually reverted changes.
     * so needed to change status from UPDATE -> NONE.
     *
     */

    const isBlockNotInitialized =
      initialBlockList.findIndex(block => block.function_id === function_id) ===
      -1;

    /**
     *
     * Since User can drag same org block multiple time so checking if already has the org block copy or not.
     * If has then doesn't push it again, as all the org block which has same id(same org block multiple times)
     * points to same initial copy.
     *
     */
    if (blockDetails?.is_shared && isBlockNotInitialized) {
      setInitialBlockCopy([...initialBlockList, blockDetails]);
    }

    updateBlockList([...blocks, blockDetails]);
  };

  return (
    <div
      className={css.blocks}
      onDragOver={event => event.preventDefault()}
      onDrop={createNewBlockOnDrop}
    >
      {isPassthrough && (
        <div className={css.passthroughAlert}>
          <Alert
            icon={<AlertIcon className={css.alert} />}
            text="THIS PIPELINE IS IN PASSTHROUGH MODE, EVENTS WILL FLOW THROUGH THIS PIPELINE WITHOUT BLOCKS APPLIED"
          />
        </div>
      )}
      <Reorder.Group axis="y" onReorder={updateBlockList} values={blocks}>
        {isAnyBlockAvailable &&
          blocks.map((block, index) =>
            block.state !== DELETE ? (
              <div key={block.priority}>
                <PipelineBlock
                  acsFields={acsFields}
                  acsFieldOperations={acsFieldOperations}
                  blockDetails={block}
                  isPassthrough={isPassthrough}
                  startValidationSession={startValidationSession}
                  initialBlockCopy={initialBlockList.find(
                    initialBlock =>
                      block.function_id === initialBlock.function_id
                  )}
                  enrichmentCSVList={enrichmentCSVList}
                  blockValidation={blockValidation}
                  onBlockValidation={onBlockValidation}
                  addToOrganizationBlock={() => addToOrganizationBlock(index)}
                  onBlockUpdate={block => handleUpdateBlock(index, block)}
                  syncLocalBlocksWithOrg={() => syncLocalBlocksWithOrg(index)}
                  updateFunctionMutation={updateFunctionMutation}
                  createDuplicateBlock={() => createDuplicateBlock(index)}
                  deleteBlock={() => deleteBlock(index)}
                />
              </div>
            ) : null
          )}
        {!isAnyBlockAvailable && !isPassthrough && (
          <MotionItem>
            <EmptyState
              illustration={<EmptyPipeline className={css.emptyEditPipeline} />}
              title="Pipeline Logic"
              subtitle="Drag the blocks from the left panel to make changes in the pipeline’s functionality"
            />
          </MotionItem>
        )}
      </Reorder.Group>
    </div>
  );
};
