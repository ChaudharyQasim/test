export { EnrichmentBlock as default } from './EnrichmentBlock';
