import { FC, useCallback, useMemo, useState } from 'react';
import {
  Button,
  Divider,
  Select,
  SelectInput,
  SelectOption,
  Stack,
  Sub,
  Text
} from 'reablocks';

// CSS
import css from './AggregateBlock.module.css';

// Icons
import { ReactComponent as ExpandIcon } from 'assets/icons/chevron-down.svg';

import ConditionsSummary from 'App/Views/Condition/ConditionsSummary';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';

// Shared
import {
  EventCondition,
  EventConditionRow,
  createEmptyCondition
} from 'shared/elements/EventCondition';
import { updateSnapshot } from 'shared/utils/Helper/blockFormation';

// Constants
import {
  AGGREGATION_ACTION_OPTIONS,
  TIME_MINUTES_WINDOW,
  TIME_UNITS
} from 'shared/utils/Constants';
import {
  AggregateBlockProp,
  Aggregation
} from 'App/PipelineManager/Pipeline.types';

const aggregationActionObject: Aggregation = {
  field: '',
  field_operation: null
};

export const AggregateBlock: FC<AggregateBlockProp> = ({
  acsFields,
  acsFieldOperations,
  block,
  snapshot,
  isEditMode,
  isInValidBlock,
  onBlockUpdate
}) => {
  const { operator } = (block?.groups?.length && block?.groups[0]) || {};

  const { config, groups } = block || {};

  const { fields, aggregations = [] } = config || {};

  const memoizedFieldArray = useMemo(
    () =>
      acsFields
        ?.filter(option => !fields.includes(option.field))
        .map(({ field }) => ({ label: field, value: field })),
    [acsFields, fields]
  );

  const memoizedAggregatedActionArray = useMemo(
    () =>
      acsFields
        ?.filter(
          option =>
            !aggregations
              .map(aggregate => aggregate.field)
              .includes(option.field)
        )
        .map(({ field }) => ({ label: field, value: field })),
    [acsFields, aggregations]
  );

  const onSnapshotUpdate = useCallback(
    (operation: string, parameterValue) => {
      const nestedObject = updateSnapshot({
        operation,
        parameterValue,
        block,
        groups,
        snapshot,
        operator
      });
      onBlockUpdate(nestedObject);
    },
    [groups, block, operator, snapshot, onBlockUpdate]
  );

  const setUpdatedFields = (params, parameterValue, index?: number) => {
    let fieldsArray = [...fields];
    let aggregationsArray = [...aggregations];

    switch (params) {
      case 'FIELD_ADD':
        fieldsArray = [...fields, parameterValue];
        break;
      case 'FIELD_REMOVE':
        fieldsArray = fieldsArray.filter((_val, ind) => index !== ind);
        break;
      case 'FIELD_CHANGE':
        fieldsArray[index] = parameterValue;
        break;
      case 'FIELD_ACTION_ADD':
        aggregationsArray = [...aggregations, aggregationActionObject];
        break;
      case 'FIELD_ACTION_REMOVE':
        aggregationsArray = aggregationsArray.filter(
          (_val, ind) => index !== ind
        );
        break;
      case 'FIELD_OPERATION_CHANGE':
        aggregationsArray[index] = {
          ...aggregationsArray[index],
          field_operation: parameterValue
        };
        break;
      case 'FIELD_NAME_CHANGE':
        aggregationsArray[index] = {
          ...aggregationsArray[index],
          field: parameterValue
        };
        break;
      default:
        break;
    }

    const nestedObject = {
      config: {
        fields: fieldsArray,
        aggregations: aggregationsArray,
        windowMinutes: params === 'WINDOW_MINUTES' ? Number(parameterValue) : 1
      },
      groups
    };
    onBlockUpdate({
      blockJson: nestedObject,
      snapshot
    });
  };

  if (!isEditMode) {
    return (
      <>
        {snapshot?.length > 0 && (
          <>
            <Text className={css.readModeHeading}>
              Block optional conditions
            </Text>
            <ConditionsSummary conditions={snapshot} />
          </>
        )}

        <Text className={css.readModeHeading}>Fields to aggregate</Text>
        <Stack direction="column" alignItems="start">
          {fields?.length > 0 ? (
            fields?.map((value, index) => (
              <Text key={index} className={css.readModeValue}>
                {value}
              </Text>
            ))
          ) : (
            <Text color="error">Missing aggregate field</Text>
          )}
        </Stack>

        <Text className={css.readModeHeading}>Aggregation Time Window</Text>
        <Stack direction="column" alignItems="start">
          <Text className={css.readModeValue}>
            {config.windowMinutes} minutes
          </Text>
        </Stack>

        {aggregations?.length > 0 && (
          <>
            <Text className={css.readModeHeading}>
              Aggregation Action (Optional)
            </Text>
            <Stack direction="column" alignItems="start">
              {aggregations?.map((value, index) => (
                <Text key={index} className={css.readModeValue}>
                  {value.field_operation} {value.field}
                </Text>
              ))}
            </Stack>
          </>
        )}
      </>
    );
  }

  return (
    <>
      {snapshot?.length > 0 ? (
        <EventCondition
          fields={acsFields}
          fieldOperationsMap={acsFieldOperations}
          conditions={snapshot}
          operator={operator ?? 'and'}
          updateBaseOperator={newOperator =>
            onSnapshotUpdate('OPERATOR_CHANGE', newOperator)
          }
          onConditionsChange={newCondition =>
            onSnapshotUpdate('CONDITION_CHANGE', newCondition)
          }
        />
      ) : (
        <Stack className={css.specifyCondition} dense>
          <Button
            variant="outline"
            size="small"
            onClick={() =>
              onSnapshotUpdate('CONDITION_CHANGE', [createEmptyCondition()])
            }
          >
            Specify Condition
          </Button>
          <Sub className={css.subText}>(Optional)</Sub>
        </Stack>
      )}
      <Divider orientation="horizontal" />
      <Sub className={css.subText}>
        Fields to aggregate (must select at least 1 field)
      </Sub>
      {fields?.map((field, index) => (
        <EventConditionRow
          key={index}
          conditions={[
            {
              conditionOptions: memoizedFieldArray,
              value: [field],
              onConditionChange: value =>
                setUpdatedFields('FIELD_CHANGE', value, index)
            }
          ]}
          showError={isInValidBlock}
          onDelete={() => setUpdatedFields('FIELD_REMOVE', null, index)}
        />
      ))}
      <Button
        variant="outline"
        className={css.addButton}
        color={isInValidBlock && !fields.length ? 'error' : 'default'}
        size="small"
        onClick={() => setUpdatedFields('FIELD_ADD', null)}
      >
        <PlusIcon />
        Add
      </Button>
      <Stack direction="column" alignItems="start">
        <Sub className={css.subText}>Aggregation Time Window</Sub>
        <Stack>
          <Select
            value={config.windowMinutes.toString() || '1'}
            clearable={false}
            className={css.timeDropdown}
            onChange={value => setUpdatedFields('WINDOW_MINUTES', value)}
            input={<SelectInput expandIcon={<ExpandIcon />} />}
          >
            {TIME_MINUTES_WINDOW.map(timeWindow => (
              <SelectOption key={timeWindow} value={timeWindow}>
                {timeWindow}
              </SelectOption>
            ))}
          </Select>
          <Select
            // Only Minutes is supported in the backend
            value="Minutes"
            clearable={false}
            className={css.timeDropdown}
            input={<SelectInput expandIcon={<ExpandIcon />} />}
          >
            {TIME_UNITS.map(timeUnit => (
              <SelectOption key={timeUnit} value={timeUnit}>
                {timeUnit}
              </SelectOption>
            ))}
          </Select>
        </Stack>
      </Stack>
      <Stack direction="column" alignItems="start">
        <Sub className={css.subText}>Aggregation Action (Optional)</Sub>
      </Stack>
      {aggregations?.map((aggregation, index) => (
        <EventConditionRow
          key={index}
          conditions={[
            {
              conditionOptions: AGGREGATION_ACTION_OPTIONS.map(
                ({ field, value }) => ({ label: field, value })
              ),
              value: [aggregation.field_operation],
              onConditionChange: value =>
                setUpdatedFields('FIELD_OPERATION_CHANGE', value, index)
            },
            {
              conditionOptions: memoizedAggregatedActionArray,
              value: [aggregation.field],
              onConditionChange: value =>
                setUpdatedFields('FIELD_NAME_CHANGE', value, index)
            }
          ]}
          showError={isInValidBlock}
          onDelete={() => setUpdatedFields('FIELD_ACTION_REMOVE', null, index)}
        />
      ))}
      <Button
        variant="outline"
        className={css.addButton}
        size="small"
        onClick={() => setUpdatedFields('FIELD_ACTION_ADD', null)}
      >
        <PlusIcon width={13} height={13} />
        Add
      </Button>
    </>
  );
};
