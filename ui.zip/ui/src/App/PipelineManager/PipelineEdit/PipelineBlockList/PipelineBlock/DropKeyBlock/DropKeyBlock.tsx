import { FC, useCallback, useMemo, useState } from 'react';
import { Button, Divider, Stack, Sub, Text } from 'reablocks';
import css from './DropKeyBlock.module.css';

import ConditionsSummary from 'App/Views/Condition/ConditionsSummary';
// Shared
import {
  EventCondition,
  EventConditionRow,
  createEmptyCondition
} from 'shared/elements/EventCondition';
import { updateSnapshot } from 'shared/utils/Helper/blockFormation';

// Icons
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import { DropKeyBlockProp } from 'App/PipelineManager/Pipeline.types';

export const DropKeyBlock: FC<DropKeyBlockProp> = ({
  acsFields,
  acsFieldOperations,
  block,
  snapshot,
  isEditMode,
  isInValidBlock,
  onBlockUpdate
}) => {
  const { operator } = (block?.groups?.length && block.groups[0]) || {};

  const { config, groups } = block || {};

  const { fields } = config || {};

  const memoizedFieldArray = useMemo(
    () =>
      acsFields
        ?.filter(option => !fields.includes(option.field))
        .map(({ field }) => ({ label: field, value: field })),
    [acsFields, fields]
  );

  const onSnapshotUpdate = useCallback(
    (operation: string, parameterValue) => {
      const nestedObject = updateSnapshot({
        operation,
        parameterValue,
        block,
        groups,
        snapshot,
        operator
      });
      onBlockUpdate(nestedObject);
    },
    [groups, block, operator, snapshot, onBlockUpdate]
  );

  const setUpdatedFields = useCallback(
    (params: string, parameterValue, index?: number) => {
      let fieldsArray = [...fields];

      switch (params) {
        case 'FIELD_ADD':
          fieldsArray = [...fields, parameterValue];
          break;
        case 'FIELD_REMOVE':
          fieldsArray = fieldsArray.filter(
            (_val, fieldIndex) => index !== fieldIndex
          );
          break;
        case 'FIELD_CHANGE':
          fieldsArray[index] = parameterValue;
          break;
        default:
          break;
      }

      const nestedObject = {
        config: {
          field_operation: 'DROP_KEYS',
          fields: fieldsArray
        },
        groups
      };

      onBlockUpdate({
        blockJson: nestedObject,
        snapshot
      });
    },
    [groups, snapshot, fields, onBlockUpdate]
  );

  if (!isEditMode) {
    return (
      <>
        {snapshot?.length > 0 && (
          <>
            <Text className={css.readModeHeading}>
              Block optional conditions
            </Text>
            <ConditionsSummary conditions={snapshot} />
          </>
        )}

        <Text className={css.readModeHeading}>Field to drop</Text>
        <Stack direction="column" alignItems="start">
          {fields?.length > 0 ? (
            fields?.map((value, index) => (
              <Text key={index} className={css.readModeValue}>
                {value}
              </Text>
            ))
          ) : (
            <Text color="error">Missing fields to drop</Text>
          )}
        </Stack>
      </>
    );
  }

  return (
    <>
      {snapshot.length > 0 ? (
        <EventCondition
          fields={acsFields}
          fieldOperationsMap={acsFieldOperations}
          conditions={snapshot}
          operator={operator ?? 'and'}
          updateBaseOperator={newOperator =>
            onSnapshotUpdate('OPERATOR_CHANGE', newOperator)
          }
          onConditionsChange={newCondition =>
            onSnapshotUpdate('CONDITION_CHANGE', newCondition)
          }
        />
      ) : (
        <Stack className={css.specifyCondition} dense>
          <Button
            variant="outline"
            size="small"
            onClick={() =>
              onSnapshotUpdate('CONDITION_CHANGE', [createEmptyCondition()])
            }
          >
            Specify Condition
          </Button>
          <Sub className={css.subText}>(Optional)</Sub>
        </Stack>
      )}

      <Divider orientation="horizontal" />

      <Sub className={css.subText}>Field to drop</Sub>
      {fields.map((field, index) => (
        <EventConditionRow
          key={index}
          conditions={[
            {
              conditionOptions: memoizedFieldArray,
              value: [field],
              onConditionChange: value =>
                setUpdatedFields('FIELD_CHANGE', value, index)
            }
          ]}
          showError={isInValidBlock}
          onDelete={() => setUpdatedFields('FIELD_REMOVE', null, index)}
        />
      ))}
      <Button
        variant="outline"
        className={css.addButton}
        color={isInValidBlock && !fields.length ? 'error' : 'default'}
        size="small"
        onClick={() => setUpdatedFields('FIELD_ADD', null)}
      >
        <PlusIcon />
        Add
      </Button>
    </>
  );
};
