import { FC, useCallback, useMemo } from 'react';
import { Button, Divider, Stack, Sub, Text } from 'reablocks';
import css from './EnrichmentBlock.module.css';

import {
  EventCondition,
  EventConditionRow,
  createEmptyCondition
} from 'shared/elements/EventCondition';
import { updateSnapshot } from 'shared/utils/Helper/blockFormation';

import { EnrichmentBlockProp } from 'App/PipelineManager/Pipeline.types';
import ConditionsSummary from 'App/Views/Condition/ConditionsSummary';

export const EnrichmentBlock: FC<EnrichmentBlockProp> = ({
  acsFields,
  acsFieldOperations,
  block,
  snapshot,
  isEditMode,
  current_csv,
  isInValidBlock,
  enrichmentCSVList,
  onBlockUpdate
}) => {
  const { config, groups } = block || {};
  const { field } = config || {};
  const { operator } = (groups.length && groups[0]) || {};

  const formattedEnrichmentOptions = useMemo(
    () =>
      enrichmentCSVList.map(({ file_name, id }) => ({
        label: file_name,
        value: id
      })),
    [enrichmentCSVList]
  );

  const memoizedFieldArray = useMemo(
    () => acsFields?.map(({ field }) => ({ label: field, value: field })),
    [acsFields]
  );
  const onSnapshotUpdate = useCallback(
    (operation: string, parameterValue) => {
      const nestedObject = updateSnapshot({
        operation,
        parameterValue,
        block,
        groups,
        snapshot,
        operator
      });
      onBlockUpdate({ ...nestedObject, current_csv });
    },
    [groups, block, current_csv, operator, snapshot, onBlockUpdate]
  );

  const setUpdatedFields = (params: string, parameterValue) => {
    const updatedField = params === 'FIELD_CHANGE' ? parameterValue : field;
    const updatedCsv = params === 'CSV_CHANGE' ? parameterValue : current_csv;
    const file_name = enrichmentCSVList?.find(
      enrichment => enrichment?.id === updatedCsv
    )?.file_name;

    const nestedObject = {
      config: {
        ...config,
        field: updatedField,
        value: file_name
      },
      groups
    };
    onBlockUpdate({
      blockJson: nestedObject,
      snapshot,
      current_csv: updatedCsv
    });
  };

  if (!isEditMode) {
    return (
      <>
        {snapshot.length > 0 && (
          <>
            <Text className={css.readModeHeading}>
              Block optional conditions
            </Text>
            <ConditionsSummary conditions={snapshot} />
          </>
        )}

        <Text className={css.readModeHeading}>Field to enrich</Text>
        <Text className={css.readModeValue} color={field ? 'default' : 'error'}>
          {field || 'Missing field'}
        </Text>

        <Text className={css.readModeHeading}>Enrichment CSV</Text>
        <Text className={css.readModeValue} color={field ? 'default' : 'error'}>
          {current_csv || 'Missing CSV file'}
        </Text>
      </>
    );
  }

  return (
    <>
      {snapshot?.length > 0 ? (
        <EventCondition
          fields={acsFields}
          fieldOperationsMap={acsFieldOperations}
          conditions={snapshot}
          operator={operator ?? 'and'}
          updateBaseOperator={newOperator =>
            onSnapshotUpdate('OPERATOR_CHANGE', newOperator)
          }
          onConditionsChange={newCondition =>
            onSnapshotUpdate('CONDITION_CHANGE', newCondition)
          }
        />
      ) : (
        <Stack className={css.specifyCondition} dense>
          <Button
            variant="outline"
            size="small"
            onClick={() =>
              onSnapshotUpdate('CONDITION_CHANGE', [createEmptyCondition()])
            }
          >
            Specify Condition
          </Button>
          <Sub className={css.subText}>(Optional)</Sub>
        </Stack>
      )}

      <Divider orientation="horizontal" />

      <Sub className={css.subText}>Field to enrich</Sub>
      <EventConditionRow
        conditions={[
          {
            conditionOptions: memoizedFieldArray,
            value: [field || null],
            onConditionChange: value => setUpdatedFields('FIELD_CHANGE', value)
          }
        ]}
        showError={isInValidBlock}
      />

      <Sub className={css.subText}>Enrichment CSV</Sub>
      <EventConditionRow
        conditions={[
          {
            conditionOptions: formattedEnrichmentOptions,
            value: [
              formattedEnrichmentOptions?.find(
                options => options?.value === current_csv
              )?.value ?? null
            ],
            onConditionChange: value => setUpdatedFields('CSV_CHANGE', value)
          }
        ]}
        showError={isInValidBlock}
      />
    </>
  );
};
