export { ReplaceBlock as default } from './ReplaceBlock';
