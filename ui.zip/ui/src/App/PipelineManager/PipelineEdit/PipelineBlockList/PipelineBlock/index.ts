export { PipelineBlock as default } from './PipelineBlock';
