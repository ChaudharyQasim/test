import { FC, useCallback, useMemo } from 'react';
import { Button, Divider, Stack, Sub, Text, Tooltip } from 'reablocks';

import css from './ReplaceBlock.module.css';

// Icons
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import { ReactComponent as HelpIcon } from 'assets/icons/help.svg';

import ConditionsSummary from 'App/Views/Condition/ConditionsSummary';

import { checkIfValidRegex } from 'shared/utils/Helper';
import { ConditionInput } from 'shared/form/Input';

import {
  EventCondition,
  EventConditionRow,
  createEmptyCondition
} from 'shared/elements/EventCondition';
import { updateSnapshot } from 'shared/utils/Helper/blockFormation';

// Constants
import { ReplaceBlockProp } from 'App/PipelineManager/Pipeline.types';
import classNames from 'classnames';

export const ReplaceBlock: FC<ReplaceBlockProp> = ({
  acsFields,
  acsFieldOperations,
  block,
  snapshot,
  isEditMode,
  isInValidBlock,
  onBlockUpdate
}) => {
  const { operator } = (block?.groups?.length && block?.groups[0]) || {};

  const { config, groups } = block || {};
  const { fields, value, find, caseSensitive, regex } = config || {};

  const onSnapshotUpdate = useCallback(
    (operation, parameterValue) => {
      const nestedObject = updateSnapshot({
        operation,
        parameterValue,
        block,
        groups,
        snapshot,
        operator
      });
      onBlockUpdate(nestedObject);
    },
    [groups, snapshot, block, operator, onBlockUpdate]
  );

  const memoizedFieldArray = useMemo(
    () =>
      acsFields
        ?.filter(option => !fields.includes(option.field))
        .map(({ field }) => ({ value: field, label: field })),
    [acsFields, fields]
  );

  const isValidRegex = useMemo(() => checkIfValidRegex(find), [find]);

  const setUpdatedFields = useCallback(
    (params: string, parameterValue, index?: number) => {
      let fieldsArray = [...fields];
      let regexToggle = regex;
      let caseSensitiveToggle = caseSensitive;

      switch (params) {
        case 'FIELD_ADD':
          fieldsArray = [...fields, parameterValue];
          break;
        case 'FIELD_REMOVE':
          fieldsArray = fieldsArray.filter((_val, ind) => index !== ind);
          break;
        case 'FIELD_CHANGE':
          fieldsArray[index] = parameterValue;
          break;
        case 'REGEX':
          regexToggle = parameterValue;
          caseSensitiveToggle = false;
          break;
        case 'CASE_SENSITIVE':
          caseSensitiveToggle = parameterValue;
          regexToggle = false;
          break;
      }

      const blockValue = params === 'VALUE' ? parameterValue : value;
      const blockFind = params === 'FIND' ? parameterValue : find;

      const nestedObject = {
        config: {
          field_operation: 'REPLACE',
          fields: fieldsArray,
          value: blockValue,
          find: blockFind,
          regex: regexToggle,
          caseSensitive: caseSensitiveToggle
        },
        groups
      };

      onBlockUpdate({
        blockJson: nestedObject,
        snapshot
      });
    },
    [fields, caseSensitive, regex, find, groups, snapshot, value, onBlockUpdate]
  );

  if (!isEditMode) {
    return (
      <>
        {snapshot.length > 0 && (
          <>
            <Text className={css.readModeHeading}>
              Block optional conditions
            </Text>
            <ConditionsSummary conditions={snapshot} />
          </>
        )}
        <Text className={css.readModeHeading}>Field replace text</Text>
        <Stack direction="column" alignItems="start">
          {fields.length > 0 ? (
            fields.map((value, index) => (
              <Text key={index} className={css.readModeValue}>
                {value}
              </Text>
            ))
          ) : (
            <Text color="error">Missing replace text</Text>
          )}
        </Stack>
        <Stack direction="column" alignItems="start">
          <Text className={css.readModeHeading}>Find</Text>
          <Text
            className={css.readModeValue}
            color={find ? 'default' : 'error'}
          >
            {find || 'Missing find'}
          </Text>
        </Stack>
        <Text className={css.readModeHeading}>Replace</Text>
        <Text className={css.readModeValue} color={value ? 'default' : 'error'}>
          {value || 'Missing replace'}
        </Text>
      </>
    );
  }

  return (
    <>
      {snapshot.length > 0 ? (
        <EventCondition
          fields={acsFields}
          fieldOperationsMap={acsFieldOperations}
          conditions={snapshot}
          operator={operator ?? 'and'}
          updateBaseOperator={newOperator =>
            onSnapshotUpdate('OPERATOR_CHANGE', newOperator)
          }
          onConditionsChange={newCondition =>
            onSnapshotUpdate('CONDITION_CHANGE', newCondition)
          }
        />
      ) : (
        <Stack className={css.specifyCondition} dense>
          <Button
            variant="outline"
            size="small"
            onClick={() =>
              onSnapshotUpdate('CONDITION_CHANGE', [createEmptyCondition()])
            }
          >
            Specify Condition
          </Button>
          <Sub className={css.subText}>(Optional)</Sub>
        </Stack>
      )}

      <Divider orientation="horizontal" className={css.divider} />

      <Sub className={css.subText}>Field replace text</Sub>
      {fields.map((field, index) => (
        <EventConditionRow
          key={index}
          conditions={[
            {
              conditionOptions: memoizedFieldArray,
              value: [field],
              onConditionChange: value =>
                setUpdatedFields('FIELD_CHANGE', value, index)
            }
          ]}
          showError={isInValidBlock}
          onDelete={() => setUpdatedFields('FIELD_REMOVE', null, index)}
        />
      ))}
      <Button
        variant="outline"
        className={css.addButton}
        size="small"
        color={isInValidBlock && !fields.length ? 'error' : 'default'}
        onClick={() => setUpdatedFields('FIELD_ADD', null)}
      >
        <PlusIcon />
        Add
      </Button>

      <Stack>
        <Sub className={css.subText}>Find</Sub>
        <Tooltip content="Use ^ to prepend the value, $ to append the value, or give value to find from event to perform operation">
          <HelpIcon className={css.helpIcon} />
        </Tooltip>
      </Stack>

      <div
        className={classNames(css.condition, {
          [css.isError]: isInValidBlock && !find
        })}
      >
        <ConditionInput
          value={find}
          onChange={event => setUpdatedFields('FIND', event.target.value)}
          placeholder="Start typing..."
          caseSensitive={caseSensitive}
          regex={regex}
          isValidRegex={!regex || isValidRegex}
          onRegexChange={regex => {
            if (regex) {
              setUpdatedFields('REGEX', regex);
            }
          }}
          onCaseSensitiveChange={caseSensitive => {
            setUpdatedFields('CASE_SENSITIVE', caseSensitive);
          }}
        />
      </div>

      <Sub className={css.subText}>Replace</Sub>
      <div
        className={classNames(css.condition, {
          [css.isError]: isInValidBlock && !value
        })}
      >
        <ConditionInput
          value={value}
          onChange={event => setUpdatedFields('VALUE', event.target.value)}
          placeholder="Start typing..."
        />
      </div>
    </>
  );
};
