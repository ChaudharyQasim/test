import { ChangeEvent, FC, useCallback, useMemo, useState } from 'react';
import {
  Button,
  Collapse,
  InlineInput,
  SmallHeading,
  Stack,
  Sub,
  Text,
  useNotification
} from 'reablocks';
import isEqual from 'react-fast-compare';
import { Reorder, useDragControls } from 'framer-motion';

// CSS
import css from './PipelineBlock.module.css';

// Icons
import { ReactComponent as AlertIcon } from 'assets/icons/warning.svg';
import { ReactComponent as DragIcon } from 'assets/icons/drag.svg';
import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as DuplicateIcon } from 'assets/icons/duplicate.svg';
import { ReactComponent as EditIcon } from 'assets/icons/edit.svg';
import { ReactComponent as ExpandIcon } from 'assets/icons/chevron-down.svg';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import classNames from 'classnames';

// Shared
import { ListMenu } from 'shared/elements/ListMenu/ListMenu';
import { Alert } from 'shared/elements/Alert/Alert';
import { ConditionType } from 'shared/elements/EventCondition';

// Modules
import AggregateBlock from './AggregateBlock';
import ReplaceBlock from './ReplaceBlock';
import DropKeyBlock from './DropKeyBlock';
import EnrichmentBlock from './EnrichmentBlock';
import { ConfigBlock } from '../../ConfigBlock';

// Types
import {
  AggregateBlockJson,
  BlockPropType,
  BlockType,
  DropKeyBlockJson,
  EnrichmentBlockJson,
  ReplaceBlockJson
} from 'App/PipelineManager/Pipeline.types';

import { PipelineFunctionStateEnum, UpdatePipelineFunction } from 'core/Api';
import { blockType, formattedBlock } from 'shared/utils/Helper/blockFormation';
import { BLOCK_HEADER_LABEL, BLOCK_TYPE } from 'shared/utils/Constants';
import { validateBlock } from 'shared/utils/Helper/blockValidation';

const { NONE, UPDATE, CREATE } = PipelineFunctionStateEnum;
const { AGGREGATION, ENRICHMENT, FILTER, REPLACE, DROPKEYS } = BLOCK_TYPE;

type EditModeState = {
  isNameEditing: boolean;
  isDescriptionEditing: boolean;
};

const MENU_LOCAL_BLOCK = [
  {
    icon: <PlusIcon />,
    iconName: 'Add To My Org Blocks',
    iconId: 0
  },
  {
    icon: <DuplicateIcon />,
    iconName: 'Duplicate',
    iconId: 1
  },
  {
    icon: <DeleteIcon />,
    iconName: 'Delete',
    iconId: 2
  }
];

const MENU_SHARED_BLOCK = [
  {
    icon: <DuplicateIcon />,
    iconName: 'Duplicate',
    iconId: 1
  },
  {
    icon: <DeleteIcon />,
    iconName: 'Delete',
    iconId: 2
  }
];

export const PipelineBlock: FC<BlockPropType> = ({
  acsFields,
  acsFieldOperations,
  blockDetails,
  isPassthrough,
  initialBlockCopy,
  enrichmentCSVList,
  startValidationSession,
  blockValidation,
  deleteBlock,
  onBlockUpdate,
  onBlockValidation,
  addToOrganizationBlock,
  syncLocalBlocksWithOrg,
  updateFunctionMutation,
  createDuplicateBlock
}) => {
  const {
    name,
    field_operation_type,
    description,
    function_id,
    priority,
    is_shared,
    tags,
    block
  } = blockDetails;
  const { block: blockJson, snapshot: currentSnapshot } =
    (block as BlockType) || {};

  const { notifyError } = useNotification();

  const [open, setOpen] = useState<boolean>(true);

  const [isEditMode, setIsEditMode] = useState<EditModeState>({
    isNameEditing: false,
    isDescriptionEditing: false
  });

  const [showAlertComponent, setShowAlertComponent] = useState(false);

  const { isNameEditing, isDescriptionEditing } = isEditMode;

  const controls = useDragControls();

  const { current_csv: initial_csv } =
    (initialBlockCopy?.block as BlockType) || {};

  const isInvalidBlock =
    startValidationSession &&
    (blockValidation[priority] === undefined
      ? false
      : !blockValidation[priority]);

  const checkIfBlockUpdated = useCallback(
    (blockPayload: object) => {
      const { block, name, is_shared } = initialBlockCopy || {};
      const isUpdated = isEqual(blockPayload, {
        block,
        name,
        is_shared
      });

      return isUpdated ? NONE : UPDATE;
    },
    [initialBlockCopy]
  );

  const handleBlockUpdate = useCallback(
    ({
      blockJson,
      blockName,
      blockDescription,
      snapshot,
      current_csv = null
    }: {
      blockJson: object;
      blockName?: string;
      blockDescription?: string;
      snapshot?: ConditionType[];
      current_csv?: string;
    }) => {
      const blockStructure = {
        name: blockName ?? name,
        block: { block: blockJson, snapshot: snapshot, current_csv },
        is_shared
      };

      let blockStatus;

      /***
       *
       * Here if the block status = 'CREATE' then block is dirty(As block is unsaved.)
       * For state = 'CREATE' function_id is undefined.
       * So only comparing the blocks if block's state is not 'CREATE'
       * Here checking the state to make sure that if update made then state should change to NONE -> UPDATE.
       * Now user manually go back to initial state means reverted the update so setting the state from UPDATE -> NONE by comparing.
       *
       */
      if (function_id) {
        blockStatus = checkIfBlockUpdated(blockStructure);
      }

      // Creating the structure for updates
      const updatedBlockStructure: UpdatePipelineFunction = {
        ...blockStructure,
        field_operation_type,
        priority,
        tags,
        description: blockDescription || description,
        state: function_id ? blockStatus : CREATE
      };

      if (function_id) {
        updatedBlockStructure.function_id = function_id;
      }

      const isEnrichment =
        blockType(field_operation_type, block) === ENRICHMENT;
      if (isEnrichment && initial_csv !== current_csv) {
        updatedBlockStructure.new_csv_file_id = current_csv;
        if (function_id) {
          updatedBlockStructure.old_csv_file_id = initial_csv;
        }
      }

      /***
       *
       * @description Validation session = User successfully able to save the data - User first press the save button and got some errors in blocks.
       *
       * during Validation session we are showing the block errors.
       * So user is fixing the errors in block at that time we are validating the block on every changes.
       *
       * As we need to show and hide the error border.
       *
       * For example, If Drop key Block found invalid when user press save button. We are showing error border to indicate the invalid block.
       * Now user resolving the errors in block. So on every change we are validing here, because if user fixed all the validation,
       * then we need to hide error border as well.
       *
       * This step can help us to improve the optimization as we are checking for validation on save.
       * On save got some error then on every change we are validating.
       *
       */
      if (startValidationSession) {
        const validate = validateBlock({
          field_operation_type,
          block: blockStructure.block,
          enrichmentCSVList
        });

        onBlockValidation({ ...blockValidation, [priority]: validate });
      }

      if (is_shared) {
        setShowAlertComponent([CREATE, UPDATE].includes(blockStatus));
      }
      onBlockUpdate(updatedBlockStructure);
    },
    [
      name,
      description,
      function_id,
      is_shared,
      priority,
      tags,
      block,
      blockValidation,
      enrichmentCSVList,
      initial_csv,
      field_operation_type,
      startValidationSession,
      checkIfBlockUpdated,
      onBlockUpdate,
      onBlockValidation
    ]
  );

  /**
   * @description Updates the block details that is_shared in the organization.
   * This will update all the blocks used by other pipelines.
   */
  const handleApplyChangesOrgBlock = async () => {
    const updatedBlock = {
      name,
      description,
      tags,
      field_operation_type,
      block: formattedBlock({ block, field_operation_type })
    };
    if (validateBlock({ field_operation_type, block, enrichmentCSVList })) {
      await updateFunctionMutation({
        functionId: function_id,
        customFunction: updatedBlock
      });
      syncLocalBlocksWithOrg();
      setShowAlertComponent(false);
    } else {
      notifyError('Please resolve all errors before applying the changes');
    }
  };

  /**
   * @description Reverts the changes made to the original block that is_shared in the organization.
   * This will restore the original block details without updating the blocks used by other pipelines.
   */
  const handleRevertChanges = () => {
    const {
      name: initialName,
      description: initialDescription,
      block
    } = initialBlockCopy;
    const {
      block: initialBlockJson,
      snapshot: initialSnapshot,
      current_csv: initial_csv
    } = block as BlockType;
    handleBlockUpdate({
      blockJson: initialBlockJson,
      blockName: initialName,
      blockDescription: initialDescription,
      snapshot: initialSnapshot,
      current_csv: initial_csv ?? null
    });
    setShowAlertComponent(false);
  };

  const currentBlockType = useMemo(
    () => blockType(field_operation_type, blockJson),
    [field_operation_type, blockJson]
  );

  const onActionClick = (actionId: number) => {
    if (actionId === 0) {
      addToOrganizationBlock();
    } else if (actionId === 1) {
      createDuplicateBlock();
    } else if (actionId === 2) {
      deleteBlock();
    }
  };

  const renderedBlock = () => {
    switch (currentBlockType) {
      case AGGREGATION:
        return (
          <AggregateBlock
            acsFields={acsFields}
            acsFieldOperations={acsFieldOperations}
            isEditMode={!isPassthrough}
            block={blockJson as AggregateBlockJson}
            snapshot={currentSnapshot}
            isInValidBlock={isInvalidBlock}
            onBlockUpdate={handleBlockUpdate}
          />
        );
      case ENRICHMENT:
        return (
          <EnrichmentBlock
            acsFields={acsFields}
            acsFieldOperations={acsFieldOperations}
            block={blockJson as EnrichmentBlockJson}
            isEditMode={!isPassthrough}
            current_csv={(block as BlockType).current_csv}
            snapshot={currentSnapshot}
            enrichmentCSVList={enrichmentCSVList}
            isInValidBlock={isInvalidBlock}
            onBlockUpdate={handleBlockUpdate}
          />
        );
      case FILTER:
        return (
          <ConfigBlock
            acsFields={acsFields}
            acsFieldOperations={acsFieldOperations}
            block={blockJson}
            isEditMode={!isPassthrough}
            snapshot={currentSnapshot}
            isInValidBlock={isInvalidBlock}
            onBlockUpdate={handleBlockUpdate}
          />
        );
      case REPLACE:
        return (
          <ReplaceBlock
            acsFields={acsFields}
            acsFieldOperations={acsFieldOperations}
            isEditMode={!isPassthrough}
            block={blockJson as ReplaceBlockJson}
            snapshot={currentSnapshot}
            isInValidBlock={isInvalidBlock}
            onBlockUpdate={handleBlockUpdate}
          />
        );
      case DROPKEYS:
        return (
          <DropKeyBlock
            acsFields={acsFields}
            acsFieldOperations={acsFieldOperations}
            isEditMode={!isPassthrough}
            block={blockJson as DropKeyBlockJson}
            snapshot={currentSnapshot}
            isInValidBlock={isInvalidBlock}
            onBlockUpdate={handleBlockUpdate}
          />
        );
      default:
        return null;
    }
  };

  return (
    <Reorder.Item
      key={priority}
      className={css.block}
      dragListener={false}
      dragControls={controls}
      value={blockDetails}
    >
      <div className={is_shared ? css.sharedBlockHeader : css.header}>
        <Stack justifyContent="spaceBetween">
          <Stack className={css.info}>
            {!isPassthrough && (
              <DragIcon
                className={css.dragHandle}
                onPointerDown={event => controls.start(event)}
              />
            )}
            <Text className={css.blockName}>{name}</Text>
            <Text className={css.blockType}>
              {BLOCK_HEADER_LABEL[currentBlockType]}
            </Text>
          </Stack>
          <Stack>
            <Button
              variant="text"
              onClick={() => setOpen(!open)}
              disableMargins
              disablePadding
            >
              <ExpandIcon
                className={classNames(css.expander, { [css.collapsed]: !open })}
              />
            </Button>
            <ListMenu
              listItems={is_shared ? MENU_SHARED_BLOCK : MENU_LOCAL_BLOCK}
              disableOptions={isPassthrough}
              className={css.menuPlacement}
              disabledMargin
              disabledPadding
              onItemClick={onActionClick}
            />
          </Stack>
        </Stack>
      </div>
      <Collapse expanded={open}>
        <div
          className={classNames(css.content, {
            [css.isError]: isInvalidBlock
          })}
        >
          {!isPassthrough && is_shared && showAlertComponent && (
            <Stack>
              <Alert
                icon={<AlertIcon className={css.alert} />}
                text="THIS BLOCK HAS UNDERGONE CHANGES. WOULD YOU LIKE TO APPLY THESE MODIFICATIONS TO ALL OTHER INSTANCES OF THIS BLOCK, OR WOULD YOU PREFER TO CREATE A NEW BLOCK?"
              />
              <Button variant="outline" onClick={handleApplyChangesOrgBlock}>
                Apply Changes
              </Button>
              <Button variant="outline" onClick={handleRevertChanges}>
                Revert Changes
              </Button>
            </Stack>
          )}
          {!isPassthrough && (
            <>
              <Stack alignItems="center">
                <SmallHeading disableMargins>
                  <InlineInput
                    className={css.input}
                    value={name}
                    disabled={!isNameEditing}
                    onChange={(event: ChangeEvent<HTMLInputElement>) => {
                      handleBlockUpdate({
                        blockJson,
                        blockName: event.target.value,
                        blockDescription: null,
                        snapshot: currentSnapshot
                      });
                    }}
                    autoFocus
                    maxLength={50}
                    onBlur={() =>
                      setIsEditMode(prev => ({ ...prev, isNameEditing: false }))
                    }
                  />
                </SmallHeading>
                {!isNameEditing && (
                  <>
                    <Button
                      variant="text"
                      disableMargins
                      disablePadding
                      onClick={() =>
                        setIsEditMode(prev => ({
                          ...prev,
                          isNameEditing: true
                        }))
                      }
                    >
                      <EditIcon />
                    </Button>
                  </>
                )}
              </Stack>
              <Sub>{description}</Sub>
            </>
          )}

          {renderedBlock()}
        </div>
      </Collapse>
    </Reorder.Item>
  );
};
