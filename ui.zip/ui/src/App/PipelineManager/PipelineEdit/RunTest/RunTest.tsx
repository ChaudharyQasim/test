import { FC, useState } from 'react';
import {
  Button,
  Divider,
  DotsLoader,
  Input,
  SmallHeading,
  Stack
} from 'reablocks';
import css from './RunTest.module.css';

import { ReactComponent as NextIcon } from 'assets/icons/chevron-right.svg';
import { ReactComponent as SearchIcon } from 'assets/icons/search.svg';

const mockEvents = [
  { name: '@timestamp', value: '2017-08-12 00:01:12' },
  { name: 'event.abstract.id', value: '23k45jhe98eu' },
  { name: 'agent.name', value: 'collector' },
  { name: 'agent.type', value: 'data here' },
  { name: 'agent.version', value: '1.0' },
  { name: '@timestamp', value: '2017-08-12 00:01:12' },
  { name: 'event.abstract.id', value: '23k45jhe98eu' },
  { name: 'agent.name', value: 'collector' },
  { name: 'agent.type', value: 'data here' },
  { name: 'agent.version', value: '1.0' },
  { name: '@timestamp', value: '2017-08-12 00:01:12' },
  { name: 'event.abstract.id', value: '23k45jhe98eu' },
  { name: 'agent.name', value: 'collector' },
  { name: 'agent.type', value: 'data here' },
  { name: 'agent.version', value: '1.0' }
];

interface RunTestProps {
  onClose: () => void;
}

export const RunTest: FC<RunTestProps> = ({ onClose }) => {
  const [loading, setLoading] = useState<boolean>(false);

  return (
    <div className={css.layout}>
      <div className={css.find}>
        <Input
          start={<SearchIcon className={css.searchIcon} />}
          placeholder="Find events"
          fullWidth
        />
      </div>
      {loading ? (
        <div className={css.loading}>
          <DotsLoader />
        </div>
      ) : (
        <div className={css.comparison}>
          <div className={css.navigators}>
            {/* TODO: Disable button if last event */}
            <Button
              className={css.nav}
              variant="text"
              size="small"
              disableMargins
            >
              <NextIcon className={css.reverse} />
            </Button>
          </div>
          <div className={css.before}>
            <SmallHeading>Events Before (1000)</SmallHeading>
            <Stack direction="column" alignItems="start">
              {mockEvents.map(({ name, value }, idx) => (
                <Stack
                  key={`${name}-${idx}-before`}
                  className={css.row}
                  justifyContent="spaceBetween"
                >
                  <span>{name}</span>
                  {value}
                </Stack>
              ))}
            </Stack>
          </div>
          <Divider orientation="vertical" disableMargins />
          <div className={css.after}>
            <SmallHeading>Events After (1000)</SmallHeading>
            <Stack direction="column" alignItems="start">
              {mockEvents.map(({ name, value }, idx) => (
                <Stack
                  key={`${name}-${idx}-after`}
                  className={css.row}
                  justifyContent="spaceBetween"
                >
                  <span>{name}</span>
                  {value}
                </Stack>
              ))}
            </Stack>
          </div>
          <div className={css.navigators}>
            {/* TODO: Disable button if last event */}
            <Button
              className={css.nav}
              variant="text"
              size="small"
              disableMargins
            >
              <NextIcon />
            </Button>
          </div>
        </div>
      )}
      <div className={css.actions}>
        <Button variant="outline" onClick={onClose}>
          Cancel
        </Button>
      </div>
    </div>
  );
};
