import { FC, useCallback } from 'react';

import { Divider, Text } from 'reablocks';
import { EventCondition } from 'shared/elements/EventCondition';
import { createEmptyCondition } from 'shared/elements/EventCondition/utils';

import css from './ConfigBlock.module.css';

import { ConfigBlockProp } from 'App/PipelineManager/Pipeline.types';
import ConditionsSummary from 'App/Views/Condition/ConditionsSummary';

export const ConfigBlock: FC<ConfigBlockProp> = ({
  acsFields,
  acsFieldOperations,
  block,
  snapshot,
  isEditMode,
  onBlockUpdate
}) => {
  const { operator } = block;

  const setUpdatedFields = useCallback(
    (params: string, parameterValue) => {
      const updatedOperator =
        params === 'OPERATOR_CHANGE' ? parameterValue : operator;

      const updatedSnapshot =
        params === 'CONDITION_CHANGE' ? parameterValue : snapshot;

      onBlockUpdate({
        blockJson: {
          ...block,
          operator: updatedOperator
        },
        snapshot: updatedSnapshot
      });
    },
    [operator, block, snapshot, onBlockUpdate]
  );

  if (!isEditMode) {
    return (
      <>
        <Text className={css.readModeHeading}>Drop block condition</Text>
        {snapshot.length > 0 ? (
          <ConditionsSummary conditions={snapshot} />
        ) : (
          <Text color="error">There are no conditions</Text>
        )}
      </>
    );
  }

  return (
    <>
      <Divider />
      <EventCondition
        fields={acsFields}
        fieldOperationsMap={acsFieldOperations}
        conditions={snapshot ?? [createEmptyCondition()]}
        operator={operator}
        updateBaseOperator={newOperator =>
          setUpdatedFields('OPERATOR_CHANGE', newOperator)
        }
        onConditionsChange={newCondition =>
          setUpdatedFields('CONDITION_CHANGE', newCondition)
        }
      />
    </>
  );
};
