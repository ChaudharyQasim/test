import { FC, useRef, useState } from 'react';
import {
  Button,
  Card,
  List,
  ListItem,
  MotionItem,
  Menu,
  Text
} from 'reablocks';
import css from './LibraryBlock.module.css';

import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as MoreIcon } from 'assets/icons/dots-horz.svg';
import classNames from 'classnames';

type LibraryBlockProps = {
  id: string;
  label: string;
  loader: boolean;
  isDisabled?: boolean;
  csvFileId?: string | null;
  onDelete?: ({ id, csv_file_id }) => void;
};

export const LibraryBlock: FC<LibraryBlockProps> = ({
  id,
  label,
  loader,
  isDisabled = false,
  csvFileId,
  onDelete
}) => {
  const btnRef = useRef<HTMLButtonElement | null>(null);
  const [menuOpen, setMenuOpen] = useState<boolean>(false);

  return (
    <MotionItem
      className={classNames(css.block, {
        [css.disabled]: isDisabled
      })}
      key={label}
    >
      <Text className={isDisabled ? css.disabled : ''}>{label}</Text>
      {onDelete && (
        <Button
          ref={btnRef}
          variant="text"
          onClick={() => setMenuOpen(!menuOpen)}
          disableMargins
          disablePadding
        >
          <MoreIcon className={css.moreIcon} />
        </Button>
      )}
      <Menu
        reference={btnRef}
        open={menuOpen}
        placement="bottom-start"
        onClose={() => setMenuOpen(false)}
      >
        <Card>
          <List>
            {onDelete && (
              <ListItem
                start={<DeleteIcon />}
                disabled={loader || isDisabled}
                onClick={() => {
                  setMenuOpen(false);
                  onDelete({ id, csv_file_id: csvFileId });
                }}
              >
                Remove From My Org Blocks
              </ListItem>
            )}
          </List>
        </Card>
      </Menu>
    </MotionItem>
  );
};
