import { FC } from 'react';
import { Dialog, useNotification } from 'reablocks';
import {
  useInfiniteQuery,
  useMutation,
  useQuery,
  useQueryClient
} from 'react-query';
import { useParams } from 'react-router-dom';

// Modules
import { PipelineEdit } from './PipelineEdit';

// Shared
import { errorHandler } from 'shared/utils/Helper';
import { Loader } from 'shared/elements/Loader';

// Core
import { useAuth } from 'core/Auth';
import { useQueryParams } from 'core/Hooks/useQueryParams';

import {
  createFunction,
  updateFunction,
  deleteFunction,
  getFunctionList,
  getPipelineById,
  updatePipeline,
  getFoundationalList,
  getEnrichmentCSVList
} from 'core/Api/PipelineApi';

import css from './PipelineEdit.module.css';

import { AxiosError } from 'axios';
import { ErrorResponseMessage } from 'App/Integrations/Integration.types';
import { CreateFunctionIn, UpdateFunctionIn } from 'core/Api';
import { getAcsFields, getAcsFieldOperations } from 'core/Api/AcsApi';
import { PAGE_LIMIT_XXL } from 'shared/utils/Constants';

export const PipelineEditContainer: FC = () => {
  const queryClient = useQueryClient();

  const { id } = useParams();

  const { keyword: blockSearch } = useQueryParams();

  const { user } = useAuth();

  const { notifySuccess, notifyError } = useNotification();

  const {
    data: pipelineDetails,
    refetch: refetchPipelineDetails,
    isLoading: isPipelineDetailsLoading
  } = useQuery(['pipelineDetails', id], () => getPipelineById(id), {
    onError(error: AxiosError<ErrorResponseMessage> | any) {
      notifyError(errorHandler(error));
    },
    enabled: !!id
  });

  const { data: acsFields } = useQuery('acsFields', () => getAcsFields(), {
    onError(error: any) {
      notifyError(errorHandler(error));
    }
  });

  const {
    data: enrichmentCSVList,
    isLoading: isEnrichmentLoading,
    refetch: refetchEnrichmentList
  } = useQuery(['enrichmentCSVEntireList', 1], () =>
    getEnrichmentCSVList({ pageNumber: '1', pageSize: PAGE_LIMIT_XXL })
  );

  const { data: acsFieldOperations } = useQuery(
    'acsFieldOperations',
    () => getAcsFieldOperations(),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { data: foundationalBlocks } = useQuery(
    ['foundationalFunction', blockSearch],
    () => getFoundationalList(blockSearch),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      },
      enabled: !!user?.current_organization?.id
    }
  );

  const {
    data: organizationBlocks,
    fetchNextPage: fetchMoreOrgFunction,
    hasNextPage: hasMoreOrgFunction
  } = useInfiniteQuery(
    ['organizationFunction', blockSearch],
    ({ pageParam = 1 }) =>
      getFunctionList({
        organization_id: user?.current_organization?.id,
        function_type: 'CUSTOM',
        pageNumber: pageParam,
        searchString: blockSearch
      }),
    {
      enabled: !!user?.current_organization?.id,
      onError(error: any) {
        notifyError(errorHandler(error));
      },
      getNextPageParam: (lastPage, allPages) => {
        if (lastPage?.length === 10) {
          return allPages.length + 1;
        }
        return undefined;
      },
      onSettled: _data => {
        queryClient.setQueryData('organizationFunction', () => {
          return _data;
        });
      }
    }
  );

  const {
    mutateAsync: savePipelineDetailsAsyncMutation,
    isLoading: isSavePipelineDetailsLoading
  } = useMutation(
    ({ payload }: { payload: any }) => updatePipeline(id, payload),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      },
      onSuccess(data) {
        notifySuccess(data?.message);
        queryClient.invalidateQueries(['pipelineDetails', id]);
      }
    }
  );

  const { mutateAsync: deleteFunctionMutation } = useMutation(
    'deleteFunction',
    (deleteFunctionPayload: {
      id: string;
      isForceDelete: boolean;
      csv_file_id?: string;
    }) => deleteFunction(deleteFunctionPayload),
    {
      onSuccess() {
        notifySuccess('Organization block is deleted');
        queryClient.refetchQueries('organizationFunction');
      }
    }
  );

  const { mutateAsync: createFunctionMutation } = useMutation(
    'createFunction',
    (customFunction: CreateFunctionIn) => createFunction(customFunction),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      },
      onSuccess() {
        notifySuccess('Function added to organization');
        queryClient.refetchQueries('organizationFunction');
      }
    }
  );

  const { mutateAsync: updateFunctionMutation } = useMutation(
    'updateFunction',
    ({
      functionId,
      customFunction
    }: {
      functionId: string;
      customFunction: UpdateFunctionIn;
    }) => updateFunction({ functionId, customFunction }),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      },
      onSuccess() {
        notifySuccess('Organization block is updated');
        queryClient.refetchQueries('organizationFunction');
      }
    }
  );

  return (
    <Dialog
      open
      className={css.dialog}
      innerClassName={css.fullDialog}
      size="100vw"
      header={null}
      showCloseButton={false}
      disablePadding
    >
      {isPipelineDetailsLoading ? (
        <Loader />
      ) : (
        <PipelineEdit
          isSavePipelineDetailsLoading={
            isSavePipelineDetailsLoading || isEnrichmentLoading
          }
          pipelineDetails={pipelineDetails}
          acsFields={acsFields}
          acsFieldOperations={acsFieldOperations}
          foundationalBlocks={foundationalBlocks}
          organizationBlocks={organizationBlocks}
          hasMoreOrgFunction={hasMoreOrgFunction}
          enrichmentCSVList={enrichmentCSVList?.file_list ?? []}
          refetchEnrichmentList={refetchEnrichmentList}
          createFunctionMutation={createFunctionMutation}
          updateFunctionMutation={updateFunctionMutation}
          deleteFunctionMutation={deleteFunctionMutation}
          refetchPipelineDetails={refetchPipelineDetails}
          savePipelineDetailsAsyncMutation={savePipelineDetailsAsyncMutation}
          fetchMoreOrgFunction={fetchMoreOrgFunction}
        />
      )}
    </Dialog>
  );
};
