import { FC, useState } from 'react';
import { Button, Collapse, MotionGroup, Stack } from 'reablocks';
import classNames from 'classnames';

import { LibraryBlock } from 'App/PipelineManager/PipelineEdit/LibraryBlock';

// Shared
import { Chip } from 'shared/elements/Chip';

// CSS
import css from './PipelineLibraryBlock.module.css';

// Icons
import { ReactComponent as ExpandIcon } from 'assets/icons/chevron-alt-down.svg';

// Types
import {
  BlockType,
  PipelineLibraryBlockType
} from 'App/PipelineManager/Pipeline.types';

export const PipelineLibraryBlock: FC<PipelineLibraryBlockType> = ({
  blockLabel,
  blocks,
  isDraggable,
  blockItemLoader = {},
  hasMoreOrgFunction,
  fetchMoreFunction,
  onDrag,
  onDelete
}) => {
  const [expanded, setExpanded] = useState<boolean>(true);

  const handleFetchMore = () => {
    if (!isDraggable) {
      return;
    }
    fetchMoreFunction();
  };

  return (
    <div className={css.root}>
      <Button
        variant="text"
        onClick={() => setExpanded(prev => !prev)}
        disableMargins
        disablePadding
      >
        <Stack>
          <ExpandIcon
            className={classNames(css.expander, {
              [css.collapsed]: !expanded
            })}
          />
          <div className={css.sectionHeading}>{blockLabel}</div>
          <Chip variant="outline" color="secondary">
            {blocks?.length.toLocaleString() ?? 0}
          </Chip>
        </Stack>
      </Button>
      <Collapse expanded={expanded}>
        <MotionGroup className={css.sectionList}>
          {blocks?.map(block => {
            const { function_id, name, block: blockJson } = block;
            const { current_csv } = blockJson as BlockType;
            return (
              <div
                key={function_id}
                onDragStart={() => onDrag(block)}
                draggable={isDraggable}
              >
                <LibraryBlock
                  id={function_id.toString()}
                  csvFileId={current_csv}
                  label={name}
                  loader={blockItemLoader[function_id] ?? false}
                  isDisabled={!isDraggable}
                  onDelete={onDelete}
                />
              </div>
            );
          })}
        </MotionGroup>
        {hasMoreOrgFunction && (
          <Chip
            variant="outline"
            onClick={handleFetchMore}
            className={classNames(css.loadMoreChip, {
              [css.disabled]: !isDraggable
            })}
            disabled={!isDraggable}
          >
            Load More ...
          </Chip>
        )}
      </Collapse>
    </div>
  );
};
