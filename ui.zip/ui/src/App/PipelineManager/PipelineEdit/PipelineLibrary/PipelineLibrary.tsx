import { FC, useMemo, useState } from 'react';
import {
  DebouncedInput,
  Divider,
  SmallHeading,
  VerticalSpacer
} from 'reablocks';

// CSS
import css from './PipelineLibrary.module.css';

// Icons
import { ReactComponent as SearchIcon } from 'assets/icons/search.svg';

// Modules
import { PipelineLibraryBlock } from './PipelineLibraryBlock/PipelineLibraryBlock';

// Types
import { PipelineLibraryProps } from 'App/PipelineManager/Pipeline.types';
import { ConfirmationDialog } from 'shared/layers/ConfirmationDialog/ConfirmationDialog';
import { FunctionCategoryEnum } from 'core/Api';

type ConfirmationType = {
  confirmationDialogType: 'DELETE' | 'FORCE_DELETE';
  isOpen: boolean;
};

const { FOUNDATIONAL, CUSTOM } = FunctionCategoryEnum;

export const PipelineLibrary: FC<PipelineLibraryProps> = ({
  isPassthrough,
  foundationalBlocks,
  organizationBlocks,
  hasMoreOrgFunction,
  keyword,
  setKeyword,
  deleteFunctionMutation,
  deleteOrganizationBlockFromList,
  fetchMoreOrgFunction,
  onDrag
}) => {
  const [myOrgLoader, setMyOrgLoader] = useState<{ [key: string]: boolean }>(
    {}
  );

  const [confirmationMessage, setConfirmationMessage] = useState<string | null>(
    null
  );

  const [deleteParameter, setDeleteParameter] = useState<{
    id: string;
    csv_file_id: string;
  }>(null);

  const { id: functionIdToDelete, csv_file_id } = deleteParameter || {};

  const [confirmationDialog, setConfirmationDialog] =
    useState<ConfirmationType>({
      isOpen: false,
      confirmationDialogType: 'DELETE'
    });

  const { isOpen, confirmationDialogType } = confirmationDialog;

  const organizationBlocksInfiniteList = useMemo(
    () => (organizationBlocks?.pages ? organizationBlocks.pages.flat() : []),
    [organizationBlocks?.pages]
  );

  const deleteFunction = async () => {
    try {
      setMyOrgLoader(prev => ({ ...prev, [functionIdToDelete]: true }));
      await deleteFunctionMutation({
        id: functionIdToDelete,
        isForceDelete: false,
        csv_file_id
      });
      deleteOrganizationBlockFromList(functionIdToDelete);
    } catch (error: any) {
      const {
        response: { status, data }
      } = error;
      if (status === 409) {
        setDeleteParameter({ id: functionIdToDelete, csv_file_id });
        setConfirmationDialog({
          isOpen: true,
          confirmationDialogType: 'FORCE_DELETE'
        });
        setConfirmationMessage(
          `Are you sure you want to force delete organization block as ${data.pipeline_list
            .map(pipeline => pipeline.name)
            .join(', ')} depends on it?`
        );
      }
    }
    setMyOrgLoader(prev => ({ ...prev, [functionIdToDelete]: false }));
  };

  const onConfirmation = async () => {
    setConfirmationDialog(prev => ({ ...prev, isOpen: false }));
    if (confirmationDialogType === 'DELETE') {
      deleteFunction();
    } else {
      await deleteFunctionMutation({
        id: functionIdToDelete,
        isForceDelete: true,
        csv_file_id
      });
      deleteOrganizationBlockFromList(functionIdToDelete);
    }
  };

  return (
    <>
      <div className={css.library}>
        <SmallHeading className={css.libraryContent}>Library</SmallHeading>
        <Divider />
        <VerticalSpacer space="lg" />
        <div className={css.libraryContent}>
          <DebouncedInput
            size="small"
            debounce={500}
            value={keyword}
            onChange={event => setKeyword(event.target.value)}
            start={<SearchIcon className={css.search} />}
            placeholder="Find..."
          />
          <VerticalSpacer space="sm" />
          <PipelineLibraryBlock
            isDraggable={!isPassthrough}
            blockLabel="Foundation Blocks"
            blocks={foundationalBlocks}
            onDrag={block =>
              onDrag({ type: FOUNDATIONAL, draggedBlock: block })
            }
          />
          <VerticalSpacer space="xxl" />
          <PipelineLibraryBlock
            blockLabel="My Org Blocks"
            isDraggable={!isPassthrough}
            blocks={organizationBlocksInfiniteList}
            blockItemLoader={myOrgLoader}
            hasMoreOrgFunction={hasMoreOrgFunction}
            fetchMoreFunction={fetchMoreOrgFunction}
            onDelete={deleteParams => {
              setDeleteParameter(deleteParams);
              setConfirmationDialog({
                isOpen: true,
                confirmationDialogType: 'DELETE'
              });
            }}
            onDrag={block => onDrag({ type: CUSTOM, draggedBlock: block })}
          />
        </div>
      </div>
      <ConfirmationDialog
        open={isOpen}
        dialogType="DELETE"
        confirmationHeading={
          confirmationDialogType === 'FORCE_DELETE'
            ? 'Want to delete reference Block'
            : 'Want to delete organization block'
        }
        confirmationMessage={
          confirmationDialogType === 'DELETE'
            ? 'Are you sure you want to delete the organization block?'
            : confirmationMessage
        }
        confirmationButtonName="Delete"
        onConfirm={onConfirmation}
        onCancel={() =>
          setConfirmationDialog(prev => ({ ...prev, isOpen: false }))
        }
      />
    </>
  );
};
