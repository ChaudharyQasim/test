import { FC, useMemo, useState } from 'react';
import { Button, Stack } from 'reablocks';
import { createSearchParams, useNavigate } from 'react-router-dom';

// CSS
import css from './PipelineEdit.module.css';

// Icons
import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';
import { ReactComponent as PipelineConnectorIcon } from 'assets/icons/pipeline-connector.svg';
import { ReactComponent as SaveIcon } from 'assets/icons/check.svg';

// Modules
import { PipelineLibrary } from './PipelineLibrary';
import { PipelineHeader } from './PipelineHeader';
import { PipelineBlockList } from './PipelineBlockList';

import { useFilterPager } from 'core/Hooks/useFilterPager';

// Shared
import { ConfirmationDialog } from 'shared/layers/ConfirmationDialog';
import { BLOCK_TYPE } from 'shared/utils/Constants';
import { formattedBlock, validateBlock } from 'shared/utils/Helper';

// Types
import {
  DragTypeParams,
  PipelineEditProps,
  PipelineHeaderState,
  BlockValidationType
} from '../Pipeline.types';

import { useQueryParams } from 'core/Hooks/useQueryParams';
import {
  GetPipelineFunctions,
  PipelineFunctionStateEnum,
  UpdatePipelineFunction
} from 'core/Api';
import isEqual from 'react-fast-compare';

const { ENRICHMENT } = BLOCK_TYPE;

type ConfirmationType = {
  confirmationDialogType: 'SAVE' | 'SAVE_CLOSE' | 'WARNING' | 'WARNING_DISCARD';
  isOpen: boolean;
};

const { NONE, CREATE, UPDATE } = PipelineFunctionStateEnum;

const formattedFunctions = (functionsToFormat: GetPipelineFunctions[]) =>
  functionsToFormat?.map(funct => ({
    ...funct,
    state: NONE
  })) || [];

// This function is used to format the initial copy of the saved block.
export const formattedInitialFunctions = (
  functionsToFormat: GetPipelineFunctions[]
) => {
  const initialBlocks = functionsToFormat
    ?.filter(
      (block, index, self) =>
        index ===
        self.findIndex(findBlock => findBlock.function_id === block.function_id)
    )
    .map(initialFunction => ({ ...initialFunction, state: NONE }));
  return initialBlocks;
};

export const PipelineEdit: FC<PipelineEditProps> = ({
  acsFields,
  pipelineDetails,
  acsFieldOperations,
  foundationalBlocks,
  organizationBlocks,
  hasMoreOrgFunction,
  enrichmentCSVList,
  isSavePipelineDetailsLoading,
  refetchEnrichmentList,
  refetchPipelineDetails,
  fetchMoreOrgFunction,
  createFunctionMutation,
  updateFunctionMutation,
  deleteFunctionMutation,
  savePipelineDetailsAsyncMutation
}) => {
  const { pipelineView, configurationId, configurationVendorId } =
    useQueryParams();

  const { keyword, setKeyword } = useFilterPager();

  const navigate = useNavigate();

  const { name, description, is_passthrough, tags, functions } =
    pipelineDetails || {};

  const [dragBlock, setDragBlock] = useState<DragTypeParams>(null);

  const [blocks, setBlocks] = useState<UpdatePipelineFunction[]>(() =>
    formattedFunctions(functions)
  );

  const [initialBlockCopy, setInitialBlockCopy] = useState<
    UpdatePipelineFunction[]
  >(() => formattedInitialFunctions(functions));

  const [headerFields, setHeaderFields] = useState<PipelineHeaderState>({
    name,
    description,
    is_passthrough,
    tags
  });

  const [blockValidation, setBlockValidation] = useState<BlockValidationType>(
    () =>
      functions?.reduce((acc, obj) => {
        acc[obj.priority] = true;
        return acc;
      }, {})
  );

  const [openSaveConfirmation, setOpenSaveConfirmation] =
    useState<ConfirmationType>({
      isOpen: false,
      confirmationDialogType: 'SAVE'
    });

  const [startValidationSession, setStartValidationSession] =
    useState<boolean>(false);

  const { isOpen, confirmationDialogType } = openSaveConfirmation;

  const dirtyBlocks = useMemo(
    () => blocks?.filter(({ state }) => [CREATE, UPDATE].includes(state)),
    [blocks]
  );

  // Checking if any of the fields are updated.
  const isPipelineDirty = useMemo(
    () =>
      dirtyBlocks.length > 0 ||
      !isEqual(headerFields, {
        name,
        description,
        is_passthrough,
        tags
      }),
    [dirtyBlocks, headerFields, name, description, is_passthrough, tags]
  );

  const dialogConfiguration = useMemo(() => {
    switch (confirmationDialogType) {
      case 'WARNING':
        return {
          buttonName: 'Fix the Blocks',
          heading: 'You have some invalid blocks',
          message:
            'You have invalid blocks. Please fix the validations to save the pipeline.'
        };
      case 'WARNING_DISCARD':
        return {
          buttonName: 'Discard Changes',
          heading: 'You have some unsaved changes',
          message: 'Are you sure you want to discard changes?'
        };
      case 'SAVE':
      case 'SAVE_CLOSE':
        return {
          buttonName: 'Save Changes',
          heading: 'Want to save pipeline',
          message: 'Are you sure you want to save pipeline?'
        };
      default:
        break;
    }
  }, [confirmationDialogType]);

  const onNavigate = () => {
    let goTo: any = `/pipeline?pipelineView=${pipelineView}`;
    if (pipelineView === 'ConfigurationDetail') {
      goTo = {
        pathname: `/marketplace/${configurationId}`,
        search: createSearchParams({
          vendor_account_id: configurationVendorId,
          selectedTab: '1'
        }).toString()
      };
    }
    navigate(goTo);
  };

  const deleteOrganizationBlockFromList = (id: string) => {
    const blocksToDelete = blocks.filter(block => block.function_id !== id);

    setBlocks(blocksToDelete);
  };

  const savePipelineDetails = async () => {
    const savePayload = {
      ...headerFields,
      // resetting the priority
      functions: blocks.map((blockDetail, index) => {
        const { state, block, field_operation_type } = blockDetail;
        return {
          ...blockDetail,
          block: [CREATE, UPDATE].includes(state)
            ? formattedBlock({ block, field_operation_type })
            : block,
          priority: index
        };
      })
    };
    setOpenSaveConfirmation(prev => ({ ...prev, isOpen: false }));
    await savePipelineDetailsAsyncMutation({ payload: savePayload });
    if (confirmationDialogType === 'SAVE') {
      const { data } = await refetchPipelineDetails();

      // resetting the blocks state to NONE after save
      setBlocks(formattedFunctions(data?.functions));
      setInitialBlockCopy(formattedInitialFunctions(data?.functions));
    } else {
      onNavigate();
    }
  };

  const validateBlocksOnSave = async () => {
    const enrichmentBlockIndex = dirtyBlocks.findIndex(
      block => block.field_operation_type === (ENRICHMENT as any)
    );
    if (enrichmentBlockIndex !== -1) {
      await refetchEnrichmentList();
    }

    let validationObject = {};
    dirtyBlocks.forEach(({ block, field_operation_type, priority }) => {
      const currentValidation = validateBlock({
        field_operation_type,
        block,
        enrichmentCSVList
      });
      validationObject = {
        ...validationObject,
        [priority]: currentValidation
      };
    });

    setBlockValidation(validationObject);

    return Object.values(validationObject).includes(false);
  };

  const onConfirmation = () => {
    if (confirmationDialogType === 'WARNING') {
      setStartValidationSession(true);
      setOpenSaveConfirmation(prev => ({ ...prev, isOpen: false }));
    } else if (confirmationDialogType === 'WARNING_DISCARD') {
      setOpenSaveConfirmation(prev => ({ ...prev, isOpen: false }));
      onNavigate();
    } else {
      setStartValidationSession(false);
      savePipelineDetails();
    }
  };

  const onSavePipelineDetails = async (isSaveClose: boolean) => {
    const isAllBlocksValid = await validateBlocksOnSave();

    if (isAllBlocksValid) {
      setOpenSaveConfirmation({
        isOpen: true,
        confirmationDialogType: 'WARNING'
      });
    } else {
      setOpenSaveConfirmation({
        isOpen: true,
        confirmationDialogType: isSaveClose ? 'SAVE_CLOSE' : 'SAVE'
      });
    }
  };

  return (
    <>
      <header>
        <div className={css.dialogHeader}>
          <div className={css.title}>
            <PipelineConnectorIcon /> Pipeline Connector
          </div>
          <Stack justifyContent="end">
            <Button
              variant="outline"
              className={css.iconBtn}
              onClick={() => {
                if (isPipelineDirty) {
                  setOpenSaveConfirmation({
                    isOpen: true,
                    confirmationDialogType: 'WARNING_DISCARD'
                  });
                } else {
                  onNavigate();
                }
              }}
            >
              <CloseIcon /> Cancel
            </Button>
            <Button
              variant="outline"
              className={css.iconBtn}
              disabled={isSavePipelineDetailsLoading}
              onClick={() => onSavePipelineDetails(false)}
            >
              {isSavePipelineDetailsLoading ? 'Saving...' : 'Save'}
            </Button>
            <Button
              variant="filled"
              color="primary"
              className={css.iconBtn}
              onClick={() => onSavePipelineDetails(true)}
              disabled={isSavePipelineDetailsLoading}
            >
              <SaveIcon />
              {isSavePipelineDetailsLoading ? 'Saving...' : 'Save and Close'}
            </Button>
          </Stack>
        </div>
      </header>
      <div className={css.layout}>
        <PipelineHeader
          headerFields={headerFields}
          pipelineDetails={pipelineDetails}
          setHeaderFields={setHeaderFields}
        />
        <PipelineLibrary
          keyword={keyword}
          foundationalBlocks={foundationalBlocks}
          organizationBlocks={organizationBlocks}
          hasMoreOrgFunction={hasMoreOrgFunction}
          isPassthrough={headerFields.is_passthrough}
          deleteFunctionMutation={deleteFunctionMutation}
          deleteOrganizationBlockFromList={deleteOrganizationBlockFromList}
          fetchMoreOrgFunction={fetchMoreOrgFunction}
          setKeyword={setKeyword}
          onDrag={setDragBlock}
        />
        <PipelineBlockList
          acsFields={acsFields}
          acsFieldOperations={acsFieldOperations}
          blocks={blocks}
          isPassthrough={headerFields.is_passthrough}
          dragBlock={dragBlock}
          blockValidation={blockValidation}
          startValidationSession={startValidationSession}
          enrichmentCSVList={enrichmentCSVList}
          initialBlockList={initialBlockCopy}
          onBlockValidation={setBlockValidation}
          setInitialBlockCopy={newInitialCopy =>
            setInitialBlockCopy([...newInitialCopy])
          }
          updateBlockList={newBlocks => setBlocks([...newBlocks])}
          createFunctionMutation={createFunctionMutation}
          updateFunctionMutation={updateFunctionMutation}
        />
      </div>
      <ConfirmationDialog
        open={isOpen}
        dialogType={
          ['WARNING', 'WARNING_DISCARD'].includes(confirmationDialogType)
            ? 'WARNING'
            : 'CONFIRMATION'
        }
        confirmationButtonName={dialogConfiguration.buttonName}
        confirmationHeading={dialogConfiguration.heading}
        confirmationMessage={dialogConfiguration.message}
        onConfirm={onConfirmation}
        onCancel={() =>
          setOpenSaveConfirmation(prev => ({ ...prev, isOpen: false }))
        }
      />
    </>
  );
};
