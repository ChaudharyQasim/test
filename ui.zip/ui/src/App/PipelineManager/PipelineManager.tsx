import {
  FC,
  MutableRefObject,
  useEffect,
  useMemo,
  useRef,
  useState
} from 'react';
import {
  Button,
  Divider,
  PrimaryHeading,
  Select,
  SelectOption,
  Stack
} from 'reablocks';
import { Count } from 'reaviz';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';

import { ButtonGroup } from 'shared/elements/ButtonGroup/ButtonGroup';
import { Chip } from 'shared/elements/Chip';
import { AppliedFilter } from 'shared/elements/AppliedFilter';
import { FilterPanel } from 'shared/elements/Filters';
import { SearchInput } from 'shared/form/Input/SearchInput';
import { constructQueryParams } from 'shared/utils/Helper';
import { Pager } from 'shared/data/Pager';
import { useFilterPager } from 'core/Hooks/useFilterPager';

import { PipelineListView } from './PipelineListView';
import css from './PipelineManager.module.css';

import { ReactComponent as PipelineIcon } from 'assets/icons/pipeline.svg';
import { ReactComponent as FilterIcon } from 'assets/icons/filter.svg';
import { ReactComponent as ListIcon } from 'assets/icons/list-view.svg';

import { PipelineManagerProps } from './Pipeline.types';
import { PipelineRoute } from 'App/DataConfig/PipelineManager/PipelineRoute/PipelineRoute';
import { CONFIGURATION_TYPE } from 'shared/utils/Constants';

import { useSmartFilter, SmartFilterEnum } from 'core/Hooks/useSmartFilter';

const { SOURCE, DESTINATION } = CONFIGURATION_TYPE;

const AIFilterButton = ({ isAiFilter, filterName, toggleSearchMode }) => {
  const variant = isAiFilter ? 'filled' : 'text';
  const color = isAiFilter ? 'primary' : 'default';
  const className = `${css.iconBtn} ${isAiFilter ? css.filled : css.text}`;
  return (
    <Button
      className={className}
      variant={variant}
      color={color}
      size="small"
      onClick={() => toggleSearchMode(filterName)}
    >
      {filterName}
    </Button>
  );
};

export const PipelineManager: FC<PipelineManagerProps> = ({
  pipelineListData,
  isPipelineListLoading,
  isPipelineListSuccess,
  filterOptions,
  nodes,
  edges,
  pipelineView = 'connector',
  instanceList,
  selectedVendorId,
  isLoadingPipeline,
  onViewChange,
  onAddConnection,
  onChangeVendorId,
  onDeleteConnection,
  onDeleteListRoute,
  updatePipelineFilters
}) => {
  const navigate = useNavigate();
  const pipelinePath = '/pipeline';
  const isConnectorView = pipelineView === 'connector';
  const isListView = pipelineView === 'list';
  const { keyword, setKeyword, filter, setFilter, page, setPage } =
    useFilterPager();

  // useRef
  const filterBtnRef = useRef<HTMLButtonElement | null>(null);
  const currentFilterRef = useRef<MutableRefObject<HTMLButtonElement>>(null);

  // useState
  const [openFilter, setOpenFilter] = useState<boolean>(false);
  const [abortController, setAbortController] =
    useState<AbortController | null>(new AbortController());

  // useMemo
  const constructedUrl = useMemo(
    () =>
      constructQueryParams(
        { searchValue: keyword, searchKey: 'name' },
        filter,
        page + 1
      ),
    [filter, keyword, page]
  );

  const [isAiFilter, setIsAiFilter] = useState<boolean>(false);
  const [submitJob, setSubmitJob] = useState<boolean>(false);
  const [smartFilterQuery, setSmartFilterQuery] = useState<string>('');

  const toggleSearchMode = (mode: 'Search' | 'AI Filter') => {
    setIsAiFilter(mode === 'AI Filter');
  };

  const handleSearchInputChange = event => {
    if (isAiFilter) {
      setSubmitJob(true);
      setSmartFilterQuery(event.target.value);
    } else {
      setKeyword(event.target.value);
      setPage(0);
    }
  };

  const { smartFilterState } = useSmartFilter({
    smartFilterType: SmartFilterEnum.PIPELINES,
    query: smartFilterQuery,
    submitJob: submitJob
  });

  // useEffect
  useEffect(() => {
    setSubmitJob(false);
    if (smartFilterState.data !== null) {
      setFilter(smartFilterState.data);
    }
  }, [smartFilterState.data, setFilter]);

  /**
   * @description Provides getPipelineListMutation with the constructedUrl and abortController
   * when the user makes a change to the filter options
   */
  useEffect(() => {
    updatePipelineFilters({
      constructedUrl,
      abortController
    });
  }, [updatePipelineFilters, constructedUrl, abortController]);

  const { metadata } = pipelineListData ?? {};
  /**
   * @description
   * This function is called when the user makes a change to the filter options
   * Cancels the pending requests and continues with the updated filter payloads
   * Reduces stale request payloads and content downloads when the user is making
   * multiple changes to the filter options while the request is still pending
   */
  const handleOnFilterChange = (filter: any) => {
    abortController.abort();
    setAbortController(new AbortController());
    setFilter(filter);
  };

  const sourceConfigurations = useMemo(
    () => nodes.filter(configuration => configuration.type === SOURCE),
    [nodes]
  );

  const destinationConfigurations = useMemo(
    () => nodes.filter(configuration => configuration.type === DESTINATION),
    [nodes]
  );

  const handleNavigateBack = () => {
    let path = pipelinePath;
    if (isConnectorView) {
      path += '?view=connector';
    } else if (isListView) {
      path += '?view=list';
    }
    navigate(path);
  };

  return (
    <>
      {isConnectorView && (
        <div className={css.background}>
          {isConnectorView && (
            <>
              <div className={css.sourceCol} />
              <div className={css.routeCol} />
              <div className={css.destCol} />
            </>
          )}
        </div>
      )}
      <div className={css.root}>
        <Helmet>
          <title>Pipeline Manager</title>
        </Helmet>
        <header className={css.header}>
          <Stack>
            <PrimaryHeading disableMargins>Pipeline</PrimaryHeading>
            <Chip variant="outline" color="secondary">
              <div className={css.counter}>
                <Count to={metadata?.total_count || 0} />
              </div>
            </Chip>
          </Stack>
          <div className={css.push} />
          <Stack className={css.searchFilter}>
            {isListView && (
              <Stack>
                {/* New Button Group for the AI Filter toggle */}
                <ButtonGroup>
                  <AIFilterButton
                    isAiFilter={!isAiFilter}
                    filterName="Search"
                    toggleSearchMode={toggleSearchMode}
                  />
                  <AIFilterButton
                    isAiFilter={isAiFilter}
                    filterName="AI Filter"
                    toggleSearchMode={toggleSearchMode}
                  />
                </ButtonGroup>
                {/* Search Input */}
                <SearchInput
                  placeholder={isAiFilter ? 'AI Filter' : 'Search by Name'}
                  debounce={500}
                  value={keyword}
                  onChange={handleSearchInputChange}
                />
                <Button
                  ref={filterBtnRef}
                  className={css.iconBtn}
                  variant="outline"
                  onClick={() => {
                    currentFilterRef.current = filterBtnRef;
                    setOpenFilter(!openFilter);
                  }}
                >
                  <FilterIcon />
                  Filters
                </Button>
              </Stack>
            )}
            {isConnectorView && (
              <Select
                placeholder="Select an instance"
                className={css.instanceSelector}
                value={selectedVendorId}
                clearable={false}
                onChange={onChangeVendorId}
              >
                {instanceList.map(vendor => (
                  <SelectOption key={vendor.nanoid} value={vendor.nanoid}>
                    {vendor.name}
                  </SelectOption>
                ))}
              </Select>
            )}
            <Divider orientation="vertical" className={css.divider} />
          </Stack>
          <Stack>
            <ButtonGroup>
              <Button
                className={css.iconBtn}
                variant={isConnectorView ? 'filled' : 'text'}
                color={isConnectorView ? 'primary' : 'default'}
                size="small"
                onClick={() => onViewChange('connector')}
              >
                <PipelineIcon />
                Data Routes
              </Button>
              <Button
                className={css.iconBtn}
                variant={isListView ? 'filled' : 'text'}
                color={isListView ? 'primary' : 'default'}
                size="small"
                onClick={() => onViewChange('list')}
              >
                <ListIcon />
                Pipeline List
              </Button>
            </ButtonGroup>
          </Stack>
        </header>
        {isListView && (
          <AppliedFilter
            reference={currentFilterRef.current}
            filter={filter}
            filterOptions={filterOptions}
            addFilter={addDropdown => {
              currentFilterRef.current = addDropdown;
              setOpenFilter(!openFilter);
            }}
            setFilter={handleOnFilterChange}
          />
        )}

        {isConnectorView && (
          <PipelineRoute
            sourceConfigurations={sourceConfigurations}
            destinationConfigurations={destinationConfigurations}
            selectedVendorId={selectedVendorId}
            isLoadingPipeline={isLoadingPipeline}
            routes={edges}
            onAddConnection={onAddConnection}
            onEditConnection={routeId =>
              navigate(
                `${pipelinePath}/details/${routeId}?pipelineView=connector`
              )
            }
            onDeleteConnection={onDeleteConnection}
          />
        )}
        {isListView && (
          <>
            <PipelineListView
              pipelineListData={pipelineListData}
              isPipelineListLoading={isPipelineListLoading}
              isPipelineListSuccess={isPipelineListSuccess}
              filter={filter}
              onDeleteListRoute={async route_id => {
                await onDeleteListRoute(route_id);
                updatePipelineFilters({ constructedUrl, abortController });
              }}
              setFilter={setFilter}
            />
            {metadata?.total_count > metadata?.page_size && (
              <Pager
                total={metadata?.total_count}
                page={page}
                size={metadata?.page_size}
                onPageChange={(page: number) => setPage(page)}
              />
            )}
          </>
        )}
      </div>
      <FilterPanel
        reference={currentFilterRef.current}
        open={openFilter}
        onClose={() => {
          setOpenFilter(false);
          currentFilterRef.current = null;
        }}
        filter={filter}
        filters={filterOptions}
        onFilterChange={handleOnFilterChange}
      />
    </>
  );
};
