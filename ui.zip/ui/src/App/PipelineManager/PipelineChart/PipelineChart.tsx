import { FC } from 'react';
import {
  Bar,
  ChartNestedDataShape,
  ChartTooltip,
  Gridline,
  GridlineSeries,
  LinearXAxis,
  LinearXAxisTickSeries,
  LinearYAxis,
  LinearYAxisTickSeries,
  StackedBarChart,
  StackedBarSeries,
  TooltipArea,
  TooltipTemplate
} from 'reaviz';
import { DateFormat, formatSize, useTheme } from 'reablocks';
import { DATE_FORMAT } from 'shared/utils/Constants';
import { binaryScale } from 'shared/utils/Constants/data';

interface PipelineChartProps {
  data: ChartNestedDataShape[];
}

export const PipelineChart: FC<PipelineChartProps> = ({ data }) => {
  const theme = useTheme();

  return (
    <StackedBarChart
      width={325}
      height={125}
      margins={0}
      data={data}
      gridlines={
        <GridlineSeries
          line={
            <Gridline
              direction="y"
              strokeDasharray="0"
              strokeColor="rgba(255, 255, 255, 0.1)"
            />
          }
        />
      }
      series={
        <StackedBarSeries
          bar={[
            <Bar key="input" rx={3} ry={3} width={4} gradient={null} />,
            <Bar key="output" rx={3} ry={3} width={4} gradient={null} />
          ]}
          type="stackedDiverging"
          colorScheme={[theme.colors.pink[100], theme.colors.blue[100]]}
          tooltip={
            <TooltipArea
              tooltip={
                <ChartTooltip
                  followCursor={true}
                  content={(series, color) => {
                    if (!series) {
                      return null;
                    }

                    const value = {
                      ...series,
                      x: <DateFormat date={series.x} format={DATE_FORMAT} />,
                      data: series.data.map(d => ({
                        ...d,
                        value: formatSize(
                          Math.abs(d.value),
                          undefined,
                          binaryScale
                        )
                      }))
                    };

                    return <TooltipTemplate color={color} value={value} />;
                  }}
                />
              }
            />
          }
        />
      }
      yAxis={
        <LinearYAxis
          roundDomains={true}
          axisLine={null}
          tickSeries={
            <LinearYAxisTickSeries line={null} label={null} width={0} />
          }
        />
      }
      xAxis={
        <LinearXAxis
          type="category"
          position="center"
          height={40}
          axisLine={null}
          tickSeries={
            <LinearXAxisTickSeries
              height={40}
              line={null}
              label={null} // Hide label for now
              // TODO: figure out how to create space for the label
              // label={
              //   <LinearXAxisTickLabel
              //     padding={5}
              //     rotation={0}
              //     format={f => format(new Date(f), 'mm')}
              //   />
              // }
            />
          }
        />
      }
    />
  );
};
