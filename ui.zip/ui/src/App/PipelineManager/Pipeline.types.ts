import {
  ConfigurationOut,
  ACSFieldType,
  CreateFunctionIn,
  FuncOperationTypeEnum,
  GetPipelineFunctions,
  GetPipelineOut,
  ListFunctionOut,
  ResponseMessage,
  RouteIn,
  RouteOut,
  UpdateFunctionIn,
  UpdatePipelineFunction,
  VendorAccountOut,
  UploadCSVOut,
  ListCSVOut,
  PipelineOut
} from 'core/Api';
import {
  FetchNextPageOptions,
  InfiniteData,
  InfiniteQueryObserverResult,
  QueryObserverResult,
  RefetchOptions,
  RefetchQueryFilters,
  UseMutateAsyncFunction,
  UseMutateFunction
} from 'react-query';
import { ChartNestedDataShape } from 'reaviz';
import { ConditionType, FieldOperations } from 'shared/elements/EventCondition';
import { FilterType } from 'shared/elements/Filters';
import { FIELD_TYPES } from 'shared/utils/Constants';

export type DataInfoType = {
  total_bytes_in: number;
  total_bytes_out: number;
  last_hour_bytes_in_rate: number;
  last_hour_bytes_out_rate: number;
};

// Todo: Remove once OpenAPI spec is available
/**
 * PipelineCategoryEnum
 * Enum for different pipeline category.
 */
export enum PipelineCategoryEnum {
  SOURCE = 'SOURCE',
  DESTINATION = 'DESTINATION',
  ROUTE = 'ROUTE'
}

/**
 * PaginationInfo
 * Response Model for Pagination Info.
 */
export interface PaginationInfo {
  /** Total Count */
  total_count: number;
  /** Page Size */
  page_size: number;
  /** Page Number */
  page_number: number;
}

/**
 * ListIntegrationOut
 * Response model for list integration.
 */
export interface ListPipelineOut {
  /** Integrations */
  pipelines: PipelineOut[];
  /** Response Model for Pagination Info. */
  metadata: PaginationInfo;
}

export type onDeleteType = {
  nodeId: string;
  category: string;
};

export interface PipelineRouteType {
  id: string;
  name: string;
  label?: string;
  pipelineLabel?: string;
  description: string;
  category: 'SOURCE' | 'ROUTE' | 'DESTINATION';
  source?: string;
  destination?: string;
  is_passthrough?: boolean;
  tags: string[];
  data: DataInfoType;
  metrics: ChartNestedDataShape[];
}

export type GetPipelineListParams = {
  constructedUrl: string;
  abortController: AbortController | null;
};

export type PipelineManagerProps = {
  pipelineListData: ListPipelineOut;
  updatePipelineFilters: ({
    constructedUrl,
    abortController
  }: GetPipelineListParams) => void;
  isPipelineListLoading: boolean;
  isPipelineListSuccess: boolean;
  filterOptions: FilterType;
  nodes: ConfigurationOut[];
  edges: RouteOut[];
  pipelineView: string;
  isLoadingPipeline: boolean;
  instanceList: VendorAccountOut[];
  selectedVendorId: string;
  onChangeVendorId: (id: string) => void;
  onViewChange: (view: string) => void;
  onAddConnection: UseMutateAsyncFunction<RouteOut, any, RouteIn, unknown>;
  onDeleteConnection: UseMutateFunction<ResponseMessage, any, string, unknown>;
  onDeleteListRoute: UseMutateAsyncFunction<any, any, string, unknown>;
};

export type PipelineListViewProps = {
  pipelineListData: ListPipelineOut;
  isPipelineListLoading: boolean;
  isPipelineListSuccess: boolean;
  filter: any;
  onDeleteListRoute: (route_id: string) => void;
  setFilter: (filter: any) => void;
};

export type PipelineRowProps = {
  row: PipelineOut;
  filter: any;
  onDeleteListRoute: (route_id: string) => void;
  setFilter: (filter: any) => void;
};

export type RowActionsProps = {
  row: PipelineOut;
  onDeleteListRoute: (route_id: string) => void;
};

export type PipelinePaginatorProps = {
  metadata: PaginationInfo;
  page: number;
  setPage: (page: number) => void;
};

type PipelineEditQueriesType = {
  pipelineDetails: GetPipelineOut;
  acsFields: ACSFieldType[];
  acsFieldOperations: FieldOperations;
  foundationalBlocks: GetPipelineFunctions[];
  organizationBlocks: InfiniteData<GetPipelineFunctions[]>;
  hasMoreOrgFunction: boolean;
  enrichmentCSVList: UploadCSVOut[];
  refetchEnrichmentList: <TPageData>(
    options?: RefetchOptions & RefetchQueryFilters<TPageData>
  ) => Promise<QueryObserverResult<ListCSVOut, unknown>>;
  createFunctionMutation: UseMutateAsyncFunction<
    any,
    any,
    CreateFunctionIn,
    unknown
  >;
  updateFunctionMutation: UseMutateAsyncFunction<
    UpdateFunctionIn,
    any,
    {
      functionId: string;
      customFunction: UpdateFunctionIn;
    },
    unknown
  >;
  refetchPipelineDetails: <TPageData>(
    options?: RefetchOptions & RefetchQueryFilters<TPageData>
  ) => Promise<QueryObserverResult<GetPipelineOut, any>>;
  savePipelineDetailsAsyncMutation: UseMutateAsyncFunction<
    SavePipelineDetails,
    any,
    {
      payload: any;
    },
    unknown
  >;
  deleteFunctionMutation: UseMutateAsyncFunction<
    DeleteFunctionType,
    any,
    {
      id: string;
      isForceDelete: boolean;
      csv_file_id?: string;
    },
    unknown
  >;
  fetchMoreOrgFunction: (
    options?: FetchNextPageOptions
  ) => Promise<InfiniteQueryObserverResult<GetPipelineFunctions[], any>>;
};

export type DragTypeParams = {
  type: string;
  draggedBlock: GetPipelineFunctions;
};

export type PipelineLibraryProps = Pick<
  PipelineEditQueriesType,
  | 'organizationBlocks'
  | 'hasMoreOrgFunction'
  | 'deleteFunctionMutation'
  | 'foundationalBlocks'
  | 'fetchMoreOrgFunction'
> & {
  isPassthrough: boolean;
  keyword: string;
  deleteOrganizationBlockFromList: (id: string) => void;
  setKeyword: (keyword: string) => void;
  onDrag: (block: DragTypeParams) => void;
};

export type PipelineHeaderState = {
  name: string;
  description: string;
  is_passthrough: boolean;
  tags: string[];
};

export type PipelineHeaderProps = {
  headerFields: PipelineHeaderState;
  pipelineDetails: GetPipelineOut;
  setHeaderFields: React.Dispatch<React.SetStateAction<PipelineHeaderState>>;
};

export interface PipelineEditProps extends PipelineEditQueriesType {
  isSavePipelineDetailsLoading: boolean;
}

export type BlockValidationType = {
  [key: string]: boolean;
};

export type PipelineBlockListProps = {
  acsFields: ACSFieldType[];
  acsFieldOperations: FieldOperations;
  blocks: UpdatePipelineFunction[];
  initialBlockList: UpdatePipelineFunction[];
  isPassthrough: boolean;
  dragBlock: DragTypeParams;
  startValidationSession: boolean;
  blockValidation: BlockValidationType;
  enrichmentCSVList: UploadCSVOut[];
  onBlockValidation: (updatedValidation: BlockValidationType) => void;
  createFunctionMutation: UseMutateAsyncFunction<
    any,
    any,
    CreateFunctionIn,
    unknown
  >;
  setInitialBlockCopy: (newInitialBlock: UpdatePipelineFunction[]) => void;
  updateFunctionMutation: UseMutateAsyncFunction<
    UpdateFunctionIn,
    any,
    {
      functionId: string;
      customFunction: UpdateFunctionIn;
    },
    unknown
  >;
  updateBlockList: (blocks: UpdatePipelineFunction[]) => void;
};

export type BlockPropType = {
  acsFields: ACSFieldType[];
  acsFieldOperations: FieldOperations;
  enrichmentCSVList: UploadCSVOut[];
  onBlockUpdate: (blockJson: any) => void;
  createDuplicateBlock: () => void;
  syncLocalBlocksWithOrg: () => void;
  deleteBlock: () => void;
  blockDetails: UpdatePipelineFunction;
  initialBlockCopy: UpdatePipelineFunction;
  startValidationSession: boolean;
  blockValidation: BlockValidationType;
  onBlockValidation: (updatedValidation: BlockValidationType) => void;
  isPassthrough: boolean;
  addToOrganizationBlock: () => void;
  updateFunctionMutation: UseMutateAsyncFunction<
    UpdateFunctionIn,
    any,
    {
      functionId: string;
      customFunction: UpdateFunctionIn;
    },
    unknown
  >;
};

export type DeleteFunctionType = {
  message: string;
  pipeline_list: string[];
};

export type SavePipelineDetails = {
  message: string;
};

export type PipelineLibraryBlockType = {
  blockLabel: string;
  isDraggable: boolean;
  blockItemLoader?: { [key: string]: boolean };
  blocks: GetPipelineFunctions[];
  hasMoreOrgFunction?: boolean;
  fetchMoreFunction?: (
    options?: FetchNextPageOptions
  ) => Promise<InfiniteQueryObserverResult<GetPipelineFunctions[], any>>;
  onDrag?: (block: GetPipelineFunctions) => void;
  onDelete?: ({ id, csv_file_id }) => void;
};

type FoundationalConfig = AggregationConfig | DropKeysConfig | ReplaceConfig;

type AggregationConfig = {
  field_operation: FuncOperationTypeEnum.AGGREGATION;
  fields: string[];
};

type DropKeysConfig = {
  field_operation: 'DROP_KEYS';
  fields: string[];
};

type ReplaceConfig = {
  field_operation: 'REPLACE';
  fields: string[];
  find: string;
  value: string;
};

type FoundationalBlockProps = {
  config?: FoundationalConfig;
  groups?: any[];
};

export interface ListFoundationalFunctionType extends ListFunctionOut {
  block: FoundationalBlockProps;
  priority: number;
  is_shared: boolean;
}

export type FieldResponseTypes = {
  field: string;
  data_type: FIELD_TYPES;
  type: 'acs';
};

export type AggregationOperation = 'COUNT' | 'SUM' | 'AVERAGE' | 'MIN' | 'MAX';

export type Aggregation = {
  field: string;
  field_operation: AggregationOperation;
};

export type ConfigBlockJson = {
  operator?: 'and' | 'or';
  conditions?: ConditionType[];
  groups?: ConditionType[];
};

export type AggregateBlockJson = {
  config: {
    fields: string[];
    aggregations: Aggregation[];
    windowMinutes: number;
  };
  groups?: [ConfigBlockJson];
};

export type ReplaceBlockJson = {
  config: {
    find: string;
    value: string;
    fields: string[];
    field_operation: string;
    caseSensitive: boolean;
    regex: boolean;
  };
  groups?: null | [ConfigBlockJson];
};

export type DropKeyBlockJson = {
  config: {
    fields: string[];
    field_operation: string;
  };
  groups?: [ConfigBlockJson];
};

export type EnrichmentBlockJson = {
  config: {
    field: string;
    field_operation: string;
  };
  groups?: [ConfigBlockJson];
};

type BlockCommonPropsType<T> = {
  acsFields: ACSFieldType[];
  acsFieldOperations: FieldOperations;
  snapshot?: ConditionType[];
  isEditMode?: boolean;
  isInValidBlock?: boolean;
  block: T;
  onBlockUpdate: ({
    blockJson,
    snapshot,
    current_csv
  }: {
    blockJson: T;
    snapshot?: ConditionType[];
    current_csv?: string;
  }) => void;
};

export type AggregateBlockProp = BlockCommonPropsType<AggregateBlockJson>;
export type EnrichmentBlockProp = BlockCommonPropsType<EnrichmentBlockJson> & {
  enrichmentCSVList: UploadCSVOut[];
  current_csv: string;
};
export type ConfigBlockProp = BlockCommonPropsType<ConfigBlockJson>;
export type ReplaceBlockProp = BlockCommonPropsType<ReplaceBlockJson>;
export type DropKeyBlockProp = BlockCommonPropsType<DropKeyBlockJson>;

export type BlockType = {
  block:
    | AggregateBlockJson
    | ConfigBlockJson
    | DropKeyBlockJson
    | EnrichmentBlockJson
    | ReplaceBlockJson;
  snapshot?: [];
  current_csv?: string;
};

export type BlockWithType<T> = {
  block: T;
  snapshot?: ConditionType;
  current_csv?: string;
};

export type AggregateBlockType = BlockWithType<AggregateBlockJson>;
export type ConfigBlockType = BlockWithType<ConfigBlockJson>;
export type DropKeyBlockType = BlockWithType<DropKeyBlockJson>;
export type EnrichmentBlockType = BlockWithType<EnrichmentBlockJson>;
export type ReplaceBlockType = BlockWithType<ReplaceBlockJson>;
