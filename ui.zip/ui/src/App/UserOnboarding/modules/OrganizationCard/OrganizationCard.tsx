import { FC } from 'react';
import { Button } from 'reablocks';

// CSS
import css from './OrganizationCard.module.css';

// Types
type OrganizationCardProps = {
  name: string;
  type: 'Accept' | 'Join';
  onChange?: (e: React.MouseEvent<HTMLButtonElement>) => void;
};

export const OrganizationCard: FC<OrganizationCardProps> = ({
  name,
  type,
  onChange
}) => (
  <div className={css.organizationCard}>
    <span>{name}</span>
    <Button variant="filled" color="primary" onClick={onChange}>
      {type}
    </Button>
  </div>
);
