import { FC } from 'react';
import {
  Block,
  Button,
  Divider,
  Input,
  MotionGroup,
  MotionItem,
  PageTitle,
  Textarea
} from 'reablocks';

// Form lib validation
import * as Yup from 'yup';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

// CSS
import css from './CreateOrganization.module.css';

// Types
type CreateOrganizationProps = {
  onSubmit: (data: { name: string; domains: string[] }) => Promise<void>;
  onJoinOrganization: () => void;
};

const credentialsSchema = Yup.object().shape({
  name: Yup.string().required('Required'),
  domains: Yup.string()
});

export const CreateOrganization: FC<CreateOrganizationProps> = ({
  onSubmit,
  onJoinOrganization
}) => {
  const {
    control,
    handleSubmit,
    reset,
    formState: { isSubmitting, isValid },
    getValues
  } = useForm({
    mode: 'onChange',
    reValidateMode: 'onChange',
    resolver: yupResolver(credentialsSchema),
    defaultValues: {
      name: '',
      domains: ''
    }
  });
  return (
    <>
      <MotionGroup className={css.container}>
        <MotionItem className={css.organizations}>
          <header className={css.organizationHeader}>
            <PageTitle disableMargins className={css.organizationTitle}>
              Create a new organization
            </PageTitle>
          </header>
        </MotionItem>
        <MotionItem className={css.organizations}>
          <form
            onSubmit={handleSubmit(async () => {
              await onSubmit({
                name: getValues('name'),
                domains: getValues('domains').split(',')
              });
              reset();
            })}
            className={css.container}
          >
            <Block label="Organization name">
              <Controller
                name="name"
                control={control}
                render={({ field: { value, onBlur, onChange } }) => (
                  <Input
                    name="name"
                    type="text"
                    autoFocus
                    value={value}
                    onChange={onChange}
                    onBlur={onBlur}
                    placeholder="Abstract"
                  />
                )}
              />
            </Block>
            <Block label="Invite co-workers to your organization">
              <Controller
                name="domains"
                control={control}
                render={({ field: { value, onBlur, onChange } }) => (
                  <Textarea
                    name="domains"
                    fullWidth
                    minRows={4}
                    value={value}
                    onChange={onChange}
                    onBlur={onBlur}
                    placeholder="email@example.com, email2@example.com..."
                  />
                )}
              />
            </Block>
            <Button
              className={css.createButton}
              fullWidth
              variant="filled"
              color="primary"
              disabled={!isValid || isSubmitting}
              type="submit"
            >
              {isSubmitting ? 'Creating' : 'Create'}
            </Button>
          </form>
          <Divider />
          <Button
            fullWidth
            variant="text"
            color="primary"
            onClick={onJoinOrganization}
          >
            Join an existing organization instead
          </Button>
        </MotionItem>
      </MotionGroup>
    </>
  );
};
