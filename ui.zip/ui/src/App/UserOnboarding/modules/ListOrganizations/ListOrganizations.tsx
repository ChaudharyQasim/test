import { FC } from 'react';

// Modules
import { OrganizationCard } from '../OrganizationCard';

// CSS
import css from './ListOrganizations.module.css';

// Core
import { AcceptInvitation } from 'core/Api';

// Types
type OrganizationType = {
  id: number;
  name: string;
  token?: AcceptInvitation;
};
type ListOrganizationsProps = {
  organizationList: OrganizationType[];
  onChange: (organization: OrganizationType) => void;
  fallBackMessage: string | React.ReactNode;
  type: 'Accept' | 'Join';
};

export const ListOrganizations: FC<ListOrganizationsProps> = ({
  organizationList,
  onChange,
  fallBackMessage,
  type
}) => {
  return (
    <div className={css.cardContainer}>
      {organizationList.length > 0 ? (
        organizationList.map(organization => (
          <OrganizationCard
            key={organization.id}
            name={organization.name}
            onChange={() => onChange(organization)}
            type={type}
          />
        ))
      ) : (
        <div className={css.tagline}>{fallBackMessage}</div>
      )}
    </div>
  );
};
