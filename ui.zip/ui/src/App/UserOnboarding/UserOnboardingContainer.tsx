import { FC, useCallback, useEffect, useMemo } from 'react';
import { Navigate } from 'react-router-dom';
import { useNotification } from 'reablocks';

import { useMutation, useQuery, useQueryClient } from 'react-query';

import { UserOnboarding } from './UserOnboarding';

// Components
import { Loader } from 'shared/elements/Loader';

// Hooks
import { useAuth } from 'core/Auth';

// API Service
import {
  getOrganizationInvitations,
  postCreateOrganization,
  postBulkInvitations,
  updateAcceptOrgInvitation,
  CreateOrganizationType
} from 'core/Api/OrganizationApi';

// Core
import { useOrganization } from 'core/Organization';
import { useQueryParams } from 'core/Hooks/useQueryParams';
import { AcceptInvitation } from 'core/Api';

// Shared
import { errorHandler } from 'shared/utils/Helper';

export const UserOnboardingContainer: FC = () => {
  const { user, isLoading } = useAuth();
  const { organizationList, fetchOrganizationList, fetchCurrentOrganization } =
    useOrganization();

  const { create_organization, org, invitee, token } = useQueryParams();

  const { notifySuccess, notifyError } = useNotification();

  const queryClient = useQueryClient();

  const hasInvitation = org && invitee && token;

  const { data: invitationList, isLoading: isInvitationListLoading } = useQuery(
    'invitationList',
    getOrganizationInvitations
  );

  const { mutate: joinOrganizationMutation, isLoading: isJoinOrgLoading } =
    useMutation(
      (organization_id: number) => {
        return fetchCurrentOrganization(organization_id);
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries('organizationList');
        },
        onError: error => {
          notifyError(errorHandler(error));
        }
      }
    );

  const {
    mutate: acceptInvitationMutation,
    isLoading: isAcceptInvitationLoading
  } = useMutation(
    (data: { token: AcceptInvitation; organization_id: number }) => {
      return updateAcceptOrgInvitation({
        patchData: {
          token: data.token
        }
      });
    },
    {
      onError: error => {
        notifyError(errorHandler(error));
      },
      onSuccess: (data, vairables) => {
        queryClient.invalidateQueries('invitationList');
        joinOrganizationMutation(vairables.organization_id);
      }
    }
  );

  /**
   * @description This function is used to get the unique emails from the list of invitations
   * to send bulk invitations
   */
  function getEmailFromInvites(invitationEmails: string[]): string[] {
    const emails = invitationEmails
      .map((invitation: string) => {
        const match = invitation.match(/@(\S+)/);
        const domain = match ? match[1] : null;
        return domain;
      })
      .filter((email: string) => email !== null);
    const setEmails = Array.from(new Set(emails));
    const uniqueEmails = [...setEmails];
    return uniqueEmails;
  }

  const createOrganization = useCallback(
    async ({ name, domains }: CreateOrganizationType) => {
      try {
        // Domains are the list of emails from the invited users and the current user
        const orgResponse = await postCreateOrganization({
          name,
          domains: getEmailFromInvites([...domains, user.email])
        });
        const cleanedInvitations = domains.filter(
          (email: string) => email !== ''
        );

        // This condition is used to check if the organization already exists
        if (orgResponse?.detail) {
          notifyError(`${name} organization already exists`);
          return;
        }

        // Fetch the organization list after creating the organization
        await fetchOrganizationList();

        if (cleanedInvitations.length > 0) {
          // Mapping the emails to send bulk invitations
          // Clean the emails and remove the empty strings
          const mappingEmail = cleanedInvitations.map((email: string) => {
            const cleanEmail = email.trim();
            return {
              email: cleanEmail
            };
          });
          await postBulkInvitations({
            organization_id: orgResponse.id,
            emails: mappingEmail
          });
        }

        joinOrganizationMutation(orgResponse.id);

        notifySuccess(`${name} Organization created successfully`);
      } catch (error) {
        notifyError(errorHandler(error));
      }
    },
    [
      fetchOrganizationList,
      notifySuccess,
      notifyError,
      user,
      joinOrganizationMutation
    ]
  );

  const listOrganization = useMemo(() => {
    if (!organizationList) {
      return [];
    }
    return organizationList;
  }, [organizationList]);

  useEffect(() => {
    if (token) {
      acceptInvitationMutation({
        token: token as unknown as AcceptInvitation,
        organization_id: parseInt(org)
      });
    }
  }, [token, org, acceptInvitationMutation]);

  if (
    isLoading ||
    isInvitationListLoading ||
    isAcceptInvitationLoading ||
    isJoinOrgLoading
  ) {
    return <Loader />;
  }

  if (
    user.current_organization.name !== 'default' &&
    !create_organization &&
    !hasInvitation
  ) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <UserOnboarding
      invitationList={invitationList}
      isInvitationLoading={isInvitationListLoading}
      organizationList={listOrganization}
      acceptInvitation={acceptInvitationMutation}
      joinOrganization={joinOrganizationMutation}
      createOrganization={createOrganization}
    />
  );
};
