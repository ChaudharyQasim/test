import {
  Button,
  Divider,
  MotionGroup,
  MotionItem,
  PageTitle,
  SmallHeading
} from 'reablocks';
import { useNavigate } from 'react-router-dom';
import { FC, useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Tab, TabList, TabPanel, Tabs } from 'shared/layout/Tabs';

// Modules
import { CreateOrganization } from './modules/CreateOrganization';
import { ListOrganizations } from './modules/ListOrganizations';

// Icons
import { ReactComponent as LogoIcon } from 'assets/brand/logo-color.svg';
import { ReactComponent as ChevronDown } from 'assets/icons/chevron-down.svg';

// CSS
import css from './UserOnboarding.module.css';

// Hooks
import { useQueryParams } from 'core/Hooks/useQueryParams';

// Types
import {
  CreateOrganizationType,
  InvitationsType,
  UserOrganizationType
} from 'core/Api/OrganizationApi';
import { useAuth } from 'core/Auth';
import { AcceptInvitation } from 'core/Api';
import { Loader } from '../../shared/elements/Loader';

type UserOnboardingProps = {
  invitationList: InvitationsType[];
  isInvitationLoading: boolean;
  organizationList: UserOrganizationType[];
  joinOrganization?: (org_id: number) => void;
  acceptInvitation?: (data: {
    token: AcceptInvitation;
    organization_id: number;
  }) => void;
  createOrganization?: (organization: CreateOrganizationType) => Promise<void>;
};

const EXISTING_ORG_TEXT = 'Join an existing organization';
const INVITATION_ORG_TEXT = 'Accept an invitation to an organization';

export const UserOnboarding: FC<UserOnboardingProps> = ({
  invitationList,
  isInvitationLoading,
  organizationList,
  joinOrganization,
  acceptInvitation,
  createOrganization
}) => {
  const [showCreateOrganization, setShowOrganization] =
    useState<boolean>(false);
  const [selectedTab, setSelectedTab] = useState<number>(0);

  const { create_organization } = useQueryParams();

  const { logout, isLoggingOut } = useAuth();

  const navigate = useNavigate();

  /**
   * @description Format invitations to be used in the ListOrganizations component
   */
  const formatInvitations = useMemo(() => {
    return invitationList.map(invitation => ({
      id: invitation.organization_id,
      name: invitation.organization_name,
      token: invitation.token
    }));
  }, [invitationList]);

  function onToggleOrganizationAction() {
    setShowOrganization(!showCreateOrganization);
  }

  async function onSubmitOrganization({ name, domains }) {
    await createOrganization({
      name,
      domains
    });
    setSelectedTab(1);
  }

  function goBack() {
    navigate(-1);
  }

  useEffect(() => {
    const hasNoInvitations =
      invitationList.length === 0 && !isInvitationLoading;
    if (hasNoInvitations && organizationList.length > 0) {
      // Select existing organization tab if there are no invitations
      // and there are existing organizations
      setSelectedTab(1);
    }

    // This will show up the create organization form
    // if user comes from the create organization settings button
    if (create_organization) {
      setShowOrganization(true);
    }
  }, [
    invitationList,
    organizationList,
    isInvitationLoading,
    create_organization
  ]);

  return (
    <>
      <Helmet>
        <title>User Onboarding</title>
      </Helmet>

      <header className={css.mainHeader}>
        {create_organization ? (
          <Button variant="outline" className={css.goback} onClick={goBack}>
            <ChevronDown className={css.icon} />
            Go back
          </Button>
        ) : (
          <Button
            disabled={isLoggingOut}
            variant="outline"
            className={css.goback}
            onClick={logout}
          >
            {isLoggingOut ? 'Logging out...' : 'Log out'}
          </Button>
        )}
      </header>

      {isLoggingOut ? (
        <Loader />
      ) : (
        <div className={css.root}>
          <MotionGroup>
            {!create_organization && (
              <MotionItem className={css.header}>
                <LogoIcon className={css.logo} />
              </MotionItem>
            )}
            {!showCreateOrganization && (
              <div className={css.content}>
                <MotionGroup className={css.box}>
                  <MotionItem className={css.organizations}>
                    <header className={css.organizationHeader}>
                      <PageTitle
                        disableMargins
                        className={css.organizationTitle}
                      >
                        Organizations
                      </PageTitle>
                      <SmallHeading className={css.tagline}>
                        {selectedTab === 1
                          ? EXISTING_ORG_TEXT
                          : INVITATION_ORG_TEXT}
                      </SmallHeading>
                    </header>
                  </MotionItem>
                  <MotionItem className={css.organizations}>
                    <Tabs
                      onSelect={(selected: number) => {
                        setSelectedTab(selected);
                      }}
                      selectedIndex={selectedTab}
                      className={css.tabsContainer}
                    >
                      <TabList>
                        <Tab>Invitations</Tab>
                        <Tab>Existing organizations</Tab>
                      </TabList>
                      <TabPanel>
                        <ListOrganizations
                          organizationList={formatInvitations}
                          onChange={organization => {
                            acceptInvitation({
                              token: organization.token,
                              organization_id: organization.id
                            });
                            setSelectedTab(1);
                          }}
                          fallBackMessage="No invitations yet."
                          type="Accept"
                        />
                      </TabPanel>
                      <TabPanel>
                        <ListOrganizations
                          organizationList={organizationList}
                          onChange={organization =>
                            joinOrganization(organization.id)
                          }
                          fallBackMessage="No organizations yet."
                          type="Join"
                        />
                      </TabPanel>
                    </Tabs>
                    <span className={css.or}>
                      <Divider />
                      <span className={css.text}>OR</span>
                    </span>
                    <Button
                      fullWidth
                      variant="outline"
                      color="primary"
                      onClick={onToggleOrganizationAction}
                    >
                      Create a new organization
                    </Button>
                  </MotionItem>
                </MotionGroup>
              </div>
            )}
            {showCreateOrganization && (
              <div className={css.content}>
                <div className={css.box}>
                  <CreateOrganization
                    onSubmit={onSubmitOrganization}
                    onJoinOrganization={() => setShowOrganization(false)}
                  />
                </div>
              </div>
            )}
          </MotionGroup>
        </div>
      )}
    </>
  );
};
