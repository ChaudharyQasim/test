import { FC } from 'react';
import { Helmet } from 'react-helmet-async';
import {
  Block,
  Button,
  MotionGroup,
  MotionItem,
  PageTitle,
  SmallHeading,
  useNotification
} from 'reablocks';

// Form lib validation
import * as Yup from 'yup';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

// Shared Elements
import InputCode from 'shared/form/InputCode';
import { errorHandler } from 'shared/utils/Helper';

// Icons
import { ReactComponent as LogoIcon } from 'assets/brand/logo-color.svg';

// Hooks
import { useQueryParams } from 'core/Hooks/useQueryParams';

// CSS
import css from './Passcode.module.css';

const credentialsSchema = Yup.object().shape({
  passcode: Yup.string().required('Required')
});

// Types
type PasscodeProps = {
  onResentPasscode: () => Promise<void>;
  onSubmitLogin: (passcode: string) => Promise<void>;
};

export const Passcode: FC<PasscodeProps> = ({
  onResentPasscode,
  onSubmitLogin
}) => {
  const { email } = useQueryParams();

  const { notifyError } = useNotification();

  const {
    control,
    handleSubmit,
    formState: { isSubmitting, isValid },
    getValues
  } = useForm({
    mode: 'onChange',
    reValidateMode: 'onChange',
    resolver: yupResolver(credentialsSchema),
    defaultValues: {
      passcode: ''
    }
  });

  /**
   * @description We validate if the user is signing up or logging in
   * if the user is signing up we call the onSignUpConfirmation function
   * if the user is logging in we call the onSubmitLogin function
   */
  async function onSubmit() {
    const passcode = getValues('passcode');
    try {
      await onSubmitLogin(passcode);
    } catch (error: any) {
      notifyError(errorHandler(error));
    }
  }

  return (
    <>
      <Helmet>
        <title>Verification code</title>
      </Helmet>
      <div className={css.root}>
        <MotionGroup>
          <MotionItem className={css.header}>
            <LogoIcon className={css.logo} />
          </MotionItem>
          <div className={css.content}>
            <MotionGroup className={css.box}>
              <MotionItem className={css.login}>
                <header className={css.loginHeader}>
                  <PageTitle disableMargins className={css.loginTitle}>
                    Passcode Verification
                  </PageTitle>
                  <SmallHeading className={css.tagline}>
                    We sent a 6-digit code to{' '}
                    <strong className={css.email}>
                      {email || 'not available'}
                    </strong>
                  </SmallHeading>
                </header>
                <form onSubmit={handleSubmit(onSubmit)}>
                  <Block>
                    <Controller
                      name="passcode"
                      control={control}
                      render={({ field: { onChange } }) => (
                        <InputCode
                          length={6}
                          loading={false}
                          onComplete={onChange}
                        />
                      )}
                    />
                  </Block>
                  <br />
                  <Button
                    type="submit"
                    fullWidth
                    variant="filled"
                    color="primary"
                    disabled={isSubmitting || !isValid}
                  >
                    {isSubmitting ? 'Verifying...' : 'Verify'}
                  </Button>
                </form>
              </MotionItem>
              <br />
              <MotionItem className={css.login}>
                <SmallHeading className={css.tagline}>
                  Didn&rsquo;t receive the email?{' '}
                  <Button
                    variant="text"
                    color="primary"
                    disableMargins
                    disablePadding
                    onClick={onResentPasscode}
                  >
                    Resend
                  </Button>
                </SmallHeading>
              </MotionItem>
            </MotionGroup>
          </div>
        </MotionGroup>
      </div>
    </>
  );
};
