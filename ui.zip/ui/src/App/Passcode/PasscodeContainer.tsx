import { FC, useCallback } from 'react';
import { Navigate } from 'react-router-dom';
import { Passcode } from './Passcode';

import { useNotification } from 'reablocks';

// API Service
import { postLogin, postVerifyPasscode } from 'core/Api/AuthApi';

// Hooks
import { useQueryParams } from 'core/Hooks/useQueryParams';
import { useAuth } from 'core/Auth';

// Utils
import { errorHandler } from 'shared/utils/Helper';

export const PasscodeContainer: FC = () => {
  const { isAuthenticated, login } = useAuth();
  const { email } = useQueryParams();

  const decodedEmail = decodeURIComponent(email);

  const { notifySuccess, notifyError } = useNotification();

  /**
   * @description This function is used to login the user with the passcode
   * sent to the email
   */
  async function onSubmitLogin(passcode: string) {
    try {
      const formData = {
        code: passcode
      };
      await postVerifyPasscode(formData);
      login({
        type: 'frontEgg'
      });
    } catch (error: any) {
      notifyError(errorHandler(error));
    }
  }

  /**
   * @description This function is used to resend the passcode
   */
  const onResentPasscode = useCallback(async () => {
    try {
      await postLogin({
        email: decodedEmail
      });
      notifySuccess('Passcode resent');
    } catch (error: any) {
      notifyError(errorHandler(error));
    }
  }, [email, notifyError, notifySuccess]);

  if (isAuthenticated) {
    return <Navigate to="/" />;
  }

  return (
    <Passcode
      onResentPasscode={onResentPasscode}
      onSubmitLogin={onSubmitLogin}
    />
  );
};
