import { FC, useCallback, useMemo, useState } from 'react';
import { SortDirection, Stack, VerticalSpacer } from 'reablocks';
import { UseMutateAsyncFunction, UseMutateFunction } from 'react-query';

import { EventsContainer } from 'App/Views/Events';
import { View } from 'App/Views/ViewRow/ViewRow';

// core
import { useFilterPager } from 'core/Hooks/useFilterPager';

// Shared
import { ConditionType, FieldOperations } from 'shared/elements/EventCondition';
import { createConfigBlockPayload } from 'shared/utils/Helper/blockPayloadHelper';
import { Loader } from 'shared/elements/Loader';

// Types
import {
  ACSFieldType,
  Condition,
  ConditionGroup,
  ConditionOperatorEnum,
  Events as EventType,
  FieldEnum,
  GetEvents,
  GetEventsTimeline,
  VendorAccountOut
} from 'core/Api';
import {
  StreamViewFormattedGraphData,
  FormattedTableData,
  StreamViewGraphType
} from '../View.type';
import { formatGraphPayload } from 'shared/utils/Helper';
import { DEFAULT_COLUMNS } from 'App/Rules/constants';
import classNames from 'classnames';
import css from './ViewTab.module.css';
import { EVENT_TIME_TYPES } from 'shared/elements/EventTime/utils';

export type ViewTabProps = {
  view?: View;
  tableData: FormattedTableData;
  isEditable?: boolean;
  graphData: StreamViewFormattedGraphData[];
  selectedVendorAccount: VendorAccountOut;
  acsFields: ACSFieldType[];
  acsFieldOperations: FieldOperations;
  isLoadingStreamViewData: boolean;
  fieldSelector: { [key: string]: string[] };
  tableDataWithQueryMutation: UseMutateAsyncFunction<
    EventType,
    unknown,
    GetEvents,
    unknown
  >;
  graphDataWithQueryMutation: UseMutateFunction<
    StreamViewGraphType[],
    unknown,
    GetEventsTimeline,
    unknown
  >;
};

export type StreamViewJson = {
  operator: ConditionOperatorEnum.And | ConditionOperatorEnum.Or;
  conditions?: Condition[];
  groups?: ConditionType[];
};

export const ViewTab: FC<ViewTabProps> = ({
  tableData,
  graphData,
  acsFields,
  isLoadingStreamViewData,
  acsFieldOperations,
  fieldSelector,
  selectedVendorAccount,
  tableDataWithQueryMutation,
  graphDataWithQueryMutation
}) => {
  const { filter, setFilter } = useFilterPager();

  const { start_time, end_time } = filter || {};
  const [typeValue, setTypeValue] = useState<string>(
    EVENT_TIME_TYPES.REAL_TIME.value
  );

  const [currentPage, setCurrentPage] = useState<number>(0);

  const [conditionJson, setConditionJson] = useState<ConditionGroup>(null);
  const [, setConditionsArray] = useState<ConditionType[]>([]);
  const [visibleFields, setVisibleFields] =
    useState<FieldEnum[]>(DEFAULT_COLUMNS);

  const [baseOperator, setBaseOperator] = useState<'and' | 'or'>('and');
  const [conditions, setConditions] = useState<ConditionType[]>([]);
  const [timestamp, setTimestamp] = useState<string | [string, string] | null>(
    null
  );

  // TODO: Data passed to the child components for conditions, time, events and histogram should come from the view object.
  // Currently hardcoded mock data is plugged in here so it's same for all the views

  // Grouping by 'Date' (all timestamps on a given day)
  const histogramData = useMemo(() => {
    const transformedData = graphData
      ?.map(x => ({ ...x, key: new Date(x.key) }))
      .sort((a, b) => a.key.valueOf() - b.key.valueOf());
    return transformedData;
  }, [graphData]);

  const formatPayload = useCallback(
    ({
      streamViewJson,
      pageNumber = currentPage,
      start_time,
      end_time,
      selectedFields = [...visibleFields]
    }: {
      streamViewJson: ConditionGroup;
      pageNumber?: number;
      start_time: string;
      end_time: string;
      selectedFields?: any;
    }) => {
      tableDataWithQueryMutation({
        start_time,
        end_time,
        vendor_account_id: selectedVendorAccount?.nanoid,
        condition: streamViewJson,
        page_number: Number(pageNumber) + 1,
        selected_fields: selectedFields
      });
      graphDataWithQueryMutation(
        formatGraphPayload({
          start_time,
          end_time,
          condition: streamViewJson,
          vendor_account_id: selectedVendorAccount?.nanoid
        })
      );
    },
    [
      tableDataWithQueryMutation,
      graphDataWithQueryMutation,
      selectedVendorAccount,
      currentPage,
      visibleFields
    ]
  );

  const updateEventsData = useCallback(
    (
      conditions: ConditionType[],
      baseOperator: 'and' | 'or',
      timestamp: string | [string, string] | null,
      selectedFields?: string[] | null
    ) => {
      const currentIsoTime = new Date().toISOString();
      const streamViewJson = createConfigBlockPayload(
        conditions,
        baseOperator,
        true
      );

      setCurrentPage(0);

      const start_time = Array.isArray(timestamp) ? timestamp[0] : timestamp;
      const end_time = Array.isArray(timestamp) ? timestamp[1] : currentIsoTime;

      setFilter({
        start_time,
        end_time
      });

      setConditionJson(streamViewJson as ConditionGroup);
      setConditionsArray(conditions);

      formatPayload({
        streamViewJson: streamViewJson as ConditionGroup,
        start_time,
        end_time,
        pageNumber: 0,
        selectedFields
      });
    },
    [setFilter, setConditionJson, setConditionsArray, formatPayload]
  );

  const onSortChange = useCallback(
    (sortDirection: SortDirection, columnName: string) => {
      console.log(
        `column name is ${columnName} and direction is ${sortDirection}`
      );
    },
    []
  );

  const renderEditableView = useCallback(
    () => (
      <>
        {isLoadingStreamViewData && <Loader />}

        <Stack
          direction="column"
          className={classNames([
            isLoadingStreamViewData ? css.hideLoader : css.showLoader
          ])}
        >
          <EventsContainer
            data={tableData}
            histogramData={histogramData}
            acsFields={acsFields}
            fieldSelector={fieldSelector}
            onPageChange={(pageNumber: number) => {
              setCurrentPage(pageNumber);
              formatPayload({
                streamViewJson: conditionJson,
                start_time,
                end_time,
                pageNumber
              });
            }}
            fields={visibleFields}
            onFieldChange={setVisibleFields}
            onSortChange={onSortChange}
            selectedVendorAccount={selectedVendorAccount}
            acsFieldOperations={acsFieldOperations}
            updateEventsData={updateEventsData}
            baseOperator={baseOperator}
            setBaseOperator={setBaseOperator}
            conditions={conditions}
            setConditions={setConditions}
            timestamp={timestamp}
            setTimestamp={setTimestamp}
            typeValue={typeValue}
            setTypeValue={setTypeValue}
            isLoadingStreamViewData={isLoadingStreamViewData}
          />
        </Stack>
      </>
    ),
    [
      isLoadingStreamViewData,
      tableData,
      histogramData,
      acsFields,
      fieldSelector,
      visibleFields,
      onSortChange,
      selectedVendorAccount,
      acsFieldOperations,
      updateEventsData,
      baseOperator,
      conditions,
      timestamp,
      typeValue,
      formatPayload,
      conditionJson,
      start_time,
      end_time
    ]
  );

  return renderEditableView();
};
