import { View } from '../ViewRow/ViewRow';

export const mockViewsData: View[] = [
  {
    id: '1',
    name: 'Suspicious Login',
    createdBy: 'Diogo Brax',
    createdOn: '2022-06-14T21:55:12Z',
    lastOpenedOn: '2022-06-14T21:55:12Z'
  },
  {
    id: '2',
    name: "Ryan's Finding Queue",
    createdBy: 'Diogo Brax',
    createdOn: '2022-06-14T21:55:12Z',
    lastOpenedOn: '2022-06-14T21:55:12Z'
  },
  {
    id: '3',
    name: 'AWS Privileged Actions',
    createdBy: 'Diogo Brax',
    createdOn: '2022-06-14T21:55:12Z',
    lastOpenedOn: '2022-06-14T21:55:12Z'
  }
];
