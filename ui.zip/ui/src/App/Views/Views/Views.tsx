import { FC } from 'react';
import css from './Views.module.css';
import { Helmet } from 'react-helmet-async';
import {
  Button,
  MotionGroup,
  MotionItem,
  PrimaryHeading,
  Stack
} from 'reablocks';
import { Count } from 'reaviz';
import { SearchInput } from 'shared/form/Input';
import { Tab, TabList, TabPanel, Tabs } from 'shared/layout/Tabs';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import { EmptyState } from 'shared/elements/EmptyState';
import { ReactComponent as EmptyIllustration } from 'assets/illustrations/empty-list.svg';
import { Chip } from 'shared/elements/Chip';
import { View, ViewRow } from 'App/Views/ViewRow/ViewRow';

export interface ViewsProps {
  myViews: View[];
  sharedViews: View[];
  recentViews: View[];
  onNewView: () => void;
  openSavedView: (view: View, editMode: boolean) => void;
}

export const Views: FC<ViewsProps> = ({
  myViews,
  sharedViews,
  recentViews,
  onNewView,
  openSavedView
}) => (
  <div className={css.root}>
    <Helmet>
      <title>Views</title>
    </Helmet>
    <header className={css.header}>
      <PrimaryHeading>
        <Stack>
          <span>Views</span>
          <Chip variant="outline" color="secondary">
            <div className={css.counter}>
              <Count
                to={
                  (myViews?.length || 0) +
                  (sharedViews?.length || 0) +
                  (recentViews?.length || 0)
                }
              />
            </div>
          </Chip>
        </Stack>
      </PrimaryHeading>
      <div className={css.push} />
      <SearchInput placeholder=" Find..." />
      <Button
        className={css.newBtn}
        color="primary"
        onClick={() => onNewView()}
      >
        <PlusIcon />
        New View
      </Button>
    </header>
    <Tabs className={css.tabs}>
      <TabList>
        <Tab>My Views ({(myViews?.length || 0).toLocaleString()})</Tab>
        <Tab>Shared ({(sharedViews?.length || 0).toLocaleString()})</Tab>
        <Tab>Recent ({(recentViews?.length || 0).toLocaleString()})</Tab>
      </TabList>
      <TabPanel>
        <MotionGroup>
          {myViews?.map(view => (
            <MotionItem key={view.id} layout>
              <ViewRow view={view} openSavedView={openSavedView} />
            </MotionItem>
          ))}
        </MotionGroup>
      </TabPanel>
      <TabPanel className={css.empty}>
        <EmptyState
          illustration={<EmptyIllustration />}
          title="No views under development"
          actions={
            <Button color="primary" onClick={() => onNewView()}>
              <PlusIcon />
              New View
            </Button>
          }
        />
      </TabPanel>
      <TabPanel className={css.empty}>
        <EmptyState
          illustration={<EmptyIllustration />}
          title="No views under development"
          actions={
            <Button color="primary" onClick={() => onNewView()}>
              <PlusIcon />
              New View
            </Button>
          }
        />
      </TabPanel>
    </Tabs>
  </div>
);
