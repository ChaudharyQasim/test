import { FC, useMemo } from 'react';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { useNotification } from 'reablocks';
import { nanoid } from 'nanoid';

import { StreamView } from './StreamView/StreamView';

// Shared
import { errorHandler, formatGraphPayload } from 'shared/utils/Helper';
import { Loader } from 'shared/elements/Loader';

// Core
import {
  ConditionOperatorEnum,
  FieldEnum,
  GetEvents,
  GetEventsTimeline,
  OrderTypeEnum,
  StatusEnum
} from 'core/Api';
import { getListTenantsAccounts } from 'core/Api/VendorApi';
import { getViewTableData, getViewGraphData } from 'core/Api/ViewApi';
import { useAuth } from 'core/Auth';
import {
  getAcsFieldOperations,
  getAcsFields,
  getFields
} from 'core/Api/AcsApi';
import { subHours } from 'date-fns';
import { useFilterPager } from 'core/Hooks/useFilterPager';
import { PAGE_LIMIT_XL, ONE_HOUR } from 'shared/utils/Constants';
import { DEFAULT_COLUMNS } from 'App/Rules/constants';

export const ViewsContainer: FC = () => {
  const { notifyError } = useNotification();

  const queryClient = useQueryClient();

  const { user } = useAuth();

  const { setFilter } = useFilterPager();

  const userOrganizationId = user?.current_organization.id;

  const { data: configuredTenantList, isFetching: isListTenantFetching } =
    useQuery('tenantList', () => getListTenantsAccounts(userOrganizationId), {
      initialData: [],
      onError(error: any) {
        notifyError(`Error fetching tenants: ${errorHandler(error)}`);
      },
      onSettled(data) {
        const current_time = new Date();
        const start_time = subHours(current_time, ONE_HOUR).toISOString();
        const end_time = current_time.toISOString();
        setFilter({ start_time, end_time });

        const completedTenantId = data?.find(
          tenant => tenant?.status[0]?.status === StatusEnum.Completed
        )?.nanoid;

        if (completedTenantId) {
          tableDataWithQueryMutation({
            start_time,
            end_time,
            vendor_account_id: completedTenantId,
            page_number: 1,
            condition: {
              operator: ConditionOperatorEnum.And
            },
            page_size: PAGE_LIMIT_XL,
            order_by: FieldEnum.ValueTimestamp,
            order_type: OrderTypeEnum.DESC,
            selected_fields: [...DEFAULT_COLUMNS]
          });
          graphDataWithQueryMutation(
            formatGraphPayload({
              start_time,
              end_time,
              vendor_account_id: completedTenantId,
              condition: {
                operator: ConditionOperatorEnum.And
              }
            })
          );
        }
      }
    });

  const { data: acsFields } = useQuery('acsFields', () => getAcsFields(), {
    onError(error: any) {
      notifyError(errorHandler(error));
    }
  });

  const { data: acsFieldOperations } = useQuery(
    'acsFieldOperations',
    () => getAcsFieldOperations(),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { data: fieldSelector } = useQuery('fieldSelector', () => getFields(), {
    onError(error: any) {
      notifyError('Error occurred while getting field selectors');
    },
    initialData: {}
  });

  const selectedVendorAccount = useMemo(
    () => (configuredTenantList?.length ? configuredTenantList[0] : null),
    [configuredTenantList]
  );

  const {
    mutateAsync: tableDataWithQueryMutation,
    isLoading: isTableMutationLoading,
    data: streamViewTableData
  } = useMutation((tablePayload: GetEvents) => getViewTableData(tablePayload), {
    onSuccess(data) {
      queryClient.setQueryData('streamViewTableData', () => data);
    }
  });

  const {
    mutate: graphDataWithQueryMutation,
    isLoading: isGraphMutationLoading,
    data: streamViewGraphData
  } = useMutation(
    (graphPayload: GetEventsTimeline) => getViewGraphData(graphPayload),
    {
      onSuccess(data) {
        queryClient.setQueryData('streamViewGraphData', () => data);
      }
    }
  );

  const formattedGraphData = useMemo(() => {
    return streamViewGraphData?.map(({ timestamp, event_count }) => ({
      key: timestamp,
      data: event_count,
      id: nanoid()
    }));
  }, [streamViewGraphData]);

  if (isListTenantFetching) {
    return <Loader />;
  }

  return (
    <StreamView
      tableData={streamViewTableData}
      graphData={formattedGraphData}
      acsFields={acsFields}
      acsFieldOperations={acsFieldOperations}
      selectedVendorAccount={selectedVendorAccount}
      fieldSelector={fieldSelector}
      isLoadingStreamViewData={isTableMutationLoading && isGraphMutationLoading}
      tableDataWithQueryMutation={tableDataWithQueryMutation}
      graphDataWithQueryMutation={graphDataWithQueryMutation}
    />
  );
};
