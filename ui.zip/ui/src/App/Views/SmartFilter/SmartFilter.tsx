import { Button, Input, Stack, VerticalSpacer } from 'reablocks';
import {
  Dispatch,
  FC,
  SetStateAction,
  useCallback,
  useEffect,
  useState
} from 'react';
import { StyledCard } from 'shared/layout/Card';
import css from './SmartFilter.module.css';
import classNames from 'classnames';
import { ReactComponent as ExpandedIcon } from 'assets/icons/chevron-filled-down.svg';
import { ReactComponent as HeadIcon } from 'assets/icons/head.svg';
import {
  ConditionType,
  EventCondition,
  FieldOperations
} from 'shared/elements/EventCondition';
import { mockDefaultTime } from './utils';
import { ConditionsSummary } from '../Condition/ConditionsSummary/ConditionsSummary';
import { ACSFieldType } from 'core/Api';
import { SmartFilterEnum, useSmartFilter } from 'core/Hooks/useSmartFilter';
import { Controller, useForm } from 'react-hook-form';

interface SmartFilterProps {
  acsFields: ACSFieldType[];
  acsFieldOperations: FieldOperations;
  onRun: (
    conditions: ConditionType[],
    baseOperator: 'and' | 'or',
    timestamp: string | [string, string] | null
  ) => void;
  typeValue?: string;
  setTypeValue?: Dispatch<SetStateAction<string>>;
  baseOperator: 'and' | 'or';
  setBaseOperator: Dispatch<SetStateAction<'and' | 'or'>>;
  conditions: ConditionType[];
  setConditions: Dispatch<SetStateAction<ConditionType[]>>;
  timestamp: string | [string, string] | null;
  setTimestamp: Dispatch<SetStateAction<string | [string, string] | null>>;
  isLoadingStreamViewData: boolean;
}

export const SmartFilter: FC<SmartFilterProps> = ({
  acsFields,
  acsFieldOperations,
  onRun,
  typeValue,
  setTypeValue,
  baseOperator,
  setBaseOperator,
  conditions,
  setConditions,
  timestamp,
  setTimestamp,
  isLoadingStreamViewData
}) => {
  const [conditionsExpanded, setConditionsExpanded] = useState<boolean>(true);
  const [isQuerySubmitted, setIsQuerySubmitted] = useState<boolean>(false);

  const { control, handleSubmit, getValues } = useForm({
    mode: 'onChange',
    defaultValues: {
      query: ''
    }
  });

  const { smartFilterState, isAiJobInProgress } = useSmartFilter({
    smartFilterType: SmartFilterEnum.STREAMS,
    query: getValues('query'),
    submitJob: isQuerySubmitted
  });

  useEffect(() => {
    setIsQuerySubmitted(false);
    if (smartFilterState?.data) {
      setBaseOperator(smartFilterState?.data?.operator ?? 'and');
      setConditions(smartFilterState?.data?.value ?? []);
    }
  }, [
    smartFilterState,
    isAiJobInProgress,
    setIsQuerySubmitted,
    setBaseOperator,
    setConditions
  ]);

  const onSubmit = () => setIsQuerySubmitted(true);

  const renderSummary = useCallback(
    () => (
      <>
        <ConditionsSummary conditions={conditions} time={mockDefaultTime} />
      </>
    ),
    [conditions]
  );

  const renderSmartFilterSection = useCallback(
    () => (
      <>
        <VerticalSpacer space="xxl" />
        <VerticalSpacer space="md" />
        <EventCondition
          fields={acsFields}
          fieldOperationsMap={acsFieldOperations}
          conditions={conditions}
          operator={baseOperator}
          defaultTime={mockDefaultTime}
          onConditionsChange={setConditions}
          onTimeChange={setTimestamp}
          updateBaseOperator={setBaseOperator}
          typeValue={typeValue}
          setTypeValue={setTypeValue}
          isLoadingStreamViewData={isLoadingStreamViewData}
        />
        <Button
          variant="filled"
          size="small"
          color="primary"
          onClick={() => onRun(conditions, baseOperator, timestamp)}
          className={css.runBtn}
        >
          Run
        </Button>
      </>
    ),
    [
      acsFields,
      acsFieldOperations,
      conditions,
      baseOperator,
      typeValue,
      setTypeValue,
      onRun,
      timestamp,
      setConditions,
      setTimestamp,
      setBaseOperator,
      isLoadingStreamViewData
    ]
  );

  return (
    <StyledCard>
      {/* <Stack justifyContent="end"> */}
      <Stack justifyContent="end">
        {conditionsExpanded && (
          <>
            <Button variant="outline" size="medium" className={css.headButton}>
              <HeadIcon />
            </Button>
            <form className={css.inputForm} onSubmit={handleSubmit(onSubmit)}>
              <Controller
                name="query"
                control={control}
                render={({ field: { value, onChange } }) => (
                  <Input
                    fullWidth
                    size="medium"
                    value={value}
                    disabled={isAiJobInProgress}
                    placeholder="Tell ASE what you are looking for. For example: Find authentication logs from 2.2.2.2"
                    onChange={onChange}
                  />
                )}
              />
            </form>
          </>
        )}
        <Button
          variant="text"
          size="small"
          onClick={() => setConditionsExpanded(!conditionsExpanded)}
        >
          <ExpandedIcon
            className={classNames(css.expandIcon, {
              [css.isExpanded]: conditionsExpanded
            })}
          />
        </Button>
      </Stack>
      {conditionsExpanded ? renderSmartFilterSection() : renderSummary()}
      {/* </Stack> */}
      <VerticalSpacer space="lg" />
    </StyledCard>
  );
};
