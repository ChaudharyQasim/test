import { Time } from 'shared/elements/EventTime/utils';

export const mockDefaultTime: Time = {
  type: 'realTime',
  timestamp: {
    unit: 'hour',
    value: 1
  }
};
