import { Dispatch, FC, SetStateAction, useCallback, useState } from 'react';
import { Button } from 'reablocks';
import { SmartFilter } from '../SmartFilter/SmartFilter';
import { OverlayComponent } from 'shared/layout/OverlayComponent/OverlayComponent';
import { ConditionType, FieldOperations } from 'shared/elements/EventCondition';
import { ACSFieldType } from 'core/Api';
import css from './Filter.module.css';

interface FilterProps {
  acsFields: ACSFieldType[];
  acsFieldOperations: FieldOperations;
  updateEventsData: (
    conditions: ConditionType[],
    baseOperator: 'and' | 'or',
    timestamp: string | [string, string] | null
  ) => void;
  typeValue?: string;
  setTypeValue?: Dispatch<SetStateAction<string>>;
  baseOperator: 'and' | 'or';
  setBaseOperator: Dispatch<SetStateAction<'and' | 'or'>>;
  conditions: ConditionType[];
  setConditions: Dispatch<SetStateAction<ConditionType[]>>;
  timestamp: string | [string, string] | null;
  setTimestamp: Dispatch<SetStateAction<string | [string, string] | null>>;
  isLoadingStreamViewData: boolean;
}

export const Filter: FC<FilterProps> = ({
  acsFields,
  acsFieldOperations,
  updateEventsData,
  typeValue,
  setTypeValue,
  baseOperator,
  setBaseOperator,
  conditions,
  setConditions,
  timestamp,
  setTimestamp,
  isLoadingStreamViewData
}) => {
  const [showOffCanvas, setShowOffCanvas] = useState<boolean>(false);
  const [isRendered, setIsRendered] = useState<boolean>(false);

  const onClose = () => {
    setShowOffCanvas(false);
  };

  const onRun = useCallback(
    (
      conditions: ConditionType[],
      baseOperator: 'and' | 'or',
      timestamp: string | [string, string] | null
    ) => {
      updateEventsData(conditions, baseOperator, timestamp);
      onClose();

      return {
        conditions,
        baseOperator,
        timestamp
      };
    },
    [updateEventsData]
  );

  const renderEditableView = useCallback(
    () => (
      <OverlayComponent
        isRendered={isRendered}
        setIsRendered={setIsRendered}
        showOffCanvas={showOffCanvas}
        onClose={onClose}
      >
        <SmartFilter
          acsFieldOperations={acsFieldOperations}
          acsFields={acsFields}
          onRun={onRun}
          typeValue={typeValue}
          setTypeValue={setTypeValue}
          baseOperator={baseOperator}
          setBaseOperator={setBaseOperator}
          conditions={conditions}
          setConditions={setConditions}
          timestamp={timestamp}
          setTimestamp={setTimestamp}
          isLoadingStreamViewData={isLoadingStreamViewData}
        />
      </OverlayComponent>
    ),
    [
      acsFieldOperations,
      acsFields,
      isRendered,
      onRun,
      setTypeValue,
      showOffCanvas,
      typeValue,
      timestamp,
      setTimestamp,
      conditions,
      setConditions,
      baseOperator,
      setBaseOperator,
      isLoadingStreamViewData
    ]
  );

  const handleConditionButtonClick = event => {
    event.stopPropagation();
    setShowOffCanvas(!showOffCanvas);
  };

  return (
    <>
      <div className={css.conditionButton} onClick={handleConditionButtonClick}>
        <Button variant="text" size="small" disablePadding>
          Conditions
        </Button>
      </div>
      {renderEditableView()}
    </>
  );
};
