import { FC } from 'react';
import { UseMutateAsyncFunction, UseMutateFunction } from 'react-query';

import { ViewTab } from '../ViewTab/ViewTab';

// Shared
import { FieldOperations } from 'shared/elements/EventCondition';

import {
  ACSFieldType,
  Events,
  GetEvents,
  GetEventsTimeline,
  VendorAccountOut
} from 'core/Api';

// types
import {
  FormattedTableData,
  StreamViewFormattedGraphData,
  StreamViewGraphType
} from '../View.type';

// type RenderedView = {
//   // 'renderId' is set on the UI side when the view is opened for viewing in a new tab
//   renderId: string;
//   // set on the UI side depending upon whether View should be editable or not
//   isEditable: boolean;
//   view: View;
// };

type StreamViewType = {
  tableData: FormattedTableData;
  graphData: StreamViewFormattedGraphData[];
  selectedVendorAccount: VendorAccountOut;
  acsFields: ACSFieldType[];
  isLoadingStreamViewData: boolean;
  acsFieldOperations: FieldOperations;
  fieldSelector: { [key: string]: string[] };
  tableDataWithQueryMutation: UseMutateAsyncFunction<
    Events,
    unknown,
    GetEvents,
    unknown
  >;
  graphDataWithQueryMutation: UseMutateFunction<
    StreamViewGraphType[],
    unknown,
    GetEventsTimeline,
    unknown
  >;
};

export const StreamView: FC<StreamViewType> = ({
  tableData,
  graphData,
  acsFields,
  isLoadingStreamViewData,
  acsFieldOperations,
  fieldSelector,
  selectedVendorAccount,
  tableDataWithQueryMutation,
  graphDataWithQueryMutation
}) => {
  // default value is 0 as the first tab cannot be closed

  /**
   * 
   * TODO: When we supporting views creation enable commented code.
   * 
  const [openedViews, setOpenedViews] = useState<{
    tabIndex: number;
    renderedViews: RenderedView[];
  }>({ tabIndex: 0, renderedViews: [] });

  const createNewView = () => {
    const blankView: View = {
      id: nanoid(),
      name: 'New View',
      createdBy: '',
      createdOn: '',
      lastOpenedOn: ''
    };

    // Switch to newly created tab
    setOpenedViews({
      tabIndex: openedViews.renderedViews.length + 1,
      renderedViews: [
        ...openedViews.renderedViews,
        { view: blankView, renderId: nanoid(), isEditable: true }
      ]
    });
  };

  const openSavedView = (view: View, editMode: boolean) => {
    // Switch to newly opened tab
    setOpenedViews({
      tabIndex: openedViews.renderedViews.length + 1,
      renderedViews: [
        ...openedViews.renderedViews,
        { view: view, renderId: nanoid(), isEditable: editMode }
      ]
    });
  };

  const closeTab = (viewIndex: number) => {
    const updatedViews = [...openedViews.renderedViews];
    updatedViews.splice(viewIndex, 1);

    // Switch to next open tab or the default tab
    let selectedTabIndex = 0;
    if (updatedViews.length > 0) {
      if (viewIndex === updatedViews.length) {
        selectedTabIndex = viewIndex;
      } else {
        selectedTabIndex = viewIndex + 1;
      }
    }
    setOpenedViews({ tabIndex: selectedTabIndex, renderedViews: updatedViews });
  };
 */
  // Using 'renderId' as 'key' to tabs as same tab can be opened multiple times
  // so the view 'id' may not be a unique identifier in that case

  return (
    /***
     * TODO: Not Supporting Views as of now.
     *     
     * <Tabs
     * selectedIndex={openedViews.tabIndex}
     * onSelect={(index: number) =>
        setOpenedViews({
          tabIndex: index,
          renderedViews: openedViews.renderedViews
        })
      }
      selectedTabClassName={css.selectedTab}
      defaultIndex={0}
    >
      <TabList
        className={classNames(css.tabList, {
          [css.hiddenTabs]: openedViews.renderedViews.length === 0
        })}
      >
        <Tab className={css.tab} selectedTabClassName={css.selectedTab}>
          My Views
        </Tab>
        {openedViews?.renderedViews?.map((renderedView, index) => (
          <Tab
            key={`tab-${renderedView?.renderId}`}
            className={css.tab}
            selectedTabClassName={css.selectedTab}
            onClose={() => closeTab(index)}
          >
            {renderedView.view.name}
          </Tab>
        ))}
        <Tab
          className={css.tab}
          selectedTabClassName={css.selectedTab}
          onClick={e => {
            createNewView();
            // This tab is not selectable and does not have a panel associated with it
            e.stopPropagation();
          }}
        >
          <PlusIcon />
        </Tab>
      </TabList>
      <TabPanel>
        <Views
          myViews={mockViewsData}
          sharedViews={[]}
          recentViews={[]}
          onNewView={createNewView}
          openSavedView={openSavedView}
        />
      </TabPanel>
      {openedViews?.renderedViews?.map(renderedView => (
        <TabPanel key={`panel-${renderedView?.renderId}`}>
          <ViewTab
            view={renderedView.view}
            isEditable={renderedView.isEditable}
          />
        </TabPanel>
      ))}
    </Tabs>
     * 
     * 
     * 
     * 
     */

    <ViewTab
      tableData={tableData}
      isEditable={false}
      graphData={graphData}
      acsFields={acsFields}
      isLoadingStreamViewData={isLoadingStreamViewData}
      acsFieldOperations={acsFieldOperations}
      selectedVendorAccount={selectedVendorAccount}
      fieldSelector={fieldSelector}
      tableDataWithQueryMutation={tableDataWithQueryMutation}
      graphDataWithQueryMutation={graphDataWithQueryMutation}
    />
  );
};
