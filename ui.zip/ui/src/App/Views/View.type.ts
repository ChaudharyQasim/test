import { AppStreamviewerSchemasPaginationInfo, ECSEventFull } from 'core/Api';

export type StreamViewFormattedGraphData = {
  id: string;
  data: number;
  key: string;
};

export type StreamViewGraphType = {
  timestamp: string;
  event_count: number;
};

export interface StreamViewEventResponse extends ECSEventFull {
  id?: string;
}

export type EventsData = {
  timestamp: string;
  kind: string;
  category: string;
  type: string[];
  outcome: boolean;
  dataset: string;
  tags: string[];
  [key: string]: any;
};

export type FormattedTableData = {
  metadata: AppStreamviewerSchemasPaginationInfo;
  events: EventsData[];
};
