import { Button, Card, Divider, List, ListItem } from 'reablocks';
import { useRef, useState } from 'react';
import { Menu } from 'shared/layers/Menu';
import { ReactComponent as ChevronDown } from 'assets/icons/chevron-down.svg';
import css from './FieldSetSelector.module.css';

interface FieldSetSelectorProps {
  options: { name: string; value: string }[];
  actions: { name: string; action: () => void }[];
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
}

export const FieldSetSelector = ({
  options,
  actions,
  value,
  onChange,
  placeholder
}: FieldSetSelectorProps) => {
  const fieldSetBtnRef = useRef<HTMLButtonElement>(null);
  const [openFieldSetMenu, setOpenFieldsetMenu] = useState(false);

  const handleClickFieldSetMenu = (value: string) => () => {
    if (typeof onChange === 'function') {
      onChange(value);
    }
    setOpenFieldsetMenu(false);
  };

  const handleClickAction = (action: () => void) => () => {
    action();
    setOpenFieldsetMenu(false);
  };

  const currentOptionName = options.find(option => option.value === value)
    ?.name;

  return (
    <>
      <Button
        variant="outline"
        size="small"
        ref={fieldSetBtnRef}
        className={css.selectorDropdown}
        endAdornment={<ChevronDown />}
        onClick={() => setOpenFieldsetMenu(prev => !prev)}
      >
        {currentOptionName || placeholder || 'Select Fieldset'}
      </Button>
      <Menu
        open={openFieldSetMenu}
        onClose={() => setOpenFieldsetMenu(false)}
        reference={fieldSetBtnRef}
        placement="bottom-end"
        className={css.menu}
      >
        <Card>
          <List>
            <ListItem className={css.optionType}>Options</ListItem>
            {options.map(({ name, value }) => (
              <ListItem key={value} onClick={handleClickFieldSetMenu(value)}>
                {name}
              </ListItem>
            ))}
            <ListItem className={css.optionType}>Actions</ListItem>
            {actions.map(({ name, action }) => (
              <ListItem key={name} onClick={handleClickAction(action)}>
                {name}
              </ListItem>
            ))}
          </List>
        </Card>
      </Menu>
    </>
  );
};
