import { ReactComponent as KindAlert } from 'assets/icons/kind-alert.svg';
import { ReactComponent as KindAsset } from 'assets/icons/kind-asset.svg';
import { ReactComponent as KindEnrichment } from 'assets/icons/kind-enrichment.svg';
import { ReactComponent as KindEvent } from 'assets/icons/kind-event.svg';
import { ReactComponent as KindFinding } from 'assets/icons/kind-finding.svg';
import { ReactComponent as KindMetric } from 'assets/icons/kind-metric.svg';
import { ReactComponent as KindPipeline } from 'assets/icons/kind-pipeline.svg';
import { ReactComponent as KindState } from 'assets/icons/kind-state.svg';

import {
  Button,
  DateFormat,
  SortDirection,
  Stack,
  Toggle,
  Tooltip,
  VerticalSpacer,
  safeFormat,
  useNotification,
  useTheme
} from 'reablocks';
import {
  FC,
  useCallback,
  useMemo,
  useState,
  useRef,
  useEffect,
  Dispatch,
  SetStateAction
} from 'react';
import {
  Bar,
  BarChart,
  BarSeries,
  ChartShallowDataShape,
  ChartTooltip,
  Gridline,
  GridlineSeries,
  LinearXAxis,
  LinearXAxisTickSeries,
  TooltipArea,
  TooltipTemplate
} from 'reaviz';
import { Chip, LabelChip } from 'shared/elements/Chip';
import { StyledCard } from 'shared/layout/Card';
import css from './Events.module.css';
import { FieldValuePair, getCommonFields } from './utils';
import { FieldSelector } from './FieldSelector';
import { EventsData, FormattedTableData } from '../View.type';
import {
  EMPTY,
  PAGE_LIMIT_XL,
  SHORT_DATE_FORMAT,
  TIME_24_HOUR_FORMAT
} from 'shared/utils/Constants';
import { PagerVCR } from 'shared/data/PagerVCR';
import { ACSFieldType, FieldEnum, VendorAccountOut } from 'core/Api';
import { AIJobResponse } from 'core/Api/AIApi';
import { EVENTS_KIND_TYPES } from 'App/Rules/constants';
import { OffCanvas } from './OffCanvas';
import { FieldSetSelector } from './FieldSetSelector';
import { AgTable } from 'shared/layout/AgTable';
import {
  GridApi,
  GridReadyEvent,
  ColDef,
  SelectionChangedEvent
} from 'ag-grid-community';
import classNames from 'classnames';
import { ConditionType, FieldOperations } from 'shared/elements/EventCondition';
import { Filter } from '../Filter';

const DefaultFieldSetOptions = [
  { name: 'Default', value: 'default' },
  { name: 'Fraud Field', value: 'fraud-field' },
  { name: 'Multicloud Field', value: 'multicloud-field' }
];

const DefaultFieldSetActions = [
  {
    name: 'Create New Field Set',
    action: () => alert('Create New Field Set')
  },
  {
    name: 'Update Current Field Set',
    action: () => alert('Update Current Field Set')
  },
  {
    name: 'Manage Field Set',
    action: () => alert('Manage Field Set')
  }
];

type EventsProps = {
  data: FormattedTableData;
  histogramData: ChartShallowDataShape[];
  acsFields: ACSFieldType[];
  fields: string[];
  fieldSelector: { [key: string]: string[] };
  onFieldChange: (fields: FieldEnum[]) => void;
  onPageChange: (pageNumber: number) => void;
  onSortChange?: (sortDirection: SortDirection, columnName: string) => void;
  smartEventState: AIJobResponse;
  getEventData: (event: EventsData) => void;
  onClose?: () => void;
  selectedVendorAccount: VendorAccountOut;
  typeValue?: string;
  setTypeValue?: Dispatch<SetStateAction<string>>;
  acsFieldOperations: FieldOperations;
  updateEventsData: (
    conditions: ConditionType[],
    baseOperator: 'and' | 'or',
    timestamp: string | [string, string] | null
  ) => void;
  baseOperator: 'and' | 'or';
  setBaseOperator: Dispatch<SetStateAction<'and' | 'or'>>;
  conditions: ConditionType[];
  setConditions: Dispatch<SetStateAction<ConditionType[]>>;
  timestamp: string | [string, string] | null;
  setTimestamp: Dispatch<SetStateAction<string | [string, string] | null>>;
  isLoadingStreamViewData: boolean;
};

const PRIMITIVE_TYPE = [
  'Boolean',
  'Float32',
  'Float64',
  'Ipv4',
  'Long',
  'String',
  'StringifyJson',
  'Enum'
];

const LIST_TYPE = ['List(String)'];

const EventKindComponents = {
  [EVENTS_KIND_TYPES.EVENT]: KindEvent,
  [EVENTS_KIND_TYPES.ASSET]: KindAsset,
  [EVENTS_KIND_TYPES.METRIC]: KindMetric,
  [EVENTS_KIND_TYPES.STATE]: KindState,
  [EVENTS_KIND_TYPES.ALERT]: KindAlert,
  [EVENTS_KIND_TYPES.ENRICHMENT]: KindEnrichment,
  [EVENTS_KIND_TYPES.PIPELINE]: KindPipeline,
  [EVENTS_KIND_TYPES.FINDING]: KindFinding
};
const renderEventKind = kind => {
  const KindComponent = EventKindComponents[kind];
  return KindComponent ? <KindComponent /> : null;
};

const renderEventOutcome = outcome => {
  if (!outcome) {
    return null;
  }
  switch (outcome) {
    case 'success':
      return (
        <LabelChip className={classNames(css.success, css.truncateText)}>
          Success
        </LabelChip>
      );
    case 'failure':
      return (
        <LabelChip className={classNames(css.failure, css.truncateText)}>
          Failure
        </LabelChip>
      );
    default:
      return (
        <LabelChip className={classNames(css.outcome, css.truncateText)}>
          {outcome.charAt(0).toUpperCase()}
        </LabelChip>
      );
  }
};

const renderListType = list => (
  <div>
    {list?.map(chipValue => (
      <Chip
        className={classNames(css.chip, css.truncateText)}
        key={chipValue}
        variant="outline"
        color="secondary"
      >
        {chipValue}
      </Chip>
    ))}
  </div>
);

const renderDateType = date => {
  const getDateFormat = date && (
    <DateFormat date={date} format={SHORT_DATE_FORMAT} />
  );
  const getTimeFormat = date && (
    <DateFormat date={date} format={TIME_24_HOUR_FORMAT} />
  );

  const dateTime = (
    <div className={css.truncateText}>
      {getDateFormat} {getTimeFormat}
    </div>
  );

  return date && <Stack dense>{dateTime}</Stack>;
};

const renderDefault = value => (
  <div className={classNames(css.dataset, css.truncateText)}>
    {value ?? EMPTY}
  </div>
);

const EventValueRenderer = ({ field, value, data_type }) => {
  const valueContent = value.getValue();
  if (field === 'event.kind') {
    return (
      <Tooltip content={valueContent}>{renderEventKind(valueContent)}</Tooltip>
    );
  } else if (field === 'event.outcome') {
    return renderEventOutcome(valueContent);
  } else if (PRIMITIVE_TYPE.includes(data_type)) {
    return renderDefault(valueContent);
  } else if (LIST_TYPE.includes(data_type)) {
    return renderListType(valueContent);
  } else if (['Date'].includes(data_type)) {
    return renderDateType(valueContent);
  }
  return renderDefault(valueContent);
};

const defaultColDef: ColDef = {
  resizable: true,
  sortable: true,
  suppressMovable: false
};

export const Events: FC<EventsProps> = ({
  data,
  histogramData,
  acsFields,
  fields,
  fieldSelector,
  onFieldChange,
  onPageChange,
  smartEventState,
  getEventData,
  onClose: onclose,
  selectedVendorAccount,
  typeValue,
  setTypeValue,
  acsFieldOperations,
  updateEventsData,
  baseOperator,
  setBaseOperator,
  conditions,
  setConditions,
  timestamp,
  setTimestamp,
  isLoadingStreamViewData
}) => {
  const { colors } = useTheme();
  const { notifyError } = useNotification();
  const gridRef = useRef(null);
  const isLive = typeValue === 'realTime';

  const [showBarChart, setShowBarChart] = useState<boolean>(true);
  const [fieldSelectorKeyProp, setFieldSelectorKeyProp] = useState<number>(
    Math.random()
  );
  const [currentFieldSetValue, setCurrentFieldSetValue] = useState('');

  const { metadata, events = [] } = data || {};

  const { total_count, page_size, page_number } = metadata || {};

  const [selectedRows, setSelectedRows] = useState<EventsData[]>([]);
  const [showOffCanvas, setShowOffCanvas] = useState<boolean>(false);
  const [selectedRowTableData, setSelectedRowTableData] = useState<
    FieldValuePair[]
  >([]);
  const [selectedRowTableDataOrig, setSelectedRowTableDataOrig] = useState<
    FieldValuePair[]
  >([]);
  const [buttonText, setButtonText] = useState<string>('Copy Row Details');
  const [open, setOpen] = useState<boolean>(false);
  const [gridApi, setGridApi] = useState<GridApi | null>(null);
  const [cellText, setCellText] = useState<string>('Copy Cell Value');
  const [selectedCellValue, setSelectedCellValue] = useState(null);
  const [clickedOutside, setClickedOutside] = useState<boolean>(false);
  const [startLive, setStartLive] = useState<boolean>(false);

  const columnDefs = useMemo(
    () =>
      fields?.map(field => {
        const data_type = acsFields?.find(
          acsField => acsField.field === (field as FieldEnum)
        ).data_type;

        return {
          id: field,
          headerName: field === 'event.kind' ? EMPTY : field,
          fieldName: field,
          width: field === 'event.kind' && 50,
          minWidth: field === 'event.kind' && 50,
          cellRenderer: value => (
            <EventValueRenderer
              field={field}
              value={value}
              data_type={data_type}
            />
          )
        };
      }),
    [acsFields, fields]
  );

  const renderedColumns = useMemo(() => {
    const cols: any[] = [
      {
        field: '',
        header: '',
        checkboxSelection: true,
        suppressMenu: true,
        width: 50,
        minWidth: 50
      }
    ];
    for (const field of fields) {
      const index = columnDefs?.findIndex(col => col.fieldName === field);
      if (index > -1) {
        const { fieldName, ...rest } = columnDefs[index];
        cols.push({
          field: fieldName,
          suppressMenu: true,
          ...rest
        });
      } else {
        cols.push({
          id: field,
          header: field,
          accessor: field,
          suppressMenu: true,
          cell: value => <div className={css.dataset}>{value.getValue()}</div>
        });
      }
    }
    return cols;
  }, [fields, columnDefs]);

  const renderTableButtons = useMemo(
    () => (
      <Stack dense inline={false}>
        <FieldSelector
          key={fieldSelectorKeyProp}
          fieldGroups={fieldSelector}
          preSelectedFields={fields}
          onClose={(selectedFields: string[]) => {
            if (selectedFields.join(',') !== fields.join(',')) {
              setFieldSelectorKeyProp(prevKey => prevKey + 1);
              onFieldChange(selectedFields as FieldEnum[]);
            }
          }}
          open={open}
          setOpen={setOpen}
          updateEventsData={updateEventsData}
          baseOperator={baseOperator}
          conditions={conditions}
          timestamp={timestamp}
        />
      </Stack>
    ),
    [
      fieldSelectorKeyProp,
      fieldSelector,
      fields,
      open,
      updateEventsData,
      baseOperator,
      conditions,
      timestamp,
      onFieldChange
    ]
  );

  useEffect(() => {
    // Handler to toggle the button state once click outside the grid
    const handleClickOutside = (event: MouseEvent) => {
      const hasEvents = !(
        gridRef.current && !gridRef.current.contains(event.target as Node)
      );
      setClickedOutside(hasEvents);
    };

    document.addEventListener('click', handleClickOutside);

    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [selectedCellValue]);

  const renderBarChart = useMemo(
    () => (
      <BarChart
        height={100}
        gridlines={<GridlineSeries line={<Gridline direction="y" />} />}
        xAxis={
          <LinearXAxis
            type="category"
            tickSeries={<LinearXAxisTickSeries label={null} />}
          />
        }
        series={
          <BarSeries
            colorScheme={[colors.pink[100]]}
            bar={<Bar rx={5} ry={5} gradient={null} width={5} />}
            tooltip={
              <TooltipArea
                tooltip={
                  <ChartTooltip
                    followCursor={true}
                    content={(data, color) => (
                      <TooltipTemplate
                        color={color}
                        value={{
                          ...data,
                          x: safeFormat(data.x, { format: 'MM/d HH:mm' })
                            .formatted
                        }}
                      />
                    )}
                  />
                }
              />
            }
          />
        }
        data={histogramData}
      />
    ),
    [colors.pink, histogramData]
  );

  const handleCopyRowDetailsClick = async () => {
    if (selectedRows.length > 0) {
      const formattedRowData = JSON.stringify(selectedRows, null, 2);
      try {
        await navigator.clipboard.writeText(formattedRowData);
        setButtonText('Copied Successfully!');
        setTimeout(() => {
          setButtonText('Copy Row Details');
        }, 2000);
      } catch (error) {
        notifyError('Maximum retry limit reached', error);
      }
    }
  };

  const handleDetailButtonClick = () => {
    const updatedSelectedRows = [...selectedRows];
    updatedSelectedRows[0].selected = true;
    const fields = getCommonFields(updatedSelectedRows, true);
    getEventData(selectedRows[0]);
    setShowOffCanvas(true);
    setSelectedRowTableData(fields);
    setSelectedRowTableDataOrig(fields);
  };

  const onGridReady = (params: GridReadyEvent) => {
    setGridApi(params.api);
  };

  const handleSelectionChanged = useCallback(
    (event: SelectionChangedEvent) => {
      if (gridApi) {
        const selectedNodes = event.api.getSelectedNodes();
        const selectedRowsData = selectedNodes.map(node => node.data);
        setSelectedRows(selectedRowsData);
      }
    },
    [gridApi]
  );

  const copyCellValue = () => {
    if (selectedCellValue !== undefined && selectedCellValue !== null) {
      const valueToCopy =
        typeof selectedCellValue === 'object'
          ? JSON.stringify(selectedCellValue)
          : String(selectedCellValue);
      navigator.clipboard.writeText(valueToCopy);
      setCellText('Copied Successfully!');
      setTimeout(() => {
        setCellText('Copy Cell Values');
      }, 2000);
    }
  };

  const gridOptions = {
    onCellClicked: event => {
      const selectedNode = event.node;
      const selectedCol = event.column.getColDef().field;
      // Accessing nested properties safely
      const nestedProperties = selectedCol.split('.');
      // Iterate through nested properties to access the value
      let value = selectedNode.data;
      for (const prop of nestedProperties) {
        value = value[prop]; // Traverse through each nested property
        if (value === undefined || value === null) {
          break;
        }
      }
      setSelectedCellValue(
        value !== undefined && value !== null ? value : null
      );
    }
  };

  //Added pooling behavior. It is temporary and will be replaced by a proper web socket call in future.
  useEffect(() => {
    if (typeValue === 'realTime' && startLive) {
      const id = setInterval(() => {
        onPageChange(0);
      }, 60000);

      return () => {
        clearInterval(id);
      };
    } else {
      setStartLive(false);
    }
  }, [onPageChange, startLive, typeValue]);

  const handleLiveDataClick = () => {
    setStartLive(prevStartLive => !prevStartLive);
  };

  return (
    <>
      <StyledCard className={css.events}>
        <Stack justifyContent="spaceBetween">
          <div className={css.eventHeader}>
            <h5 className={css.cardTitle}>Events</h5>
            {total_count > page_size && (
              <PagerVCR
                page={page_number - 1}
                total={total_count}
                size={page_size ?? PAGE_LIMIT_XL}
                onPageChange={onPageChange}
                handleLiveDataClick={handleLiveDataClick}
                isLive={isLive}
                startLive={startLive}
              />
            )}
          </div>
          {renderTableButtons}
        </Stack>
        <VerticalSpacer space="lg" />
        {showBarChart && renderBarChart}
        <VerticalSpacer space="lg" />
        <Stack justifyContent="spaceBetween" className={css.metadata}>
          <div>{total_count || 0} Results</div>
          <Stack>
            <Button
              onClick={copyCellValue}
              variant="outline"
              size="small"
              disabled={!clickedOutside}
            >
              {cellText}
            </Button>
            <Button
              onClick={handleCopyRowDetailsClick}
              variant="outline"
              size="small"
              disabled={!selectedRows.length}
            >
              {buttonText}
            </Button>
            <div className={css.detailButton} onClick={handleDetailButtonClick}>
              <Button
                disabled={!selectedRows.length}
                variant="text"
                size="small"
                disablePadding
              >
                Details
              </Button>
            </div>
            <Filter
              acsFieldOperations={acsFieldOperations}
              acsFields={acsFields}
              updateEventsData={updateEventsData}
              typeValue={typeValue}
              setTypeValue={setTypeValue}
              baseOperator={baseOperator}
              setBaseOperator={setBaseOperator}
              conditions={conditions}
              setConditions={setConditions}
              timestamp={timestamp}
              setTimestamp={setTimestamp}
              isLoadingStreamViewData={isLoadingStreamViewData}
            />
            <div>Chart</div>
            <Toggle
              size="small"
              onChange={setShowBarChart}
              checked={showBarChart}
            />
            <Button
              variant="outline"
              size="small"
              onClick={() => setOpen(!open)}
            >
              Fields
            </Button>
            {/* TODO: Uncomment and update this section when ready to connect to api
            <FieldSetSelector
              options={DefaultFieldSetOptions}
              actions={DefaultFieldSetActions}
              value={currentFieldSetValue}
              onChange={setCurrentFieldSetValue}
            /> */}
          </Stack>
        </Stack>
        <VerticalSpacer space="lg" />
        <div className={css.tableContainer} ref={gridRef}>
          <AgTable
            columnDefs={renderedColumns}
            rowData={events}
            rowSelection="multiple"
            rowMultiSelectWithClick={true}
            defaultColDef={defaultColDef}
            suppressCopyRowsToClipboard={true}
            onSelectionChanged={handleSelectionChanged}
            onGridReady={onGridReady}
            gridOptions={gridOptions}
            height={'calc(100vh - 340px)'}
          />
        </div>
      </StyledCard>
      {(showOffCanvas || selectedRows.length > 0) && (
        <OffCanvas
          fieldSelector={fieldSelector}
          smartEventState={smartEventState}
          showOffCanvas={showOffCanvas}
          setShowOffCanvas={setShowOffCanvas}
          getEventData={getEventData}
          selectedRows={selectedRows}
          setSelectedRows={setSelectedRows}
          selectedRowTableData={selectedRowTableData}
          setSelectedRowTableData={setSelectedRowTableData}
          selectedRowTableDataOrig={selectedRowTableDataOrig}
          setSelectedRowTableDataOrig={setSelectedRowTableDataOrig}
          gridApi={gridApi}
          selectedVendorAccount={selectedVendorAccount}
          onclose={onclose}
        />
      )}
    </>
  );
};
