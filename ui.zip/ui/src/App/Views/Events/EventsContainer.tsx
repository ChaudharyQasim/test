import { SortDirection, useNotification } from 'reablocks';
import {
  Dispatch,
  FC,
  SetStateAction,
  useCallback,
  useEffect,
  useState
} from 'react';
import { ChartShallowDataShape } from 'reaviz';

import { EventsData, FormattedTableData } from '../View.type';
import { ACSFieldType, FieldEnum, VendorAccountOut } from 'core/Api';
import { Events } from './Events';
import {
  AIJobResponse,
  AIJobStatus,
  describeEvent,
  jobStatus
} from 'core/Api/AIApi';
import { useMutation } from 'react-query';
import { MAX_RETRIES } from 'App/Rules/constants';
import { ConditionType, FieldOperations } from 'shared/elements/EventCondition';

interface EventsContainerProps {
  data: FormattedTableData;
  histogramData: ChartShallowDataShape[];
  acsFields: ACSFieldType[];
  fields: string[];
  fieldSelector: { [key: string]: string[] };
  onFieldChange: (fields: FieldEnum[]) => void;
  onPageChange: (pageNumber: number) => void;
  onSortChange?: (sortDirection: SortDirection, columnName: string) => void;
  selectedVendorAccount: VendorAccountOut;
  typeValue?: string;
  setTypeValue?: Dispatch<SetStateAction<string>>;
  acsFieldOperations: FieldOperations;
  updateEventsData: (
    conditions: ConditionType[],
    baseOperator: 'and' | 'or',
    timestamp: string | [string, string] | null
  ) => void;
  baseOperator: 'and' | 'or';
  setBaseOperator: Dispatch<SetStateAction<'and' | 'or'>>;
  conditions: ConditionType[];
  setConditions: Dispatch<SetStateAction<ConditionType[]>>;
  timestamp: string | [string, string] | null;
  setTimestamp: Dispatch<SetStateAction<string | [string, string] | null>>;
  isLoadingStreamViewData: boolean;
}
const initialState: AIJobResponse = {
  status: AIJobStatus.IN_PROGRESS,
  data: null,
  job_id: null
};

export const EventsContainer: FC<EventsContainerProps> = ({
  data,
  histogramData,
  acsFields,
  fields,
  fieldSelector,
  onFieldChange,
  onPageChange,
  onSortChange,
  selectedVendorAccount,
  typeValue,
  setTypeValue,
  acsFieldOperations,
  updateEventsData,
  baseOperator,
  setBaseOperator,
  conditions,
  setConditions,
  timestamp,
  setTimestamp,
  isLoadingStreamViewData
}) => {
  const { notifyError } = useNotification();

  const {
    data: smartEventState = initialState,
    mutate: fetchJobStatus,
    reset
  } = useMutation<AIJobResponse, Error, string>('eventData', async resp => {
    if (!resp) {
      return initialState;
    }
    let retries = 0;
    let isCancelled: boolean = false;

    let jobStatusResp = initialState as AIJobResponse;
    while (!isCancelled && retries < MAX_RETRIES) {
      jobStatusResp = await jobStatus(resp as string);
      if (jobStatusResp.status === AIJobStatus.CANCELLED) {
        isCancelled = true;
        break;
      }
      if (jobStatusResp.status !== AIJobStatus.IN_PROGRESS) {
        if (
          typeof jobStatusResp.data === 'string' &&
          jobStatusResp.status === AIJobStatus.ERROR
        ) {
          notifyError('Query could not be resolved');
        }
        break;
      }
      await new Promise(res => setTimeout(res, 1000));
      retries++;
    }

    if (!isCancelled && retries >= MAX_RETRIES) {
      // Handle reaching maximum retries here
      notifyError('Maximum retry limit reached');
    }

    return jobStatusResp;
  });

  const { data: describeEventResponse, mutate: mutateDescribeEvents } =
    useMutation<AIJobResponse, Error, EventsData>(
      'describeEvent',
      async query => {
        if (!query) {
          return;
        }
        const initialResponse: AIJobResponse = await describeEvent(
          query as EventsData
        );
        return initialResponse;
      },
      {
        onSuccess: data => {
          if (data) {
            fetchJobStatus(data.job_id);
          }
        },
        onError: () => {
          notifyError('Describe Events Failed');
        }
      }
    );

  return (
    <Events
      data={data}
      histogramData={histogramData}
      acsFields={acsFields}
      fields={fields}
      fieldSelector={fieldSelector}
      onFieldChange={onFieldChange}
      onPageChange={onPageChange}
      onSortChange={onSortChange}
      smartEventState={smartEventState}
      getEventData={mutateDescribeEvents}
      onClose={reset}
      selectedVendorAccount={selectedVendorAccount}
      typeValue={typeValue}
      setTypeValue={setTypeValue}
      updateEventsData={updateEventsData}
      acsFieldOperations={acsFieldOperations}
      baseOperator={baseOperator}
      setBaseOperator={setBaseOperator}
      conditions={conditions}
      setConditions={setConditions}
      timestamp={timestamp}
      setTimestamp={setTimestamp}
      isLoadingStreamViewData={isLoadingStreamViewData}
    />
  );
};
