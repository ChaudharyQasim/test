import {
  FC,
  useCallback,
  useEffect,
  useMemo,
  useState,
  Dispatch,
  SetStateAction
} from 'react';
import classNames from 'classnames';

import { Button, MotionItem, Toggle, Tree } from 'reablocks';
import { ReactComponent as ExpandedIcon } from 'assets/icons/chevron-filled-down.svg';
import { ReactComponent as CollapsedIcon } from 'assets/icons/chevron-filled-right.svg';
import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';
import { ReactComponent as HeadSvg } from 'assets/icons/head.svg';
import { ReactComponent as EmptyInsights } from 'assets/illustrations/empty-insights.svg';

import { Loader } from 'shared/elements/Loader';
import { EventsData } from 'App/Views/View.type';
import { AIJobResponse, AIJobStatus } from 'core/Api/AIApi';

import {
  FieldValuePair,
  getCommonFields,
  isNonEmptyAndValid
} from '../utils';
import { FieldSelector } from '../FieldSelector';
import { Table } from 'shared/layout/Table';
import { EmptyState } from 'shared/elements/EmptyState';

import { EventTreeNode } from '../EventTreeNode/EventTreeNode';
import { EventIcons } from '../EventIcons/EventIcons';

import css from './OffCanvas.module.css';
import { ColDef, GridApi, IRowNode } from 'ag-grid-community';
import { AgTable } from 'shared/layout/AgTable';
import { VendorAccountOut } from 'core/Api';
import { OverlayComponent } from 'shared/layout/OverlayComponent/OverlayComponent';

const selectedRowColumns = [
  {
    id: 'field',
    header: 'Field',
    accessor: 'field',
    cell: value => value.getValue()
  },
  {
    id: 'value',
    header: 'Value',
    accessor: 'value',
    cell: value => {
      const retrievedValue = value.getValue();
      if (Array.isArray(retrievedValue)) {
        return retrievedValue.join(', ');
      }
      return retrievedValue;
    }
  }
];

interface OffCanvasProps {
  smartEventState: AIJobResponse;
  getEventData: (event: EventsData) => void;
  fieldSelector: { [key: string]: string[] };
  onclose?: () => void;
  selectedRows: EventsData[];
  setSelectedRows: Dispatch<SetStateAction<EventsData[]>>;
  showOffCanvas: boolean;
  setShowOffCanvas: Dispatch<SetStateAction<boolean>>;
  selectedRowTableData: FieldValuePair[];
  setSelectedRowTableData: Dispatch<SetStateAction<FieldValuePair[]>>;
  selectedRowTableDataOrig: FieldValuePair[];
  setSelectedRowTableDataOrig: Dispatch<SetStateAction<FieldValuePair[]>>;
  gridApi: GridApi;
  selectedVendorAccount:VendorAccountOut
}

export const OffCanvas: FC<OffCanvasProps> = ({
  smartEventState,
  fieldSelector,
  getEventData,
  selectedRows,
  showOffCanvas,
  setShowOffCanvas,
  setSelectedRows,
  selectedRowTableData,
  selectedRowTableDataOrig,
  setSelectedRowTableData,
  setSelectedRowTableDataOrig,
  onclose,
  gridApi,
  selectedVendorAccount
}) => {
  const [openDetails, setOpenDetails] = useState<boolean>(false);
  const [selectedChildRows, setSelectedChildRows] = useState<EventsData[]>([]);
  const [displayField, setDisplayfields] = useState<string[]>([]);
  const [fieldSelectorKeyProp, setFieldSelectorKeyProp] = useState<number>(
    Math.random()
  );
  const [isRendered, setIsRendered] = useState<boolean>(false);
  useEffect(() => {
    const filterData =
      filterFields(selectedRowTableDataOrig, displayField);
    setSelectedRowTableData(filterData);
  }, [displayField, selectedRowTableDataOrig, setSelectedRowTableData]);

  const EventDrillColDef: ColDef = {
    resizable: false,
    suppressMovable: true
  };

  const selectedRowColumns: ColDef[] = [
    {
      headerName: 'Field',
      field: 'field',
      suppressMenu: true,
      flex: 1,
      valueFormatter: params => params.value
    },
    {
      headerName: 'Value',
      field: 'value',
      suppressMenu: true,
      flex: 1,
      valueFormatter: params => {
        const retrievedValue = params.value;
        if (Array.isArray(retrievedValue)) {
          return retrievedValue.join(', ');
        }
        return retrievedValue;
      }
    }
  ];


  const closeOffCanvas = () => {
    setShowOffCanvas(false);
    setSelectedRowTableData([]);
    setSelectedRowTableDataOrig([]);
    setDisplayfields([]);
    setSelectedChildRows([]);
    if (onclose) {
      onclose();
    }
  };

  const filterFields = (selectedRowTableDataOrig:FieldValuePair[], displayField:string[]) => {
    return displayField.length > 0
      ? selectedRowTableDataOrig.filter(fieldData =>
        displayField.includes(fieldData.field)
      )
      : selectedRowTableDataOrig;
  };

  const computeDisplayFields = useCallback(
    (rows: EventsData[], displayFields: string[]) => {
      const fields = getCommonFields(rows);
      const filterResult = filterFields(fields, displayFields);
      return { fields, filterFields: filterResult };
    },
    []
  );

  const handleDeleteRow = (rowId: string) => {
    const filteredRows = selectedRows.filter(row => row.id !== rowId);
    setSelectedRows(filteredRows);

    const { fields, filterFields } = computeDisplayFields(
      filteredRows,
      displayField
    );
    // Find and deselect the grid row with the specified rowId, if found
    if (gridApi) {
      const selectedNodes = gridApi.getSelectedNodes();
      const rowNode = selectedNodes.find(node => node.data.id === rowId);
      if (rowNode) {
        rowNode.setSelected(false);
      }
    }

    setSelectedRowTableDataOrig(fields);
    setSelectedRowTableData(filterFields);
  };

  const renderTableDetailsButtons = useMemo(
    () => (
      <FieldSelector
        key={fieldSelectorKeyProp}
        fieldGroups={fieldSelector}
        preSelectedFields={displayField}
        onClose={(fields: string[]) => {
          if (fields.join(',') !== displayField.join(',')) {
            setDisplayfields(fields);
            setFieldSelectorKeyProp(prevKey => prevKey + 1);
          }
        }}
        open={openDetails}
        setOpen={setOpenDetails}
      />
    ),
    [fieldSelectorKeyProp, fieldSelector, openDetails, displayField]
  );

  const filteredTableRows = selectedRowTableData.reduce((result, row) => {
    const rowValues = Array.isArray(row.value) ? row.value : [row.value];
    const isValidField = row.field !== 'selected';

    rowValues.forEach(value => {
      if (isValidField && isNonEmptyAndValid(value)) {
        result.push({ field: row.field, value });
      }
    });

    return result;
  }, []);

  // Updates the selected child rows based on current selections
  const updateSelectedChildRows = (currentSelectedChildRows: EventsData[], currentSelectedRows: EventsData[]): EventsData[] => {
    const updatedChildRows: EventsData[] = [
      ...currentSelectedChildRows,
      ...currentSelectedRows.filter(row => !currentSelectedChildRows.some(childRow => childRow.id === row.id))
    ];
    return updatedChildRows;
  };

  // Toggles selection of child rows and manages the selected child rows state
  const updateChildRowSelection = useCallback(
    (id: string, row: EventsData, updatedChildRows: EventsData[]) => {
      const clickedChildRowIndex = updatedChildRows.findIndex(
        row => row.id === id
      );
      if (clickedChildRowIndex === -1) {
        row.selected = true;
        updatedChildRows.push(row);
        getEventData(row);
      } else {
        row.selected = !row.selected;
        updatedChildRows.splice(clickedChildRowIndex, 1);
      }
      setSelectedChildRows(updatedChildRows);
    }, [getEventData]
  )
  // Retrieves selected rows data based on updated child rows
  const getSelectedRowsData = useCallback((updatedChildRows: EventsData[]) => {
    const rows = updatedChildRows.filter(updatedRow => updatedRow.selected);
    return computeDisplayFields(rows, displayField);
  }, [computeDisplayFields, displayField]);

  // Toggles row selection and fetches data based on the row and its child status
  const toggleRowSelectionAndFetchData = useCallback(
    (id: string, row: EventsData, isChildRow: boolean = false) => {
      const updatedRows = [...selectedRows];
      const updatedChildRows = updateSelectedChildRows(selectedChildRows, selectedRows);
      // Find the index of the clicked row within the updated rows array
      const clickedRowIndex = updatedRows.findIndex(row => row.id === id);
      if (clickedRowIndex !== -1) {
        // Toggle the selection status of the clicked row
        const clickedRow = updatedRows[clickedRowIndex];
        clickedRow.selected = !clickedRow.selected;
        if (clickedRow.selected) {
          getEventData(row);
        }
      }
      // Update the state with the modified selected rows
      setSelectedRows(updatedRows);

      if (isChildRow) {
        updateChildRowSelection(id, row, updatedChildRows);
      }

      const selectedRowsData = getSelectedRowsData(updatedChildRows);
      setSelectedRowTableDataOrig(selectedRowsData.fields);
      setSelectedRowTableData(selectedRowsData.filterFields);
    },
    [getEventData, getSelectedRowsData, selectedChildRows, selectedRows, setSelectedRowTableData, setSelectedRowTableDataOrig, setSelectedRows, updateChildRowSelection]
  );

  return (
    <OverlayComponent
      isRendered={isRendered}
      setIsRendered={setIsRendered}
      showOffCanvas={showOffCanvas}
      onClose={closeOffCanvas}
    >
      {selectedRows && selectedRows.length > 0 ? (
        <div className={css.aseSummaryContainer}>
          <div className={css.aseImageContainer}>
            <HeadSvg className={css.headIcon} />
            <h3 className={css.aseSummary}>ASE Summary</h3>
          </div>
          {smartEventState.status === AIJobStatus.COMPLETE ? (
            <div className={css.eventDesc}>{smartEventState.data}</div>
          ) : (
            <div className={css.loaderContainer}>
              <Loader className={css.loaderIcon} />
            </div>
          )}
          {selectedRows.map(row => (
            <div key={row.id}>
              {row.event.kind === 'finding' ? (
                <Tree
                  expandedIcon={<ExpandedIcon />}
                  collapsedIcon={<CollapsedIcon />}
                  className={css.rowStyle}
                >
                  <EventTreeNode
                    row={row}
                    handleDeleteRow={handleDeleteRow}
                    toggleRowSelectionAndFetchData={
                      toggleRowSelectionAndFetchData
                    }
                    selectedVendorAccount={selectedVendorAccount}
                  />
                </Tree>
              ) : (
                <div
                  className={`${css.rowStyle} ${row.selected && css.selected}`}
                  onClick={event => {
                    event.stopPropagation();
                    toggleRowSelectionAndFetchData(row.id, row);
                  }}
                >
                  <div className={css.rowDetails}>
                    <EventIcons kind={row.event.kind} />
                    <div>{row.message ? row.message : row.id}</div>
                  </div>
                  <CloseIcon
                    onClick={event => {
                      event.stopPropagation();
                      handleDeleteRow(row.id);
                    }}
                  />
                </div>
              )}
            </div>
          ))}
          <div className={css.buttonsContainer}>
            <Button
              variant="outline"
              size="small"
              onClick={() => setOpenDetails(!openDetails)}
              className={css.fieldButton}
            >
              Fields
            </Button>
            {renderTableDetailsButtons}
          </div>
          {showOffCanvas && selectedRowTableData.length > 0 && (
            <div className={classNames(css.tableContainer, css.canvaTable)}>
              <AgTable
                columnDefs={selectedRowColumns}
                rowData={filteredTableRows}
                rowSelection="multiple"
                rowMultiSelectWithClick={true}
                defaultColDef={EventDrillColDef}
                height={550}
              />
            </div>
          )}
        </div>
      ) : (
        <MotionItem className={css.emptyAlert}>
          <EmptyState
            illustration={<EmptyInsights />}
            title="No Selected Event found"
            subtitle="Looks like there's nothing here at the moment."
          />
        </MotionItem>
      )}
    </OverlayComponent>
  );
};
