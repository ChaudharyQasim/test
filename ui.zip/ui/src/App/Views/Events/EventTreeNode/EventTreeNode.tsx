import { FC, useState } from 'react';
import { useMutation } from 'react-query';

import { TreeNode } from 'reablocks';
import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';

import { EventsData, FormattedTableData } from 'App/Views/View.type';

import { getViewTableData } from 'core/Api/ViewApi';
import {
  ConditionGroup,
  ConditionOperatorEnum,
  FieldEnum,
  GetEvents,
  OperationsEnum,
  TypeEnum,
  VendorAccountOut
} from 'core/Api';
import { ConditionType } from 'shared/elements/EventCondition';

import css from '../OffCanvas/OffCanvas.module.css';
import { EventIcons } from '../EventIcons/EventIcons';
import { DEFAULT_COLUMNS } from 'App/Rules/constants';

const constructCondition = (relatedEventIds: string, selectedVendorAccount:VendorAccountOut): GetEvents => {
  return {
    start_time: '2000-01-01T00:00:00.000Z',
    end_time: '3000-12-31T00:00:00.000Z',
    vendor_account_id: selectedVendorAccount.nanoid,
    condition: {
      operator: ConditionOperatorEnum.And,
      conditions: [
        {
          field: FieldEnum.Id,
          field_operation: OperationsEnum.EQUALS,
          fieldType: TypeEnum.String,
          caseSensitive: false,
          value: relatedEventIds
        } as ConditionType
      ],
      groups: []
    } as ConditionGroup,
    page_number: 1,
    selected_fields: [...DEFAULT_COLUMNS]
  };
};

interface EventTreeNodeProps {
  row: EventsData;
  handleDeleteRow: (rowId: string) => void;
  isChild?: boolean;
  selectedVendorAccount:VendorAccountOut
  toggleRowSelectionAndFetchData: (
    id: string,
    row: EventsData,
    isChildRow?: boolean
  ) => void;
}

export const EventTreeNode: FC<EventTreeNodeProps> = ({
  row,
  handleDeleteRow,
  toggleRowSelectionAndFetchData,
  isChild = false,
  selectedVendorAccount
}) => {
  const [relatedEvents, setRelatedEvents] = useState<EventsData[]>([]);
  const { mutate: fetchRelatedEventsMutation, isLoading } = useMutation(
    (relatedEventIds: string) =>
      getViewTableData(constructCondition(relatedEventIds, selectedVendorAccount)),
    {
      onSuccess: (data: FormattedTableData) => {
        const newRelatedEvents = data.events;

        // Filter out the items that already exist in relatedEvents based on the id
        const existingIds = relatedEvents.map(event => event.id);
        const uniqueNewRelatedEvents = newRelatedEvents.filter(
          event => !existingIds.includes(event.id)
        );
        const updatedRelatedEvents = [
          ...relatedEvents,
          ...uniqueNewRelatedEvents
        ];

        setRelatedEvents(updatedRelatedEvents);
      },
    }
  );

  const filterFindingEvents = (rowIds: string[]) => {
    if (rowIds.length > 0) {
      const rowId = rowIds[0];
      fetchRelatedEventsMutation(rowId);
    }
  };

  return (
    <TreeNode
      className="tree-node"
      onExpand={() => filterFindingEvents(row?.abstract.related_events)}
      label={
        <div
          className={`${css.rowStyle} ${row?.selected && css.selected}`}
          onClick={event => {
            event.stopPropagation();
            toggleRowSelectionAndFetchData(row?.id, row, isChild);
          }}
        >
          <EventIcons kind={row?.event.kind} />
          <div>{row?.message || row?.id}</div>
          {!isChild && (
            <CloseIcon
              onClick={event => {
                event.stopPropagation();
                handleDeleteRow(row?.id);
              }}
            />
          )}
        </div>
      }
    >
      {row &&
        row.abstract &&
        row.abstract.related_events &&
        row.abstract.related_events.map((related_event_id: string) => {
          const related_event = relatedEvents.find(
            relatedEvent => relatedEvent.id === related_event_id
          );

          return (
            <EventTreeNode
              key={related_event_id}
              row={related_event}
              handleDeleteRow={handleDeleteRow}
              toggleRowSelectionAndFetchData={toggleRowSelectionAndFetchData}
              isChild
              selectedVendorAccount={selectedVendorAccount}
            />
          );
        })}
    </TreeNode>
  );
};
