import { FC } from 'react';
import { ReactComponent as KindEvent } from 'assets/icons/kind-event.svg';
import { ReactComponent as KindFinding } from 'assets/icons/kind-finding.svg';
import { ReactComponent as KindMetric } from 'assets/icons/kind-metric.svg';
import { ReactComponent as KindPipeline } from 'assets/icons/kind-pipeline.svg';
import { ReactComponent as KindState } from 'assets/icons/kind-state.svg';
import { ReactComponent as KindAlert } from 'assets/icons/kind-alert.svg';
import { ReactComponent as KindAsset } from 'assets/icons/kind-asset.svg';
import { ReactComponent as KindEnrichment } from 'assets/icons/kind-enrichment.svg';

import { EVENTS_KIND_TYPES } from 'App/Rules/constants';
import css from './EventsIcons.module.css';

interface EventIconsProps {
  kind: string;
}

export const EventIcons: FC<EventIconsProps> = ({ kind }) => {
  switch (kind) {
    case EVENTS_KIND_TYPES.EVENT:
      return <KindEvent className={css.icon} />;
    case EVENTS_KIND_TYPES.ASSET:
      return <KindAsset className={css.icon} />;
    case EVENTS_KIND_TYPES.METRIC:
      return <KindMetric className={css.icon} />;
    case EVENTS_KIND_TYPES.STATE:
      return <KindState className={css.icon} />;
    case EVENTS_KIND_TYPES.ALERT:
      return <KindAlert className={css.icon} />;
    case EVENTS_KIND_TYPES.ENRICHMENT:
      return <KindEnrichment className={css.icon} />;
    case EVENTS_KIND_TYPES.PIPELINE:
      return <KindPipeline className={css.icon} />;
    case EVENTS_KIND_TYPES.FINDING:
      return <KindFinding className={css.icon} />;
    default:
      return null;
  }
};

