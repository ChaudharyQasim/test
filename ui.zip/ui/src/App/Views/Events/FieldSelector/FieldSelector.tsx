import {
  Dispatch,
  FC,
  SetStateAction,
  useCallback,
  useEffect,
  useMemo,
  useState,
  memo,
  CSSProperties
} from 'react';
import { FixedSizeList as List, areEqual } from 'react-window';
import css from './FieldSelector.module.css';
import { Button, Stack, Tree, TreeNode, VerticalSpacer } from 'reablocks';
import { Dialog } from 'shared/layers/Dialog';
import { SearchInput } from 'shared/form/Input';
import { Checkbox } from 'shared/form/Checkbox';
import { ReactComponent as ExpandedIcon } from 'assets/icons/chevron-filled-down.svg';
import { ReactComponent as CollapsedIcon } from 'assets/icons/chevron-filled-right.svg';
import { DEFAULT_COLUMNS } from 'App/Rules/constants';
import { ConditionType } from 'shared/elements/EventCondition';
import { SelectedFields } from './SelectedFields';

interface FieldSelectorProps {
  fieldGroups: { [key: string]: string[] };
  preSelectedFields: string[];
  onClose: (selectedFields: string[]) => void;
  open: boolean;
  setOpen: Dispatch<SetStateAction<boolean>>;
  updateEventsData?: (
    conditions: ConditionType[],
    baseOperator: 'and' | 'or',
    timestamp: string | [string, string] | null,
    selectedFields: string[]
  ) => void;
  baseOperator?: 'and' | 'or';
  conditions?: ConditionType[];
  timestamp?: string | [string, string] | null;
}

const Row = memo(
  ({
    index,
    style,
    data
  }: {
    index: number;
    style: CSSProperties;
    data: any;
  }) => {
    const {
      allFields,
      groupNames,
      renderedFields,
      selectedFields,
      updateSelectedFields
    } = data;
    const field = allFields[index];
    const groupName = groupNames.find(name =>
      renderedFields[name].includes(field)
    );
    const groupIndex = groupNames.indexOf(groupName);

    return (
      <div style={style}>
        <Checkbox
          key={groupName + field}
          checked={selectedFields?.includes(field)}
          label={field}
          onChange={val =>
            updateSelectedFields(field, val, groupName, groupIndex)
          }
        />
      </div>
    );
  },
  areEqual
);

export const FieldSelector: FC<FieldSelectorProps> = ({
  fieldGroups,
  preSelectedFields,
  onClose,
  open,
  setOpen,
  updateEventsData,
  baseOperator,
  conditions,
  timestamp
}) => {
  const [value, setValue] = useState<string>('');
  const [showOnlySelectedFields, setShowOnlySelectedFields] =
    useState<boolean>(false);
  const [groupMode, setGroupMode] = useState(true);

  const [selectedFields, setSelectedFields] = useState<string[] | null>(
    preSelectedFields?.filter(x => x) || []
  );

  const [groupNames, setGroupNames] = useState<string[]>(
    Object.keys(fieldGroups)
  );
  const [renderedFields, setRenderedFields] = useState<{
    [key: string]: string[];
  }>(fieldGroups);
  const [groupNameChecked, setGroupNameChecked] = useState<boolean[]>(
    Array(Object.keys(fieldGroups).length).fill(false)
  );
  const [groupNameIntermediate, setGroupNameIntermediate] = useState<boolean[]>(
    Array(Object.keys(fieldGroups).length).fill(false)
  );
  const allFields = Object.values(fieldGroups).flat();

  const initTree = useCallback(
    (fieldGroup: { [key: string]: string[] }, fields: string[]) => {
      const updatedGroupNameChecked = [];
      const updatedGroupNameIntermediate = [];

      Object.keys(fieldGroup).forEach((groupName, groupIndex) => {
        const allFieldsInSameGroup = fieldGroups[groupName];
        const isCompleteGroupSelected =
          allFieldsInSameGroup.length > 0 &&
          allFieldsInSameGroup.every(val => fields.includes(val));
        const isAnyFieldInGroupSelected =
          allFieldsInSameGroup.length > 0 &&
          allFieldsInSameGroup.some(val => fields.includes(val));

        if (isCompleteGroupSelected) {
          updatedGroupNameChecked[groupIndex] = true;
          updatedGroupNameIntermediate[groupIndex] = false;
        } else if (isAnyFieldInGroupSelected) {
          updatedGroupNameChecked[groupIndex] = true;
          updatedGroupNameIntermediate[groupIndex] = true;
        } else {
          updatedGroupNameChecked[groupIndex] = false;
          updatedGroupNameIntermediate[groupIndex] = false;
        }
      });

      setGroupNameChecked(updatedGroupNameChecked);
      setGroupNameIntermediate(updatedGroupNameIntermediate);
    },
    [fieldGroups]
  );

  useEffect(() => {
    // on initial render
    initTree(fieldGroups, preSelectedFields);
  }, [fieldGroups, initTree, preSelectedFields]);

  const onReset = () => {
    setValue('');
    setSelectedFields(DEFAULT_COLUMNS?.filter(x => x) || []);
    setGroupNames(Object.keys(fieldGroups));
    setRenderedFields(fieldGroups);
    setGroupNameChecked(Array(Object.keys(fieldGroups).length).fill(false));
    setGroupNameIntermediate(
      Array(Object.keys(fieldGroups).length).fill(false)
    );
    initTree(fieldGroups, DEFAULT_COLUMNS);
  };

  const updateRenderedGroupNames = useCallback(
    (searchInput: string, showAll: boolean) => {
      const updatedRenderedFields: { [key: string]: string[] } = {};
      for (const groupName in fieldGroups) {
        const fields = fieldGroups[groupName];
        for (const field of fields) {
          const shouldShowThisField =
            showAll || (!showAll && selectedFields.includes(field));
          if (
            field.toLowerCase().includes(searchInput) &&
            shouldShowThisField
          ) {
            if (!updatedRenderedFields[groupName]) {
              updatedRenderedFields[groupName] = [];
            }
            const subFields = updatedRenderedFields[groupName];
            subFields.push(field);
            updatedRenderedFields[groupName] = subFields;
          }
        }
      }
      const updatedGroupNames = Object.keys(updatedRenderedFields);
      setGroupNames(updatedGroupNames);
      setRenderedFields(updatedRenderedFields);
      initTree(updatedRenderedFields, selectedFields);
    },
    [fieldGroups, initTree, selectedFields]
  );

  const updateGroupState = useCallback(
    (state: boolean, index: number) => {
      const updatedState = [...groupNameChecked];
      updatedState[index] = state;
      setGroupNameChecked(updatedState);
    },
    [groupNameChecked]
  );

  const updateGroupIntermediate = useCallback(
    (state: boolean, index: number) => {
      const updatedState = [...groupNameIntermediate];
      updatedState[index] = state;
      setGroupNameIntermediate(updatedState);
    },
    [groupNameIntermediate]
  );

  const refreshGroupCheckboxState = useCallback(
    (groupName: string, groupIndex: number, selectedFields: string[]) => {
      const allFieldsInSameGroup = fieldGroups[groupName];
      const isCompleteGroupSelected =
        allFieldsInSameGroup.length > 0 &&
        allFieldsInSameGroup.every(val => selectedFields.includes(val));
      const isAnyFieldInGroupSelected =
        allFieldsInSameGroup.length > 0 &&
        allFieldsInSameGroup.some(val => selectedFields.includes(val));

      if (isCompleteGroupSelected) {
        updateGroupState(true, groupIndex);
        updateGroupIntermediate(false, groupIndex);
      } else if (isAnyFieldInGroupSelected) {
        updateGroupState(true, groupIndex);
        updateGroupIntermediate(true, groupIndex);
      } else {
        updateGroupState(false, groupIndex);
        updateGroupIntermediate(false, groupIndex);
      }
    },
    [fieldGroups, updateGroupIntermediate, updateGroupState]
  );

  const updateSelectedFields = useCallback(
    (
      field: string,
      checked: boolean,
      groupName: string,
      groupIndex: number
    ) => {
      let updatedFields = [...selectedFields];
      if (!checked && updatedFields?.includes(field)) {
        updatedFields = updatedFields.filter(x => x != field);
      } else {
        updatedFields = updatedFields.concat(field);
      }
      setSelectedFields(updatedFields);
      // Refresh the state of the parent group
      refreshGroupCheckboxState(groupName, groupIndex, updatedFields);
    },
    [refreshGroupCheckboxState, selectedFields]
  );

  const updateGroupFields = useCallback(
    (checked: boolean, groupName: string, groupIndex: number) => {
      const fields = fieldGroups[groupName];
      let updatedFields = [...selectedFields];
      for (const field of fields) {
        if (!checked && updatedFields?.includes(field)) {
          updatedFields = updatedFields.filter(x => x != field);
        } else if (checked && !updatedFields?.includes(field)) {
          updatedFields = updatedFields.concat(field);
        }
      }

      setSelectedFields(updatedFields);
      // Refresh the state of the parent group
      refreshGroupCheckboxState(groupName, groupIndex, updatedFields);
    },
    [fieldGroups, refreshGroupCheckboxState, selectedFields]
  );

  const renderFields = useCallback(
    (groupName: string, groupIndex: number) => {
      const fields = renderedFields[groupName];
      return fields?.map((field, index) => (
        <TreeNode
          key={groupName + field}
          label={
            <Checkbox
              checked={selectedFields?.includes(field)}
              label={field}
              onChange={val =>
                updateSelectedFields(field, val, groupName, groupIndex)
              }
            />
          }
        />
      ));
    },
    [renderedFields, selectedFields, updateSelectedFields]
  );

  const renderFieldGroups = useMemo(() => {
    if (groupMode) {
      return (
        <Tree expandedIcon={<ExpandedIcon />} collapsedIcon={<CollapsedIcon />}>
          {groupNames?.length > 0 ? (
            groupNames.map((groupName, index) => (
              <TreeNode
                key={groupName}
                label={
                  <Checkbox
                    checked={groupNameChecked[index]}
                    label={groupName}
                    onChange={val => updateGroupFields(val, groupName, index)}
                    intermediate={groupNameIntermediate[index]}
                  />
                }
              >
                {renderFields(groupName, index)}
              </TreeNode>
            ))
          ) : (
            <div>No matching fields {showOnlySelectedFields && 'selected'}</div>
          )}
        </Tree>
      );
    }

    const itemData = {
      allFields,
      renderedFields,
      groupNames,
      selectedFields,
      updateSelectedFields
    };

    return (
      <>
        {groupNames?.length > 0 ? (
          <List
            height={428}
            itemCount={allFields.length}
            itemSize={24.25}
            width={349}
            itemData={itemData}
          >
            {Row}
          </List>
        ) : (
          <div>No matching fields {showOnlySelectedFields && 'selected'}</div>
        )}
      </>
    );
  }, [
    groupNameChecked,
    groupNameIntermediate,
    groupNames,
    renderFields,
    renderedFields,
    showOnlySelectedFields,
    updateGroupFields,
    selectedFields,
    updateSelectedFields,
    groupMode,
    allFields
  ]);

  const renderFooter = (
    <Stack justifyContent="spaceBetween" className={css.footer}>
      <Button variant="outline" size="small" onClick={onReset}>
        Reset
      </Button>
      <Stack>
        <Button
          variant="outline"
          size="small"
          onClick={() => closeDialog(preSelectedFields)}
        >
          Cancel
        </Button>
        <Button
          variant="filled"
          size="small"
          onClick={() => onDone(selectedFields)}
          color="primary"
          disabled={selectedFields.length === 0}
        >
          Done
        </Button>
      </Stack>
    </Stack>
  );

  const closeDialog = (fields: string[]) => {
    setOpen(false);
    onClose(fields);
  };

  const onDone = (fields: string[]) => {
    if (updateEventsData && preSelectedFields.length < selectedFields.length) {
      updateEventsData(conditions, baseOperator, timestamp, selectedFields);
    }
    setOpen(false);
    onClose(fields);
  };

  const toggleSelectedFieldsVisibility = useCallback(() => {
    setShowOnlySelectedFields(!showOnlySelectedFields);
    updateRenderedGroupNames(value.toLowerCase(), showOnlySelectedFields);
  }, [showOnlySelectedFields, updateRenderedGroupNames, value]);

  const handleFieldsOrderChange = (fields: string[]) => {
    setSelectedFields([...fields]);
  };

  useEffect(() => {
    // remove field from view once it's unchecked
    if (showOnlySelectedFields) {
      updateRenderedGroupNames(value.toLowerCase(), false);
    }
  }, [selectedFields, showOnlySelectedFields, updateRenderedGroupNames, value]);

  return (
    <>
      <Dialog
        open={open}
        onClose={() => closeDialog(preSelectedFields)}
        footer={renderFooter}
        size={800}
        contentClassName={css.dialogWrapper}
      >
        <div className={css.leftWrapper}>
          <h5 className={css.title}>Available Fields</h5>
          <div className={css.availableView}>
            <Stack justifyContent="spaceBetween">
              <SearchInput
                containerClassname={css.input}
                value={value}
                onValueChange={value => {
                  updateRenderedGroupNames(
                    value.toLowerCase(),
                    !showOnlySelectedFields
                  );
                  setValue(value);
                }}
                placeholder="Find..."
                fullWidth
              />

              <Checkbox
                checked={groupMode}
                label="Group Fields"
                onChange={setGroupMode}
                containerClassName={css.groupModeCheckbox}
                labelClassName={css.groupModeCheckboxLabel}
              />
            </Stack>
            <VerticalSpacer space="lg" />
            {renderFieldGroups}
          </div>
        </div>
        <div className={css.rightWrapper}>
          <h5 className={css.title}>Selected Fields</h5>
          <div className={css.selectedViewList}>
            <SelectedFields
              selected={selectedFields}
              onSelectedChange={handleFieldsOrderChange}
            />
          </div>
        </div>
      </Dialog>
    </>
  );
};
