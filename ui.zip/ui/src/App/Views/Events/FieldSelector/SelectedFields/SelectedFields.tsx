import { useCallback, useEffect, useState } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { FieldItem } from './FieldItem';

export interface Item {
  id: string;
  text: string;
}

interface SelectedFieldsProps {
  selected: string[];
  onSelectedChange: (selected: string[]) => void;
}

export const SelectedFields = ({
  selected,
  onSelectedChange
}: SelectedFieldsProps) => {
  {
    const [fields, setFields] = useState<Item[]>([]);

    useEffect(() => {
      setFields(selected.map((fieldName) => ({ id: fieldName, text: fieldName })));
    }, [selected]);

    const moveField = useCallback(
      (dragIndex: number, hoverIndex: number) => {
        const updatedFields = [...fields];
        const dragField = updatedFields[dragIndex];
        updatedFields.splice(dragIndex, 1);
        updatedFields.splice(hoverIndex, 0, dragField);
        setFields([...updatedFields]);
        onSelectedChange([...updatedFields.map(fieldItem => fieldItem.text)]);
      },
      [fields, onSelectedChange]
    );

    return (
      <DndProvider backend={HTML5Backend}>
        {fields.map((field, i) => (
          <FieldItem
            key={field.id}
            index={i}
            id={field.id}
            text={field.text}
            moveField={moveField}
          />
        ))}
      </DndProvider>
    );
  }
};
