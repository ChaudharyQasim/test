import { EVENTS_KIND_TYPES } from 'App/Rules/constants';

type FlattenedObject = {
  [key: string]: any;
};

export type FieldValuePair = {
  field: string;
  value: string | string[] | boolean | null;
};

export type EventKind = keyof typeof EVENTS_KIND_TYPES;

export const flattenObject = (
  nestedObj: Record<string, any>,
  prefix = ''
): FlattenedObject =>
  Object.entries(nestedObj).reduce(
    (flattenedObj, [key, value]: [string, any]) => {
      // Prepare the prefix for the current key
      const pre = prefix.length ? `${prefix}.` : '';

      // Check if the value is a non-null object (excluding arrays)
      if (
        typeof value === 'object' &&
        value !== null &&
        !Array.isArray(value)
      ) {
        // Recursively flatten nested objects
        Object.assign(flattenedObj, flattenObject(value, `${pre}${key}`));
      } else {
        // Assign the flattened key-value pair to the object
        flattenedObj[`${pre}${key}`] = value;
      }

      return flattenedObj;
    },
    {}
  );

// Format nested objects into field-value pairs
export const formatNestedObjects = (
  fields: Record<string, any>
): FieldValuePair[] => {
  const formattedFields: FieldValuePair[] = [];
  Object.entries(fields).forEach(([field, value]) => {
    if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
      // Recursively format nested fields
      const nestedFields = formatNestedObjects(value);
      // Flatten and push nested fields into the formattedFields array
      formattedFields.push(
        ...nestedFields.map(nestedField => ({
          field: `${field}.${nestedField.field}`,
          value: nestedField.value
        }))
      );
    } else {
      // Push non-nested field-value pairs into the formattedFields array
      formattedFields.push({ field, value });
    }
  });
  return formattedFields;
};

// Find common fields among multiple rows
export const findCommonFields = (
  objects: Record<string, any>[]
): Record<string, any> => {
  const flattenedObjs = objects.map(obj => flattenObject(obj));
  const commonFields: Record<string, any> = {};

  // Function to get nested value from an object using dot notation
  const getNestedValue = (obj: Record<string, any>, field: string): any => {
    const keys = field.split('.');
    return keys.reduce(
      (result, key) => (result && key in result ? result[key] : null),
      obj
    );
  };

  // Get all unique keys from all objects
  const keysInObjects = flattenedObjs
    .map(Object.keys)
    .flat()
    .filter((value, index, self) => self.indexOf(value) === index);

  // Iterate through keys to find common fields
  keysInObjects.forEach(key => {
    const valuesForKey = objects.map(obj => getNestedValue(obj, key));
    const isCommon = valuesForKey.every(
      (value, _, arr) => JSON.stringify(value) === JSON.stringify(arr[0])
    );
    if (isCommon) {
      commonFields[key] = valuesForKey[0];
    }
  });

  return commonFields;
};

export const isNonEmptyAndValid = rowValue => {
  return (
    rowValue !== null &&
    rowValue !== undefined &&
    rowValue !== '' &&
    (!Array.isArray(rowValue) ||
      (Array.isArray(rowValue) && rowValue.length > 0))
  );
};

// Get common fields among the provided rows
export const getCommonFields = (
  rows: Record<string, any>[],
  isDetailClicked: boolean = false
): FieldValuePair[] => {
  let commonFields = [];
  if ((rows.length === 1 && rows.some(row => row.selected === true)) || isDetailClicked) {
    // If there's only one row or detail is clicked, extract fields and values
    const flattenedObj = flattenObject(rows[0]);
    commonFields = Object.entries(flattenedObj).map(([field, value]) => ({
      field,
      value: [value]
    }));
  } else if (rows.length > 1 && rows.some(row => row.selected === true)) {
    const foundFields = findCommonFields(rows);
    commonFields = formatNestedObjects(foundFields);
  }

  return commonFields;
};