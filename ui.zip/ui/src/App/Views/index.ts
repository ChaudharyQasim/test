export { ViewsContainer as default } from './ViewsContainer';
