import {
  Block,
  Select,
  SelectOption,
  Stack,
  Tooltip,
  Tree,
  TreeNode,
  useNotification
} from 'reablocks';
import { StyledCard } from 'shared/layout/Card';
import css from './SchemaExplorer.module.css';
import classNames from 'classnames';
import { useCallback, useMemo, useState } from 'react';
import { ReactComponent as CollapsedIcon } from 'assets/icons/chevron-filled-right.svg';
import { ReactComponent as CollapsedExplorerIcon } from 'assets/icons/chevron-filled-left.svg';
import { ReactComponent as ExpandedIcon } from 'assets/icons/chevron-filled-down.svg';
import { ReactComponent as StringIcon } from 'assets/icons/stringIcon.svg';
import { ReactComponent as SearchIcon } from 'assets/icons/search.svg';
import { SearchInput } from 'shared/form/Input';
import { useQuery } from 'react-query';
import { getFields } from 'core/Api/AcsApi';
import { DEFAULT_COLUMNS } from 'App/Rules/constants';

export const Explorer = () => {
  const { notifyError } = useNotification();

  const [value, setValue] = useState<string>('');
  const [option, setOption] = useState<string>('All');
  const [collapseExplorer, setCollapseExplorer] = useState<boolean>(false);
  const [groupNames, setGroupNames] = useState<string[]>(null);
  const [renderedFields, setRenderedFields] = useState<{
    [key: string]: string[];
  }>(null);
  const [showOnlyPopulatedFields, setShowOnlyPopulatedFields] =
    useState<boolean>(false);
  const [selectedFields, setSelectedFields] = useState<string[] | null>(
    DEFAULT_COLUMNS?.filter(x => x) || []
  );

  const { data: fieldSelector } = useQuery('fieldSelector', () => getFields(), {
    onSuccess(data) {
      setGroupNames(Object.keys(data));
      setRenderedFields(data);
    },
    onError(error: any) {
      notifyError('Error occurred while getting field selectors');
    },
    initialData: {}
  });

  const initTree = useCallback(
    (fieldGroup: { [key: string]: string[] }, selectedFields: string[]) => {
      const updatedGroupCheckedStatus = [];
      const updatedGroupIntermediateStatus = [];
      Object.keys(fieldGroup).forEach((groupName, groupIndex) => {
        const fieldsInGroup = fieldSelector[groupName];
        const isGroupCompletelySelected =
          fieldsInGroup.length > 0 &&
          fieldsInGroup.every(field => selectedFields.includes(field));
        const isPartialGroupSelected =
          fieldsInGroup.length > 0 &&
          fieldsInGroup.some(field => selectedFields.includes(field));
        updatedGroupCheckedStatus[groupIndex] =
          isGroupCompletelySelected || isPartialGroupSelected;
        updatedGroupIntermediateStatus[groupIndex] =
          isPartialGroupSelected && !isGroupCompletelySelected;
      });
    },
    [fieldSelector]
  );

  const updateRenderedGroupNames = useCallback(
    (searchInput: string, showAll: boolean) => {
      const updatedRenderedFields: { [key: string]: string[] } = {};
      for (const groupName in fieldSelector) {
        const fields = fieldSelector[groupName];
        for (const field of fields) {
          const shouldShowThisField =
            showAll || (!showAll && selectedFields.includes(field));
          if (
            field.toLowerCase().includes(searchInput) &&
            shouldShowThisField
          ) {
            if (!updatedRenderedFields[groupName]) {
              updatedRenderedFields[groupName] = [];
            }
            const subFields = updatedRenderedFields[groupName];
            subFields.push(field);
            updatedRenderedFields[groupName] = subFields;
          }
        }
      }
      const updatedGroupNames = Object.keys(updatedRenderedFields);
      setGroupNames(updatedGroupNames);
      setRenderedFields(updatedRenderedFields);
      initTree(updatedRenderedFields, selectedFields);
    },
    [fieldSelector, initTree, selectedFields]
  );

  const renderField = useCallback(
    (groupName: string) =>
      (renderedFields[groupName] || []).map((field, index) => (
        <TreeNode
          key={`${groupName}-${field}`}
          label={
            <Tooltip content={field}>
              <Block className={css.fieldsText}>
                <StringIcon className={css.fieldIcon} />
                <div className={css.attributes}>{field}</div>
              </Block>
            </Tooltip>
          }
          className={css.fieldsTreeNode}
        />
      )),
    [renderedFields]
  );

  const renderFieldGroups = useMemo(() => {
    return (
      <Tree
        expandedIcon={<ExpandedIcon />}
        collapsedIcon={<CollapsedIcon />}
        className={css.fieldsTree}
      >
        {groupNames &&
          groupNames.length > 0 &&
          groupNames.map((groupName, index) => (
            <TreeNode
              key={groupName}
              label={
                <Stack className={css.groupHeadings}>
                  {groupName}
                  {renderedFields[groupName]?.length > 0 && (
                    <div className={css.groupLength}>
                      {renderedFields[groupName].length}
                    </div>
                  )}
                </Stack>
              }
              className={css.groupFields}
            >
              {renderField(groupName)}
            </TreeNode>
          ))}
      </Tree>
    );
  }, [groupNames, renderField, renderedFields]);

  // TODO: uncomment this function when populated fields functionality required

  // const toggleSelectedFieldsVisibility = useCallback(() => {
  //   setShowOnlyPopulatedFields(!showOnlyPopulatedFields);
  //   updateRenderedGroupNames(value.toLowerCase(), showOnlyPopulatedFields);
  // }, [showOnlyPopulatedFields, updateRenderedGroupNames, value]);

  const renderSearchField = useMemo(() => {
    return (
      <Stack className={css.selectFields}>
        <Select
          className={css.select}
          clearable={false}
          placeholder="All"
          value={option}
          onChange={value => {
            setOption(value);
            // toggleSelectedFieldsVisibility();
          }}
        >
          <SelectOption value={'All'}>All</SelectOption>
          {/* <SelectOption value={'Populated'}>Populated</SelectOption> */}
        </Select>

        <SearchInput
          start={<SearchIcon />}
          containerClassname={css.searchInput}
          value={value}
          onValueChange={val => {
            updateRenderedGroupNames(
              val.toLowerCase(),
              !showOnlyPopulatedFields
            );
            setValue(val);
          }}
          placeholder="Find..."
        />
      </Stack>
    );
  }, [option, showOnlyPopulatedFields, updateRenderedGroupNames, value]);

  return (
    <StyledCard
      className={classNames(css.root, { [css.collapsed]: !collapseExplorer })}
    >
      <div className={css.header}>
        <div
          className={css.icons}
          onClick={() => setCollapseExplorer(!collapseExplorer)}
        >
          {collapseExplorer ? <CollapsedExplorerIcon /> : <ExpandedIcon />}
        </div>
        {collapseExplorer && <Stack className={css.headerText}>Explorer</Stack>}
      </div>
      {collapseExplorer && (
        <>
          {renderSearchField}
          {renderFieldGroups}
        </>
      )}
    </StyledCard>
  );
};
