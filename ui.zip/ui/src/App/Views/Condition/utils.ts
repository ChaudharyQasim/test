import { ConditionType } from 'shared/elements/EventCondition';
import { ValueType } from 'shared/elements/EventCondition/utils';

export const mockConditions = [
  {
    id: '2D04NwPo8VdTlDjiPWGMf',
    field: 'event.dataset',
    field_operation: 'EQUALS',
    value: 'testDataset'
  },
  {
    id: '8deT0GKMRCX_SJLjVJIjE',
    field: 'event.count',
    field_operation: 'IN_RANGE',
    value: [2, 10]
  },
  {
    id: 'JNfIKFBF86YsqcGdZcjpX',
    field: 'event.active',
    field_operation: 'IS_TRUE',
    value: ''
  },
  {
    id: 'ZQRlRi3wmUGHyV3Qzf8MH',
    field: 'event.createdAt',
    field_operation: 'IN_RANGE',
    value: ['2023-10-10T07:00:00.000Z', '2023-10-31T07:00:00.000Z']
  },
  {
    id: 'E4sGxOS8_3pvlX_Qs1MfE',
    field: 'destination.geo.location',
    field_operation: 'IN_RANGE',
    value: {
      range: 100,
      lat: -50,
      long: 150
    }
  },
  {
    id: 'VBm9RI13gM4knjVefWzQw',
    operator: 'or',
    value: [
      {
        id: 'BHVKldS3YtYdjbS-G20I2',
        field: 'client.originIp',
        field_operation: 'IN_LIST',
        value: ''
      },
      {
        id: '5NspdP9eJOGWogH02JHhj',
        field: 'client.destinationIp',
        field_operation: 'NOT_IN_LIST',
        value: ''
      },
      {
        id: 'TyLue1W652BZvRBdpia62',
        operator: 'and',
        value: [
          {
            id: 'xNfIzS5ZUHq9wA7aHz_v2',
            field: 'event.count',
            field_operation: 'GREATER_THAN',
            value: 50
          }
        ]
      }
    ]
  }
];

/**
 * Get value to render based on the type of value
 * @param value
 */
export const getRenderValue = (value: ValueType) => {
  if (Array.isArray(value)) {
    return value.join(', ');
  }
  if (typeof value === 'object') {
    return Object.entries(value)
      .map(([key, val]) => `${key}=${val}`)
      .join(', ');
  }
  return value.toLocaleString();
};

/**
 * Returns the list of fields across all the conditions including the nested ones
 * @param conditions
 */
export const getFieldsFromConditions = (
  conditions: ConditionType[]
): string[] => {
  const fields: string[] = [];
  for (const condition of conditions) {
    if (condition?.field) {
      fields.push(condition?.field);
    }
    if (condition?.operator) {
      const nestedFields = getFieldsFromConditions(
        condition?.value as ConditionType[]
      );
      fields.push(...nestedFields);
    }
  }
  return fields;
};

/**
 * Returns the first 'n' conditions from the list of conditions
 * This includes the nested conditions
 * @param conditions
 * @param n Number of conditions
 * @returns List of conditions where each condition is a string fromed by `field field_operation value`
 */
export const getFirsNConditionsRow = (
  conditions: ConditionType[],
  n: number
): string[] => {
  const firstNConditions: string[] = [];
  for (const condition of conditions) {
    if (firstNConditions?.length === n) {
      return firstNConditions;
    }
    if (condition?.field && condition?.field_operation && condition?.value) {
      firstNConditions.push(
        [
          condition?.field,
          condition?.field_operation,
          getRenderValue(condition?.value as ValueType)
        ].join(' ')
      );
    }
    if (condition?.operator) {
      const nestedConditions = getFirsNConditionsRow(
        condition?.value as ConditionType[],
        n - firstNConditions?.length
      );
      firstNConditions.push(...nestedConditions);
    }
  }
  return firstNConditions;
};
