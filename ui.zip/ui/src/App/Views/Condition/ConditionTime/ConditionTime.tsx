import { DateFormat, Pluralize, Stack } from 'reablocks';
import { FC } from 'react';
import { LabelChip } from 'shared/elements/Chip';
import {
  EVENT_TIME_TYPES,
  FixedTime,
  Time
} from 'shared/elements/EventTime/utils';
import { DATE_FORMAT } from 'shared/utils/Constants';

interface ConditionTime {
  time: Time;
}

export const ConditionTime: FC<ConditionTime> = ({ time }) => {
  if (time.type === EVENT_TIME_TYPES.RANGE.value) {
    const [startTime, endTime]: [Date, Date] = time.timestamp as [Date, Date];
    return (
      <Stack dense>
        From
        <LabelChip>
          <DateFormat date={startTime} format={DATE_FORMAT} />
        </LabelChip>
        to
        <LabelChip>
          <DateFormat date={endTime} format={DATE_FORMAT} />
        </LabelChip>
      </Stack>
    );
  }
  if (time.type === EVENT_TIME_TYPES.RELATIVE.value) {
    const timestamp: FixedTime = time.timestamp as FixedTime;
    return (
      <Stack dense>
        Past
        <LabelChip>
          {timestamp?.value}
          &nbsp;
          <Pluralize
            count={timestamp.value}
            singular={timestamp?.unit}
            showCount={false}
            zero={timestamp?.unit}
          />
        </LabelChip>
      </Stack>
    );
  }
  if (time.type === EVENT_TIME_TYPES.REAL_TIME.value) {
    const timestamp: FixedTime = time.timestamp as FixedTime;
    return (
      <Stack dense>
        Now -
        <LabelChip>
          {timestamp?.value}
          &nbsp;
          <Pluralize
            count={timestamp.value}
            singular={timestamp?.unit}
            showCount={false}
            zero={timestamp?.unit}
          />
        </LabelChip>
      </Stack>
    );
  }
  return null;
};
