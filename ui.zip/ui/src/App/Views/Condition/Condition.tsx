import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as VerticalDots } from 'assets/icons/dots.svg';
import { ReactComponent as EditIcon } from 'assets/icons/edit-2.svg';
import { ReactComponent as RenameIcon } from 'assets/icons/pencil.svg';
import {
  Button,
  Card,
  List,
  ListItem,
  Pluralize,
  Stack,
  VerticalSpacer
} from 'reablocks';
import { FC, useCallback, useMemo, useRef, useState } from 'react';
import { Menu } from 'shared/layers/Menu';
import { StyledCard } from 'shared/layout/Card';
import css from './Condition.module.css';
import { ReactComponent as ExpandedIcon } from 'assets/icons/chevron-filled-down.svg';
import classNames from 'classnames';
import { ConditionType } from 'shared/elements/EventCondition';
import { LabelChip } from 'shared/elements/Chip';
import { ValueType } from 'shared/elements/EventCondition/utils';
import { getRenderValue } from './utils';
import { Time } from 'shared/elements/EventTime/utils';
import { ConditionTime } from './ConditionTime/ConditionTime';
import { ConditionsSummary } from './ConditionsSummary/ConditionsSummary';

interface ConditionProps {
  conditions: ConditionType[];
  onEdit: () => void;
  time: Time;
}

export const Condition: FC<ConditionProps> = ({ conditions, onEdit, time }) => {
  const [openConditionMenu, setOpenConditionMenu] = useState<boolean>(false);
  const buttonMenu = useRef<HTMLButtonElement | null>(null);
  const [conditionsExpanded, setConditionsExpanded] = useState<boolean>(false);

  const renderTableButtons = useMemo(
    () => (
      <Stack dense>
        <Button
          variant="text"
          size="small"
          onClick={() => setConditionsExpanded(!conditionsExpanded)}
        >
          <ExpandedIcon
            className={classNames(css.expandIcon, {
              [css.isExpanded]: conditionsExpanded
            })}
          />
        </Button>
        <Button
          variant="text"
          size="small"
          ref={buttonMenu}
          onClick={() => setOpenConditionMenu(!openConditionMenu)}
        >
          <VerticalDots />
        </Button>
        <Menu
          open={openConditionMenu}
          onClose={() => setOpenConditionMenu(false)}
          reference={buttonMenu}
          placement="bottom-end"
          autofocus={false}
        >
          <Card disablePadding>
            <List>
              <ListItem
                start={<EditIcon className={css.menuIcon} />}
                onClick={() => onEdit()}
              >
                Edit View
              </ListItem>
              {/* <ListItem
              start={<RenameIcon className={css.menuIcon}/>}
              onClick={() => console.log('rename')}
            >
              Rename View
            </ListItem>
            <ListItem
              start={<DeleteIcon className={css.menuIcon}/>}
              onClick={() => console.log('delete')}
            >
              Delete
            </ListItem> */}
            </List>
          </Card>
        </Menu>
      </Stack>
    ),
    [conditionsExpanded, onEdit, openConditionMenu]
  );

  const renderConditionRow = useCallback((condition: ConditionType) => {
    if (condition?.operator) {
      return (
        <Stack direction="column" alignItems="start">
          <Stack direction="row" alignItems="start" dense>
            <LabelChip variant="filled">{condition?.operator}</LabelChip>
            <div>of the following are true</div>
          </Stack>
          {(condition?.value as ConditionType[]).map(condition => (
            <div className={css.nestedCondition} key={condition?.id}>
              {renderConditionRow(condition)}
            </div>
          ))}
        </Stack>
      );
    } else {
      return (
        <Stack direction="row" dense>
          {condition?.field && (
            <LabelChip variant="filled">{condition?.field}</LabelChip>
          )}
          {condition?.field_operation && (
            <LabelChip variant="filled">{condition?.field_operation}</LabelChip>
          )}
          {condition?.value && (
            <LabelChip variant="filled">
              {getRenderValue(condition?.value as ValueType)}
            </LabelChip>
          )}
        </Stack>
      );
    }
  }, []);

  const renderConditionsExpanded = useCallback(() => {
    return (
      <>
        <Stack justifyContent="spaceBetween">
          <Stack dense>
            Events must match
            {conditions.length > 1 ? (
              <LabelChip variant="filled"> all/any </LabelChip>
            ) : (
              ' the '
            )}
            <Pluralize
              singular="condition"
              count={conditions.length}
              showCount={false}
              zero="condition"
            />
          </Stack>
          <ConditionTime time={time} />
        </Stack>
        <VerticalSpacer space="md" />
        <Stack direction="column" alignItems="start">
          {conditions.map(renderConditionRow)}
        </Stack>
      </>
    );
  }, [conditions, renderConditionRow, time]);

  const renderConditionsCollapsed = useCallback(
    () => <ConditionsSummary conditions={conditions} time={time} />,
    [conditions, time]
  );

  const renderConditions = useCallback(
    () =>
      conditionsExpanded
        ? renderConditionsExpanded()
        : renderConditionsCollapsed(),
    [conditionsExpanded, renderConditionsCollapsed, renderConditionsExpanded]
  );

  return (
    <StyledCard className={css.card}>
      <Stack justifyContent="spaceBetween">
        <h5 className={css.cardTitle}>Condition</h5>
        {renderTableButtons}
      </Stack>
      <VerticalSpacer space="lg" />
      <div className={css.conditionsContainer}>{renderConditions()}</div>
    </StyledCard>
  );
};
