import { Pluralize, Stack, VerticalSpacer } from 'reablocks';
import { FC } from 'react';
import { LabelChip } from 'shared/elements/Chip';
import { getFieldsFromConditions, getFirsNConditionsRow } from '../utils';
import { ConditionType } from 'shared/elements/EventCondition';
import css from './ConditionsSummary.module.css';
import { ConditionTime } from '../ConditionTime/ConditionTime';
import { Time } from 'shared/elements/EventTime/utils';

interface ConditionsSummaryProps {
  conditions: ConditionType[];
  time?: Time;
}

const numConditionsToShow = 5;

export const ConditionsSummary: FC<ConditionsSummaryProps> = ({
  conditions,
  time
}) => {
  const numFields = getFieldsFromConditions(conditions)?.length || 0;
  const firstNConditions = getFirsNConditionsRow(
    conditions,
    numConditionsToShow
  );

  return (
    <>
      <VerticalSpacer space="md" />
      <Stack direction="row" dense className={css.flexWrap}>
        {firstNConditions?.map(condition => (
          <LabelChip key={condition} variant="filled">
            {condition}
          </LabelChip>
        ))}
        {numFields > numConditionsToShow && (
          <LabelChip variant="filled">
            {`+ ${(numFields - numConditionsToShow).toLocaleString()}`}&nbsp;
            <Pluralize
              singular="Field"
              count={numFields - numConditionsToShow}
              showCount={false}
              zero="Field"
            />
          </LabelChip>
        )}{' '}
        {time && <ConditionTime time={time} />}
      </Stack>
    </>
  );
};
