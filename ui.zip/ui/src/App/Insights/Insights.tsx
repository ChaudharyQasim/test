import {
  FC,
  MutableRefObject,
  ChangeEvent,
  useEffect,
  useMemo,
  useRef,
  useState
} from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import { Count } from 'reaviz';
import { Button, DateFormat, PrimaryHeading, Stack, Text } from 'reablocks';
import { AgGridReact } from 'ag-grid-react';

// CSS
import css from './Insights.module.css';

// Shared
import { SearchInput } from 'shared/form/Input/SearchInput/SearchInput';
import { EmptyState } from 'shared/elements/EmptyState/EmptyState';
import { FilterPanel } from 'shared/elements/Filters';
import { DATE_FORMAT, INSIGHT_FILTERS } from 'shared/utils/Constants';
import { Dialog } from 'shared/layers/Dialog';
import { Chip } from 'shared/elements/Chip';
import { AgTable } from 'shared/layout/AgTable';

// Icons
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import { ReactComponent as FilterIcon } from 'assets/icons/filter.svg';
import { ReactComponent as EmptyIllustration } from 'assets/illustrations/empty-list.svg';
import { ReactComponent as PencilIcon } from 'assets/icons/pencil.svg';
import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';

// Modules
import { CreateInsightDialog } from './modules/CreateInsightDialog';

// Core
import { InsightOut } from 'core/Api';
import { AppliedFilter } from 'shared/elements/AppliedFilter/AppliedFilter';
import { useFilterPager } from 'core/Hooks/useFilterPager';

// Types
import { InsightFilterType, InsightProps } from './Insights.types';
import { Loader } from '../../shared/elements/Loader';
import { Pager } from '../../shared/data/Pager';

export const Insights: FC<InsightProps> = ({
  organizationUsers,
  createInsight,
  insightsData,
  deleteInsight,
  insightMutateAsync
}) => {
  const [openFilter, setOpenFilter] = useState<boolean>(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState<boolean>(false);
  const [insight, setInsight] = useState<InsightOut | null>(null);

  const [openCreateInsightDialog, setOpenCreateInsightDialog] =
    useState<boolean>(false);

  const gridApiRef = useRef<AgGridReact>(null);

  const [filterAndSearch, setFilterAndSearch] = useState<{
    search: string;
    filter: { [key: string]: string[] };
  }>({
    search: '',
    filter: {
      status: ['open']
    }
  });

  const {
    setFilter: setUrlFilter,
    page,
    setPage,
    setKeyword,
    keyword
  } = useFilterPager();

  const navigate = useNavigate();

  const { insights, metadata } = insightsData;

  // This ref is used to open the filter panel
  const filterBtnRef = useRef<HTMLButtonElement | null>(null);

  // This ref is used to open the filter panel in the applied filter component
  const currentFilterRef = useRef<MutableRefObject<HTMLButtonElement> | null>(
    null
  );

  const insightsColumn = useMemo(() => {
    return [
      {
        flex: 1,
        field: 'title'
      },
      {
        flex: 1,
        field: 'category'
      },
      {
        flex: 1,
        field: 'status'
      },
      {
        flex: 1,
        field: 'assignees'
      },
      {
        flex: 1,
        field: 'created_date',
        cellRenderer: ({ value }) => {
          return value ? <DateFormat date={value} format={DATE_FORMAT} /> : '';
        }
      },
      {
        flex: 1,
        field: 'modified_date',
        cellRenderer: ({ value }) => {
          return value ? <DateFormat date={value} format={DATE_FORMAT} /> : '';
        }
      },
      {
        width: 150,
        headerName: 'Count Events',
        field: 'count_events',
        cellRenderer: ({ value }) => (value ? value : 0)
      },
      {
        width: 100,
        headerName: 'Actions',
        sortable: false,
        cellRenderer: ({ data }) => {
          return (
            <Stack
              direction="row"
              justifyContent="start"
              alignItems="center"
              className={css.tableActions}
            >
              <Button
                variant="text"
                size="small"
                onClick={() => navigate(`/insights/${data.id}`)}
                disablePadding={true}
              >
                <PencilIcon />
              </Button>
              <Button
                variant="text"
                size="small"
                disablePadding={true}
                onClick={() => {
                  setOpenDeleteDialog(true);
                  setInsight(data);
                }}
              >
                <DeleteIcon />
              </Button>
            </Stack>
          );
        }
      }
    ];
  }, [navigate]);

  /**
   * @description This useMemo is used to construct the filter options
   * Adding the dynamic users to the assignee filter
   */
  const insightsFilterList = useMemo(() => {
    INSIGHT_FILTERS['assignee']['options'] = organizationUsers.map(user => ({
      label: user.email,
      value: user.email
    }));
    return INSIGHT_FILTERS;
  }, [organizationUsers]);

  /**
   * @description This function is used to apply the filter
   * to the insights list and fetch the insights list,
   * it also sets the filter in the url
   */
  async function onApplyFilterHandler(filter: { [key: string]: string[] }) {
    setUrlFilter(filter);
    await fetchInsightsOnQuery({
      pageNumber: 1,
      keyword: filterAndSearch.search || null,
      ...filter
    });
    setFilterAndSearch(prev => ({ ...prev, filter }));
  }

  async function onSearchByKeywordHandler(
    event: ChangeEvent<HTMLInputElement>
  ) {
    setKeyword(event.target.value);
    await fetchInsightsOnQuery({
      pageNumber: 1,
      ...filterAndSearch.filter,
      keyword: event.target.value || null
    });

    setFilterAndSearch(prev => ({
      ...prev,
      search: event.target.value
    }));
  }

  function onFilterReferenceHandler(
    dropdownRef: MutableRefObject<HTMLButtonElement>
  ) {
    // This switch the reference of the filter button
    currentFilterRef.current = dropdownRef;

    // This opens the filter panel
    setOpenFilter(!openFilter);
  }

  async function fetchInsightsOnQuery(params: InsightFilterType) {
    gridApiRef.current?.api?.showLoadingOverlay();
    await insightMutateAsync(params);
    gridApiRef.current?.api?.hideOverlay();
  }

  useEffect(() => {
    // Setting the default filter to open
    setUrlFilter({
      status: ['open']
    });

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className={css.container}>
      <Helmet>
        <title>Insights</title>
      </Helmet>
      <header className={css.header}>
        <PrimaryHeading>
          <Stack>
            <span>Insights</span>
            <Chip variant="outline" color="secondary">
              <div className={css.counter}>
                <Count to={metadata.total_count} />
              </div>
            </Chip>
          </Stack>
        </PrimaryHeading>
        <div className={css.push} />
        <SearchInput
          placeholder="Search by insight title..."
          debounce={500}
          value={keyword}
          onChange={onSearchByKeywordHandler}
        />
        <Button
          ref={filterBtnRef}
          onClick={() => onFilterReferenceHandler(filterBtnRef)}
          className={css.newBtn}
          variant="outline"
        >
          <FilterIcon />
          Filter
        </Button>
        <Button
          className={css.newBtn}
          color="primary"
          onClick={() => {
            setOpenCreateInsightDialog(true);
          }}
        >
          <PlusIcon />
          New Insight
        </Button>
      </header>

      <AppliedFilter
        reference={currentFilterRef.current}
        filter={filterAndSearch.filter}
        filterOptions={insightsFilterList}
        addFilter={onFilterReferenceHandler}
        setFilter={onApplyFilterHandler}
      />

      {/* This FilterPanel component Opens the popover for applied filters
       and for the filter button */}
      <FilterPanel
        reference={currentFilterRef.current}
        open={openFilter}
        filters={insightsFilterList}
        filter={filterAndSearch.filter}
        onFilterChange={onApplyFilterHandler}
        onClose={() => setOpenFilter(false)}
      />

      {insights.length > 0 ? (
        <>
          <AgTable
            agGridRef={gridApiRef}
            rowData={insights}
            suppressCellFocus={true}
            columnDefs={insightsColumn}
            loadingOverlayComponent={Loader}
          />
          <Pager
            total={metadata.total_count}
            page={page}
            size={metadata.page_size}
            onPageChange={async value => {
              // Incrementing the page number by 1 as the pager starts from 0
              // and the API starts from 1
              const exactPage = value + 1;
              await fetchInsightsOnQuery({
                pageNumber: exactPage,
                ...filterAndSearch.filter,
                keyword: filterAndSearch.search
              });
              setPage(exactPage);
            }}
          />
        </>
      ) : (
        <EmptyState
          illustration={<EmptyIllustration />}
          title="No Insights Found"
          actions={
            <Button
              color="primary"
              onClick={() => setOpenCreateInsightDialog(true)}
            >
              <PlusIcon />
              New Insight
            </Button>
          }
        />
      )}

      <Dialog
        open={openDeleteDialog}
        onClose={() => setOpenDeleteDialog(false)}
        size="450px"
        header={`Delete ${insight?.title} Insight`}
      >
        <Text className={css.text}>
          Are you sure you want to delete the <strong>{insight?.title}</strong>{' '}
          insight?
        </Text>
        <footer className={css.footer}>
          <Stack justifyContent="end">
            <Button
              variant="outline"
              onClick={() => setOpenDeleteDialog(false)}
            >
              Cancel
            </Button>
            <Button
              variant="filled"
              color="error"
              onClick={() => {
                deleteInsight(insight.id);
                setInsight(null);
                setOpenDeleteDialog(false);
              }}
            >
              Delete Insight
            </Button>
          </Stack>
        </footer>
      </Dialog>

      <CreateInsightDialog
        organizationUsers={organizationUsers}
        openNewInsight={openCreateInsightDialog}
        setOpenNewInsight={setOpenCreateInsightDialog}
        onChange={async data => {
          await createInsight(data);
          setOpenCreateInsightDialog(false);
        }}
      />
    </div>
  );
};
