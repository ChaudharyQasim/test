import { FC, useMemo, useReducer, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import {
  Button,
  DateFormat,
  SecondaryHeading,
  Select,
  SelectOption,
  SmallHeading,
  Stack,
  Textarea,
  Chip,
  DebouncedInput,
  Divider,
  Block
} from 'reablocks';

// CSS
import css from './InsightDetail.module.css';

// Core
import { useAuth } from 'core/Auth';
import {
  AddCommentRequest,
  Category,
  InsightOut,
  Reaction
} from 'core/Api/types';
import { useOrganization } from 'core/Organization';

// Icons
import { ReactComponent as LinkIcon } from 'assets/icons/link.svg';
import { ReactComponent as DateIcon } from 'assets/icons/date.svg';
import { ReactComponent as UserIcon } from 'assets/icons/user.svg';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';

// Modules
import { AssigneeList } from '../modules/AssigneeList';

// Shared
import {
  CATEGORIES,
  DATE_FORMAT,
  SEVERITIES,
  STATUS
} from 'shared/utils/Constants';
import { Table } from 'shared/layout/Table';
import { Comments } from 'shared/data/Comments';
import { Breadcrumb, BreadcrumbItem } from 'shared/elements/Breadcrumb';
import { ToggleInputEdit } from 'shared/form/ToggleInputEdit';
import { Dialog } from 'shared/layers/Dialog';
import { MitreTechniques } from 'shared/data/MitreTechniques';
import { CollapseTags } from 'shared/elements/CollapseTags';

// Core
import { useMitreTechniques } from 'core/Hooks/useMitreTechniques';

// Types
import { InsightDetailProps } from '../Insights.types';
import { MitreTechniqueType } from 'shared/data/MitreTechniques/MitreTechniques.types';

export const InsightDetailView: FC<InsightDetailProps> = ({
  insightDetails,
  commentList,
  addComment,
  deleteComment,
  addReaction,
  removeReaction,
  updateInsight,
  updateInsightAssignee,
  updateInsightCategory,
  updateMitreTechniques
}) => {
  const { user } = useAuth();
  const { currentOrganization } = useOrganization();

  const {
    title,
    content,
    assignees,
    status,
    category,
    severity,
    created_by,
    created_date,
    modified_date,
    mitre_attack_techniques,
    id
  } = insightDetails;

  const [focusSummary, setFocusSummary] = useState<boolean>(false);
  const [selectedTechniques, setSelectedTechniques] = useState<
    MitreTechniqueType[]
  >(mitre_attack_techniques);
  const [resetTechniques, setResetTechniques] = useState<boolean>(false);
  const [openMitreTechniquesDialog, setOpenMitreTechniquesDialog] =
    useState<boolean>(false);

  const [insightDetailsState, updateInsightDetailsState] = useReducer(
    (state: InsightOut, newState: any) => ({ ...state, ...newState }),
    {
      title: title,
      content: content,
      assignees: assignees,
      status: status,
      category: category,
      severity: severity,
      mitre_attack_techniques: mitre_attack_techniques
    }
  );

  const { techniques } = useMitreTechniques();

  const associated_columns = useMemo(
    () => [
      {
        id: 'date',
        header: '@Timestamp',
        accessor: 'organization_id',
        cell: value => <span>05/25/22 04:03:12 PM</span>
      },
      {
        id: 'kind',
        header: 'Kind',
        accessor: 'kind',
        cell: value => <span>event</span>
      },
      {
        id: 'category',
        header: 'Category',
        accessor: 'category',
        cell: value => <Chip>Authentication</Chip>
      },
      {
        id: 'type',
        header: 'Type',
        accessor: 'type',
        cell: value => <Chip>Change</Chip>
      },
      {
        id: 'outcome',
        header: 'Outcome',
        accessor: 'outcome',
        cell: value => <Chip color="success">success</Chip>
      },
      {
        id: 'dataset',
        header: 'Dataset',
        accessor: 'dataset',
        cell: value => <span>aws.cloudtrail</span>
      }
    ],
    []
  );

  const availableAssignees = useMemo(() => {
    return currentOrganization?.users.map(({ user }) => user.email) || [];
  }, [currentOrganization]);

  function updateInsightDetails(type: string, value: string) {
    updateInsightDetailsState({
      [type]: value
    });
    updateInsight({
      ...insightDetailsState,
      [type]: value
    });
  }

  function updateInsightAssigneesHandler(assigneeValues: string[]) {
    assignees.forEach(assignee => {
      if (!assigneeValues.includes(assignee)) {
        updateInsightAssignee({
          id: id,
          insightData: { assignee: assignee },
          remove: true
        });
      }
    });
    assigneeValues.forEach(innerAssignee => {
      if (!assignees.includes(innerAssignee)) {
        updateInsightAssignee({
          id: id,
          insightData: { assignee: innerAssignee }
        });
      }
    });
  }

  function updateInsightMitreTechniquesHandler() {
    updateMitreTechniques({
      id,
      techniques: selectedTechniques
    });
  }

  function updateInsightCategoriesHandler(categories: Category[]) {
    const removeCategories = category.filter(
      categoryItem => !categories.includes(categoryItem)
    );
    const addCategories = categories.filter(
      categoryItem => !category.includes(categoryItem)
    );
    if (removeCategories.length > 0) {
      updateInsightCategory({
        id: id,
        insightData: { names: removeCategories },
        remove: true
      });
    }
    if (addCategories.length > 0) {
      updateInsightCategory({
        id: id,
        insightData: { names: addCategories }
      });
    }
  }

  function onSelectedMitreTechniques(techniquesSelected: MitreTechniqueType[]) {
    setSelectedTechniques(techniquesSelected);
    if (techniquesSelected.length === 0) {
      setResetTechniques(false);
    }
  }

  return (
    <>
      <Helmet>
        <title>Insights Details</title>
      </Helmet>

      <header className={css.header}>
        <Breadcrumb>
          <BreadcrumbItem href="/insights">Insights</BreadcrumbItem>
          <BreadcrumbItem>
            <ToggleInputEdit
              toggleToComponent={
                <DebouncedInput
                  className={css.titleInput}
                  value={insightDetailsState.title}
                  debounce={1000}
                  fullWidth
                  onChange={event => {
                    const title = event.target.value;
                    updateInsightDetailsState({
                      title
                    });
                    updateInsightDetails('title', title);
                  }}
                />
              }
            >
              {insightDetailsState.title}
            </ToggleInputEdit>
          </BreadcrumbItem>
        </Breadcrumb>
      </header>

      {techniques.length > 0 && (
        <Dialog
          open={openMitreTechniquesDialog}
          onClose={() => setOpenMitreTechniquesDialog(false)}
          size="780px"
          header="Add MITRE Att&ck Techniques"
          disablePadding
        >
          <Divider />
          <MitreTechniques
            mitreTechniques={techniques}
            selectedTechniques={selectedTechniques}
            reset={resetTechniques}
            onChange={onSelectedMitreTechniques}
          />
          <Divider />
          <footer className={css.mitreFooter}>
            <Block>
              <Stack justifyContent="spaceBetween">
                <Button
                  disabled={selectedTechniques.length === 0}
                  variant="outline"
                  onClick={() => setResetTechniques(true)}
                >
                  Reset
                </Button>
                <Stack justifyContent="end">
                  <Button
                    variant="outline"
                    onClick={() => setOpenMitreTechniquesDialog(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    variant="filled"
                    color="primary"
                    onClick={() => {
                      updateInsightMitreTechniquesHandler();
                      setOpenMitreTechniquesDialog(false);
                    }}
                  >
                    Done
                  </Button>
                </Stack>
              </Stack>
            </Block>
          </footer>
        </Dialog>
      )}

      <section className={css.infoContainer}>
        <Stack className={css.subSection}>
          <Stack alignItems="center" dense>
            <SmallHeading className={css.attribute}>Assignee(s)</SmallHeading>
            <ToggleInputEdit
              toggleToComponent={
                <Select
                  menuPlacement="bottom-start"
                  placeholder="Select an assignee..."
                  value={insightDetailsState.assignees}
                  multiple
                  filterable
                  clearable={false}
                  onChange={value => {
                    updateInsightDetailsState({
                      assignees: value
                    });
                    updateInsightAssigneesHandler(value);
                  }}
                >
                  {availableAssignees.map((assignee, index) => (
                    <SelectOption key={index} value={assignee}>
                      {assignee}
                    </SelectOption>
                  ))}
                </Select>
              }
            >
              <AssigneeList assignees={insightDetailsState.assignees} />
            </ToggleInputEdit>
            ·
          </Stack>
          <Stack alignItems="center" dense>
            <SmallHeading className={css.attribute}>Status</SmallHeading>
            <ToggleInputEdit
              toggleToComponent={
                <Select
                  className={css.selectStatus}
                  menuPlacement="bottom-start"
                  placeholder="Select a status..."
                  value={insightDetailsState.status}
                  clearable={false}
                  filterable
                  onChange={value => {
                    updateInsightDetails('status', value);
                  }}
                >
                  {STATUS.map((status, index) => {
                    const color =
                      status.value === 'open'
                        ? 'info'
                        : status.value === 'in-progress'
                        ? 'warning'
                        : 'error';
                    return (
                      <SelectOption
                        key={index}
                        value={status.value}
                        inputLabel={
                          <Chip size="small" color={color}>
                            {status.label}
                          </Chip>
                        }
                      >
                        {status.label}
                      </SelectOption>
                    );
                  })}
                </Select>
              }
            >
              {insightDetailsState.status}
            </ToggleInputEdit>
            ·
          </Stack>
          <Stack alignItems="center" dense>
            <SmallHeading className={css.attribute}>Category</SmallHeading>
            <ToggleInputEdit
              toggleToComponent={
                <Select
                  menuPlacement="bottom-start"
                  placeholder="Select a category..."
                  value={insightDetailsState.category}
                  multiple
                  clearable={false}
                  filterable
                  onChange={value => {
                    updateInsightDetailsState({
                      category: value
                    });
                    updateInsightCategoriesHandler(value);
                  }}
                >
                  {CATEGORIES.map((category, index) => (
                    <SelectOption key={index} value={category.value}>
                      {category.label}
                    </SelectOption>
                  ))}
                </Select>
              }
            >
              <div>
                {insightDetailsState.category.map(
                  (categoryItem: string, index: number) => (
                    <Chip variant="outline" key={`${categoryItem}-${index}`}>
                      {categoryItem}
                    </Chip>
                  )
                )}
              </div>
            </ToggleInputEdit>
            ·
          </Stack>
          <Stack alignItems="center" dense>
            <SmallHeading className={css.attribute}>Severity</SmallHeading>
            <ToggleInputEdit
              toggleToComponent={
                <Select
                  menuPlacement="bottom-start"
                  placeholder="Select a severity..."
                  value={insightDetailsState.severity}
                  clearable={false}
                  onChange={value => {
                    updateInsightDetails('severity', value);
                  }}
                >
                  {SEVERITIES.map((severity, index) => {
                    return (
                      <SelectOption key={index} value={severity.value}>
                        {severity.label}
                      </SelectOption>
                    );
                  })}
                </Select>
              }
            >
              {insightDetailsState.severity}
            </ToggleInputEdit>
          </Stack>
        </Stack>

        <Stack className={css.subSection}>
          <Stack className={css.attribute} dense>
            <UserIcon /> Created by - {created_by} ·
          </Stack>
          <Stack className={css.attribute} dense>
            <DateIcon /> Created On -{' '}
            <DateFormat date={created_date} format={DATE_FORMAT} /> ·
          </Stack>
          <Stack className={css.attribute} dense>
            <DateIcon /> Updated On -{' '}
            <DateFormat date={modified_date} format={DATE_FORMAT} />
          </Stack>
        </Stack>

        <Stack alignItems="center">
          <SmallHeading className={css.attribute}>
            MITRE Techniques
          </SmallHeading>
          <CollapseTags
            tagList={selectedTechniques.map(technique => technique.name)}
            fallback="No mitre techniques added"
          >
            <Button
              className={css.addTechniqueButton}
              onClick={() => setOpenMitreTechniquesDialog(true)}
              variant="text"
              disableMargins
              disablePadding
            >
              <PlusIcon />
            </Button>
          </CollapseTags>
        </Stack>
      </section>
      <section className={css.summary}>
        <SecondaryHeading>Summary</SecondaryHeading>
        <Textarea
          minRows={7}
          fullWidth
          placeholder="Add a summary..."
          size="medium"
          onFocus={() => setFocusSummary(true)}
          onBlur={() => {
            if (insightDetailsState.content === content) {
              setFocusSummary(false);
            }
          }}
          value={insightDetailsState.content}
          onChange={event => {
            updateInsightDetailsState({
              content: event.target.value
            });
          }}
        />
        <Button
          variant="filled"
          color="primary"
          onClick={() => {
            updateInsightDetails('content', insightDetailsState.content);
            setFocusSummary(false);
          }}
          disabled={!focusSummary}
          className={css.updateButton}
        >
          Update
        </Button>
      </section>

      {/* This will be uncomment when we can get the data from backend */}
      {/* <section className={css.associated}>
        <header>
          <Stack justifyContent="spaceBetween">
            <SecondaryHeading>
              <Stack>
                <span>Associated Events</span>

                <Button variant="text" color="primary" disablePadding>
                  <LinkIcon />
                </Button>
              </Stack>
            </SecondaryHeading>
            <Stack>
              <Button variant="outline" color="primary" size="small">
                Remove Selected
              </Button>
              <Button variant="filled" color="primary" size="small">
                Add Event
              </Button>
            </Stack>
          </Stack>
        </header>
        <Table data={[]} columns={associated_columns} />
      </section> */}

      <section className={css.comments}>
        <SecondaryHeading>Comments</SecondaryHeading>
        <Comments
          comments={commentList}
          currentUser={user.email}
          onCreateComment={async (data: AddCommentRequest) => {
            addComment(data);
          }}
          onDeleteComment={async (id: string) => {
            deleteComment(id);
          }}
          onAddReaction={async (commentId: string, reaction: Reaction) => {
            addReaction({ commentId, reaction });
          }}
          onRemoveReaction={async (commentId: string, reaction: Reaction) => {
            removeReaction({ commentId, reaction });
          }}
        />
      </section>
    </>
  );
};
