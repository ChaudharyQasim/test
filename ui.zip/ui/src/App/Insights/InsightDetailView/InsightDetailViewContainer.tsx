import { FC } from 'react';
import { useParams } from 'react-router-dom';
import { useNotification } from 'reablocks';
import { AxiosError } from 'axios';
import { useMutation, useQuery, useQueryClient } from 'react-query';

import { InsightDetailView } from './InsightDetailView';

// Shared
import { Loader } from 'shared/elements/Loader';

// Core
import {
  deleteInsightComment,
  getInsightsById,
  getInsightComments,
  postAddReaction,
  postInsightComment,
  postRemoveReaction,
  updateAssigneeInsight,
  updateCategoryInsight,
  updateInsight,
  updateRemoveAssigneeInsight,
  updateRemoveCategoryInsight,
  updateMitreTechniques
} from 'core/Api/InsightsApi';
import {
  AddCommentRequest,
  Reaction,
  UpdateInsightAssigneesRequest,
  UpdateInsightCategoryRequest,
  UpdateInsightRequest
} from 'core/Api';
import { useAuth } from 'core/Auth';
import { ErrorResponseMessage } from 'App/Integrations/Integration.types';
import { MitreTechniqueType } from 'shared/data/MitreTechniques/MitreTechniques.types';

export const InsightDetailViewContainer: FC = () => {
  const { id } = useParams();
  const { user } = useAuth();

  const queryClient = useQueryClient();

  const { notifyError, notifySuccess } = useNotification();

  const { data: insightDetails } = useQuery(
    'insightDetails',
    () => getInsightsById(id),
    {
      enabled: id !== null || id !== undefined,
      onError(error: AxiosError<ErrorResponseMessage> | any) {
        notifyError(
          error?.response?.data?.message ||
            'Error occur while getting insight details'
        );
      }
    }
  );

  const { data: comments, refetch: refetchComments } = useQuery(
    'comments',
    () => getInsightComments(id),
    { initialData: [] }
  );

  const { mutate: addCommentInsightMutation } = useMutation(
    (data: AddCommentRequest) => postInsightComment(id, data),
    {
      onSuccess() {
        notifySuccess('Comment added successfully.');
      },
      onError(error: any) {
        notifyError(error?.response?.data?.message);
      },
      onSettled(_data, _error) {
        queryClient.setQueryData('comments', (oldData: any) => {
          return [...oldData, _data];
        });
      }
    }
  );

  const { mutate: deleteCommentInsightMutation } = useMutation(
    (commentId: string) => deleteInsightComment(commentId),
    {
      onSuccess() {
        notifySuccess('Comment deleted successfully');
        refetchComments();
      },
      onError(error: any) {
        notifyError(error?.response?.data?.message);
      }
    }
  );

  const { mutate: addReactionMutation } = useMutation(
    ({ commentId, reaction }: { commentId: string; reaction: Reaction }) =>
      postAddReaction(commentId, reaction),
    {
      onSettled(_data, _error, variables) {
        // Updates the comments list with the new reaction
        // This avoid to refetch the comments list
        queryClient.setQueryData('comments', (oldData: any) => {
          const index = oldData.findIndex(
            (item: any) => item.id === variables.commentId
          );

          if (index !== -1) {
            oldData[index].reactions.push({
              reaction: variables.reaction.reaction_id,
              user: user.email
            });
          }

          return [...oldData];
        });
      }
    }
  );

  const { mutate: removeReactionMutation } = useMutation(
    ({ commentId, reaction }: { commentId: string; reaction: Reaction }) =>
      postRemoveReaction(commentId, reaction),
    {
      onError(error: any) {
        notifyError(error?.response?.data?.detail);
      },
      onSettled(_data, _error, variables) {
        queryClient.setQueryData('comments', (oldData: any) => {
          const index = oldData.findIndex(
            (item: any) => item.id === variables.commentId
          );

          const updatedData = oldData[index].reactions.filter(
            (reaction: { reaction: string; user: string }) => {
              return (
                reaction.reaction !== variables.reaction.reaction_id ||
                reaction.user !== user.email
              );
            }
          );

          oldData[index].reactions = [...updatedData];

          return [...oldData];
        });
      }
    }
  );

  const { mutate: updateInsightMutation } = useMutation(
    (insightData: UpdateInsightRequest) => updateInsight(id, insightData),
    {
      onSuccess() {
        notifySuccess('Insight updated successfully');
      },
      onError(error: any) {
        notifyError(error?.response?.data?.detail);
      },
      onSettled(_data, _error, variables) {
        queryClient.setQueryData('insightDetails', (oldData: any) => {
          return oldData;
        });
      }
    }
  );

  const { mutate: updateInsightAssigneeMutation } = useMutation(
    ({
      id,
      insightData,
      remove
    }: {
      id: string;
      insightData: UpdateInsightAssigneesRequest;
      remove?: boolean;
    }) => {
      if (remove) {
        return updateRemoveAssigneeInsight(id, insightData);
      } else {
        return updateAssigneeInsight(id, insightData);
      }
    },
    {
      onSuccess() {
        notifySuccess('Assignee updated successfully');
      },
      onError(error: any) {
        notifyError(error?.response?.data?.detail);
      }
    }
  );

  const { mutate: updateMitreTechniquesMutation } = useMutation(
    ({ id, techniques }: { id: string; techniques: MitreTechniqueType[] }) => {
      return updateMitreTechniques({ insightId: id, techniques });
    },
    {
      onSuccess() {
        notifySuccess('Mitre techniques updated successfully');
      },
      onError(error: any) {
        notifyError(error?.response?.data?.detail);
      }
    }
  );

  const { mutate: updateInsightCategoryMutation } = useMutation(
    ({
      id,
      insightData,
      remove
    }: {
      id: string;
      insightData: UpdateInsightCategoryRequest;
      remove?: boolean;
    }) => {
      if (remove) {
        return updateRemoveCategoryInsight(id, insightData);
      } else {
        return updateCategoryInsight(id, insightData);
      }
    },
    {
      onSuccess() {
        notifySuccess('Category updated successfully');
      },
      onError(error: any) {
        notifyError(error?.response?.data?.detail);
      }
    }
  );

  if (!insightDetails) {
    return <Loader />;
  }

  return (
    <InsightDetailView
      insightDetails={insightDetails}
      commentList={comments}
      addComment={addCommentInsightMutation}
      deleteComment={deleteCommentInsightMutation}
      addReaction={addReactionMutation}
      removeReaction={removeReactionMutation}
      updateInsight={updateInsightMutation}
      updateInsightAssignee={updateInsightAssigneeMutation}
      updateInsightCategory={updateInsightCategoryMutation}
      updateMitreTechniques={updateMitreTechniquesMutation}
    />
  );
};
