export { InsightDetailViewContainer as default } from './InsightDetailViewContainer';
