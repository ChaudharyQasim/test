import { FC } from 'react';
import { useNotification } from 'reablocks';
import { useQueryParams } from 'core/Hooks/useQueryParams';

import { useMutation, useQuery, useQueryClient } from 'react-query';

import { Insights } from './Insights';

// Shared
import { Loader } from 'shared/elements/Loader';

// Core
import { useAuth } from 'core/Auth';
import { getOrganizationUsers } from 'core/Api/UsersApi';
import {
  deleteInsight,
  getInsights,
  postCreateInsight
} from 'core/Api/InsightsApi';
import { CreateInsightRequest, InsightList } from 'core/Api';

import { PAGE_SIZE } from 'App/Rules/constants';

export const InsightsContainer: FC = () => {
  const { user } = useAuth();

  const queryClient = useQueryClient();

  const { notifySuccess, notifyError } = useNotification();

  const { data: users, isLoading: isUsersLoading } = useQuery(
    'organizationUsers',
    () => getOrganizationUsers(user.current_organization.id)
  );

  const { page } = useQueryParams();

  const { data: insights, isLoading: isInsightsLoading } = useQuery(
    'insights',
    () =>
      getInsights(user.email, {
        page_number: parseInt(page) || 1,
        page_size: PAGE_SIZE,
        status: 'open'
      }),
    {
      enabled: !!user,
      initialData: {
        insights: [],
        metadata: {
          page_number: 1,
          page_size: PAGE_SIZE,
          total_count: 0
        }
      }
    }
  );

  const { mutate: createInsightMutation } = useMutation(
    (insight: CreateInsightRequest) => {
      return postCreateInsight(insight);
    },
    {
      onSuccess() {
        notifySuccess('Insight created successfully');
        queryClient.invalidateQueries('insights');
      },
      onError(error: any) {
        notifyError(error?.response?.data?.detail);
      },
      onSettled(_data, _error) {
        queryClient.setQueryData('insights', (oldData: InsightList) => {
          oldData.insights.unshift(_data);
          return oldData;
        });
      }
    }
  );

  const { mutate: deleteInsightMutation, isLoading: isDeleteInsightLoading } =
    useMutation((insightId: string) => deleteInsight(insightId), {
      onSuccess(data) {
        notifySuccess('Insight deleted successfully');
        queryClient.invalidateQueries('insights');
      },
      onError(error: any) {
        notifyError(error?.response?.data?.message);
      }
    });

  const { mutateAsync: insightMutateAsync } = useMutation(
    ({
      pageNumber,
      severity,
      assignee,
      status,
      keyword
    }: {
      pageNumber: number;
      severity?: string[];
      assignee?: string[];
      status?: string[];
      keyword?: string;
    }) => {
      return getInsights(user.email, {
        page_number: pageNumber,
        page_size: PAGE_SIZE,
        severity: severity?.join(','),
        assignee: assignee?.join(','),
        status: status?.join(','),
        keyword
      });
    },
    {
      onSuccess(data) {
        queryClient.setQueryData('insights', data);
      },
      onError(error: any) {
        notifyError(error?.response?.data?.detail);
      }
    }
  );

  if (isUsersLoading) {
    return <Loader />;
  }

  return (
    <Insights
      insightsData={insights}
      createInsight={createInsightMutation}
      deleteInsight={deleteInsightMutation}
      organizationUsers={users}
      insightMutateAsync={insightMutateAsync}
    />
  );
};
