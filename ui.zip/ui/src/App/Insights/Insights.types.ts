import { UseMutateFunction, UseMutationResult } from 'react-query';

// Core
import { OrganizationUser } from 'core/Api/UsersApi';

// Types
import {
  CreateInsightRequest,
  InsightList,
  InsightOut,
  UpdateInsightAssigneesRequest,
  UpdateInsightCategoryRequest,
  UpdateInsightRequest,
  AddCommentRequest,
  Comment,
  CommentDetail,
  Reaction
} from 'core/Api';
import { MitreTechniqueType } from 'shared/data/MitreTechniques/MitreTechniques.types';

type UpdateInsightCategory = UseMutateFunction<
  InsightOut,
  unknown,
  { id: string; insightData: UpdateInsightCategoryRequest; remove?: boolean },
  unknown
>;

type UpdateInsightAssignee = UseMutateFunction<
  InsightOut,
  unknown,
  {
    id: string;
    insightData: UpdateInsightAssigneesRequest;
    remove?: boolean;
  },
  unknown
>;

export type InsightFilterType = {
  pageNumber: number;
  severity?: string[];
  assignee?: string[];
  status?: string[];
  keyword?: string;
};

export type InsightProps = {
  insightsData: InsightList;
  organizationUsers: OrganizationUser[];
  createInsight: UseMutateFunction<
    InsightOut,
    any,
    CreateInsightRequest,
    unknown
  >;
  deleteInsight: UseMutateFunction<
    { message: string },
    unknown,
    string,
    unknown
  >;
  insightMutateAsync: (params: InsightFilterType) => Promise<InsightList>;
};

export type InsightDetailProps = {
  insightDetails: InsightOut;
  commentList: CommentDetail[];
  addComment: UseMutateFunction<Comment, unknown, AddCommentRequest, unknown>;
  deleteComment: UseMutateFunction<
    { message: string },
    unknown,
    string,
    unknown
  >;
  addReaction: UseMutateFunction<
    Comment,
    unknown,
    {
      commentId: string;
      reaction: Reaction;
    },
    unknown
  >;
  removeReaction: UseMutateFunction<
    Comment,
    unknown,
    {
      commentId: string;
      reaction: Reaction;
    },
    unknown
  >;
  updateInsight: UseMutateFunction<
    InsightOut,
    unknown,
    UpdateInsightRequest,
    unknown
  >;
  updateInsightAssignee: UpdateInsightAssignee;
  updateInsightCategory: UpdateInsightCategory;
  updateMitreTechniques: UseMutateFunction<
    string,
    unknown,
    {
      id: string;
      techniques: MitreTechniqueType[];
    },
    unknown
  >;
};
