import { FC, useRef, useState } from 'react';
import {
  Button,
  Card,
  DateFormat,
  List,
  ListItem,
  SmallHeading,
  Stack,
  Text
} from 'reablocks';

// CSS
import css from './InsightRow.module.css';

// Shared
import { Menu } from 'shared/layers/Menu';
import { LabelChip } from 'shared/elements/Chip';
import { CollapseTags } from 'shared/elements/CollapseTags';

// Modules
import { AssigneeList } from '../AssigneeList';

// Icons
import { ReactComponent as DotsIcon } from 'assets/icons/dots.svg';
import { ReactComponent as PencilIcon } from 'assets/icons/pencil.svg';
import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as AlertIcon } from 'assets/icons/warning.svg';
import { ReactComponent as CalendarIcon } from 'assets/icons/calendar.svg';
import { ReactComponent as UserIcon } from 'assets/icons/user.svg';

// Types
import { InsightOut } from 'core/Api';
import { DATE_FORMAT } from 'shared/utils/Constants';

type InsightRowProps = {
  insight: InsightOut;
  onChange: () => void;
  onEdit: () => void;
  onDelete: () => void;
};

export const InsightRow: FC<InsightRowProps> = ({
  insight,
  onChange,
  onEdit,
  onDelete
}) => {
  const btnRef = useRef<HTMLButtonElement | null>(null);
  const [menuOpen, setMenuOpen] = useState<boolean>(false);

  const {
    title,
    category,
    status,
    assignees,
    severity,
    created_date,
    modified_date,
    count_events,
    mitre_attack_techniques
  } = insight;

  const statusLabelColor =
    status === 'open' ? 'info' : status === 'in-progress' ? 'warning' : 'error';

  return (
    <Card
      className={css.card}
      contentClassName={css.cardContent}
      disablePadding
      onClick={event => {
        event.stopPropagation();
        onChange();
      }}
    >
      <div className={css.gridItemFull}>
        <Stack>
          <SmallHeading className={css.title} disableMargins>
            <Button variant="text" disablePadding disableMargins>
              {title}
            </Button>
          </SmallHeading>
          <span>Category: </span>
          {category.map((categoryItem, index) => (
            <LabelChip variant="outline" key={`${categoryItem}-${index}`}>
              {categoryItem}
            </LabelChip>
          ))}
          <span>Status: </span>
          <LabelChip variant="outline" color={statusLabelColor}>
            {status}
          </LabelChip>
        </Stack>
      </div>
      <div>
        <Stack>
          <UserIcon className={css.rowIcon} />
          <div>
            {assignees.length > 0 && <AssigneeList assignees={assignees} />}
          </div>
        </Stack>
      </div>
      <div>
        <Stack>
          <AlertIcon className={css[severity]} />
          {severity}
        </Stack>
      </div>
      <div>
        <Stack>
          <CalendarIcon className={css.rowIcon} />
          <span>Modified at: </span>
          <DateFormat date={modified_date} format={DATE_FORMAT} />
        </Stack>
        <Stack>
          <CalendarIcon className={css.rowIcon} />
          <span>Created at: </span>
          <DateFormat date={created_date} format={DATE_FORMAT} />
        </Stack>
      </div>
      <div>
        <SmallHeading className={css.subheading}>Events</SmallHeading>
        <Text>{count_events === null ? 0 : count_events} total</Text>
      </div>
      <div className={css.gridItemFull}>
        <SmallHeading className={css.subheading}>MITRE Techniques</SmallHeading>
        <CollapseTags
          tagList={mitre_attack_techniques.map(({ name }) => name)}
          fallback="No mitre techniques added"
        />
      </div>
      <div>
        <Button
          variant="text"
          ref={btnRef}
          className={css.actions}
          onClick={event => {
            event.stopPropagation();
            setMenuOpen(!menuOpen);
          }}
        >
          <DotsIcon />
        </Button>
        <Menu
          reference={btnRef}
          open={menuOpen}
          placement="bottom-end"
          onClose={() => setMenuOpen(false)}
        >
          <Card>
            <List>
              <ListItem
                start={<PencilIcon />}
                onClick={event => {
                  event.stopPropagation();
                  onEdit();
                }}
              >
                Edit
              </ListItem>
              <ListItem
                start={<DeleteIcon />}
                onClick={event => {
                  event.stopPropagation();
                  onDelete();
                }}
              >
                Delete
              </ListItem>
            </List>
          </Card>
        </Menu>
      </div>
    </Card>
  );
};
