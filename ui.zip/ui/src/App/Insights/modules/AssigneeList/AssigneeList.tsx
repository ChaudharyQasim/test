import { FC } from 'react';

// Shared
import { Tooltip } from 'shared/layers/Tooltip';
import { Chip } from 'shared/elements/Chip';

// Types
type AssigneeListProps = {
  assignees: string[];
};

export const AssigneeList: FC<AssigneeListProps> = ({ assignees }) => (
  <div>
    {assignees[0]}{' '}
    <Tooltip
      content={
        <>
          {assignees.slice(1).map((assignee: string, index: number) => (
            <div key={index}>{assignee}</div>
          ))}
        </>
      }
      placement="bottom-end"
      arrow
    >
      {assignees.length > 1 && (
        <Chip variant="outline">
          + {(assignees.length - 1).toLocaleString()}
        </Chip>
      )}
    </Tooltip>
  </div>
);
