import { FC, useMemo } from 'react';
import {
  Button,
  Chip,
  Input,
  Select,
  SelectOption,
  SmallHeading,
  Stack,
  Text,
  Textarea,
  Tree,
  TreeNode
} from 'reablocks';

// CSS
import css from './CreateInsightDialog.module.css';

// Form lib validation
import * as Yup from 'yup';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

// Shared
import { Dialog } from 'shared/layers/Dialog';
import { MitreTechniques } from 'shared/data/MitreTechniques';

// Constants
import { STATUS } from 'shared/utils/Constants';

// Core
import { useAuth } from 'core/Auth';
import { OrganizationUser } from 'core/Api/UsersApi';
import { Category, CreateInsightRequest, Severity, Status } from 'core/Api';
import { useMitreTechniques } from 'core/Hooks/useMitreTechniques';
import classNames from 'classnames';

// Types
type CreateInsightDialogProps = {
  openNewInsight: boolean;
  organizationUsers: OrganizationUser[];
  isEditable?: boolean;
  setOpenNewInsight: (open: boolean) => void;
  onChange?: (data: CreateInsightRequest) => Promise<void>;
};

const credentialsSchema = Yup.object().shape({
  title: Yup.string().required('Required'),
  assignees: Yup.array().of(Yup.string()),
  category: Yup.array().of(Yup.string()),
  severity: Yup.string(),
  content: Yup.string(),
  status: Yup.string(),
  mitre: Yup.array()
});

export const CreateInsightDialog: FC<CreateInsightDialogProps> = ({
  setOpenNewInsight,
  openNewInsight,
  organizationUsers,
  onChange,
  isEditable
}) => {
  const { user: currentUser } = useAuth();
  const defaultAssigneeUsers = useMemo(
    () =>
      organizationUsers
        ?.filter(user => user.email === currentUser.email)
        .map(user => user.email),
    [organizationUsers, currentUser.email]
  );

  const {
    control,
    handleSubmit,
    formState: { isSubmitting, isValid },
    getValues,
    setValue,
    reset
  } = useForm({
    mode: 'onChange',
    reValidateMode: 'onChange',
    resolver: yupResolver(credentialsSchema),
    defaultValues: {
      title: '',
      assignees: defaultAssigneeUsers,
      category: ['detection'],
      severity: 'Low',
      content: '',
      status: 'open',
      mitre: []
    }
  });

  const { techniques } = useMitreTechniques();

  return (
    <Dialog
      open={openNewInsight}
      size="40%"
      onClose={() => {
        reset();
        setOpenNewInsight(false);
      }}
      header={`${isEditable ? 'Edit' : 'Create New'} Insight`}
    >
      <form
        className={css.container}
        onSubmit={handleSubmit(async () => {
          await onChange({
            title: getValues('title'),
            assignees: getValues('assignees'),
            severity: Severity[getValues('severity')],
            category: getValues('category') as Category[],
            content: getValues('content'),
            status: getValues('status') as Status,
            mitre_attack_techniques: getValues('mitre')
          });
          reset();
        })}
      >
        <Stack className={css.row}>
          <Text>Title</Text>
          <Controller
            name="title"
            control={control}
            render={({ field: { value, onBlur, onChange } }) => (
              <Input
                name="title"
                disabled={isSubmitting}
                autoFocus
                type="text"
                value={value}
                onChange={onChange}
                onBlur={onBlur}
                placeholder="Enter a title..."
              />
            )}
          />
        </Stack>
        <Stack className={css.row}>
          <Text>Assigned to</Text>

          <Controller
            name="assignees"
            control={control}
            render={({ field: { value, onBlur, onChange } }) => (
              <Select
                clearable={false}
                placeholder="Select an user..."
                value={value}
                multiple
                onChange={onChange}
                onBlur={onBlur}
              >
                {organizationUsers.map(user => {
                  return (
                    <SelectOption key={user.id} value={user.email}>
                      {user.email}
                    </SelectOption>
                  );
                })}
              </Select>
            )}
          />
        </Stack>
        <Stack className={css.row}>
          <Text>Status</Text>
          <Controller
            name="status"
            control={control}
            render={({ field: { value, onBlur, onChange } }) => (
              <Select
                clearable={false}
                placeholder="Select a status..."
                value={value}
                onChange={onChange}
                onBlur={onBlur}
              >
                {STATUS.map((status, index) => {
                  const color =
                    status.value === 'open'
                      ? 'info'
                      : status.value === 'in-progress'
                      ? 'warning'
                      : 'error';
                  return (
                    <SelectOption
                      key={index}
                      value={status.value}
                      inputLabel={
                        <Chip size="small" color={color}>
                          <span
                            className={classNames({
                              [css.inProgressStatus]:
                                status.value === 'in-progress'
                            })}
                          >
                            {status.label}
                          </span>
                        </Chip>
                      }
                    >
                      {status.label}
                    </SelectOption>
                  );
                })}
              </Select>
            )}
          />
        </Stack>
        <Stack className={css.row}>
          <Text>Category</Text>
          <Controller
            name="category"
            control={control}
            render={({ field: { value, onBlur, onChange } }) => (
              <Select
                clearable={false}
                placeholder="Select a category..."
                value={value}
                multiple
                onChange={onChange}
                onBlur={onBlur}
              >
                <SelectOption value="collection">Collection</SelectOption>
                <SelectOption value="environment">Environment</SelectOption>
                <SelectOption value="detection">Detection</SelectOption>
              </Select>
            )}
          />
        </Stack>
        <Stack className={css.row}>
          <Text>Severity</Text>
          <Controller
            name="severity"
            control={control}
            render={({ field: { value, onBlur, onChange } }) => (
              <Select
                clearable={false}
                placeholder="Select a severity..."
                value={value}
                onChange={onChange}
                onBlur={onBlur}
              >
                <SelectOption value="Info">Info</SelectOption>
                <SelectOption value="Low">Low</SelectOption>
                <SelectOption value="Medium">Medium</SelectOption>
                <SelectOption value="High">High</SelectOption>
                <SelectOption value="Critical">Critical</SelectOption>
              </Select>
            )}
          />
        </Stack>
        <section className={css.section}>
          <Tree className={css.toggleMitre}>
            <TreeNode
              className={css.node}
              label={
                <SmallHeading className={css.subtitle}>
                  Add MITRE Techniques
                </SmallHeading>
              }
            >
              <MitreTechniques
                isMenu
                mitreTechniques={techniques}
                selectedTechniques={[]}
                onChange={selected => {
                  const selectedTechniques = selected.map(
                    ({ id, sub_id, name }) => ({ id, sub_id, name })
                  );
                  setValue('mitre', selectedTechniques);
                }}
              />
            </TreeNode>
          </Tree>
        </section>
        <section className={css.section}>
          <SmallHeading className={css.subtitle}>Summary</SmallHeading>
          <Controller
            name="content"
            control={control}
            render={({ field: { value, onBlur, onChange } }) => (
              <Textarea
                onChange={onChange}
                onBlur={onBlur}
                value={value}
                size="medium"
                placeholder="Add summary here..."
                minRows={5}
                fullWidth
              ></Textarea>
            )}
          />
        </section>
        <footer className={css.footer}>
          <Stack justifyContent="end">
            <Button variant="outline" onClick={() => setOpenNewInsight(false)}>
              Cancel
            </Button>
            <Button
              variant="filled"
              color="primary"
              disabled={!isValid || isSubmitting}
              type="submit"
            >
              {isEditable
                ? isSubmitting && isEditable
                  ? 'Editing Insight...'
                  : 'Edit Insight'
                : isSubmitting
                ? 'Creating Insight...'
                : 'Create Insight'}
            </Button>
          </Stack>
        </footer>
      </form>
    </Dialog>
  );
};
