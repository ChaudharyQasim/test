export { InsightsContainer as default } from './InsightsContainer';
