import { FC } from 'react';
import { PendingApproval } from './PendingApproval';

export const PendingApprovalContainer: FC = () => <PendingApproval />;
