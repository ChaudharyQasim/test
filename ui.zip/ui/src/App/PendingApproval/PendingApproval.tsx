import { FC } from 'react';
import { Button, SecondaryHeading, Text } from 'reablocks';

// CSS
import css from './PendingApproval.module.css';

// Icons
import { ReactComponent as LogoIcon } from 'assets/brand/logo-color.svg';
import { ReactComponent as CheckIcon } from 'assets/icons/check.svg';

// core
import { useAuth } from 'core/Auth';

export const PendingApproval: FC = () => {
  const { logout, isLoggingOut } = useAuth();

  const quote = `"Hooray, you're in the system! We're just taking a quick peek at your account. You will be notified via email once approved."`;

  return (
    <div className={css.root}>
      <header className={css.header}>
        <LogoIcon />

        <Button
          disabled={isLoggingOut}
          variant="outline"
          className={css.logOut}
          onClick={logout}
        >
          {isLoggingOut ? 'Logging out...' : 'Log out'}
        </Button>
      </header>
      <section className={css.content}>
        <span className={css.checkIcon}>
          <CheckIcon />
        </span>
        <SecondaryHeading>Account Verification</SecondaryHeading>
        <Text className={css.text}>{quote}</Text>
      </section>
    </div>
  );
};
