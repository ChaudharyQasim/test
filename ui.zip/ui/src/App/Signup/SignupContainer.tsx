import { FC } from 'react';
import { Signup } from './Signup';
import { useNotification } from 'reablocks';
import { useNavigate, Navigate } from 'react-router-dom';

// API Service
import { PostSignupType, postSignUp, postLogin } from 'core/Api/AuthApi';

// Hooks
import { useAuth } from 'core/Auth';

// Shared
import { errorHandler } from 'shared/utils/Helper';

export const SignupContainer: FC = () => {
  const { user, isAuthenticated } = useAuth();

  const { notifyError } = useNotification();

  const navigate = useNavigate();

  async function onPostSignUpHandler({
    email,
    first_name,
    last_name
  }: PostSignupType): Promise<void> {
    try {
      const response = await postSignUp({ email, first_name, last_name });
      if (response.status === 200) {
        // Request a passcode if the user is signed up successfully
        await postLogin({
          email
        });

        navigate({
          pathname: '/passcode',
          search: `?email=${encodeURIComponent(email)}`
        });
      } else {
        notifyError(response.data?.detail);
      }
    } catch (error: any) {
      notifyError(errorHandler(error));
    }
  }

  if (user && !user?.is_active) {
    return <Navigate to="/pending-approval" />;
  }

  if (isAuthenticated) {
    return <Navigate to="/user-onboarding" />;
  }

  return <Signup onPostSignUp={onPostSignUpHandler} />;
};
