import { FC } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import {
  Block,
  Button,
  Divider,
  Input,
  MotionGroup,
  MotionItem,
  PageTitle,
  SmallHeading
} from 'reablocks';

// Form lib validation
import * as Yup from 'yup';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

// Core
import { useAuth } from 'core/Auth';

// Icons
import { ReactComponent as LogoIcon } from 'assets/brand/logo-color.svg';
import { ReactComponent as GoogleIcon } from 'assets/icons/google.svg';
import { ReactComponent as MicrosoftIcon } from 'assets/icons/microsoft.svg';

// CSS
import css from './Signup.module.css';

// Types
import { PostSignupType } from 'core/Api/AuthApi';

type SignUpProps = {
  onPostSignUp: (data: PostSignupType) => Promise<void>;
};

const credentialsSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email').required('Required'),
  first_name: Yup.string().required('Required'),
  last_name: Yup.string().required('Required')
});

export const Signup: FC<SignUpProps> = ({ onPostSignUp }) => {
  const { login } = useAuth();

  const navigate = useNavigate();

  const {
    control,
    handleSubmit,
    formState: { isSubmitting, isValid },
    getValues
  } = useForm({
    mode: 'onChange',
    reValidateMode: 'onChange',
    resolver: yupResolver(credentialsSchema),
    defaultValues: {
      email: '',
      first_name: '',
      last_name: ''
    }
  });

  return (
    <>
      <Helmet>
        <title>Sign up</title>
      </Helmet>
      <div className={css.root}>
        <MotionGroup>
          <MotionItem className={css.header}>
            <LogoIcon className={css.logo} />
          </MotionItem>
          <div className={css.content}>
            <MotionGroup className={css.box}>
              <MotionItem className={css.login}>
                <header className={css.loginHeader}>
                  <PageTitle disableMargins className={css.loginTitle}>
                    Welcome To Abstract!
                  </PageTitle>
                  <SmallHeading className={css.tagline}>
                    Please fill-in the details to create your account
                  </SmallHeading>
                </header>
                <form
                  onSubmit={handleSubmit(() =>
                    onPostSignUp({
                      email: getValues('email'),
                      first_name: getValues('first_name'),
                      last_name: getValues('last_name')
                    })
                  )}
                >
                  <Block label="First Name">
                    <Controller
                      name="first_name"
                      control={control}
                      render={({ field: { value, onBlur, onChange } }) => (
                        <Input
                          name="first_name"
                          disabled={isSubmitting}
                          autoFocus
                          type="first_name"
                          value={value}
                          onChange={onChange}
                          onBlur={onBlur}
                          placeholder="John"
                        />
                      )}
                    />
                  </Block>
                  <Block label="Last Name">
                    <Controller
                      name="last_name"
                      control={control}
                      render={({ field: { value, onBlur, onChange } }) => (
                        <Input
                          name="last_name"
                          disabled={isSubmitting}
                          type="last_name"
                          value={value}
                          onChange={onChange}
                          onBlur={onBlur}
                          placeholder="Doe"
                        />
                      )}
                    />
                  </Block>
                  <Block label="Email">
                    <Controller
                      name="email"
                      control={control}
                      render={({ field: { value, onBlur, onChange } }) => (
                        <Input
                          name="email"
                          disabled={isSubmitting}
                          type="email"
                          value={value}
                          onChange={onChange}
                          onBlur={onBlur}
                          placeholder="user@abstract.security"
                        />
                      )}
                    />
                  </Block>
                  <br />
                  <Button
                    type="submit"
                    fullWidth
                    variant="filled"
                    color="primary"
                    disabled={isSubmitting || !isValid}
                  >
                    {isSubmitting ? 'Signing up...' : 'Sign Up'}
                  </Button>
                </form>
              </MotionItem>
              <MotionItem className={css.login}>
                <span className={css.or}>
                  <Divider />
                  <span className={css.text}>OR</span>
                </span>
              </MotionItem>
              <MotionItem className={css.login}>
                <Button
                  fullWidth
                  variant="outline"
                  color="default"
                  disabled={isSubmitting}
                  className={css.tpaButton}
                  onClick={() => login({ type: 'google' })}
                >
                  <GoogleIcon />
                  Continue with Google
                </Button>
                <Button
                  fullWidth
                  variant="outline"
                  color="default"
                  disabled={isSubmitting}
                  className={css.tpaButton}
                  onClick={() => login({ type: 'microsoft' })}
                >
                  <MicrosoftIcon />
                  Continue with Microsoft
                </Button>
              </MotionItem>
              <MotionItem className={css.login}>
                <SmallHeading className={css.tagline}>
                  Already have an account?{' '}
                  <Button
                    variant="text"
                    color="primary"
                    disableMargins
                    disablePadding
                    onClick={() => navigate('/login')}
                  >
                    Sign In
                  </Button>
                </SmallHeading>
              </MotionItem>
            </MotionGroup>
          </div>
        </MotionGroup>
      </div>
    </>
  );
};
