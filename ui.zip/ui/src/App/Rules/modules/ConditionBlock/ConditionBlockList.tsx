import { Block, Button, Divider, Stack, Text } from 'reablocks';
import { Reorder } from 'framer-motion';

// CSS
import css from './ConditionBlock.module.css';

// Modules
import { ConditionBlock } from './ConditionBlock';
import { AggregationField } from '../AggregationField';

// Shared
import { createEmptyCondition } from 'shared/elements/EventCondition/utils';

// Types
import { BlockType, ConditionListProps } from './ConditionBlock.types';

export const ConditionBlockList = ({
  blocks,
  onBlockListChange,
  menu,
  blockName,
  acsFieldOperations,
  acsFields
}: ConditionListProps) => {

  function updateConditionBlockList(block: BlockType, index: number) {
    const conditionBlocks = [...blocks];
    conditionBlocks.splice(index, 1, block);
    onBlockListChange(conditionBlocks);
  }

  function blockMenu(block: BlockType) {
    return menu.map((menuItem, innerIndex) => {
      return {
        ...menuItem,
        action() {
          menuItem.action?.(block, innerIndex);
        }
      };
    });
  }

  function addConditionToBlockList() {
    // Extract numbers from block names and find the highest one
    const highestNumber = blocks.reduce((max, block) => {
      const match = block?.name.match(/\d+/);
      const number = match ? parseInt(match[0], 10) : 0;
      return Math.max(max, number);
    }, 0);

    // Increment the highest number for the new block name
    const newBlockNumber = highestNumber + 1;

    // Add the new block to the list and trigger the change event
    onBlockListChange([
      ...blocks,
      {
        name: `${blockName} ${newBlockNumber}`,
        id: `${crypto.randomUUID()}`,
        operator: 'and',
        conditions: [createEmptyCondition()]
      }
    ]);
  }

  const onUpdateBaseOperator = ({
    operator,
    blockIndex
  }: {
    operator: 'and' | 'or';
    blockIndex: number;
  }) => {
    onBlockListChange(
      blocks.map((block, innerIndex) => {
        if (innerIndex === blockIndex) {
          return {
            ...block,
            operator
          };
        }
        return block;
      })
    );
  };

  return (
    <>
      <Reorder.Group
        axis="y"
        onReorder={onBlockListChange}
        values={blocks}
        className={css.block}
      >
        {blocks.map((block, blockIndex) => (
          <ConditionBlock
            key={block.id}
            className={css.block}
            block={block}
            onBlockChange={innerBlock => {
              updateConditionBlockList(innerBlock, blockIndex);
            }}
            headerText={block.name}
            reorder
            menu={blockMenu(block)}
            operator={block.operator}
            updateBaseOperator={operator =>
              onUpdateBaseOperator({ operator, blockIndex })
            }
            acsFieldOperations={acsFieldOperations}
            headerVariant="primary"
            acsFields={acsFields}
          >
            <Divider />
            {/* Aggregation Block */}
            <Block className={css.block}>
              <Stack direction="column" alignItems="start">
                {block?.aggregations?.length > 0 && (
                  <Text>And the aggregation condition is true</Text>
                )}
                <AggregationField
                  acsFields={acsFields}
                  acsFieldOperations={acsFieldOperations}
                  onChange={aggregations => {
                    const updatedBlock = { ...block, aggregations };
                    updateConditionBlockList(updatedBlock, blockIndex);
                  }}
                />
              </Stack>
            </Block>
          </ConditionBlock>
        ))}
      </Reorder.Group>

      <Button variant="outline" onClick={addConditionToBlockList}>
        Add {blockName}
      </Button>
    </>
  );
};

ConditionBlockList.defaultProps = {
  blockName: 'Block'
};
