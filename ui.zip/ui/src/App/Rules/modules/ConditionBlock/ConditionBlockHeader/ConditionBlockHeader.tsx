import { FC } from 'react';
import { Stack, Text } from 'reablocks';
import classNames from 'classnames';

// Shared
import Icon from 'shared/elements/Icon';

// Modules
import { ConditionBlockHeaderMenu } from './ConditionBlockHeaderMenu';

// CSS
import css from './ConditionBlockHeader.module.css';

// Types
import { type ConditionBlockHeaderProps } from '../ConditionBlock.types';

export const ConditionBlockHeader: FC<ConditionBlockHeaderProps> = ({
  menu,
  collapsable,
  reorder,
  name,
  dragControls,
  open,
  headerVariant,
  headerText,
  disabled
}) => (
  <header
    className={classNames(
      css.header,
      open && css.open,
      headerVariant === 'info' && css.backgroundVariantInfo,
      headerVariant === 'primary' && css.backgroundVariantPrimary
    )}
  >
    <Stack
      justifyContent="spaceBetween"
      className={classNames(open && css.open)}
    >
      <Stack>
        {reorder && (
          <Icon
            name="drag"
            className={css.dragHandle}
            onPointerDown={e => dragControls.start(e)}
          />
        )}

        <Text className={css.headerText}>{headerText || name}</Text>
      </Stack>

      <Stack>
        {collapsable && (
          <button
            data-collapse
            disabled={disabled}
            className={classNames(css.accordionToggle, open && css.rotated)}
          >
            <Icon name="chevron-down" />
          </button>
        )}

        {menu?.length > 0 && (
          <ConditionBlockHeaderMenu menu={menu} name={name} />
        )}
      </Stack>
    </Stack>
  </header>
);
