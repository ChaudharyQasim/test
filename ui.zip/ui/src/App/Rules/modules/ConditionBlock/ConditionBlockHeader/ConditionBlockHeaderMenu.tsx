import { useState, useRef } from 'react';
import { Button, Card, List, ListItem, Menu, Stack } from 'reablocks';
import Icon from 'shared/elements/Icon';
import {
  ConditionBlockHeaderMenuItem,
  ConditionBlockHeaderMenuProps
} from '../ConditionBlock.types';

export const ConditionBlockHeaderMenu = ({
  menu,
  name
}: ConditionBlockHeaderMenuProps) => {
  const [menuOpen, setMenuOpen] = useState<boolean>(false);
  const button = useRef<HTMLButtonElement | null>(null);

  function buildMenuItem(
    { iconPosition: pos, icon, action, text }: ConditionBlockHeaderMenuItem,
    i: number
  ) {
    const end = pos === 'start' || typeof pos === 'undefined';
    const start = pos === 'end';

    return (
      <ListItem
        key={`${name}.block.menu.item.${i}`}
        onClick={e => {
          action?.(e);
          setMenuOpen(false);
        }}
      >
        <Stack direction="row" justifyContent="spaceBetween">
          {start && <Icon name={icon} />}
          <span>{text}</span>
          {end && <Icon name={icon} />}
        </Stack>
      </ListItem>
    );
  }

  return (
    <>
      <Button
        ref={button}
        variant="text"
        onClick={() => setMenuOpen(!menuOpen)}
        disableMargins
        disablePadding
      >
        <Icon name="dots" />
      </Button>

      <Menu
        reference={button}
        open={menuOpen}
        placement="bottom-end"
        onClose={() => setMenuOpen(false)}
      >
        <Card>
          <List>{menu.map(buildMenuItem)}</List>
        </Card>
      </Menu>
    </>
  );
};
