import { ConditionType, FieldOperations } from 'shared/elements/EventCondition';
import { DragControls } from 'framer-motion';
import { IconName } from 'shared/elements/Icon';
import { ReactNode, Ref } from 'react';
import { ACSFieldType } from 'core/Api';

export type Aggregations = {
  condition: ConditionType;
  field_operation: string;
};

export type BlockType = {
  id: string;
  name?: string;
  operator?: 'and' | 'or';
  aggregations?: Aggregations[];
  conditions?: ConditionType[];
};

export type ConditionBlockHeaderVariant = 'primary' | 'info';

export type ConditionBlockProps = {
  block: BlockType;
  headerText?: string | ReactNode;
  reorder?: boolean;
  menu?: ConditionBlockHeaderMenuItem[];
  onBlockChange: (block: BlockType) => void;
  className?: string;
  disabled?: boolean;
  acsFieldOperations?: FieldOperations;
  headerVariant?: ConditionBlockHeaderVariant;
  dragRef?: Ref<HTMLDivElement>;
  acsFields?: ACSFieldType[];
  children?: ReactNode;
  operator?: 'and' | 'or';
  updateBaseOperator?: (operator: 'and' | 'or') => void;
};

export type ConditionBlockHeaderProps = {
  name?: string;
  open?: boolean;
  reorder?: boolean;
  block?: BlockType;
  collapsable?: boolean;
  dragControls?: DragControls;
  headerText?: string | ReactNode;
  disabled?: boolean;
  menu?: ConditionBlockHeaderMenuItem[];
  headerVariant?: ConditionBlockHeaderVariant;
  setBlock?: (block: BlockType) => void;
};

export interface ConditionBlockBodyProps extends Partial<ConditionBlockProps> {
  conditions: ConditionType[];
  setConditions: (conditions: ConditionType[]) => void;
}

export type ConditionListProps = {
  blocks: BlockType[];
  menu?: ConditionBlockHeaderMenuItem[];
  blockName?: string;
  acsFieldOperations?: FieldOperations;
  acsFields?: ACSFieldType[];
  onBlockListChange?: (blocks: BlockType[]) => void;
};

export interface ConditionBlockHeaderMenuProps
  extends Partial<ConditionBlockHeaderProps> {}

export type ConditionBlockHeaderMenuItemIconPosition = 'start' | 'end';

export type ConditionBlockHeaderMenuItem = {
  icon: IconName;
  iconPosition?: ConditionBlockHeaderMenuItemIconPosition;
  action?: (param: any, index?: number | undefined) => void;
  link?: string | null;
  text?: string;
};
