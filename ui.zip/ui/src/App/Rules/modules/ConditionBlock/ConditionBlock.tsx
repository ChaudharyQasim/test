import { FC, useState, forwardRef, Ref, useCallback } from 'react';
import { Block } from 'reablocks';

//Shared
import Accordion from 'shared/elements/Accordion';
import { EventCondition, ConditionType } from 'shared/elements/EventCondition';

// Modules
import ConditionBlockHeader from './ConditionBlockHeader';

// CSS
import css from './ConditionBlock.module.css';

// Types
import { ConditionBlockProps } from './ConditionBlock.types';
import { Reorder, useDragControls } from 'framer-motion';

export const ConditionBlock: FC<ConditionBlockProps> = forwardRef(
  (
    {
      block,
      onBlockChange,
      reorder,
      menu,
      headerVariant,
      headerText,
      disabled,
      acsFieldOperations,
      operator,
      updateBaseOperator,
      children,
      acsFields
    },
    ref: Ref<HTMLDivElement>
  ) => {

    const dragControls = useDragControls();
    const [accordionOpen, setAccordionOpen] = useState(!disabled);

    const setConditions = useCallback(
      (conditions: ConditionType[]) => {
        onBlockChange({ ...block, conditions });
      },
      [onBlockChange, block]
    );

    return (
      <Reorder.Item
        key={block.id}
        value={block}
        dragListener={false}
        dragControls={dragControls}
      >
        <Accordion
          open={accordionOpen}
          className={css.block}
          disabled={disabled}
          onToggle={() => setAccordionOpen(!accordionOpen)}
          header={
            <ConditionBlockHeader
              menu={menu}
              collapsable
              open={accordionOpen}
              reorder={reorder}
              name={block.name}
              dragControls={dragControls}
              headerVariant={headerVariant}
              headerText={headerText}
              block={block}
              setBlock={onBlockChange}
            />
          }
          body={
            <div className={css.inner} id="no-draggable" ref={ref}>
              <Block className={css.block}>
                <EventCondition
                  operator={operator}
                  updateBaseOperator={updateBaseOperator}
                  fields={acsFields}
                  conditions={block.conditions}
                  onConditionsChange={setConditions}
                  fieldOperationsMap={acsFieldOperations}
                />
              </Block>
              {children}
            </div>
          }
        />
      </Reorder.Item>
    );
  }
);
