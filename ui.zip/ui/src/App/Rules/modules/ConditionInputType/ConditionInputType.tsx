import { FC } from 'react';
import { SelectOption } from 'reablocks';

// Shared
import { NumberInput } from 'shared/elements/EventCondition/NumberInput';
import { StringInput } from 'shared/elements/EventCondition/StringInput';
import { ConditionDate } from 'shared/form/Input/ConditionDate';
import { IpInput } from 'shared/elements/EventCondition/IpInput';
import { CoordinateInput } from 'shared/elements/EventCondition/CoordinateInput';
import { ListInput } from 'shared/elements/EventCondition/ListInput';
import { ConditionSelect } from 'shared/form/Select';
import {
  ConditionType,
  CoordinateRange,
  DateRange,
  FieldOperations
} from 'shared/elements/EventCondition';

// Core
import { ACSFieldType, TypeEnum } from 'core/Api';

// Types
type ConditionInputTypeProps = {
  inputType: string;
  fields: ACSFieldType[];
  condition: ConditionType;
  fieldOperationsMap: FieldOperations;
  onConditionChange: (condition: ConditionType) => void;
};

export const ConditionInputType: FC<ConditionInputTypeProps> = ({
  inputType,
  condition,
  fields,
  onConditionChange,
  fieldOperationsMap
}) => {
  return (
    <>
      <ConditionSelect
        value={condition?.field || ''}
        placeholder="field"
        onChange={value => {
          const fieldType = fields.find(({ field }) => value === field)
            ?.data_type;
          onConditionChange({
            ...condition,
            field: value,
            field_operation: '',
            value: '',
            subFieldOperation: '',
            fieldType
          });
        }}
      >
        {fields?.map(({ field }) => (
          <SelectOption key={field} value={field}>
            {field}
          </SelectOption>
        ))}
      </ConditionSelect>
      <ConditionSelect
        value={condition?.field_operation || ''}
        placeholder="operation"
        onChange={value =>
          onConditionChange({
            ...condition,
            field_operation: value,
            subFieldOperation: ''
          })
        }
        disabled={!condition.field}
      >
        {inputType &&
          fieldOperationsMap?.condition[inputType].map(operation => (
            <SelectOption key={operation.value} value={operation.value}>
              {operation.label}
            </SelectOption>
          ))}
      </ConditionSelect>
      {['Float32', 'Float64', 'Long'].includes(inputType) && (
        <NumberInput
          condition={condition}
          onValueChange={value => onConditionChange({ ...condition, value })}
        />
      )}
      {['String', 'Enum'].includes(inputType) && (
        <StringInput
          condition={condition}
          onValueChange={value => onConditionChange({ ...condition, value })}
          onCaseSensitiveChange={caseSensitive =>
            onConditionChange({
              ...condition,
              caseSensitive
            })
          }
        />
      )}
      {inputType === 'Date' && (
        <ConditionDate
          value={
            condition?.field_operation === 'IN_RANGE'
              ? (condition.value as DateRange)
              : (condition.value as Date)
          }
          onChange={value => onConditionChange({ ...condition, value })}
          isRange={condition?.field_operation === 'IN_RANGE'}
        />
      )}
      {['Ipv4', 'Ipv6'].includes(inputType) &&
        condition?.field_operation !== 'IS_RFC1989' && (
          <IpInput
            type={inputType as TypeEnum}
            condition={condition}
            onValueChange={value => onConditionChange({ ...condition, value })}
          />
        )}
      {inputType === 'Coordinate' && (
        <CoordinateInput
          condition={condition}
          onValueChange={(value: CoordinateRange) =>
            onConditionChange({ ...condition, value })
          }
        />
      )}
      {['List(String)'].includes(inputType) && (
        <ListInput
          condition={condition}
          fieldOperationsMap={fieldOperationsMap}
          onValueChange={(subFieldOperation, value) =>
            onConditionChange({
              ...condition,
              subFieldOperation,
              value
            })
          }
          onCaseSensitiveChange={caseSensitive =>
            onConditionChange({ ...condition, caseSensitive })
          }
        />
      )}
    </>
  );
};
