import { Button } from 'reablocks';
import { FC, useState } from 'react';

// CSS
import css from './AggregationField.module.css';

import {
  EventConditionRow,
  FieldOperations,
  createEmptyCondition
} from 'shared/elements/EventCondition';
import { AGGREGATION_ACTION_OPTIONS } from 'shared/utils/Constants';

// Modules
import { Aggregations } from '../ConditionBlock';
import { ConditionInputType } from '../ConditionInputType';

// Core
import { ACSFieldType } from 'core/Api';

// Types
type AggregationsProps = {
  acsFields: ACSFieldType[];
  acsFieldOperations: FieldOperations;
  aggregationsDetails?: Aggregations[];
  onChange?: (aggregations: Aggregations[]) => void;
};

export const AggregationField: FC<AggregationsProps> = ({
  acsFields,
  acsFieldOperations,
  aggregationsDetails,
  onChange
}) => {
  const [aggregations, setAggregations] = useState<Aggregations[]>(
    aggregationsDetails || []
  );

  function addNewAgregation() {
    const newAggregation = [
      ...aggregations,
      {
        condition: createEmptyCondition(),
        field_operation: ''
      }
    ];
    setAggregations(newAggregation);
    onChange(newAggregation);
  }

  function updateAggregationFields({ aggregation, index, aggregationType }) {
    const updatedAggregations = [...aggregations];
    updatedAggregations[index] = {
      ...updatedAggregations[index],
      [aggregationType]: aggregation
    };
    onChange(updatedAggregations);
    setAggregations(updatedAggregations);
  }

  return (
    <>
      <section className={css.conditionRow}>
        {aggregations.map((aggregation, index) => (
          <EventConditionRow
            key={index}
            conditions={[
              {
                conditionOptions: AGGREGATION_ACTION_OPTIONS.map(
                  ({ field, value }) => ({ label: field, value })
                ),
                value: [aggregation.field_operation],
                onConditionChange: value =>
                  updateAggregationFields({
                    aggregation: value,
                    aggregationType: 'field_operation',
                    index
                  })
              }
            ]}
            customConditions={
              aggregation.field_operation && (
                <ConditionInputType
                  inputType={aggregation.condition.fieldType}
                  fields={acsFields}
                  onConditionChange={value => {
                    updateAggregationFields({
                      aggregation: value,
                      aggregationType: 'condition',
                      index
                    });
                  }}
                  fieldOperationsMap={acsFieldOperations}
                  condition={aggregation.condition}
                />
              )
            }
            onDelete={() => {
              const updatedAggregations = [...aggregations];
              updatedAggregations.splice(index, 1);
              setAggregations(updatedAggregations);
              onChange(updatedAggregations);
            }}
          />
        ))}
      </section>
      {aggregations.length < 1 && (
        <Button
          size="small"
          variant="outline"
          onClick={() => addNewAgregation()}
        >
          Add Aggregation
        </Button>
      )}
    </>
  );
};
