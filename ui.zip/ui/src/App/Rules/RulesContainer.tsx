import { FC, useCallback, useMemo } from 'react';
import { Rules } from './Rules';
import { useMutation, useQuery, useQueryClient } from 'react-query';

// Core
import { useAuth } from 'core/Auth';
import { RulesListOut } from 'core/Api';
import { useNotification } from 'reablocks';
import {
  deleteRule,
  getRulesList,
  RuleQueryType,
  saveAllRules
} from 'core/Api/RulesApi';
import { getOrganizationUsers } from 'core/Api/UsersApi';
import { PAGE_SIZE } from './constants';

// Shared
import { Loader } from 'shared/elements/Loader';
import { errorHandler } from 'shared/utils/Helper';

export const RulesContainer: FC = () => {
  const { user } = useAuth();

  const queryClient = useQueryClient();

  const initialRulesData = {
    initialData: {
      rules: [],
      metadata: {
        total_count: 0,
        page_size: PAGE_SIZE,
        page_number: 1
      }
    }
  };
  const { notifySuccess, notifyError } = useNotification();

  const { data: organizationUsers } = useQuery(
    'organizationUsers',
    () => getOrganizationUsers(user.current_organization.id),
    {
      initialData: []
    }
  );

  const { data: rulesDataList, isLoading: isRulesListLoading } = useQuery(
    'rulesList',
    () => {
      return getRulesList({ params: { page_size: PAGE_SIZE } });
    },
    initialRulesData
  );

  const { mutate: fetchRulesOnQuery, mutateAsync: fetchRulesMutateAsync } =
    useMutation(
      ({ params, constructedUrl }: RuleQueryType) => {
        return getRulesList({
          params: { ...params, page_size: PAGE_SIZE },
          constructedUrl
        });
      },
      {
        onSuccess: data => {
          queryClient.setQueryData('rulesList', data);
        },
        onError(error) {
          notifyError(errorHandler(error));
        }
      }
    );

  const { mutate: saveAllRulesMutation, isLoading: isSaveRulesLoading } =
    useMutation(saveAllRules, {
      onSuccess() {
        notifySuccess('Rules updated successfully.');
      },
      onError() {
        notifyError('Error occurred while updating rules.');
      }
    });

  const { mutate: deleteRuleMutation } = useMutation(
    (ruleId: string) => deleteRule(ruleId),
    {
      onSuccess() {
        fetchRulesOnQuery({});
        queryClient.invalidateQueries('rulesList');
        notifySuccess('Rule deleted successfully.');
      },
      onError() {
        notifyError('Error occurred while deleting rule.');
      }
    }
  );

  const formatFindingsGraph = (findings_details: any) => {
    if (!findings_details) {
      return findings_details;
    }

    const { graph } = findings_details;

    return graph.map((item: { timestamp: string; count: number }) => {
      return {
        key: item.timestamp,
        data: item.count
      };
    });
  };

  const formatRulesData = useCallback((rulesList: RulesListOut) => {
    if (!rulesList?.rules?.length) {
      return rulesList;
    }
    return {
      rules: rulesList.rules.map(rule => ({
        ...rule,
        findings_details: {
          ...rule.findings_details,
          graph: formatFindingsGraph(rule.findings_details)
        }
      })),
      metadata: rulesList.metadata
    };
  }, []);

  const rulesList = useMemo(() => {
    return formatRulesData(rulesDataList);
  }, [rulesDataList, formatRulesData]);

  if (isRulesListLoading) {
    return <Loader />;
  }

  return (
    <Rules
      rulesData={rulesList}
      updateListOnQuery={fetchRulesOnQuery}
      deleteRuleMutation={deleteRuleMutation}
      organizationUsers={organizationUsers}
      isSaveRulesLoading={isSaveRulesLoading}
      saveAllRulesMutation={saveAllRulesMutation}
      fetchRulesMutateAsync={fetchRulesMutateAsync}
    />
  );
};
