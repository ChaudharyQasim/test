import { FC, useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import {
  Block,
  Button,
  DateFormat,
  DebouncedInput,
  PrimaryHeading,
  SelectOption,
  SmallHeading,
  Stack,
  Text,
  Textarea
} from 'reablocks';

// CSS
import css from './RuleBuilder.module.css';

// Constants
import { DEFAULT_TITLE, DEFAULT_CORRELATION } from '../constants';

// Shared
import { ToggleInputEdit } from 'shared/form/ToggleInputEdit';
import { CreatableChip } from 'shared/elements/Chip/CreateableChip';
import { DeletableChip } from 'shared/elements/Chip';
import { TextToggle } from 'shared/elements/TextToggle';
import {
  ConditionBlockList,
  BlockType,
  ConditionBlockHeaderMenuItem
} from 'App/Rules/modules/ConditionBlock';
import ConditionBlockHeader from 'App/Rules/modules/ConditionBlock/ConditionBlockHeader';
import {
  ConditionType,
  EventCondition,
  EventConditionRow,
  FieldOperations,
  ValueType
} from 'shared/elements/EventCondition';
import { ConfirmationDialog } from 'shared/layers/ConfirmationDialog';
import Accordion from 'shared/elements/Accordion';
import { ConditionInput } from 'shared/form/Input';
import { ConditionSelect } from 'shared/form/Select';
import { DATE_FORMAT } from 'shared/utils/Constants';

// Icons
import { ReactComponent as RulesBuilderIcon } from 'assets/icons/rules-builder.svg';
import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';
import { ReactComponent as CheckIcon } from 'assets/icons/check.svg';
import { ReactComponent as DateIcon } from 'assets/icons/date.svg';
import { ReactComponent as UserIcon } from 'assets/icons/user.svg';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';

// Core
import {
  ACSFieldType,
  RuleActionEnum,
  RuleEventCategories,
  RuleStateEnum,
  RuleTypeEnum,
  RuleUpdateIn,
  SeverityTypeEnum
} from 'core/Api';
import { RuleDetailType, RuleInExtended } from 'core/Api/RulesApi';

// Rules Utils
import {
  formatMultipleEventConditions,
  uniqueEventCondition
} from '../RulesUtils';

// Types
type ConfirmationType = {
  confirmationDialogType: 'SAVE' | 'SAVE_CLOSE' | 'WARNING' | 'WARNING_DISCARD';
  isConfirmationDialogOpen: boolean;
  eventsWithErrors?: {
    conditions: any[];
    aggregations: any[];
  };
  conditionMissing?: boolean;
  aggregationMissing?: boolean;
  correlationMissing?: boolean;
};
type NewRuleProps = {
  acsFieldOperations: FieldOperations;
  acsFields: ACSFieldType[];
  isNewRulesCreationLoading?: boolean;
  ruleDetail?: RuleDetailType;
  createNewRule?: (rule: RuleInExtended) => void;
  updateRule?: (rule: RuleUpdateIn) => void;
};

export const RuleBuilder: FC<NewRuleProps> = ({
  acsFieldOperations,
  acsFields,
  createNewRule,
  ruleDetail,
  isNewRulesCreationLoading,
  updateRule
}) => {
  const ruleDescription = ruleDetail?.description;
  const ruleTagsDetail = ruleDetail?.tags || [];

  // Get window minutes
  const windowMinutesDetail =
    ruleDetail?.query_json?.block?.config?.windowMinutes;

  // Get correlation Fields
  const correlationField = ruleDetail?.query_json?.block?.config?.fields;

  // Get the events from the rule detail if it exists
  const ruleQueryBlock = ruleDetail?.query_json?.block;
  const ruleConditions = ruleQueryBlock?.config?.aggregations[0]?.conditions;
  const ruleUniqueEvent = ruleQueryBlock?.groups?.[0]?.conditions;

  // Get the events from the rule snapshot if it exists
  const ruleSnapshot = ruleDetail?.query_snapshot;

  // Get the events from the rule detail or rule snapshot
  // If the rule snapshot exists, use it
  // If the rule snapshot doesn't exist, use the rule detail if it has at least 2 events
  // If the rule detail has less than 2 events, use the unique event condition
  const getBlockEvents = ruleSnapshot?.length
    ? ruleSnapshot
    : ruleConditions?.length >= 2
    ? formatMultipleEventConditions(ruleConditions)
    : uniqueEventCondition(ruleUniqueEvent);

  const [blockEvents, setBlockEvents] = useState<BlockType[]>(getBlockEvents);

  const [title, setTitle] = useState<string>('');
  const [ruleTags, setRuleTags] = useState<string[]>(ruleTagsDetail);
  const [blockCorrelation, setBlockCorrelation] =
    useState<BlockType>(DEFAULT_CORRELATION);
  const [initialCorrelation, setInitialCorrelation] = useState<string>(
    correlationField?.[0] || ''
  );

  const [windowMinutes, setWindowMinutes] = useState<number>(
    windowMinutesDetail || 0
  );
  const [slideTimeSelect, setSlideTimeSelect] = useState<string>('tumbling');

  const [correlationAccordionOpen, setCorrelationAccordionOpen] =
    useState<boolean>(true);

  const [descriptionState, setDescriptionState] = useState<{
    toggle: boolean;
    text: string;
  }>({
    toggle: Boolean(ruleDescription),
    text: ruleDescription || ''
  });

  const [openSaveConfirmation, setOpenSaveConfirmation] =
    useState<ConfirmationType>({
      isConfirmationDialogOpen: false,
      confirmationDialogType: 'SAVE',
      conditionMissing: false,
      aggregationMissing: false,
      correlationMissing: false,
      eventsWithErrors: null
    });

  const navigate = useNavigate();

  const ruleName = title || ruleDetail?.name || DEFAULT_TITLE;

  const dialogConfiguration = useMemo(() => {
    const {
      confirmationDialogType,
      correlationMissing,
      conditionMissing,
      aggregationMissing,
      eventsWithErrors
    } = openSaveConfirmation;
    if (confirmationDialogType === 'WARNING') {
      const warningMessage = (
        <Stack alignItems="start" justifyContent="start" direction="column">
          {correlationMissing && (
            <Stack>
              <CloseIcon />{' '}
              <Text className={css.warningText}>
                You have to select a field within the correlation block to
                enable event correlation.
              </Text>
            </Stack>
          )}
          {(conditionMissing || aggregationMissing) && (
            <>
              <Stack>
                <CloseIcon />{' '}
                <Text>The following events have some fields empty.</Text>
              </Stack>
              {eventsWithErrors?.conditions.map((event: any) => (
                <Text key={event.id}>
                  - <strong>{event.name}</strong> has some conditions empty.
                </Text>
              ))}
              {eventsWithErrors?.aggregations.map((event: any) => (
                <Text key={event.id}>
                  - <strong>{event.name}</strong> has some aggregations empty.
                </Text>
              ))}
            </>
          )}
        </Stack>
      );
      return {
        buttonName: 'Fix the fields',
        heading: 'You have some invalid fields',
        message: warningMessage
      };
    }
    if (
      confirmationDialogType === 'SAVE' ||
      confirmationDialogType === 'SAVE_CLOSE'
    ) {
      return {
        buttonName: 'Save Rule',
        heading: 'Want to save the rule',
        message: 'Are you sure you want to save the rule?'
      };
    }
    return {};
  }, [openSaveConfirmation]);

  const EventHeaderMenu: ConditionBlockHeaderMenuItem[] = [
    {
      icon: 'delete',
      text: 'Delete',
      action(event) {
        const findEventIndex = blockEvents.findIndex(
          ({ id }) => id === event.id
        );
        const updatedEvents = [...blockEvents];
        updatedEvents.splice(findEventIndex, 1);
        setBlockEvents(updatedEvents);
      }
    },
    {
      icon: 'duplicate',
      text: 'Clone',
      action(event: BlockType) {
        setBlockEvents([
          ...blockEvents,
          {
            ...event,
            name: `${event.name} (Copy)`,
            id: `${event.id}-copy`
          }
        ]);
      }
    }
  ];

  /**
   * @description This function is used to validate the aggregation field
   * @param event
   * @returns object with the aggregation field and the subOperation
   */
  function aggregationFieldValidation(event: BlockType) {
    const hasAggregation = event?.aggregations;

    // Determine the aggregation field based on whether 'event' has aggregations
    // If 'hasAggregation' is true, use the first aggregation's condition; otherwise, use the first condition from 'event.conditions'
    const aggregationField = hasAggregation
      ? hasAggregation[0].condition
      : event.conditions[0];

    // When the first condition is nested it gets the value as an array
    // So we need to validate if the value is an array and get the first element
    const validAggregationField = Array.isArray(aggregationField.value)
      ? (aggregationField.value[0] as ConditionType)
      : aggregationField;

    return {
      // Set 'fieldOperation' based on whether 'event' has aggregations
      // If 'hasAggregation' is true, use the first aggregation's field_operation; otherwise, use 'field_operation' from 'aggregationField'
      fieldOperation: hasAggregation
        ? hasAggregation[0].field_operation
        : validAggregationField.field_operation,

      field: validAggregationField.field,
      subOperation: {
        fieldType: validAggregationField.fieldType,
        field_operation: validAggregationField.field_operation,
        value: validAggregationField.value
      }
    };
  }

  /**
   * @description This function is used to format and filter
   * the conditions are filtered based on whether the condition has a nested condition or not
   * @param conditions
   * @return formatted and filtered conditions as an array
   * the filter will check if the value is an array and have a field then,
   * it is a nested condition with the following structure
   * [{
   *  "field_operation": "EQUALS",
   *  "field": "message",
   *  "value": "2",
   *  "fieldType": "String"
   *  }]
   */
  function formatConditions(conditions: ConditionType[]) {
    return conditions
      .filter(condition => {
        return !condition.value?.[0]?.field && condition.field;
      })
      .map(condition => {
        return {
          field_operation: condition.field_operation,
          field: condition.field,
          value: condition.value,
          fieldType: condition.fieldType
        };
      });
  }

  /**
   * @description This function is used to format the nested conditions
   * also it will keep iterating recursively until there is no nested condition
   * @param nestedConditions
   * @returns formatted nested conditions as an array with the following structure
   * [{
   *   "conditions":  {
   *     field_operation": "EQUALS",
   *     "field": "message",
   *     "value": "2",
   *     "fieldType": "String"
   *   }],
   *   "operator": "or"
   * }]
   */
  function formatNestedConditions(nestedConditions: ConditionType[]) {
    return nestedConditions.map((nestedCondition: ConditionType) => {
      const nestedConditionValue = nestedCondition.value as ConditionType[];
      const formattedConditions = {
        conditions: formatConditions(nestedConditionValue),
        operator: nestedCondition.operator
      };
      const hasNestedConditions = nestedConditionValue.filter(
        (condition: ConditionType) => {
          return condition.value?.[0]?.field;
        }
      );

      if (hasNestedConditions.length > 0) {
        formattedConditions['groups'] =
          formatNestedConditions(hasNestedConditions);
      }

      return formattedConditions;
    });
  }

  function formatGroupEvents(validateAggregation?: boolean) {
    return blockEvents.map(event => {
      let aggregation = {};
      let blockGroup = {};
      const hasNestedConditions = event.conditions.filter(condition => {
        return condition.value?.[0]?.field || condition.value?.[0]?.operator;
      });
      const conditions = {
        conditions: formatConditions(event.conditions),
        operator: event.operator
      };

      if (hasNestedConditions.length > 0) {
        // Add nested conditions and iterate recursively until there is no nested condition
        conditions['groups'] = formatNestedConditions(hasNestedConditions);
      }

      // Block group for unique events
      blockGroup = conditions;

      // Block group for multiple events
      if (validateAggregation) {
        aggregation = aggregationFieldValidation(event);
        blockGroup = {
          ...aggregation,
          groups: [
            {
              ...conditions
            }
          ]
        };
      }

      return blockGroup;
    });
  }

  function formatRulesData(action: 'CREATE' | 'UPDATE') {
    let configuration = {};
    if (blockEvents.length === 1) {
      configuration = {
        block: {
          groups: [...formatGroupEvents()]
        },
        field_operation_type: 'AGGREGATION'
      };
    }

    if (blockEvents.length >= 2) {
      const correlationConditions = blockCorrelation.conditions
        .filter(condition => condition.field)
        .map(condition => {
          return {
            ...condition,
            fieldType: 'Field'
          };
        });
      const getCorrelationValues = [initialCorrelation];

      configuration = {
        block: {
          config: {
            aggregations: [
              {
                operator: 'and',
                conditions: [...formatGroupEvents(true)]
              }
            ],
            fields: [...getCorrelationValues],
            windowMinutes: windowMinutes
          }
        }
      };

      if (correlationConditions.length > 0) {
        configuration['block']['groups'] = [
          {
            conditions: [...correlationConditions],
            operator: 'and'
          }
        ];
      }
    }

    const rulesData = {
      name: title || DEFAULT_TITLE,
      description: descriptionState.text,
      tags: ruleTags,
      type: RuleTypeEnum.Conditional,
      action: RuleActionEnum.Realtime,
      severity: SeverityTypeEnum.Low,
      state: RuleStateEnum.Production,
      mitre_attack_techniques: [],
      event_categories: [RuleEventCategories.Api],
      query: {
        ...configuration
      },
      query_snapshot: blockEvents,
      is_enabled: true
    };

    if (action === 'UPDATE') {
      delete rulesData.query;
      rulesData['query_json'] = {
        ...configuration
      };
    }

    return rulesData;
  }

  function validateCondition(condition: ConditionType) {
    return (
      condition?.field === '' ||
      condition?.field_operation === '' ||
      condition?.value === ''
    );
  }

  function checkAggregationField() {
    return blockEvents
      .map(event => {
        return {
          ...event,
          aggregations: event?.aggregations?.filter(aggregation => {
            const condition = aggregation?.condition;
            return validateCondition(condition);
          })
        };
      })
      .filter(event => event?.aggregations?.length > 0);
  }

  function checkEventsCondition() {
    return blockEvents
      .map(event => {
        return {
          ...event,
          conditions: event.conditions.filter(condition => {
            return validateCondition(condition);
          })
        };
      })
      .filter(event => event.conditions.length > 0);
  }

  function rulesValidity(): ConfirmationType {
    const validateAggregation =
      blockEvents.length >= 2 && checkAggregationField().length > 0;
    const validateCorrelation =
      blockEvents.length >= 2 && initialCorrelation === '';
    const validateCondition =
      blockEvents.length > 0 && checkEventsCondition().length > 0;

    if (validateCondition || validateAggregation || validateCorrelation) {
      return {
        isConfirmationDialogOpen: true,
        confirmationDialogType: 'WARNING',
        conditionMissing: validateCondition,
        aggregationMissing: validateAggregation,
        correlationMissing: validateCorrelation,
        eventsWithErrors: {
          conditions: checkEventsCondition(),
          aggregations: checkAggregationField()
        }
      };
    } else {
      return {
        isConfirmationDialogOpen: true,
        confirmationDialogType: 'SAVE'
      };
    }
  }

  function onCreateRuleConfirmation() {
    if (openSaveConfirmation.confirmationDialogType === 'SAVE') {
      if (createNewRule) {
        createNewRule(formatRulesData('CREATE'));
      }
      if (updateRule) {
        updateRule(formatRulesData('UPDATE'));
      }
      setOpenSaveConfirmation(prevState => ({
        ...prevState,
        isConfirmationDialogOpen: false
      }));
    } else {
      setOpenSaveConfirmation(prevState => ({
        ...prevState,
        isConfirmationDialogOpen: false
      }));
    }
  }

  const onCorrelationConditionUpdate = useCallback(
    (conditions: ConditionType[]) => {
      setBlockCorrelation({ ...blockCorrelation, conditions });
    },
    [blockCorrelation]
  );

  return (
    <Block className={css.root}>
      <Helmet>
        <title>{ruleName}</title>
      </Helmet>

      <header className={css.dialogHeader}>
        <div className={css.title}>
          <RulesBuilderIcon /> Rules Builder
        </div>
        <Stack justifyContent="end">
          <Button
            variant="outline"
            className={css.iconBtn}
            onClick={() => navigate('/rules')}
          >
            <CloseIcon /> Cancel
          </Button>
          <Button
            variant="filled"
            color="primary"
            className={css.iconBtn}
            disabled={isNewRulesCreationLoading}
            onClick={() => {
              const rulesValidation = rulesValidity();
              setOpenSaveConfirmation({
                confirmationDialogType: rulesValidation.confirmationDialogType,
                isConfirmationDialogOpen: true,
                ...rulesValidation
              });
            }}
          >
            <CheckIcon />
            {isNewRulesCreationLoading ? 'Saving...' : 'Save'}
          </Button>
        </Stack>
      </header>

      <section className={css.subHeaderSection}>
        <Block>
          <ToggleInputEdit
            toggleToComponent={
              <DebouncedInput
                className={css.titleInput}
                value={ruleName}
                debounce={1000}
                fullWidth
                onChange={event => {
                  const title = event.target.value;
                  setTitle(title);
                }}
              />
            }
          >
            <PrimaryHeading>{ruleName}</PrimaryHeading>
          </ToggleInputEdit>
        </Block>

        <Block>
          <Stack className={css.subSection}>
            {ruleDetail?.created_by && (
              <Stack className={css.attribute} dense>
                <UserIcon className={css.detailIcon} /> Created by -{' '}
                {ruleDetail.created_by} ·
              </Stack>
            )}
            {ruleDetail?.created_at && (
              <Stack className={css.attribute} dense>
                <DateIcon className={css.detailIcon} /> Created On -{' '}
                <DateFormat
                  date={ruleDetail?.created_at}
                  format={DATE_FORMAT}
                />
              </Stack>
            )}
          </Stack>
        </Block>

        <Block>
          {!descriptionState.toggle && (
            <Button
              size="small"
              variant="text"
              disablePadding
              className={css.description}
              onClick={() => {
                setDescriptionState(prevState => ({
                  ...prevState,
                  toggle: !prevState.toggle
                }));
              }}
            >
              <PlusIcon className={css.icon} />
              <Text className={css.text}>Add Description</Text>
            </Button>
          )}
          {descriptionState.toggle && (
            <Textarea
              minRows={4}
              size="medium"
              fullWidth
              placeholder="Add a description"
              defaultValue={descriptionState.text}
              onChange={event => {
                const text = event.target.value;
                setDescriptionState(prevState => ({ ...prevState, text }));
              }}
            ></Textarea>
          )}
        </Block>

        <Stack className={css.subSection}>
          {ruleTags.length === 0 && (
            <Stack className={css.attribute} dense>
              No tags added
            </Stack>
          )}
          {ruleTags?.map((tag, idx) => (
            <DeletableChip
              key={tag}
              variant="outline"
              onDelete={() => {
                const updatedTags = [...ruleTags];
                updatedTags.splice(idx, 1);
                setRuleTags(updatedTags);
              }}
            >
              {tag}
            </DeletableChip>
          ))}
          <CreatableChip
            onCreate={newTag => setRuleTags(prev => [...prev, newTag])}
          />
        </Stack>
      </section>

      <main className={css.mainLayout}>
        {/* @TODO: This will be come on the explorer functionlity */}
        {/* <aside className={css.box}>
          <SmallHeading>Explorer</SmallHeading>
        </aside> */}

        <section className={css.box}>
          <header>
            <SmallHeading>Trigger</SmallHeading>
          </header>

          <section className={css.conditions}>
            {/* Configuration block */}
            {blockEvents.length >= 2 && (
              <>
                <ConditionBlockHeader
                  collapsable={false}
                  open={true}
                  name="Configuration"
                />
                <section className={css.block}>
                  <div className={css.inner}>
                    <EventConditionRow
                      customConditions={
                        <Text className={css.customConfCondition}>
                          <span>Events must be observed </span>
                          <strong>in sequence within a </strong>
                          <ConditionInput
                            type="number"
                            placeholder="0"
                            value={windowMinutes}
                            min={0}
                            max={60}
                            onChange={value =>
                              setWindowMinutes(parseInt(value.target.value))
                            }
                          />
                          <strong>
                            {windowMinutes === 1 ? 'minute' : 'minutes'}
                          </strong>
                          <ConditionSelect
                            value={slideTimeSelect}
                            onChange={operator => {
                              setSlideTimeSelect(operator);
                            }}
                          >
                            <SelectOption value="tumbling">
                              Tumbling
                            </SelectOption>
                          </ConditionSelect>
                        </Text>
                      }
                    />
                  </div>
                </section>
              </>
            )}

            {/* Correlation Block */}
            <Accordion
              open={correlationAccordionOpen}
              className={css.block}
              disabled={blockEvents.length < 2}
              onToggle={() =>
                setCorrelationAccordionOpen(!correlationAccordionOpen)
              }
              header={
                <ConditionBlockHeader
                  collapsable
                  open={correlationAccordionOpen}
                  name={blockCorrelation.name}
                  headerVariant="info"
                  headerText={
                    <TextToggle
                      text={[
                        `Add at least two events to create a correlation.`,
                        'Correlation (Required)'
                      ]}
                      condition={blockEvents.length < 2}
                    />
                  }
                  block={blockCorrelation}
                  setBlock={correlations => {
                    setBlockCorrelation(correlations);
                  }}
                />
              }
              body={
                <div className={css.inner}>
                  <Block>
                    <Text>Events must match the conditions</Text>
                  </Block>
                  <EventConditionRow
                    customConditions={
                      <Stack>
                        <Text>
                          The following field is equal across all events
                        </Text>
                        <ConditionSelect
                          value={initialCorrelation}
                          onChange={value => setInitialCorrelation(value)}
                        >
                          {acsFields?.map(acs => (
                            <SelectOption key={acs.field} value={acs.field}>
                              {acs.field}
                            </SelectOption>
                          ))}
                        </ConditionSelect>
                      </Stack>
                    }
                  />
                  {/* TODO: Will be added later when the requirements are met */}
                  {/* <EventCondition
                    operator={blockCorrelation.operator}
                    updateBaseOperator={operator => {
                      setBlockCorrelation({ ...blockCorrelation, operator });
                    }}
                    hideNestButton
                    fields={acsFields}
                    conditions={blockCorrelation.conditions}
                    onConditionsChange={onCorrelationConditionUpdate}
                    fieldOperationsMap={acsFieldOperations}
                    showHeaderConditionText={false}
                  /> */}
                </div>
              }
            />

            {/* Event list */}
            <ConditionBlockList
              blockName="Event"
              blocks={blockEvents}
              onBlockListChange={blockEvents => {
                setBlockEvents(blockEvents);
              }}
              menu={EventHeaderMenu}
              acsFieldOperations={acsFieldOperations}
              acsFields={acsFields}
            />
          </section>
        </section>
      </main>
      <ConfirmationDialog
        open={openSaveConfirmation.isConfirmationDialogOpen}
        dialogType={
          openSaveConfirmation.confirmationDialogType === 'WARNING'
            ? 'WARNING'
            : 'CONFIRMATION'
        }
        confirmationButtonName={dialogConfiguration.buttonName}
        confirmationHeading={dialogConfiguration.heading}
        confirmationMessage={dialogConfiguration.message}
        onConfirm={onCreateRuleConfirmation}
        onCancel={() =>
          setOpenSaveConfirmation(prevState => ({
            ...prevState,
            isConfirmationDialogOpen: false
          }))
        }
      />
    </Block>
  );
};
