import { createEmptyCondition } from 'shared/elements/EventCondition/utils';
import { BlockType } from 'App/Rules/modules/ConditionBlock/ConditionBlock.types';
import { FieldEnum } from 'core/Api';

export const DEFAULT_TITLE = 'New Rule';
export const MAX_RETRIES = 20;
export const PAGE_SIZE = 25;

export const DEFAULT_CORRELATION: BlockType = {
  name: 'Correlation',
  id: 'correlation',
  conditions: [createEmptyCondition()]
};

export const EVENTS_KIND_TYPES = {
  EVENT: 'event',
  ASSET: 'asset',
  METRIC: 'metric',
  STATE: 'state',
  ALERT: 'alert',
  ENRICHMENT: 'enrichment',
  PIPELINE: 'pipeline',
  FINDING: 'finding'
};

export const DEFAULT_COLUMNS = [
  FieldEnum.EventKind,
  FieldEnum.ValueTimestamp,
  FieldEnum.Message,
  FieldEnum.EventAction,
  FieldEnum.EventOutcome,
  FieldEnum.UserName,
  FieldEnum.DestinationIpv4,
  FieldEnum.SourceIpv4,
  FieldEnum.HostIpv4,
  FieldEnum.EventDataset,
  FieldEnum.Id,
  FieldEnum.AbstractRelatedEvents
];
