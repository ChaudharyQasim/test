export { EditRuleContainer as default } from './EditRuleContainer';
