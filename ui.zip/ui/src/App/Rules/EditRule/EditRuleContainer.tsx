import { useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { Dialog, useNotification } from 'reablocks';

import { EditRule } from './EditRule';

// CSS
import css from './EditRuleContainer.module.css';

// Core
import { getAcsFieldOperations, getAcsFields } from 'core/Api/AcsApi';
import { getRuleDetail, updateRule } from 'core/Api/RulesApi';
import { RuleUpdateIn } from 'core/Api';

// Shared
import { errorHandler } from 'shared/utils/Helper';
import { Loader } from 'shared/elements/Loader';

export const EditRuleContainer = () => {
  const { id } = useParams();

  const { notifySuccess, notifyError } = useNotification();

  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: acsFields } = useQuery('acsFields', () => getAcsFields(), {
    onError(error: any) {
      notifyError(errorHandler(error));
    }
  });

  const { data: acsFieldOperations } = useQuery(
    'acsFieldOperations',
    () => getAcsFieldOperations(),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { data: ruleData, isLoading: isRuleDetailLoading } = useQuery(
    'ruleData',
    () => getRuleDetail(id),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { mutate: updateRuleMutation, isLoading: isRuleUpdating } = useMutation(
    (rulesData: RuleUpdateIn) => {
      return updateRule({
        ruleId: id,
        data: rulesData
      });
    },
    {
      onSuccess() {
        notifySuccess('Rule updated successfully');

        queryClient.invalidateQueries('ruleData');
        navigate('/rules?state=production');
      },
      onError(error: any) {
        notifyError(error?.response?.data?.detail);
      }
    }
  );

  return (
    <Dialog
      open
      className={css.dialog}
      innerClassName={css.fullDialog}
      size="100vw"
      header={null}
      showCloseButton={false}
      disablePadding
    >
      {isRuleDetailLoading && <Loader />}
      {!isRuleDetailLoading && (
        <EditRule
          updateRule={updateRuleMutation}
          acsFieldOperations={acsFieldOperations}
          acsFields={acsFields}
          ruleDetail={ruleData}
        />
      )}
    </Dialog>
  );
};
