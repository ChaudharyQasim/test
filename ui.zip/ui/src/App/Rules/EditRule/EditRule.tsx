import { FC } from 'react';
import { Helmet } from 'react-helmet-async';
import { Block } from 'reablocks';

// Shared
import { FieldOperations } from 'shared/elements/EventCondition';

// Core
import { ACSFieldType, RuleUpdateIn } from 'core/Api';
import { RuleDetailOut } from 'core/Api/RulesApi';

// Modules
import { RuleBuilder } from '../RuleBuilder';

// Types
type EditRuleProps = {
  acsFieldOperations: FieldOperations;
  acsFields: ACSFieldType[];
  ruleDetail: RuleDetailOut;
  updateRule: (rule: RuleUpdateIn) => void;
};

export const EditRule: FC<EditRuleProps> = ({
  acsFieldOperations,
  acsFields,
  ruleDetail,
  updateRule
}) => {
  const { rule_details } = ruleDetail;

  return (
    <Block>
      <Helmet>
        <title>{rule_details.name}</title>
      </Helmet>
      <RuleBuilder
        updateRule={updateRule}
        ruleDetail={rule_details}
        acsFieldOperations={acsFieldOperations}
        acsFields={acsFields}
      />
    </Block>
  );
};
