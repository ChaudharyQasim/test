import { FC } from 'react';
import { Helmet } from 'react-helmet-async';
import { Block } from 'reablocks';

// Constants
import { DEFAULT_TITLE } from '../constants';

// Shared
import { FieldOperations } from 'shared/elements/EventCondition';

// Core
import { ACSFieldType } from 'core/Api';
import { RuleInExtended } from 'core/Api/RulesApi';
import { RuleBuilder } from '../RuleBuilder';

// Types
type NewRuleProps = {
  acsFieldOperations: FieldOperations;
  acsFields: ACSFieldType[];
  isNewRulesCreationLoading: boolean;
  createNewRule: (rule: RuleInExtended) => void;
};

export const NewRule: FC<NewRuleProps> = ({
  acsFieldOperations,
  acsFields,
  createNewRule,
  isNewRulesCreationLoading
}) => {
  return (
    <Block>
      <Helmet>
        <title>{DEFAULT_TITLE}</title>
      </Helmet>
      <RuleBuilder
        createNewRule={createNewRule}
        acsFieldOperations={acsFieldOperations}
        isNewRulesCreationLoading={isNewRulesCreationLoading}
        acsFields={acsFields}
      />
    </Block>
  );
};
