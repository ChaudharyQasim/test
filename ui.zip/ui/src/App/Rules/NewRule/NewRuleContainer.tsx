import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { Dialog, useNotification } from 'reablocks';

import { NewRule } from './NewRule';

// CSS
import css from './NewRuleContainer.module.css';

// Core
import { getAcsFieldOperations, getAcsFields } from 'core/Api/AcsApi';
import { RuleInExtended, postCreateNewRule } from 'core/Api/RulesApi';

// Shared
import { errorHandler } from 'shared/utils/Helper';

export const NewRuleContainer = () => {
  const { notifySuccess, notifyError } = useNotification();

  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: acsFields } = useQuery('acsFields', () => getAcsFields(), {
    onError(error: any) {
      notifyError(errorHandler(error));
    }
  });

  const { data: acsFieldOperations } = useQuery(
    'acsFieldOperations',
    () => getAcsFieldOperations(),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { mutate: createNewRule, isLoading: isNewRulesCreationLoading } =
    useMutation(
      (rulesData: RuleInExtended) => {
        return postCreateNewRule(rulesData);
      },
      {
        onSuccess() {
          notifySuccess('Rule created successfully');
          queryClient.invalidateQueries('rulesDev');
          queryClient.invalidateQueries('rulesProd');

          navigate('/rules?state=production');
        },
        onError(error: any) {
          notifyError(error?.response?.data?.detail);
        }
      }
    );

  return (
    <Dialog
      open
      className={css.dialog}
      innerClassName={css.fullDialog}
      size="100vw"
      header={null}
      showCloseButton={false}
      disablePadding
    >
      <NewRule
        createNewRule={createNewRule}
        acsFieldOperations={acsFieldOperations}
        isNewRulesCreationLoading={isNewRulesCreationLoading}
        acsFields={acsFields}
      />
    </Dialog>
  );
};
