export { NewRuleContainer as default } from './NewRuleContainer';
