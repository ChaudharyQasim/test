import { FC, MutableRefObject, useMemo, useRef, useState } from 'react';
import { Button, DateFormat, PrimaryHeading, Stack } from 'reablocks';
import { Count } from 'reaviz';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import { StringParam, useQueryParam, withDefault } from 'use-query-params';
import { UseMutateFunction } from 'react-query';
import { AgGridReact } from 'ag-grid-react';

// Shared
import { SearchInput } from 'shared/form/Input/SearchInput';
import { EmptyState } from 'shared/elements/EmptyState';
import { Chip } from 'shared/elements/Chip';
import { AppliedFilter } from 'shared/elements/AppliedFilter';
import { FilterPanel } from 'shared/elements/Filters';
import { SHORT_DATE_FORMAT, RULES_FILTERS } from 'shared/utils/Constants';
import { constructQueryParams } from 'shared/utils/Helper';
import { AgTable } from 'shared/layout/AgTable';
import { Pager } from 'shared/data/Pager';
import { Loader } from 'shared/elements/Loader';

// CSS
import css from './Rules.module.css';

// Icons
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import { ReactComponent as FilterIcon } from 'assets/icons/filter.svg';
import { ReactComponent as EmptyIllustration } from 'assets/illustrations/empty-list.svg';
import { ReactComponent as PencilIcon } from 'assets/icons/pencil.svg';
import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';

// Core
import { RuleQueryType } from 'core/Api/RulesApi';
import { RuleOut, RulesListOut, RuleStateEnum } from 'core/Api';
import { OrganizationUser } from 'core/Api/UsersApi';

// Hooks
import { useFilterPager } from 'core/Hooks/useFilterPager';
import SeverityIcon from 'shared/elements/SeverityIcon';
import { InitialsAvatar } from 'shared/elements/InitialsAvatar';

export interface RulesProps {
  rulesData: RulesListOut;
  isSaveRulesLoading: boolean;
  organizationUsers: OrganizationUser[];
  saveAllRulesMutation: UseMutateFunction<string, unknown, void, unknown>;
  updateListOnQuery: UseMutateFunction<
    RulesListOut,
    unknown,
    RuleQueryType,
    unknown
  >;
  deleteRuleMutation: UseMutateFunction<RuleOut, unknown, string, unknown>;
  fetchRulesMutateAsync: (params: RuleQueryType) => Promise<RulesListOut>;
}

export const Rules: FC<RulesProps> = ({
  rulesData,
  isSaveRulesLoading,
  updateListOnQuery,
  saveAllRulesMutation,
  organizationUsers,
  deleteRuleMutation,
  fetchRulesMutateAsync
}) => {
  const [openFilter, setOpenFilter] = useState<boolean>(false);

  const [ruleStateQuery] = useQueryParam(
    'state',
    withDefault(StringParam, 'production')
  );

  const {
    filter: ruleFilter,
    setFilter: setUrlFilter,
    page,
    setPage,
    setKeyword,
    keyword
  } = useFilterPager();

  const navigate = useNavigate();

  // This ref is used to open the filter panel
  const filterBtnRef = useRef<HTMLButtonElement | null>(null);

  const currentFilterRef = useRef<MutableRefObject<HTMLButtonElement> | null>(
    null
  );

  const constructedUrl = constructQueryParams(
    { searchValue: keyword, searchKey: 'name' },
    ruleFilter,
    page + 1
  );

  const { rules, metadata } = rulesData;

  const agGridRef = useRef<AgGridReact | null>(null);

  const rulesColumns = useMemo(() => {
    return [
      {
        width: 100,
        field: 'severity',
        cellRenderer: ({ value }) => {
          return value ? (
            <div className={css.severityIconContainer}>
              <SeverityIcon name={value} className={css.severityIcon} />
            </div>
          ) : null;
        }
      },
      {
        flex: 1,
        field: 'name'
      },
      {
        flex: 1,
        field: 'description',
        hide: true
      },
      {
        width: 160,
        headerName: 'Author',
        field: 'created_by',
        cellRenderer: ({ value }) => {
          return value ? (
            <div className={css.authorContainer}>
              <InitialsAvatar name={value} size={25} rounded />
              {value}
            </div>
          ) : null;
        }
      },
      {
        flex: 1,
        headerName: 'Created',
        field: 'created_at',
        cellRenderer: ({ value }) => {
          return value ? (
            <DateFormat date={value} format={SHORT_DATE_FORMAT} />
          ) : null;
        }
      },
      {
        width: 150,
        headerName: '# Findings',
        field: 'findings_details.total_findings'
      },
      {
        width: 100,
        headerName: 'Actions',
        sortable: false,
        cellRenderer: ({ data: { nanoid } }) => {
          return (
            <Stack
              direction="row"
              justifyContent="start"
              alignItems="center"
              className={css.tableActions}
            >
              <Button
                variant="text"
                size="small"
                onClick={() => navigate(`/rules/edit/${nanoid}`)}
                disablePadding={true}
              >
                <PencilIcon />
              </Button>
              <Button
                variant="text"
                size="small"
                disablePadding={true}
                onClick={() => deleteRuleMutation(nanoid)}
              >
                <DeleteIcon />
              </Button>
            </Stack>
          );
        }
      }
    ];
  }, [navigate, deleteRuleMutation]);

  async function fetchRulesOnQuery({ params, constructedUrl }: RuleQueryType) {
    agGridRef.current.api.showLoadingOverlay();
    await fetchRulesMutateAsync({ params, constructedUrl });
    agGridRef.current.api.hideOverlay();
  }

  function onFilterReferenceHandler(
    dropdownRef: React.MutableRefObject<HTMLButtonElement>
  ) {
    // This switch the reference of the filter button
    currentFilterRef.current = dropdownRef;

    // This opens the filter panel
    setOpenFilter(!openFilter);
  }

  /* @description This function is used to apply the filter
   * to the rules list and re-fetch the rules list,
   * it also sets the filter in the url
   */
  function onApplyFilterHandler(filter: { [key: string]: string[] }) {
    const filterConstructedURL = constructQueryParams(
      { searchValue: keyword, searchKey: 'name' },
      filter,
      page + 1
    );
    setUrlFilter(filter);
    updateListOnQuery({
      params: {
        state: ruleStateQuery as RuleStateEnum
      },
      constructedUrl: filterConstructedURL
    });
  }

  async function onSearchByKeywordHandler(
    event: React.ChangeEvent<HTMLInputElement>
  ) {
    const searchConstructedURL = constructQueryParams(
      { searchValue: event.target.value, searchKey: 'name' },
      ruleFilter,
      1
    );

    setPage(0);
    setKeyword(event.target.value);
    await fetchRulesOnQuery({
      params: {
        state: ruleStateQuery as RuleStateEnum
      },
      constructedUrl: searchConstructedURL
    });
  }

  /**
   * @description This useMemo is used to construct the filter options
   * Adding the dynamic users to the assignee filter
   */
  const rulesFilters = useMemo(() => {
    RULES_FILTERS['author']['options'] = organizationUsers.map(user => ({
      label: user.email,
      value: user.email
    }));
    return RULES_FILTERS;
  }, [organizationUsers]);

  return (
    <div className={css.root}>
      <Helmet>
        <title>Rules</title>
      </Helmet>
      <header className={css.header}>
        <PrimaryHeading>
          <Stack>
            <span>Rules</span>
            <Chip variant="outline" color="secondary">
              <div className={css.counter}>
                <Count from={0} to={metadata.total_count} />
              </div>
            </Chip>
          </Stack>
        </PrimaryHeading>
        <div className={css.push} />
        <SearchInput
          placeholder="Search rules..."
          debounce={500}
          value={keyword}
          onChange={onSearchByKeywordHandler}
        />
        <Button
          className={css.newBtn}
          variant="outline"
          ref={filterBtnRef}
          onClick={() => onFilterReferenceHandler(filterBtnRef)}
        >
          <FilterIcon />
          Filter
        </Button>
        <Button
          className={css.newBtn}
          color="primary"
          onClick={() => navigate('/rules/new')}
        >
          <PlusIcon />
          New Rule
        </Button>
        <Button
          className={css.newBtn}
          color="primary"
          disabled={isSaveRulesLoading}
          onClick={() => saveAllRulesMutation()}
        >
          {isSaveRulesLoading ? 'Updating Rules...' : 'Update Rules'}
        </Button>
      </header>

      <AppliedFilter
        reference={currentFilterRef.current}
        filter={ruleFilter}
        filterOptions={rulesFilters}
        addFilter={onFilterReferenceHandler}
        setFilter={onApplyFilterHandler}
      />

      {/* This FilterPanel component Opens the popover for applied filters
       and for the filter button */}
      <FilterPanel
        reference={currentFilterRef.current}
        open={openFilter}
        filters={rulesFilters}
        filter={ruleFilter}
        onFilterChange={onApplyFilterHandler}
        onClose={() => setOpenFilter(false)}
      />
      {rules.length > 0 ? (
        <>
          <AgTable
            agGridRef={agGridRef}
            suppressCellFocus={true}
            columnDefs={rulesColumns}
            loadingOverlayComponent={Loader}
            rowData={rules}
          />
          <Pager
            total={metadata.total_count}
            page={page}
            size={metadata.page_size}
            onPageChange={async value => {
              // Incrementing the page number by 1 as the pager starts from 0
              // and the API starts from 1
              const exactPage = value + 1;
              await fetchRulesOnQuery({
                params: {
                  page_number: exactPage,
                  state: ruleStateQuery as RuleStateEnum
                },
                constructedUrl
              });
              setPage(value);
            }}
          />
        </>
      ) : (
        <EmptyState
          illustration={<EmptyIllustration />}
          title="No rules added"
          actions={
            <Button color="primary" onClick={() => navigate('/rules/new')}>
              <PlusIcon />
              New Rule
            </Button>
          }
        />
      )}
    </div>
  );
};
