import { createEmptyCondition } from 'shared/elements/EventCondition';
import { BlockType } from 'App/Rules/modules/ConditionBlock';

import { nanoid } from 'nanoid';

type Event = {
  groups: Array<{
    operator: string;
    conditions: any;
  }>;
  field: string;
  subOperation: {
    value: any;
    fieldType: string;
    field_operation: string;
  };
  fieldOperation: string;
};

export const uniqueEventCondition = (eventCondition: any[]): BlockType[] => {
  const conditions =
    eventCondition?.length > 0 ? eventCondition : [createEmptyCondition()];
  return [
    {
      name: 'Event 1',
      id: nanoid(),
      operator: 'and',
      conditions
    }
  ];
};

export const formatMultipleEventConditions = (
  blockDetail: Event[]
): BlockType[] => {
  let formatBlock = [];

  if (blockDetail?.length >= 2) {
    formatBlock = blockDetail?.map((event, index) => {
      return {
        id: nanoid(),
        name: `Event ${index + 1}`,
        operator: event?.groups[0]?.operator,
        conditions: event?.groups[0]?.conditions,
        aggregations: [
          {
            condition: {
              id: nanoid(),
              field: event.field,
              value: event.subOperation.value,
              fieldType: event.subOperation.fieldType,
              field_operation: event.subOperation.field_operation
            },
            field_operation: event.fieldOperation
          }
        ]
      };
    });
  }
  return formatBlock;
};
