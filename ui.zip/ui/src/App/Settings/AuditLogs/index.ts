export { AuditLogsContainer as default } from './AuditLogsContainer';
