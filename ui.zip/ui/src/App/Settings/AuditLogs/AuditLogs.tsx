import { FC, useMemo } from 'react';
import classNames from 'classnames';
import {
  MotionGroup,
  MotionItem,
  PrimaryHeading,
  Stack,
  DateFormat,
  Chip
} from 'reablocks';
import { Helmet } from 'react-helmet-async';

// CSS
import css from './AuditLogs.module.css';

// Shared
import { Table } from 'shared/layout/Table';
import { Loader } from 'shared/elements/Loader';
import { AUDIT_PAGE_LIMIT_DEFAULT } from 'shared/utils/Constants';

// Types
type AuditLogsProps = {
  auditLogsOrganization: any;
  fetchNextPage: () => void;
  hasNextPage: boolean;
  isFetching: boolean;
};

export const AuditLogs: FC<AuditLogsProps> = ({
  auditLogsOrganization,
  fetchNextPage,
  hasNextPage,
  isFetching
}) => {
  const canLoadMore =
    hasNextPage &&
    !isFetching &&
    !(auditLogsOrganization.length < AUDIT_PAGE_LIMIT_DEFAULT);

  const logsColumns = useMemo(
    () => [
      {
        id: 'user_email',
        header: 'User Email',
        accessor: 'user_email',
        cell: value => <span className={css.tagline}>{value.getValue()}</span>
      },
      {
        id: 'action',
        header: 'Action',
        accessor: 'action',
        cell: value => (
          <span
            className={classNames({
              [css.signin]: value.getValue() === 'sign-in',
              [css.signout]: value.getValue() === 'sign-out'
            })}
          >
            {value.getValue()}
          </span>
        )
      },
      {
        id: 'data_time',
        header: 'Timestamp',
        accessor: 'timestamp',
        cell: value => <DateFormat date={value.getValue()} fromNow />
      }
    ],
    []
  );

  return (
    <MotionGroup>
      <Helmet>
        <title>Audit Logs</title>
      </Helmet>
      <header className={css.header}>
        <PrimaryHeading>
          <Stack>
            <span>Audit Logs</span>
          </Stack>
        </PrimaryHeading>
      </header>

      <MotionItem className={css.container}>
        <div className={css.content}>
          <Table data={auditLogsOrganization} columns={logsColumns} />
        </div>
      </MotionItem>

      {canLoadMore && (
        <div className={css.auditChip}>
          <Chip
            variant="outline"
            onClick={fetchNextPage}
            className={classNames(css.loadMoreChip)}
          >
            Load More ...
          </Chip>
        </div>
      )}

      {isFetching && (
        <div className={css.auditLoder}>
          <Loader />
        </div>
      )}
    </MotionGroup>
  );
};
