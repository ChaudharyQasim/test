import { FC } from 'react';

import { useInfiniteQuery } from 'react-query';

import { AuditLogs } from './AuditLogs';

// Components
import { Loader } from 'shared/elements/Loader';

// Hooks
import { useAuth } from 'core/Auth';

// API Service
import { getAuditLogsOrganization } from 'core/Api/OrganizationApi';

interface Log {
  organization_id: number;
  action: string;
  user_email: string;
  organization_name: string;
  timestamp: string;
}

type logItems = {
  logs: Log;
  next_token: string;
};

const extractLogs = (data: any) => {
  const logsArray = data?.flatMap((item: logItems) => item.logs);
  return logsArray || [];
};

export const AuditLogsContainer: FC = () => {
  const { user, isLoading } = useAuth();

  const { data, fetchNextPage, hasNextPage, isFetching } = useInfiniteQuery(
    'auditOrganization',
    ({ pageParam = '' }) =>
      getAuditLogsOrganization(user.current_organization.id, pageParam),
    {
      getNextPageParam: lastPage => lastPage.next_token || null,
      refetchOnWindowFocus: false,
      enabled: !!user
    }
  );

  if (isLoading) {
    return <Loader />;
  }

  return (
    <AuditLogs
      auditLogsOrganization={extractLogs(data?.pages)}
      fetchNextPage={fetchNextPage}
      hasNextPage={hasNextPage}
      isFetching={isFetching}
    />
  );
};
