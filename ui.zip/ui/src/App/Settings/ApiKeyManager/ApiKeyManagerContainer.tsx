import { ApiKeyManager } from './ApiKeyManager';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import {
  deleteDeleteApiKey,
  getApiKeys,
  postCreateApiKey
} from 'core/Api/KeysManagerApi';
import { CreateAPIKey } from 'core/Api';

export const ApiKeyManagerContainer = () => {
  const queryClient = useQueryClient();

  const { data: apiKeysData } = useQuery(
    'apiKeys',
    () => {
      return getApiKeys();
    },
    {
      initialData: []
    }
  );

  const { mutateAsync: createApiKeyMutation } = useMutation(
    (data: CreateAPIKey) => {
      return postCreateApiKey(data);
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries('apiKeys');
      }
    }
  );

  const { mutateAsync: deleteApiKeyMutation } = useMutation(
    (key_id: number) => {
      return deleteDeleteApiKey(key_id);
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries('apiKeys');
      }
    }
  );

  return (
    <ApiKeyManager
      apiKeysData={apiKeysData}
      createApiKey={createApiKeyMutation}
      deleteApiKey={deleteApiKeyMutation}
    />
  );
};
