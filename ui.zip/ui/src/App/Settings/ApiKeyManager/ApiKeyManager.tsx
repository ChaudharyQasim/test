import { FC, useState } from 'react';
import classNames from 'classnames';
import { Helmet } from 'react-helmet-async';
import {
  Block,
  Divider,
  Stack,
  Button,
  Input,
  Text,
  useNotification,
  SecondaryHeading,
  MotionGroup,
  MotionItem
} from 'reablocks';
import { SelectionChangedEvent } from 'ag-grid-community';
import { UseMutateAsyncFunction } from 'react-query';

// Icons
import { ReactComponent as CopyIcon } from 'assets/icons/copy.svg';
import { ReactComponent as WarningIcon } from 'assets/icons/warning.svg';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';

// CSS
import css from './ApiKeyManager.module.css';

// Shared
import { Loader } from 'shared/elements/Loader';
import { AgTable } from 'shared/layout/AgTable';
import { Dialog } from 'shared/layers/Dialog';
import { errorHandler } from 'shared/utils/Helper';
import { ConfirmationDialog } from 'shared/layers/ConfirmationDialog';

// Form lib validation
import { SubmitHandler, useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { CreateAPIKey, CreateAPIKeyResponse, ResponseMessage } from 'core/Api';

// Types
type ApiKeyManagerProps = {
  apiKeysData: any;
  createApiKey: UseMutateAsyncFunction<CreateAPIKeyResponse, any, CreateAPIKey>;
  deleteApiKey: UseMutateAsyncFunction<ResponseMessage, any, number>;
};

const credentialsSchema = Yup.object().shape({
  name: Yup.string().required('Required'),
  days_to_expire: Yup.number().required('Required')
});

export const ApiKeyManager: FC<ApiKeyManagerProps> = ({
  apiKeysData,
  createApiKey,
  deleteApiKey
}) => {
  const [openNewApiKeyDialog, setOpenNewApiKeyDialog] =
    useState<boolean>(false);
  const [openConfirmationDialog, setOpenConfirmationDialog] =
    useState<boolean>(false);
  const [apiKey, setApiKey] = useState<any>(null);
  const [selectedApiKeys, setSelectedApiKeys] = useState<any[]>([]);

  const { notifySuccess, notifyError } = useNotification();

  const {
    control,
    handleSubmit,
    formState: { isSubmitting, isValid },
    reset: resetForm
  } = useForm({
    mode: 'onChange',
    reValidateMode: 'onChange',
    resolver: yupResolver(credentialsSchema),
    defaultValues: {
      name: '',
      days_to_expire: 90
    }
  });
  const apiColumns = [
    {
      field: 'name',
      headerName: 'Name',
      checkboxSelection: true,
      flex: 1
    },
    {
      field: 'user.email',
      headerName: 'Created By',
      flex: 1
    },
    {
      field: 'created_at',
      headerName: 'Created Date',
      flex: 1
    }
  ];

  const onSubmitApiKey: SubmitHandler<any> = async data => {
    try {
      const apiResponse = await createApiKey(data);
      setApiKey(apiResponse);
      notifySuccess('API Key created successfully');
    } catch (error) {
      notifyError(errorHandler(error));
    }
  };

  const copyApiKeyToClipboard = () => {
    navigator.clipboard.writeText(apiKey.key_value);
    notifySuccess('API Key copied to clipboard');
  };

  return (
    <div>
      <Helmet>
        <title>Api Key Manager</title>
      </Helmet>
      <MotionGroup>
        <MotionItem className={css.container}>
          <header className={classNames(css.header, css.withActions)}>
            <Stack justifyContent="spaceBetween">
              <SecondaryHeading>Api key manager</SecondaryHeading>
              <Stack>
                {selectedApiKeys.length > 0 && (
                  <Button
                    variant="outline"
                    onClick={() => setOpenConfirmationDialog(true)}
                  >
                    Delete
                  </Button>
                )}
                <Button
                  size="small"
                  variant="filled"
                  color="primary"
                  onClick={() => setOpenNewApiKeyDialog(true)}
                >
                  <PlusIcon />
                  <span>New Api Key</span>
                </Button>
              </Stack>
            </Stack>
          </header>
          <AgTable
            suppressCellFocus={true}
            columnDefs={apiColumns}
            loadingOverlayComponent={Loader}
            rowData={apiKeysData}
            rowMultiSelectWithClick={true}
            onSelectionChanged={(event: SelectionChangedEvent) => {
              const selectedNodes = event.api.getSelectedNodes();
              const selectedRowsData = selectedNodes.map(node => node.data);
              setSelectedApiKeys(selectedRowsData);
            }}
          />
        </MotionItem>
      </MotionGroup>
      {selectedApiKeys.length > 0 && (
        <ConfirmationDialog
          open={openConfirmationDialog}
          dialogType="DELETE"
          confirmationButtonName="Delete api key"
          confirmationHeading="Want to delete api key?"
          confirmationMessage={`Are you sure you want to delete ${selectedApiKeys[0].name}`}
          onConfirm={async () => {
            try {
              const response = await deleteApiKey(selectedApiKeys[0].key_id);
              notifySuccess(response.message);
            } catch (error) {
              notifyError(errorHandler(error));
            }
            setOpenConfirmationDialog(false);
          }}
          onCancel={() => setOpenConfirmationDialog(false)}
        />
      )}
      <Dialog
        open={openNewApiKeyDialog}
        onClose={() => {
          resetForm();
          setApiKey(null);
          setOpenNewApiKeyDialog(false);
        }}
        size="450px"
        header="Create API Key"
        disablePadding
      >
        <Divider />
        <form onSubmit={handleSubmit(onSubmitApiKey)}>
          <div className={css.dialogContainer}>
            {!apiKey ? (
              <>
                <Block label="Api Key Name">
                  <Controller
                    name="name"
                    control={control}
                    render={({ field: { value, onBlur, onChange } }) => (
                      <Input
                        value={value}
                        onChange={onChange}
                        onBlur={onBlur}
                        placeholder="SOC automation"
                      />
                    )}
                  />
                </Block>
                <Block label="Days to expire">
                  <Controller
                    name="days_to_expire"
                    control={control}
                    render={({ field: { value, onBlur, onChange } }) => (
                      <Input
                        defaultValue={value}
                        onChange={onChange}
                        onBlur={onBlur}
                        type="number"
                        placeholder="90"
                      />
                    )}
                  />
                </Block>
              </>
            ) : (
              <Block>
                <SecondaryHeading className={css.apiKeyTitle}>
                  Key <strong>{apiKey.name}</strong> created:
                </SecondaryHeading>
                <Block className={css.apiKeyContainer}>
                  <span className={css.apiKeyText}>{apiKey?.key_value}</span>
                  <Button
                    variant="text"
                    size="small"
                    onClick={copyApiKeyToClipboard}
                    className={css.copyButton}
                    disablePadding
                    disableMargins
                  >
                    <CopyIcon />
                  </Button>
                </Block>
                <Stack className={css.warningMessage}>
                  <WarningIcon />
                  <Text>This key will only be displayed one time</Text>
                </Stack>
              </Block>
            )}
          </div>
          <Divider />
          <footer className={css.dialogFooter}>
            <Block>
              <Stack justifyContent="end">
                <Button
                  variant="outline"
                  onClick={() => setOpenNewApiKeyDialog(false)}
                >
                  Cancel
                </Button>
                {!apiKey && (
                  <Button
                    disabled={!isValid || isSubmitting}
                    variant="filled"
                    color="primary"
                    type="submit"
                  >
                    {isSubmitting ? 'Creating...' : 'Create'}
                  </Button>
                )}
                {apiKey && (
                  <Button
                    variant="filled"
                    color="primary"
                    onClick={() => {
                      resetForm();
                      setApiKey(null);
                      setOpenNewApiKeyDialog(false);
                    }}
                  >
                    Done
                  </Button>
                )}
              </Stack>
            </Block>
          </footer>
        </form>
      </Dialog>
    </div>
  );
};
