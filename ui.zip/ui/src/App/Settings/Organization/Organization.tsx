import { FC } from 'react';
import { Button, PrimaryHeading, Stack } from 'reablocks';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { UseMutateFunction } from 'react-query';
import { NumberParam, useQueryParam, withDefault } from 'use-query-params';

// CSS
import css from './Organization.module.css';

// Components
import { Tab, TabList, TabPanel, Tabs } from 'shared/layout/Tabs';
import { General, Members, Permissions } from './Tabs';
import { EnrichmentList } from './Tabs/Enrichment/Enrichment';

// Types
import { CreateRole, Permission, UpdateRole, UpdateRoleUser } from 'core/Api';
import {
  OrganizationDetailType,
  UpdateOrgDetailsType
} from 'core/Api/OrganizationApi';
import { RoleType } from 'core/Api/RolesPermissionsApi';
import { EnrichmentCsvListType } from './Organization.types';

import ApiKeyManagerContainer from '../ApiKeyManager';

interface IPermissions extends Permission {
  checked: boolean;
}

interface OrganizationProps extends EnrichmentCsvListType {
  permissions: IPermissions[];
  createRole: (role: Omit<CreateRole, 'organization_id'>) => Promise<void>;
  roles: RoleType[];
  organizationDetail: OrganizationDetailType;
  uploadOrganizationImage: UseMutateFunction<unknown, any, File, unknown>;
  isUploadOrganizationImageLoading: boolean;
  onDeleteOrganizationImage: UseMutateFunction<unknown, any, void, unknown>;
  isDeleteOrganizationImageLoading: boolean;
  inviteMembers: (data: string[]) => Promise<void>;
  updateMemberRole: (data: UpdateRoleUser) => Promise<void>;
  updateOrganizationDetails: (data: UpdateOrgDetailsType) => Promise<void>;
  deleteRole: (id: number) => Promise<void>;
  updateRole: (role: Omit<UpdateRole, 'organization_id'>) => Promise<void>;
  leaveOrganization: () => Promise<void>;
}

export const Organization: FC<OrganizationProps> = ({
  permissions,
  createRole,
  roles,
  organizationDetail,
  enrichmentCSVList,
  isEnrichmentLoading,
  deleteEnrichmentMutation,
  enrichmentUploadMutation,
  inviteMembers,
  updateRole,
  updateMemberRole,
  updateOrganizationDetails,
  uploadOrganizationImage,
  isUploadOrganizationImageLoading,
  onDeleteOrganizationImage,
  isDeleteOrganizationImageLoading,
  deleteRole,
  leaveOrganization
}) => {
  const [tab, setTab] = useQueryParam('tab', withDefault(NumberParam, 0));

  const navigate = useNavigate();

  return (
    <>
      <Helmet>
        <title>Organization</title>
      </Helmet>
      <header className={css.header}>
        <PrimaryHeading>
          <Stack>
            <span>Organization</span>
            <Button
              size="small"
              variant="filled"
              color="primary"
              onClick={() => {
                navigate('/user-onboarding?create_organization=true');
              }}
            >
              Create Organization
            </Button>
          </Stack>
        </PrimaryHeading>
      </header>
      <section>
        <Tabs
          defaultIndex={tab}
          onSelect={(event: number) => {
            setTab(event);
          }}
        >
          <TabList>
            <Tab>General</Tab>
            <Tab>Members</Tab>
            <Tab>Permissions & Roles</Tab>
            <Tab>Enrichment CSV List</Tab>
            <Tab>APIs key</Tab>
          </TabList>
          <TabPanel>
            <General
              uploadOrganizationImage={uploadOrganizationImage}
              isUploadOrganizationImageLoading={
                isUploadOrganizationImageLoading
              }
              onDeleteOrganizationImage={onDeleteOrganizationImage}
              isDeleteOrganizationImageLoading={
                isDeleteOrganizationImageLoading
              }
              updateOrganizationDetails={updateOrganizationDetails}
              leaveOrganization={leaveOrganization}
            />
          </TabPanel>
          <TabPanel>
            <Members
              roles={roles}
              updateMemberRole={updateMemberRole}
              members={organizationDetail.users}
              inviteMembers={inviteMembers}
              pendingInvitations={organizationDetail.invitations}
            />
          </TabPanel>
          <TabPanel>
            <Permissions
              updateRole={updateRole}
              permissions={permissions}
              createRole={createRole}
              deleteRole={deleteRole}
              roles={roles}
            />
          </TabPanel>
          <TabPanel>
            <EnrichmentList
              enrichmentCSVList={enrichmentCSVList}
              isEnrichmentLoading={isEnrichmentLoading}
              deleteEnrichmentMutation={deleteEnrichmentMutation}
              enrichmentUploadMutation={enrichmentUploadMutation}
            />
          </TabPanel>
          <TabPanel>
            <ApiKeyManagerContainer />
          </TabPanel>
        </Tabs>
      </section>
    </>
  );
};
