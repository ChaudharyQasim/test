import { FC, useCallback, useMemo } from 'react';
import { useNotification } from 'reablocks';
import { useNavigate } from 'react-router-dom';

import { useMutation, useQuery, useQueryClient } from 'react-query';

import { Organization } from './Organization';

// Components
import { Loader } from 'shared/elements/Loader';

// Hooks
import { useAuth } from 'core/Auth';

// API Service
import {
  UpdateOrgDetailsType,
  deleteOrganization,
  getOrganizationById,
  getPermissions,
  postBulkInvitations,
  updateCurrentOrganization,
  updateImageOrganization,
  deleteOrganizationImage,
  updateOrganization
} from 'core/Api/OrganizationApi';
import {
  postCreateRole,
  getRoles,
  updateUserRole,
  deleteUserRole,
  updateRole
} from 'core/Api/RolesPermissionsApi';
import { Permission, UpdateRole, UpdateRoleUser } from 'core/Api';
import {
  deleteEnrichment,
  getEnrichmentCSVList,
  newEnrichment
} from 'core/Api/PipelineApi';
import { useQueryParams } from 'core/Hooks/useQueryParams';

// Shared
import { errorHandler } from 'shared/utils/Helper';
import { PAGE_LIMIT_DEFAULT } from 'shared/utils/Constants';

// Types
type createRole = {
  name: string;
  permissions: string[];
};

export const OrganizationContainer: FC = () => {
  const { user, isLoading, refreshUser } = useAuth();

  const { notifySuccess, notifyError } = useNotification();

  const { page } = useQueryParams();

  const navigate = useNavigate();

  const queryClient = useQueryClient();

  const { data: permissions } = useQuery(
    'permissions',
    () => getPermissions(),
    {
      enabled: !!user
    }
  );

  const {
    data: enrichmentCSVList,
    isLoading: isEnrichmentLoading,
    refetch: refetchEnrichmentList
  } = useQuery(
    ['enrichmentCSVList', page],
    () =>
      getEnrichmentCSVList({ pageNumber: page, pageSize: PAGE_LIMIT_DEFAULT }),
    {
      enabled: !!user
    }
  );

  const { mutateAsync: deleteEnrichmentMutation } = useMutation(
    ({ fileName, fileId }: { fileName: string; fileId: string }) =>
      deleteEnrichment({ fileName, fileId }),
    {
      onError(error: any) {
        notifyError(errorHandler(error));
      },
      onSuccess(data) {
        notifySuccess(data?.message);
        refetchEnrichmentList();
      }
    }
  );

  const { mutateAsync: enrichmentUploadMutation } = useMutation(
    ({ file, onUploadProgress }: { file: any; onUploadProgress }) =>
      newEnrichment({ file, onUploadProgress }),
    {
      onSuccess() {
        notifySuccess('Enrichment uploaded successfully.');
        refetchEnrichmentList();
      },
      onError(error) {
        notifyError(errorHandler(error));
      }
    }
  );

  const { data: roles, refetch: refetchRoles } = useQuery(
    'roles',
    () => getRoles(user.current_organization.id),
    {
      enabled: !!user
    }
  );

  const {
    data: organizationDetail,
    refetch: refreshOrganization,
    isLoading: isOrganizationDetailLoading
  } = useQuery(
    'organizationbyid',
    () => getOrganizationById(user.current_organization.id),
    {
      initialData: {
        invitations: [],
        organization: {
          id: 0,
          name: '',
          domains: []
        },
        users: []
      },
      enabled: !!user
    }
  );

  const {
    mutate: uploadOrganizationImageMutation,
    isLoading: isUploadOrganizationImageLoading
  } = useMutation(
    (data: File) => {
      if (!user) {
        throw new Error('User not found');
      }
      const formData = new FormData();
      formData.append('image', data);

      return updateImageOrganization({
        id: user.current_organization.id,
        patchData: formData
      });
    },
    {
      onSuccess() {
        notifySuccess('Organization updated successfully');
      },
      onError(error: any) {
        notifyError(`Error updating organization: ${errorHandler(error)}`);
      },
      onSettled() {
        refreshUser();
      }
    }
  );

  const {
    mutate: deleteOrganizationImageMutation,
    isLoading: isDeleteOrganizationImageLoading
  } = useMutation(
    () => {
      if (!user) {
        throw new Error('User not found');
      }
      return deleteOrganizationImage({ id: user.current_organization.id });
    },
    {
      onSuccess() {
        notifySuccess('Organization image deleted successfully');
      },
      onError(error: any) {
        notifyError(
          `Error deleting organization image: ${errorHandler(error)}`
        );
      },
      onSettled() {
        refreshUser();
      }
    }
  );

  const leaveOrganization = useCallback(async () => {
    if (!user) {
      return;
    }
    try {
      await deleteOrganization(user.current_organization.id);
      updateCurrentOrganization({
        patchData: {
          organization_id: 1
        }
      });
      notifySuccess('You have left the organization successfully');
      setTimeout(() => {
        location.reload();
      }, 1000);
    } catch (error) {
      notifyError(`Error leaving organization: ${errorHandler(error)}`);
    }
  }, [user, notifyError, notifySuccess]);

  const createRole = useCallback(
    async ({ name, permissions }: createRole): Promise<void> => {
      if (!user) {
        return;
      }
      try {
        await postCreateRole({
          name: name,
          permissions: permissions,
          organization_id: user.current_organization.id
        });
        refetchRoles();
        notifySuccess('Role created successfully');
      } catch (error) {
        notifyError(`Error creating role: ${errorHandler(error)}`);
      }
    },
    [user, notifyError, notifySuccess, refetchRoles]
  );

  const updateMemberRole = useCallback(
    async ({ email, role_id, organization_id }: UpdateRoleUser) => {
      if (!user) {
        return;
      }
      try {
        await updateUserRole({
          email,
          role_id,
          organization_id
        });
        refreshOrganization();
        notifySuccess('Role updated successfully');
      } catch (error) {
        notifyError(`Error updating role: ${errorHandler(error)}`);
      }
    },
    [user, notifyError, notifySuccess, refreshOrganization]
  );

  const updateRoleAndPermissions = useCallback(
    async (role: Omit<UpdateRole, 'organization_id'>) => {
      if (!user) {
        return;
      }
      try {
        await updateRole({
          organization_id: user.current_organization.id,
          ...role
        });
        refetchRoles();
        notifySuccess('Role updated successfully');
      } catch (error) {
        notifyError(`Error updating role: ${errorHandler(error)}`);
      }
    },
    [user, notifyError, notifySuccess, refetchRoles]
  );

  const deleteRole = useCallback(
    async (role_id: number) => {
      if (!user) {
        return;
      }
      try {
        await deleteUserRole(role_id);
        refetchRoles();
        notifySuccess('Role deleted successfully');
      } catch (error) {
        notifyError(`Error deleting role: ${errorHandler(error)}`);
      }
    },
    [user, notifyError, notifySuccess, refetchRoles]
  );

  const inviteMembers = useCallback(
    async (emails: string[]) => {
      if (!user) {
        return;
      }
      try {
        const cleanedInvitations = emails.filter(
          (email: string) => email !== ''
        );

        if (cleanedInvitations.length > 0) {
          // Mapping the emails to send bulk invitations
          // Clean the emails and remove the empty strings
          const mappingEmail = cleanedInvitations.map((email: string) => {
            const cleanEmail = email.trim();
            return {
              email: cleanEmail
            };
          });
          await postBulkInvitations({
            organization_id: user.current_organization.id,
            emails: mappingEmail
          });
        }

        queryClient.invalidateQueries('organizationbyid');

        navigate('/settings/organization?tab=members');

        notifySuccess('Invitations sent successfully');
      } catch (error) {
        notifyError(`Error sending invitations: ${errorHandler(error)}`);
      }
    },
    [user, notifyError, notifySuccess, queryClient, navigate]
  );

  // TODO: Needs to be done once the backend has this functionality
  const deleteMember = useCallback(
    async (email: string) => {
      if (!user) {
        return;
      }
      try {
        refreshOrganization();
        notifySuccess('Member deleted successfully');
      } catch (error) {
        notifyError(`Error deleting member: ${errorHandler(error)}`);
      }
    },
    [user, notifyError, notifySuccess, refreshOrganization]
  );

  const updateOrganizationDetails = useCallback(
    async ({ name, domains }: UpdateOrgDetailsType): Promise<void> => {
      if (!user) {
        return;
      }
      try {
        await updateOrganization({
          id: user.current_organization.id,
          patchData: { name, domains }
        });
        notifySuccess('Organization updated successfully');
      } catch (error) {
        notifyError(`Error updating organization: ${errorHandler(error)}`);
      }
    },
    [user, notifyError, notifySuccess]
  );

  /**
   * @description Format permissions to add checked property,
   * also check if the user has the permission assigned
   */
  const permissionsFormartted = useMemo(() => {
    if (!permissions) {
      return [];
    }

    return permissions.map((permission: Permission) => {
      return {
        ...permission,
        name: permission.name,
        value: permission.name,
        checked: false
      };
    });
  }, [permissions]);

  if (isLoading || isOrganizationDetailLoading) {
    return <Loader />;
  }

  return (
    <Organization
      organizationDetail={organizationDetail}
      permissions={permissionsFormartted}
      isEnrichmentLoading={isEnrichmentLoading}
      enrichmentCSVList={enrichmentCSVList}
      inviteMembers={inviteMembers}
      deleteEnrichmentMutation={deleteEnrichmentMutation}
      enrichmentUploadMutation={enrichmentUploadMutation}
      updateOrganizationDetails={updateOrganizationDetails}
      uploadOrganizationImage={uploadOrganizationImageMutation}
      isUploadOrganizationImageLoading={isUploadOrganizationImageLoading}
      onDeleteOrganizationImage={deleteOrganizationImageMutation}
      isDeleteOrganizationImageLoading={isDeleteOrganizationImageLoading}
      leaveOrganization={leaveOrganization}
      createRole={createRole}
      updateRole={updateRoleAndPermissions}
      updateMemberRole={updateMemberRole}
      deleteRole={deleteRole}
      roles={roles}
    />
  );
};
