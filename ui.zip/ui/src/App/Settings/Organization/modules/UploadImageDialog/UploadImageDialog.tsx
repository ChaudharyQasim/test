import { FC } from 'react';
import { UploadInput } from 'shared/form/UploadInput';
import { Dialog } from 'shared/layers/Dialog';

// Types
type UploadImageDialogProps = {
  isUploadDialogOpen: boolean;
  setIsUploadDialogOpen: (value: boolean) => void;
  onCompleted: (data: any) => void;
  headerText?: string;
};

export const UploadImageDialog: FC<UploadImageDialogProps> = ({
  isUploadDialogOpen,
  setIsUploadDialogOpen,
  onCompleted,
  headerText
}) => {
  return (
    <Dialog
      open={isUploadDialogOpen}
      onClose={() => setIsUploadDialogOpen(false)}
      size="450px"
      header={headerText || 'Upload Image'}
    >
      <UploadInput
        type="thumbnail"
        options={{
          restrictions: {
            maxFileSize: 500000000,
            maxNumberOfFiles: 1,
            allowedFileTypes: ['image/*', '.jpg', '.jpeg', '.png']
          },
          autoProceed: true
        }}
        note="500 MB max file size"
        onComplete={({ file }) => {
          onCompleted(file.data);
          setIsUploadDialogOpen(false);
        }}
        dragDropLocale={{
          strings: {
            dropHereOr: 'Drop here or %{browse}',
            browse: 'Select an Image for Upload'
          }
        }}
      />
    </Dialog>
  );
};
