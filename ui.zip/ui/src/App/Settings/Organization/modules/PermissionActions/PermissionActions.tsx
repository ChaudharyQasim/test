import { FC, useRef, useState } from 'react';
import { Button, Card, List, ListItem, Menu } from 'reablocks';

// Icons
import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as DotsIcon } from 'assets/icons/dots.svg';
import { ReactComponent as PencilIcon } from 'assets/icons/pencil.svg';

import { Permission } from 'core/Api';
export interface IPermissions extends Permission {
  checked: boolean;
}
type PermissionActionsProps = {
  row: any;
  onEditChange: (row: { permissions: IPermissions[]; name: string }) => void;
  onDeleteChange: (value: number) => void;
};

export const PermissionActions: FC<PermissionActionsProps> = ({
  row,
  onEditChange,
  onDeleteChange
}) => {
  const [permissionsMenuOpen, setPermissionsMenuOpen] = useState(false);
  const permissionMenuRef = useRef(null);

  return (
    <div>
      <Button
        variant="text"
        ref={permissionMenuRef}
        onClick={() => setPermissionsMenuOpen(!permissionsMenuOpen)}
      >
        <DotsIcon />
      </Button>
      <Menu
        reference={permissionMenuRef}
        open={permissionsMenuOpen}
        placement="bottom-end"
        onClose={() => setPermissionsMenuOpen(false)}
      >
        <Card>
          <List>
            <ListItem
              start={<PencilIcon />}
              onClick={() =>
                onEditChange({
                  permissions: row.row?.original?.permissions || [],
                  name: row.row?.original?.name || ''
                })
              }
            >
              Edit
            </ListItem>
            <ListItem
              start={<DeleteIcon />}
              onClick={() => {
                setPermissionsMenuOpen(false);
                onDeleteChange(row.getValue());
              }}
            >
              Delete
            </ListItem>
          </List>
        </Card>
      </Menu>
    </div>
  );
};
