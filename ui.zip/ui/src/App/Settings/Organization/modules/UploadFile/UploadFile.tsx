import { FC } from 'react';

// Shared
import { UploadInput } from 'shared/form/UploadInput';
import { UploadFileProgress } from 'shared/elements/UploadFileProgress';

import { Dialog } from 'shared/layers/Dialog';
import { UPLOAD_FILE_SIZE } from 'shared/utils/Constants';

// Types
export type UploadFileProperties = {
  estimatedTimeRemaining: number;
  percentage: number;
};

type UploadFileProps = {
  isOpen: boolean;
  uploadProperties: UploadFileProperties;
  fileProperties: File | null;
  onStartFileUpload: (file: File) => void;
  onDelete: () => void;
  onClose: () => void;
};

export const UploadFile: FC<UploadFileProps> = ({
  isOpen,
  fileProperties,
  uploadProperties,
  onDelete,
  onClose,
  onStartFileUpload
}) => (
  <Dialog
    open={isOpen}
    onClose={onClose}
    size="530px"
    header="Upload Enrichment CSV"
  >
    {!fileProperties ? (
      <UploadInput
        options={{
          restrictions: {
            maxFileSize: UPLOAD_FILE_SIZE.tenMB,
            maxNumberOfFiles: 1,
            allowedFileTypes: ['.csv']
          },
          autoProceed: true
        }}
        note="10 MB max file size"
        onComplete={({ file }) => onStartFileUpload(file)}
        dragDropLocale={{
          strings: {
            dropHereOr: 'Drop here or %{browse}',
            browse: 'Select an CSV to Upload'
          }
        }}
      />
    ) : (
      <UploadFileProgress
        fileName={fileProperties.name}
        fileSize={fileProperties.size}
        uploadProperties={uploadProperties}
        onDelete={onDelete}
      />
    )}
  </Dialog>
);
