import { FC, useState, Fragment } from 'react';
import classNames from 'classnames';
import {
  Block,
  Button,
  Chip,
  Divider,
  Input,
  MotionGroup,
  MotionItem,
  SecondaryHeading,
  Select,
  SelectOption,
  Stack,
  Text
} from 'reablocks';

// Form lib validation
import * as Yup from 'yup';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

// Icons
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';

// Shared
import { InitialsAvatar } from 'shared/elements/InitialsAvatar';

// CSS
import css from './Tabs.module.css';

// Components
import { Dialog } from 'shared/layers/Dialog';

// Hooks
import { SearchInput } from 'shared/form/Input/SearchInput';

// Core
import { UpdateRoleUser } from 'core/Api';
import {
  MemberOrganizationType,
  OrganizationInvitationType
} from 'core/Api/OrganizationApi';
import { RoleType } from 'core/Api/RolesPermissionsApi';
import { useOrganization } from 'core/Organization';
import { nanoid } from 'nanoid';
import { useAuth } from 'core/Auth';

type MembersProps = {
  members: MemberOrganizationType[];
  pendingInvitations: OrganizationInvitationType[];
  roles: RoleType[];
  inviteMembers: (data: string[]) => Promise<void>;
  updateMemberRole: (data: UpdateRoleUser) => Promise<void>;
};

const credentialsSchema = Yup.object().shape({
  email: Yup.string().required('Required')
});

export const Members: FC<MembersProps> = ({
  members,
  pendingInvitations,
  roles,
  updateMemberRole,
  inviteMembers
}) => {
  const { user } = useAuth();
  const { permissions } = useOrganization();

  const [isDomainAllowed, setIsDomainAllowed] = useState<boolean>(null);
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);

  const {
    control,
    handleSubmit,
    reset,
    formState: { isSubmitting, isValid },
    getValues
  } = useForm({
    mode: 'onChange',
    reValidateMode: 'onChange',
    resolver: yupResolver(credentialsSchema),
    defaultValues: {
      email: ''
    }
  });

  const validateDomain = (email: string) => {
    const allowedDomains = user.current_organization.domains;
    const domain = email.split('@')[1];
    const domainCheck = !allowedDomains.includes(domain);
    setIsDomainAllowed(domainCheck);
  };

  return (
    <>
      <MotionGroup>
        <MotionItem className={css.container}>
          <header className={classNames(css.header, css.withActions)}>
            <SecondaryHeading>Members</SecondaryHeading>
            <div className={css.actions}>
              <SearchInput placeholder="Search" />
              <Button
                size="small"
                variant="filled"
                color="primary"
                onClick={() => setIsDialogOpen(true)}
              >
                <PlusIcon />
                <span>Invite</span>
              </Button>
            </div>
          </header>
          <div className={css.members}>
            {members.map((member: MemberOrganizationType) => {
              return (
                <Fragment key={member.user.id}>
                  <div className={css.memberCard}>
                    <InitialsAvatar
                      name={`${member.user.first_name} ${member.user.last_name}`}
                      id={member.user.id}
                      size={45}
                      src={member.user.picture_url}
                      rounded={true}
                    />
                    <div className={css.info}>
                      <div>
                        {member.user.first_name} {member.user.last_name}
                      </div>
                      <div className={css.tagline}>{member.user.email}</div>
                    </div>
                    {permissions.is_admin && (
                      <div className={css.actions}>
                        <Select
                          clearable={false}
                          placeholder="Select a role..."
                          value={String(member.role.id)}
                          onChange={value => {
                            updateMemberRole({
                              email: member.user.email,
                              role_id: parseInt(value),
                              organization_id: member.role.organization_id
                            });
                          }}
                        >
                          {roles?.map((role: RoleType) => (
                            <SelectOption key={role.id} value={String(role.id)}>
                              {role.name}
                            </SelectOption>
                          ))}
                        </Select>
                        {/* TODO: Add this button when backend api is ready */}
                        {/* <Button variant="text">
                        <DeleteIcon className={css.deleteIcon} />
                      </Button> */}
                      </div>
                    )}
                  </div>
                  <Divider />
                </Fragment>
              );
            })}
            {pendingInvitations.map(
              (invitedUser: OrganizationInvitationType) => {
                return (
                  <Fragment key={nanoid()}>
                    <div className={css.memberCard}>
                      <InitialsAvatar
                        name={invitedUser.email}
                        id={parseInt(nanoid())}
                        size={45}
                        src=""
                        rounded={true}
                      />
                      <div className={css.info}>
                        <div className={css.tagline}>{invitedUser.email}</div>
                      </div>
                      <Chip
                        variant="outline"
                        color="info"
                        className={css.chipInvite}
                      >
                        <span className={css.pendingInvitationChip}>
                          Invitation Pending
                        </span>
                      </Chip>
                    </div>
                    <Divider />
                  </Fragment>
                );
              }
            )}
          </div>
        </MotionItem>
      </MotionGroup>
      <Dialog
        open={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        size="450px"
        header="Invite Member"
        disablePadding
      >
        <section className={css.dialogBox}>
          <Block label="Email" required>
            <Controller
              name="email"
              control={control}
              render={({ field: { onChange, value } }) => (
                <Input
                  type="email"
                  value={value}
                  error={Boolean(isDomainAllowed && getValues('email'))}
                  onChange={event => {
                    const value = event.target.value;
                    validateDomain(value);
                    onChange(event);
                  }}
                  placeholder="Enter email"
                />
              )}
            />
            {isDomainAllowed && getValues('email') && (
              <Text color="error">Domain not allowed</Text>
            )}
          </Block>
          {user.current_organization.domains.length > 0 && (
            <Block label="Allowed domains">
              {user.current_organization.domains.map(
                (domain: string, index: number) => (
                  <Chip
                    className={css.allowedDomainsChip}
                    variant="outline"
                    color="info"
                    key={`${domain}-${index}`}
                  >
                    {domain}
                  </Chip>
                )
              )}
            </Block>
          )}
          <footer className={css.footer}>
            <Stack justifyContent="end">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                variant="filled"
                color="primary"
                disabled={!isValid || isSubmitting || isDomainAllowed}
                onClick={handleSubmit(() => {
                  inviteMembers(getValues('email').split(','));
                  setIsDialogOpen(false);
                  reset();
                })}
              >
                {isSubmitting ? 'Inviting...' : 'Invite'}
              </Button>
            </Stack>
          </footer>
        </section>
      </Dialog>
    </>
  );
};
