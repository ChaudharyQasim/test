import { FC, useState } from 'react';
import { UseMutateFunction } from 'react-query';
import classNames from 'classnames';
import {
  Button,
  Divider,
  Input,
  MotionGroup,
  MotionItem,
  SecondaryHeading,
  SmallHeading,
  Stack,
  Text
} from 'reablocks';
import { InitialsAvatar } from 'shared/elements/InitialsAvatar';

// Form lib validation
import * as Yup from 'yup';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

// Shared
import { Dialog } from 'shared/layers/Dialog';

// CSS
import css from './Tabs.module.css';

// Hooks
import { useAuth } from 'core/Auth';

// Modules
import { UploadImageDialog } from '../modules/UploadImageDialog';

// Hooks
import { useOrganization } from 'core/Organization';

// Types
import { UpdateOrgDetailsType } from 'core/Api/OrganizationApi';
type GeneralProps = {
  uploadOrganizationImage: UseMutateFunction<unknown, any, File, unknown>;
  isUploadOrganizationImageLoading: boolean;
  onDeleteOrganizationImage: UseMutateFunction<unknown, any, void, unknown>;
  isDeleteOrganizationImageLoading: boolean;
  updateOrganizationDetails: (data: UpdateOrgDetailsType) => Promise<void>;
  leaveOrganization: () => void;
};

const credentialsSchema = Yup.object().shape({
  organization_name: Yup.string().required('Required'),
  allowed_domains: Yup.string()
});

export const General: FC<GeneralProps> = ({
  uploadOrganizationImage,
  isUploadOrganizationImageLoading,
  onDeleteOrganizationImage,
  isDeleteOrganizationImageLoading,
  updateOrganizationDetails,
  leaveOrganization
}) => {
  const { user, refreshUser } = useAuth();
  const [loadedLeaving, setLoadedLeaving] = useState<boolean>(false);
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [isUploadImageDialogOpen, setIsUploadImageDialogOpen] =
    useState<boolean>(false);
  const [isDeleteImageDialogOpen, setIsDeleteImageDialogOpen] =
    useState<boolean>(false);

  const { permissions } = useOrganization();
  const {
    control,
    handleSubmit,
    formState: { isSubmitting, isValid },
    getValues
  } = useForm({
    mode: 'onChange',
    reValidateMode: 'onChange',
    resolver: yupResolver(credentialsSchema),
    defaultValues: {
      organization_name: user.current_organization.name,
      allowed_domains: user.current_organization.domains.join(', ')
    }
  });

  return (
    <>
      <MotionGroup>
        <MotionItem className={css.container}>
          <header className={css.header}>
            <SecondaryHeading>General</SecondaryHeading>
            <SmallHeading className={css.tagline}>
              Manage your user settings
            </SmallHeading>
          </header>
          <form
            onSubmit={handleSubmit(async () => {
              const cleanedDomains = getValues('allowed_domains')
                .split(',')
                .map(domain => domain.trim());
              await updateOrganizationDetails({
                name: getValues('organization_name'),
                domains: cleanedDomains
              });
              refreshUser();
            })}
            className={css.content}
          >
            <div className={css.doubleHeight}>
              <div className={css.picture}>
                <InitialsAvatar
                  orgName={user.current_organization.name}
                  id={user.current_organization.id}
                  src={user.current_organization.picture_url}
                  size={100}
                />
              </div>
            </div>

            <div className={classNames(css.doubleHeight, css.pictureActions)}>
              {permissions.is_admin && (
                <>
                  <Button
                    type="button"
                    variant="filled"
                    color="primary"
                    onClick={() => setIsUploadImageDialogOpen(true)}
                    disabled={
                      isUploadOrganizationImageLoading ||
                      isDeleteOrganizationImageLoading
                    }
                  >
                    {isUploadOrganizationImageLoading
                      ? 'Uploading Image'
                      : 'Upload Image'}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsDeleteImageDialogOpen(true)}
                    disabled={
                      !user?.current_organization?.picture_url ||
                      isUploadOrganizationImageLoading ||
                      isDeleteOrganizationImageLoading
                    }
                  >
                    {isDeleteOrganizationImageLoading ? 'Deleting' : 'Delete'}
                  </Button>
                </>
              )}
            </div>
            <div className={css.tagline}>Organization Name</div>
            <div>
              {permissions.is_admin ? (
                <Controller
                  name="organization_name"
                  control={control}
                  render={({ field: { value, onBlur, onChange } }) => (
                    <Input
                      name="organization_name"
                      disabled={isSubmitting}
                      type="text"
                      value={value}
                      onChange={onChange}
                      onBlur={onBlur}
                      placeholder="Abstract"
                    />
                  )}
                />
              ) : (
                user.current_organization.name
              )}
            </div>
            <div className={css.tagline}>Allowed domains to join</div>
            <div>
              {permissions.is_admin ? (
                <Controller
                  name="allowed_domains"
                  control={control}
                  render={({ field: { value, onBlur, onChange } }) => (
                    <Input
                      name="allowed_domains"
                      disabled={isSubmitting}
                      type="text"
                      value={value}
                      onChange={onChange}
                      onBlur={onBlur}
                      placeholder="abstract.security, gmail.com, hotmail.com etc."
                    />
                  )}
                />
              ) : (
                user.current_organization.domains.join(',')
              )}
            </div>
            <div></div>
            <Stack inline={false} justifyContent="end">
              {permissions.is_admin && (
                <Button
                  variant="filled"
                  color="primary"
                  type="submit"
                  disabled={isSubmitting || !isValid}
                >
                  {isSubmitting ? 'Updating...' : 'Update'}
                </Button>
              )}
            </Stack>
          </form>
          <Divider />
          <header className={css.header}>
            <SecondaryHeading>Leave Organization</SecondaryHeading>
            <SmallHeading className={css.tagline}>
              If you want to leave the organization you can do so below
            </SmallHeading>
          </header>
          <Stack>
            <Button
              disabled={loadedLeaving}
              variant="filled"
              color="error"
              onClick={() => setIsDialogOpen(true)}
            >
              Leave Organization
            </Button>
          </Stack>
        </MotionItem>
      </MotionGroup>

      <Dialog
        open={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        size="450px"
        header="Leave Organization"
      >
        <Text className={css.text}>
          Are you sure you want to leave the organization?
        </Text>
        <footer className={css.footer}>
          <Stack justifyContent="end">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="filled"
              color="error"
              disabled={loadedLeaving}
              onClick={() => {
                setLoadedLeaving(true);
                leaveOrganization();
              }}
            >
              Leave Organization
            </Button>
          </Stack>
        </footer>
      </Dialog>

      <Dialog
        open={isDeleteImageDialogOpen}
        onClose={() => setIsDeleteImageDialogOpen(false)}
        size="450px"
        header="Delete Image"
      >
        <Text className={css.text}>
          Are you sure you want to delete the Organization profile image?
        </Text>
        <footer className={css.footer}>
          <Stack justifyContent="end">
            <Button
              variant="outline"
              onClick={() => setIsDeleteImageDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="filled"
              color="error"
              onClick={() => {
                onDeleteOrganizationImage();
                setIsDeleteImageDialogOpen(false);
              }}
            >
              Delete Image
            </Button>
          </Stack>
        </footer>
      </Dialog>

      <UploadImageDialog
        isUploadDialogOpen={isUploadImageDialogOpen}
        setIsUploadDialogOpen={setIsUploadImageDialogOpen}
        onCompleted={async file => {
          uploadOrganizationImage(file);
        }}
        headerText="Upload Organization Image"
      />
    </>
  );
};
