import { FC, useCallback, useState } from 'react';
import classNames from 'classnames';
import {
  Block,
  Button,
  Chip,
  Input,
  MotionGroup,
  MotionItem,
  SecondaryHeading,
  SmallHeading,
  Stack
} from 'reablocks';

// Form lib validation
import * as Yup from 'yup';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

// Icons
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';

// CSS
import css from './Tabs.module.css';

// Components
import { Dialog } from 'shared/layers/Dialog';
import { Checkbox } from 'shared/form/Checkbox';
import { Table } from 'shared/layout/Table';

// Modules
import { PermissionActions } from '../modules/PermissionActions';

// Hooks
import { useOrganization } from 'core/Organization';

// Types
import { CreateRole, Permission, UpdateRole } from 'core/Api';
import { RoleType } from 'core/Api/RolesPermissionsApi';
interface IPermissions extends Permission {
  checked: boolean;
}

type OrganizationProps = {
  permissions: IPermissions[];
  createRole: (role: Omit<CreateRole, 'organization_id'>) => Promise<void>;
  roles: RoleType[];
  deleteRole: (id: number) => Promise<void>;
  updateRole: (role: Omit<UpdateRole, 'organization_id'>) => Promise<void>;
};

const credentialsSchema = Yup.object().shape({
  role_name: Yup.string().required('Required')
});

export const Permissions: FC<OrganizationProps> = ({
  permissions,
  createRole,
  roles,
  deleteRole,
  updateRole
}) => {
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [isEditable, setIsEditable] = useState<boolean>(false);
  const [roleId, setRoleId] = useState<number | null>(null);
  const [permissionsSelectedState, setPermissionsSelectedState] =
    useState<IPermissions[]>(permissions);

  const { permissions: globalPermissions } = useOrganization();

  const {
    control,
    handleSubmit,
    reset,
    formState: { isSubmitting, isValid },
    getValues,
    setValue
  } = useForm({
    mode: 'onChange',
    reValidateMode: 'onChange',
    resolver: yupResolver(credentialsSchema),
    defaultValues: {
      role_name: ''
    }
  });

  /**
   * @description This opens the edit dialog and sets the permissions and role name added
   */
  const onEditChange = useCallback(
    (row: { permissions: IPermissions[]; name: string }, value: any) => {
      const assignedPermissions = permissionsSelectedState.map(permission => {
        const isAssigned = row.permissions.some(
          assignedPermission => assignedPermission.id === permission.id
        );
        return {
          ...permission,
          checked: isAssigned
        };
      });

      setValue('role_name', row.name);
      setRoleId(value.getValue());
      setIsEditable(true);
      setPermissionsSelectedState(assignedPermissions);
      setIsDialogOpen(true);
    },
    [permissionsSelectedState, setValue, setIsEditable]
  );

  const rolesColumns = [
    {
      id: 'role',
      header: 'Role',
      accessor: 'name',
      cell: value => value.getValue()
    },
    {
      id: 'action',
      header: 'Action',
      size: 500,
      accessor: 'permissions',
      cell: value => {
        const formattedPermission = value
          .getValue()
          .map((permission: Permission) => ({
            id: permission.id,
            name: permission.name.replace(/_/g, ' ')
          }));
        return (
          <div className={css.permissions}>
            {formattedPermission.map((permission: IPermissions) => (
              <Chip key={permission.id} variant="outline">
                {permission.name}
              </Chip>
            ))}
          </div>
        );
      }
    },
    {
      id: 'actions',
      header: '',
      accessor: 'id',
      size: 50,
      cell: value => {
        const roleName = value.row.original.name;
        return globalPermissions.is_admin &&
          !['member', 'admin'].includes(roleName) ? (
          <PermissionActions
            row={value}
            onEditChange={row => onEditChange(row, value)}
            onDeleteChange={value => {
              deleteRole(value);
            }}
          />
        ) : null;
      }
    }
  ];

  /**
   * @description This toggles the permissions if the user is read only
   * it will disable all the permissions, if the user is not read only
   * it will disable is read only permission
   */
  function onGetValidPermissions({ prev, label, value }) {
    return prev.map((permission: IPermissions) => {
      let checked = permission.checked;
      if (permission.name === 'is_read_only' || label == 'is_read_only') {
        checked = false;
      }
      if (permission.name === label) {
        checked = value;
      }

      return {
        ...permission,
        checked
      };
    });
  }

  function onPermissionChange(value: boolean, permissionChanged: Permission) {
    const label = permissionChanged.name;
    setPermissionsSelectedState(prev =>
      onGetValidPermissions({ prev, label, value })
    );
  }

  /**
   * @description This handles the edit and create role
   */
  async function onSubmitRole() {
    if (isEditable) {
      await updateRole({
        name: getValues('role_name'),
        role_id: roleId,
        permissions: permissionsSelectedState
          .filter(permission => permission.checked)
          .map(permission => permission.name)
      });
    } else {
      await createRole({
        name: getValues('role_name'),
        permissions: permissionsSelectedState
          .filter(permission => permission.checked)
          .map(permission => permission.name)
      });
    }
    reset();
    setIsDialogOpen(false);
  }

  function onOpenRoleDialog() {
    // This will reset the permissions to unchecked when creating a new role
    const unCheckedPermissions = permissionsSelectedState.map(permission => ({
      ...permission,
      checked: false
    }));
    setPermissionsSelectedState(unCheckedPermissions);
    setIsDialogOpen(true);
  }

  return (
    <>
      <MotionGroup>
        <MotionItem className={css.container}>
          <header className={classNames(css.header, css.withActions)}>
            <SecondaryHeading>Permissions & Roles</SecondaryHeading>
            {globalPermissions.is_admin && (
              <div className={css.actions}>
                <Button
                  size="small"
                  variant="filled"
                  color="primary"
                  onClick={onOpenRoleDialog}
                >
                  <PlusIcon />
                  <span>Create a new Role</span>
                </Button>
              </div>
            )}
          </header>
          <div className={css.members}>
            <Table data={roles} columns={rolesColumns} />
          </div>
        </MotionItem>
      </MotionGroup>
      <Dialog
        open={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        size="450px"
        header="Create a New Role"
        disablePadding
      >
        <form onSubmit={handleSubmit(onSubmitRole)} className={css.dialogBox}>
          <Block label="Role Name">
            <Controller
              name="role_name"
              control={control}
              render={({ field: { onChange, value } }) => (
                <Input
                  name="role_name"
                  type="text"
                  placeholder="Role Name"
                  value={value}
                  onChange={onChange}
                />
              )}
            />
          </Block>
          <section className={css.boxPermissions}>
            <SmallHeading>Permissions</SmallHeading>
            {permissionsSelectedState.map(permission => {
              return (
                <li className={css.permission} key={permission.id}>
                  <Checkbox
                    checked={permission.checked}
                    onChange={value => onPermissionChange(value, permission)}
                    label={permission.name.replace(/_/g, ' ')}
                  />
                </li>
              );
            })}
          </section>
          <footer className={css.footer}>
            <Stack justifyContent="end">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                variant="filled"
                color="primary"
                type="submit"
                disabled={!isValid || isSubmitting}
              >
                {isSubmitting
                  ? isEditable
                    ? 'Updating'
                    : 'Creating'
                  : isEditable
                  ? 'Update'
                  : 'Create'}
              </Button>
            </Stack>
          </footer>
        </form>
      </Dialog>
    </>
  );
};
