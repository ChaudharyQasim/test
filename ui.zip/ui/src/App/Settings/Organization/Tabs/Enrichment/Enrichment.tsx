import { FC, useMemo, useState } from 'react';
import {
  MotionGroup,
  MotionItem,
  Button,
  SecondaryHeading,
  useNotification
} from 'reablocks';
import classNames from 'classnames';

// CSS
import css from './Enrichment.module.css';

// Icons
import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';

// Shared
import { Table } from 'shared/layout/Table';
import { Pager } from 'shared/data/Pager';

import {
  UploadFileProperties,
  UploadFile
} from 'App/Settings/Organization/modules/UploadFile';

import { useFilterPager } from 'core/Hooks/useFilterPager';
import { Loader } from 'shared/elements/Loader';
import {
  EnrichmentCsvListType,
  ListLoaderType
} from '../../Organization.types';
import { ConfirmationDialog } from 'shared/layers/ConfirmationDialog';

export const EnrichmentList: FC<EnrichmentCsvListType> = ({
  enrichmentCSVList,
  isEnrichmentLoading,
  enrichmentUploadMutation,
  deleteEnrichmentMutation
}) => {
  const { metadata, file_list } = enrichmentCSVList || {};

  const { page, setPage } = useFilterPager();

  const { notifyError } = useNotification();

  const [deleteRowLoading, setDeleteRowLoading] = useState<ListLoaderType>({});

  const [isUploadEnrichmentOpen, setIsUploadEnrichmentOpen] =
    useState<boolean>(false);

  const [uploadProperties, setUploadProperties] =
    useState<UploadFileProperties>({
      estimatedTimeRemaining: 0,
      percentage: 0
    });

  const [enrichmentIdToDelete, setEnrichmentIdToDelete] = useState<{
    fileId: string;
    fileName: string;
  } | null>(null);

  const [openDialog, setOpenDialog] = useState<boolean>(false);

  const [fileProperties, setFileProperties] = useState<File | null>(null);

  const [uploadedFileResponse, setUploadedFileResponse] = useState(null);

  const updateDeleteRowLoading = (id: string, value: boolean) =>
    setDeleteRowLoading(prev => ({
      ...prev,
      [id]: value
    }));

  const deleteEnrichment = async () => {
    const { fileId: id, fileName } = enrichmentIdToDelete;
    try {
      updateDeleteRowLoading(id, true);
      await deleteEnrichmentMutation({
        fileId: id,
        fileName
      });
    } catch (error: any) {
      const {
        response: { status, data }
      } = error;
      if (status === 409) {
        notifyError(
          `The ${fileName} CSV file can't be deleted as ${data.function_list
            .map(func => func.name)
            .join(', ')} function depends on it.`
        );
      }
    }
    updateDeleteRowLoading(id, false);
  };

  const onConfirmation = () => {
    setOpenDialog(false);
    deleteEnrichment();
  };

  const onStartFileUpload = async file => {
    const { data, name } = file;

    const formData = new FormData();
    formData.append('file', data, name);

    setFileProperties(data);

    const uploadedFile = await enrichmentUploadMutation({
      file: formData,
      onUploadProgress: setUploadProperties
    });

    setUploadedFileResponse(uploadedFile);
  };

  const enrichmentColumn = useMemo(
    () => [
      {
        id: 'enrichment',
        header: 'File Name',
        accessor: 'file_name',
        cell: value => value.getValue()
      },
      {
        id: 'id',
        header: '',
        accessor: 'id',
        cell: value => (
          <Button
            variant="outline"
            disabled={deleteRowLoading[value.getValue()]}
            className={css.iconBtn}
            onClick={() => {
              const { id, file_name } = value.row.original;
              setEnrichmentIdToDelete({
                fileId: id,
                fileName: file_name
              });
              setOpenDialog(true);
            }}
          >
            <CloseIcon />
          </Button>
        )
      }
    ],
    [deleteRowLoading]
  );

  return (
    <>
      <MotionGroup>
        <MotionItem className={css.container}>
          <header className={classNames(css.header, css.withActions)}>
            <SecondaryHeading>Enrichment CSVs</SecondaryHeading>
            <div className={css.actions}>
              <Button
                size="small"
                variant="filled"
                color="primary"
                onClick={() => setIsUploadEnrichmentOpen(true)}
              >
                <PlusIcon />
                <span>Upload Enrichment CSV</span>
              </Button>
            </div>
          </header>

          <div className={css.content}>
            {isEnrichmentLoading ? (
              <Loader />
            ) : (
              <>
                <Table data={file_list} columns={enrichmentColumn} />
                <Pager
                  total={metadata?.total_count}
                  page={(page || 1) - 1}
                  size={metadata?.page_size}
                  onPageChange={(page: number) => setPage(page + 1)}
                />
              </>
            )}
          </div>
        </MotionItem>
      </MotionGroup>
      <ConfirmationDialog
        open={openDialog}
        dialogType="DELETE"
        confirmationHeading="Delete Confirmation"
        confirmationMessage="Are you sure you want to delete the CSV file?"
        confirmationButtonName="Delete"
        onConfirm={onConfirmation}
        onCancel={() => setOpenDialog(false)}
      />
      <UploadFile
        isOpen={isUploadEnrichmentOpen}
        uploadProperties={uploadProperties}
        fileProperties={fileProperties}
        onStartFileUpload={file => onStartFileUpload(file)}
        onDelete={async () => {
          await deleteEnrichmentMutation({
            fileName: uploadedFileResponse.file_name,
            fileId: uploadedFileResponse.id
          });
          setFileProperties(null);
        }}
        onClose={() => {
          setIsUploadEnrichmentOpen(false);
          setUploadProperties(null);
          setFileProperties(null);
        }}
      />
    </>
  );
};
