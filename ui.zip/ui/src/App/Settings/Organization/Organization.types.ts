import { DeleteCSVOut, ListCSVOut, UploadCSVOut } from 'core/Api';
import { UseMutateAsyncFunction } from 'react-query';

// Types
export type EnrichmentCsvListType = {
  enrichmentCSVList: ListCSVOut;
  isEnrichmentLoading: boolean;
  deleteEnrichmentMutation: UseMutateAsyncFunction<
    DeleteCSVOut,
    any,
    {
      fileName: string;
      fileId: string;
    },
    unknown
  >;
  enrichmentUploadMutation: UseMutateAsyncFunction<
    UploadCSVOut,
    unknown,
    {
      file: any;
      onUploadProgress: any;
    },
    unknown
  >;
};

export type ListLoaderType = {
  [key: string]: boolean;
};
