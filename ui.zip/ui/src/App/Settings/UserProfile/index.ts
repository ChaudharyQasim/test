export { UserProfileContainer as default } from './UserProfileContainer';
