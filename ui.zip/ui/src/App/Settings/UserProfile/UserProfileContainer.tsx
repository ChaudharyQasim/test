import { FC } from 'react';
import { useMutation } from 'react-query';
import { useNotification } from 'reablocks';

import { UserProfile } from './UserProfile';

import { errorHandler } from 'shared/utils/Helper';

// Hooks
import { useAuth } from 'core/Auth';

// API Service
import { updateUserImage, deleteUserImage, updateUser } from 'core/Api/UserApi';

// Types
import { UpdateUser } from 'core/Api/types';

export const UserProfileContainer: FC = () => {
  const { user, refreshUser } = useAuth();

  const { notifySuccess, notifyError } = useNotification();

  const { mutate: updateUserMutation, isLoading: isUpdateUserLoading } =
    useMutation(
      (data: UpdateUser) => {
        if (!user) {
          throw new Error('User not found');
        }
        return updateUser(data);
      },
      {
        onSuccess() {
          notifySuccess('User profile updated successfully');
        },
        onError(error: any) {
          notifyError(`Error updating user profile: ${errorHandler(error)}`);
        },
        onSettled() {
          refreshUser();
        }
      }
    );

  const {
    mutate: uploadUserImageMutation,
    isLoading: isUploadUserImageLoading
  } = useMutation(
    (data: File) => {
      if (!user) {
        throw new Error('User not found');
      }
      const formData = new FormData();
      formData.append('image', data);

      return updateUserImage({
        id: user.id,
        patchData: formData
      });
    },
    {
      onSuccess() {
        notifySuccess('User profile image updated successfully');
      },
      onError(error: any) {
        notifyError(
          `Error updating user profile image: ${errorHandler(error)}`
        );
      },
      onSettled() {
        refreshUser();
      }
    }
  );

  const {
    mutate: deleteUserImageMutation,
    isLoading: isDeleteUserImageLoading
  } = useMutation(
    () => {
      if (!user) {
        throw new Error('User not found');
      }
      return deleteUserImage({ id: user.id });
    },
    {
      onSuccess() {
        notifySuccess('User profile image deleted successfully');
      },
      onError(error: any) {
        notifyError(
          `Error deleting user profile image: ${errorHandler(error)}`
        );
      },
      onSettled() {
        refreshUser();
      }
    }
  );

  return (
    <UserProfile
      uploadUserImage={uploadUserImageMutation}
      onDeleteUserImage={deleteUserImageMutation}
      updateUserProfile={updateUserMutation}
      isUploadUserImageLoading={isUploadUserImageLoading}
      isDeleteUserImageLoading={isDeleteUserImageLoading}
      isUpdateUserProfileLoading={isUpdateUserLoading}
    />
  );
};
