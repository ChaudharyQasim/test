import { FC, useState } from 'react';
import { UseMutateFunction } from 'react-query';
import classNames from 'classnames';
import {
  Button,
  Divider,
  Input,
  MotionGroup,
  MotionItem,
  PrimaryHeading,
  SecondaryHeading,
  SmallHeading,
  Stack,
  Text,
  Toggle
} from 'reablocks';
import { Helmet } from 'react-helmet-async';
import { InitialsAvatar } from 'shared/elements/InitialsAvatar';

import * as Yup from 'yup';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

// Shared
import { Dialog } from 'shared/layers/Dialog';

// CSS
import css from './UserProfile.module.css';

// Modules
import { UploadImageDialog } from '../Organization/modules/UploadImageDialog';

// Hooks
import { useAuth } from 'core/Auth';
import { useOrganization } from 'core/Organization';

// Types
import { UpdateUser } from 'core/Api/types';

type UserProfileProps = {
  updateUserProfile: UseMutateFunction<unknown, any, UpdateUser, unknown>;
  uploadUserImage: UseMutateFunction<unknown, any, File, unknown>;
  onDeleteUserImage: UseMutateFunction<unknown, any, void, unknown>;
  isDeleteUserImageLoading: boolean;
  isUploadUserImageLoading: boolean;
  isUpdateUserProfileLoading: boolean;
};

const profileSchema = Yup.object().shape({
  user_firstname: Yup.string().required('Required'),
  user_lastname: Yup.string().required('Required'),
  user_username: Yup.string().required('Required')
});

export const UserProfile: FC<UserProfileProps> = ({
  updateUserProfile,
  uploadUserImage,
  onDeleteUserImage,
  isUploadUserImageLoading,
  isDeleteUserImageLoading,
  isUpdateUserProfileLoading
}) => {
  const [isUploadImageDialogOpen, setIsUploadImageDialogOpen] =
    useState<boolean>(false);
  const [isDeleteImageDialogOpen, setIsDeleteImageDialogOpen] =
    useState<boolean>(false);

  const { user, refreshUser } = useAuth();
  const { permissions } = useOrganization();
  const {
    control,
    handleSubmit,
    formState: { isSubmitting, isValid },
    getValues
  } = useForm({
    mode: 'onChange',
    reValidateMode: 'onChange',
    resolver: yupResolver(profileSchema),
    defaultValues: {
      user_firstname: user.first_name,
      user_lastname: user.last_name,
      user_username: user.username
    }
  });

  const onProfileSubmit = async () => {
    updateUserProfile({
      first_name: getValues('user_firstname'),
      last_name: getValues('user_lastname'),
      username: getValues('user_username')
    });
  };

  return (
    <MotionGroup>
      <Helmet>
        <title>User Profile</title>
      </Helmet>
      <header className={css.header}>
        <PrimaryHeading>
          <Stack>
            <span>User Profile</span>
          </Stack>
        </PrimaryHeading>
      </header>

      <MotionItem className={css.container}>
        <header className={css.header}>
          <SecondaryHeading>General</SecondaryHeading>
          <SmallHeading className={css.tagline}>
            Manage your user settings
          </SmallHeading>
        </header>
        <form onSubmit={handleSubmit(onProfileSubmit)} className={css.content}>
          <div className={css.doubleHeight}>
            <div className={css.picture}>
              <InitialsAvatar
                name={`${user?.first_name} ${user?.last_name}`}
                id={user?.id}
                size={100}
                src={user?.picture_url}
              />
            </div>
          </div>
          <div className={classNames(css.doubleHeight, css.pictureActions)}>
            <Button
              variant="filled"
              color="primary"
              onClick={() => setIsUploadImageDialogOpen(true)}
              disabled={isUploadUserImageLoading || isDeleteUserImageLoading}
            >
              {isUploadUserImageLoading ? 'Uploading Image' : 'Upload Image'}
            </Button>
            <Button
              variant="outline"
              onClick={() => setIsDeleteImageDialogOpen(true)}
              disabled={
                !user?.picture_url ||
                isUploadUserImageLoading ||
                isDeleteUserImageLoading
              }
            >
              {isDeleteUserImageLoading ? 'Deleting' : 'Delete'}
            </Button>
          </div>
          <div className={css.tagline}>Email</div>
          <div>{user.email}</div>
          <div className={css.tagline}>Username</div>
          <div>{user.username}</div>
          <div className={css.tagline}>First Name</div>
          <div>
            <Controller
              name="user_firstname"
              control={control}
              render={({ field: { value, onBlur, onChange } }) => (
                <Input
                  name="user_firstname"
                  disabled={isSubmitting || isUpdateUserProfileLoading}
                  type="text"
                  value={value}
                  onChange={onChange}
                  onBlur={onBlur}
                  placeholder="John"
                />
              )}
            />
          </div>
          <div className={css.tagline}>Last Name</div>
          <div>
            <Controller
              name="user_lastname"
              control={control}
              render={({ field: { value, onBlur, onChange } }) => (
                <Input
                  name="user_lastname"
                  disabled={isSubmitting || isUpdateUserProfileLoading}
                  type="text"
                  value={value}
                  onChange={onChange}
                  onBlur={onBlur}
                  placeholder="Doe"
                />
              )}
            />
          </div>

          {/* Empty place holder for alignment  */}
          <div />
          <Stack justifyContent="end">
            {permissions.is_admin && (
              <Button
                variant="filled"
                color="primary"
                type="submit"
                disabled={
                  isSubmitting || !isValid || isUpdateUserProfileLoading
                }
              >
                {isSubmitting || isUpdateUserProfileLoading
                  ? 'Updating...'
                  : 'Update'}
              </Button>
            )}
          </Stack>
        </form>
      </MotionItem>
      {/* TODO: Wrap this up when the backend is ready */}
      {/* <Divider />
        <header className={css.header}>
          <SecondaryHeading>Auth Settings</SecondaryHeading>
          <SmallHeading className={css.tagline}>
            Manage your auth settings
          </SmallHeading>
        </header>
        <div className={css.content}>
          <div className={css.tagline}>Enable MFA</div>
          <div>
            <Toggle size="small" onChange={() => {}} checked={true} />
          </div>
          <div className={css.tagline}>Default Page</div>
          <div>
            <Controller
              name="default_page"
              control={control}
              render={({ field: { value, onBlur, onChange } }) => (
                <Input
                  name="default_page"
                  // disabled={isSubmitting}
                  type="text"
                  value={value}
                  onChange={onChange}
                  onBlur={onBlur}
                  placeholder="/dashboard"
                />
              )}
            />
          </div>
        </div>
        <Stack inline={false} justifyContent="end">
          <Button variant="filled" color="primary">
            Update
          </Button>
        </Stack>
      </MotionItem> */}
      <UploadImageDialog
        isUploadDialogOpen={isUploadImageDialogOpen}
        setIsUploadDialogOpen={setIsUploadImageDialogOpen}
        onCompleted={async file => {
          uploadUserImage(file);
        }}
        headerText="Upload User Image"
      />

      <Dialog
        open={isDeleteImageDialogOpen}
        onClose={() => setIsDeleteImageDialogOpen(false)}
        size="450px"
        header="Delete Image"
      >
        <Text className={css.text}>
          Are you sure you want to delete your profile image?
        </Text>
        <footer className={css.footer}>
          <Stack justifyContent="end">
            <Button
              variant="outline"
              onClick={() => setIsDeleteImageDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="filled"
              color="error"
              onClick={() => {
                onDeleteUserImage();
                setIsDeleteImageDialogOpen(false);
              }}
            >
              Delete Image
            </Button>
          </Stack>
        </footer>
      </Dialog>
    </MotionGroup>
  );
};
