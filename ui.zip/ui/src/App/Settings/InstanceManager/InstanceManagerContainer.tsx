import { FC, useCallback, useMemo } from 'react';
import { InstanceManager } from './InstanceManager';
import { useNotification } from 'reablocks';
import { useQuery, useQueryClient } from 'react-query';

// Shared
import { Loader } from 'shared/elements/Loader';

// Core
import {
  getListTenantsAccounts,
  getListVendors,
  postInitiateVendor,
  updateVendorOffBoardAccount
} from 'core/Api/VendorApi';
import { useAuth } from 'core/Auth';
import { GetStackUrlOut, VendorAccountIn } from 'core/Api';

/**
 * @todo Remove or modify this when other vendors are available
 */
export const SUPPORTED_VENDORS = ['AWS', 'Azure'];

export const InstanceManagerContainer: FC = () => {
  const { user } = useAuth();

  const { notifySuccess, notifyError } = useNotification();

  const queryClient = useQueryClient();

  const { data: vendors, isLoading: isVendorLoading } = useQuery(
    'vendors',
    () => getListVendors(),
    {
      initialData: []
    }
  );

  const {
    data: tenantAccounts,
    isLoading: isTenantsLoading,
    refetch: refetchVendors
  } = useQuery('tenantAccounts', () =>
    getListTenantsAccounts(user.current_organization.id)
  );

  const initiateNewVendor = useCallback(
    async (vendorData: VendorAccountIn): Promise<GetStackUrlOut> => {
      if (!user) {
        return;
      }
      try {
        const response = await postInitiateVendor(vendorData);
        notifySuccess('CloudFormation Stack created successfully');
        return response;
      } catch (error) {
        notifyError(`Error creating the CloudFormation Stack: ${error}`);
      }
    },
    [user, notifyError, notifySuccess]
  );

  const offBoardVendor = useCallback(
    async (vendorId: string): Promise<void> => {
      if (!user) {
        return;
      }
      try {
        await updateVendorOffBoardAccount(vendorId);
        queryClient.invalidateQueries({ queryKey: ['tenantAccounts'] });
      } catch (error: any) {
        const vendorErrorMessage = error?.response?.data?.message;
        notifyError(
          `Error offboarding the CloudFormation Stack: ${
            vendorErrorMessage ? vendorErrorMessage : error
          }`
        );
      }
    },
    [user, notifyError, queryClient]
  );

  const tenantAccountList = useMemo(() => {
    if (!tenantAccounts) {
      return [];
    }
    return tenantAccounts;
  }, [tenantAccounts]);

  /**
   * @todo Remove or modify this when other vendors are available
   */
  const availableVendors = useMemo(
    () => vendors?.filter(vendor => SUPPORTED_VENDORS.includes(vendor.name)),
    [vendors]
  );

  if (isTenantsLoading || isVendorLoading) {
    return <Loader />;
  }

  return (
    <InstanceManager
      vendors={availableVendors}
      initiateNewVendor={initiateNewVendor}
      offBoardVendor={offBoardVendor}
      tenantAccountList={tenantAccountList}
      refetchVendors={refetchVendors}
    />
  );
};
