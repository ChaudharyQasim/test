import { FC, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Button, Chip, PrimaryHeading, Stack } from 'reablocks';
import classNames from 'classnames';

// Icons
import { ReactComponent as EmptyInstance } from 'assets/illustrations/empty-instance.svg';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import { ReactComponent as AWS } from 'assets/vendors/aws.svg';
import { ReactComponent as Azure } from 'assets/vendors/azure.svg';

// Shared
import { EmptyState } from 'shared/elements/EmptyState';
import { Dialog } from 'shared/layers/Dialog';
import { Table } from 'shared/layout/Table/Table';

// Modules
import { NewInstance } from './modules/NewInstance';
import { InstanceActions } from './modules/InstanceActions';

// CSS
import css from './InstanceManager.module.css';

// Types
import { VendorAccountIn, VendorAccountOut, GetStackUrlOut } from 'core/Api';
import { Vendor } from 'core/Api/VendorApi';

export interface InstanceManagerProps {
  vendors: Vendor[];
  initiateNewVendor: (data: VendorAccountIn) => Promise<GetStackUrlOut>;
  offBoardVendor: (vendorId: string) => Promise<void>;
  tenantAccountList: VendorAccountOut[] | [];
  refetchVendors: () => void;
}

export const InstanceManager: FC<InstanceManagerProps> = ({
  initiateNewVendor,
  offBoardVendor,
  tenantAccountList,
  vendors,
  refetchVendors
}) => {
  const [isNewInstanceDialogOpen, setIsNewInstanceDialogOpen] =
    useState<boolean>(false);
  const [stackUrl, setStackUrl] = useState<string>('');

  function getStatusColor(status: string) {
    const statusColorMap = {
      initiated: 'info',
      runner_initiated: 'info',
      queued: 'info',
      'in-progress': 'warning',
      completed: 'success',
      failure: 'error'
    };

    return statusColorMap[status];
  }

  const rolesColumns = [
    {
      id: 'name',
      header: 'Name',
      accessor: 'name',
      cell: value => value.getValue()
    },
    {
      id: 'status',
      header: 'Status',
      accessor: 'status',
      cell: value => {
        const originalStatus = value.row.original.status;
        const status = originalStatus[originalStatus.length - 1].status;
        return (
          <>
            <Chip
              size="medium"
              color={getStatusColor(status)}
              className={classNames(css.chip, css[status])}
            >
              {status}
            </Chip>
          </>
        );
      }
    },
    {
      id: 'environment',
      header: 'Environment',
      accessor: 'id',
      cell: value => {
        const vendor = vendors?.filter(
          vendor => vendor.id === value.row.original.vendor_id
        )[0];
        return (
          <>
            {vendor.name === 'AWS' && <AWS className={css.vendorIcon} />}
            {vendor.name === 'Azure' && <Azure className={css.vendorIcon} />}
          </>
        );
      }
    },
    {
      id: 'region',
      header: 'Region',
      accessor: 'account_details.region',
      cell: value => {
        const region = value.row.original.account_details.region;
        return <div>{region}</div>;
      }
    },
    {
      id: 'storage',
      header: 'Data Stored',
      accessor: 'data_stored'
    },
    {
      id: 'integrations',
      header: 'Marketplace/Pipelines/Rules',
      accessor: 'id',
      cell: value => <div></div>
    },
    {
      id: 'actions',
      header: '',
      accessor: 'nanoid',
      size: 50,
      cell: value => {
        return (
          <InstanceActions
            row={value.row.original}
            onDeleteChange={vendorId => {
              offBoardVendor(vendorId);
            }}
          />
        );
      }
    }
  ];

  return (
    <div className={css.container}>
      <Helmet>
        <title>Instances</title>
      </Helmet>
      <header className={css.header}>
        <Stack justifyContent="spaceBetween">
          <PrimaryHeading>Instances</PrimaryHeading>
          <Button
            size="small"
            color="primary"
            onClick={() => setIsNewInstanceDialogOpen(true)}
          >
            <PlusIcon className={css.plusIcon} />
            New Instance
          </Button>
        </Stack>
      </header>
      <section className={css.content}>
        {tenantAccountList.length <= 0 && (
          <div className={css.isEmpty}>
            <EmptyState
              illustration={<EmptyInstance />}
              title="No Instance deployed"
              actions={
                <Button
                  color="primary"
                  onClick={() => setIsNewInstanceDialogOpen(true)}
                >
                  <PlusIcon className={css.plusIcon} />
                  New Instance
                </Button>
              }
            />
          </div>
        )}
        {tenantAccountList.length > 0 && (
          <Table data={tenantAccountList} columns={rolesColumns} />
        )}
      </section>
      <Dialog
        open={isNewInstanceDialogOpen}
        onClose={() => setIsNewInstanceDialogOpen(false)}
        size="780px"
        header="Instance Onboarding"
        disablePadding
      >
        <NewInstance
          vendors={vendors}
          onClose={() => setIsNewInstanceDialogOpen(false)}
          stack_url={stackUrl}
          onDone={async selectedVendor => {
            const response = await initiateNewVendor(selectedVendor);
            setStackUrl(response.stack_url);
            refetchVendors();
          }}
        />
      </Dialog>
    </div>
  );
};
