export const INSTANCE_SIZE = [
  {
    value: 'xsmall',
    label: 'x-small'
  },
  {
    value: 'small',
    label: 'small'
  },
  {
    value: 'medium',
    label: 'medium'
  },
  {
    value: 'large',
    label: 'large'
  },
  {
    value: 'xlarge',
    label: 'x-large'
  }
];
