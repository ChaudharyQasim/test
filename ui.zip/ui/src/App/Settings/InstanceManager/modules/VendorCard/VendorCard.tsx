import { FC, useCallback, useState } from 'react';
import classNames from 'classnames';

import { Button, SmallHeading } from 'reablocks';

// CSS
import css from './VendorCard.module.css';

//  Icons
import { ReactComponent as CheckIcon } from 'assets/icons/check.svg';
import { ReactComponent as AWS } from 'assets/vendors/aws.svg';
import { ReactComponent as GCP } from 'assets/vendors/gcp.svg';
import { ReactComponent as Azure } from 'assets/vendors/azure.svg';

// Types
import { Vendor } from 'core/Api/VendorApi';

type VendorCardProps = {
  vendor: Vendor;
  isVendorSelected?: boolean;
  onChange?: (vendor: Vendor) => void;
};

const vendorIcon = {
  aws: {
    icon: <AWS className={css.vendorIcon} />,
    text: 'Amazon Web Services'
  },
  gcp: {
    icon: <GCP className={css.vendorIcon} />,
    text: 'Google Cloud Platform'
  },
  'on-prem': {
    icon: <span className={css.vendorText}>On Prem</span>,
    text: ''
  },
  azure: {
    icon: <Azure className={css.vendorIcon} />,
    text: 'Azure'
  }
};

export const VendorCard: FC<VendorCardProps> = ({
  vendor,
  isVendorSelected,
  onChange
}) => {
  const formatName = vendor.name.replace(/ /g, '-').toLowerCase();

  function onVendorSelection(vendor: Vendor) {
    onChange(vendor);
  }

  return (
    <Button
      variant="text"
      className={classNames(css.environmentCard, css.border, {
        [css.active]: isVendorSelected
      })}
      onClick={() => onVendorSelection(vendor)}
    >
      {isVendorSelected && <CheckIcon className={css.checkIcon} />}
      {vendorIcon[formatName].icon}
      {vendorIcon[formatName].text && (
        <SmallHeading className={css.title}>
          {vendorIcon[formatName].text}
        </SmallHeading>
      )}
    </Button>
  );
};
