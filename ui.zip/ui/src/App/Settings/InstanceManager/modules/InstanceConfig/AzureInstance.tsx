import { FC, ReactElement, JSXElementConstructor } from 'react';
import { Input, Select, SelectOption } from 'reablocks';

// CSS
import css from './InstanceConfig.module.css';

// Constants
import { INSTANCE_SIZE } from '../../constants';

// Types
import {
  ControllerProps,
  FieldPath,
  FieldValues,
  Control
} from 'react-hook-form';
import { RegionType } from 'core/Api/VendorApi';

type AzureInstanceProps = {
  Controller: <
    TFieldValues extends FieldValues = FieldValues,
    TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>
  >(
    props: ControllerProps<TFieldValues, TName>
  ) => ReactElement<JSXElementConstructor<any>>;
  control: Control<any>;
  regions: RegionType[];
};

export const AzureInstance: FC<AzureInstanceProps> = ({
  control,
  Controller,
  regions
}) => {
  return (
    <div className={css.content}>
      <div className={css.tagline}>Instance Name</div>
      <div>
        <Controller
          name="tenant_name"
          control={control}
          render={({ field: { onChange, value } }) => (
            <Input
              type="text"
              value={value}
              onChange={onChange}
              placeholder="azureinstance"
            />
          )}
        />
      </div>
      <div className={css.tagline}>Subscription ID</div>
      <div>
        <Controller
          name="subscription_id"
          control={control}
          render={({ field: { onChange, value } }) => (
            <Input
              type="text"
              value={value}
              onChange={onChange}
              placeholder="abcd1234-1234-abcd-1234-abcd1234abcd"
            />
          )}
        />
      </div>
      <div className={css.tagline}>Azure Tenant ID</div>
      <div>
        <Controller
          name="azure_tenant_id"
          control={control}
          render={({ field: { onChange, value } }) => (
            <Input
              type="text"
              value={value}
              onChange={onChange}
              placeholder="x0xxx10-xx0x-0x0x-xx0x-0x0x0x0x0x0x"
            />
          )}
        />
      </div>
      <div className={css.tagline}>Azure Region</div>
      <div>
        <Controller
          name="region"
          control={control}
          render={({ field: { onChange, value, onBlur } }) => (
            <Select
              clearable={false}
              placeholder="Select a region..."
              value={value}
              onChange={onChange}
              onBlur={onBlur}
            >
              {regions.map(region => {
                return (
                  <SelectOption
                    menuLabel={
                      <span>
                        {region.value} - <small>{region.label}</small>
                      </span>
                    }
                    inputLabel={
                      <span>
                        {region.value} -{' '}
                        <small className={css.selectText}>{region.label}</small>
                      </span>
                    }
                    key={region.value}
                    value={region.value}
                  />
                );
              })}
            </Select>
          )}
        />
      </div>
      <div className={css.tagline}>Instance Size</div>
      <div>
        <Controller
          name="tenant_size"
          control={control}
          render={({ field: { value, onBlur, onChange } }) => (
            <Select
              clearable={false}
              placeholder="Select an instance size..."
              value={value}
              onChange={onChange}
              onBlur={onBlur}
            >
              {INSTANCE_SIZE.map(size => {
                return (
                  <SelectOption key={size.value} value={size.value}>
                    {size.label}
                  </SelectOption>
                );
              })}
            </Select>
          )}
        />
      </div>
    </div>
  );
};
