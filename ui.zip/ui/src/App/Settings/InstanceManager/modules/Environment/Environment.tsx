import { FC } from 'react';

// CSS
import css from './Environment.module.css';

// Modules
import { VendorCard } from '../VendorCard';

// Types
import { Vendor } from 'core/Api/VendorApi';

type EnvironmentProps = {
  vendors: Vendor[];
  selectedVendor: string;
  onSelect: (vendor: Vendor) => void;
};

export const Environment: FC<EnvironmentProps> = ({
  vendors,
  selectedVendor,
  onSelect
}) => {
  const renderVendorCard = (vendor: Vendor) => {
    const isVendorSelected = selectedVendor === vendor.name.toLocaleUpperCase();
    return (
      <VendorCard
        key={vendor.id}
        vendor={vendor}
        isVendorSelected={isVendorSelected}
        onChange={() => onSelect(vendor)}
      />
    );
  };

  return (
    <section>
      <div className={css.environmentContainer}>
        {vendors && vendors.length > 0 ? vendors.map(renderVendorCard) : null}
      </div>
    </section>
  );
};
