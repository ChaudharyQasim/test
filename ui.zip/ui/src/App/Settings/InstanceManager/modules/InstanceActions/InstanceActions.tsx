import { FC, useRef, useState } from 'react';
import { Button, Card, List, ListItem, Menu } from 'reablocks';

// Icons
import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as DotsIcon } from 'assets/icons/dots.svg';

// Types
import { VendorAccountOut } from 'core/Api';

type InstanceActionsProps = {
  row: VendorAccountOut;
  onDeleteChange: (value: string) => void;
};

export const InstanceActions: FC<InstanceActionsProps> = ({
  row,
  onDeleteChange
}) => {
  const [instanceMenuOpen, setInstanceMenuOpen] = useState(false);
  const instanceMenuRef = useRef(null);

  return (
    <div>
      <Button
        variant="text"
        ref={instanceMenuRef}
        onClick={() => setInstanceMenuOpen(!instanceMenuOpen)}
      >
        <DotsIcon />
      </Button>
      <Menu
        reference={instanceMenuRef}
        open={instanceMenuOpen}
        placement="bottom-end"
        onClose={() => setInstanceMenuOpen(false)}
      >
        <Card>
          <List>
            <ListItem
              start={<DeleteIcon />}
              onClick={() => {
                setInstanceMenuOpen(false);
                onDeleteChange(row.nanoid);
              }}
            >
              Delete
            </ListItem>
          </List>
        </Card>
      </Menu>
    </div>
  );
};
