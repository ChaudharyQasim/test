import { FC } from 'react';
import { Button, List, ListItem, SmallHeading, Stack } from 'reablocks';

// CSS
import css from './CloudFormation.module.css';

// Types
type CloudFormationProps = {
  cloudFormationUrl: string;
  onUrlOpened?: () => void;
};

export const CloudFormation: FC<CloudFormationProps> = ({
  cloudFormationUrl,
  onUrlOpened
}) => {
  return (
    <div>
      <Stack justifyContent="center">
        <Button
          variant="filled"
          size="large"
          className={css.button}
          color="primary"
          disabled={!cloudFormationUrl}
          onClick={() => {
            // Open the CloudFormation url in a new tab
            window.open(cloudFormationUrl, '_blank', 'noreferrer');
            onUrlOpened();
          }}
        >
          Launch CloudFormation Stack
        </Button>
      </Stack>
      <section>
        <header className={css.header}>
          <SmallHeading>CloudFormation instructions</SmallHeading>
        </header>

        <List className={css.list}>
          <ListItem className={css.item}>
            <strong>STEP 1:</strong> Launch the cloudformation stack above
          </ListItem>
          <ListItem className={css.item}>
            <strong>STEP 2:</strong> Complete the cloudformation deployment in
            AWS Console
          </ListItem>
          <ListItem className={css.item}>
            <strong>STEP 3:</strong> Return here and click done
          </ListItem>
        </List>
      </section>
    </div>
  );
};
