export * from './NewInstance';
