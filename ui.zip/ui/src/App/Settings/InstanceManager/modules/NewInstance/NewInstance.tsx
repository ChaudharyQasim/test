import { FC, useState } from 'react';
import { Button, List, ListItem, SmallHeading, Stack, Text } from 'reablocks';
import classNames from 'classnames';

// CSS
import css from './NewInstance.module.css';

// Modules
import { Environment } from '../Environment';
import { CloudFormation } from '../CloudFormation';

// Form lib validation
import * as Yup from 'yup';
import { Controller, SubmitHandler, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

// Instances
import { AWSInstance } from '../InstanceConfig';
import { AzureInstance } from '../InstanceConfig';

// Types
import { Vendor } from 'core/Api/VendorApi';
import { VendorAccountIn } from 'core/Api';
import { AnyObject, ObjectSchema } from 'yup';

type NewInstanceProps = {
  vendors: Vendor[];
  onClose: () => void;
  onDone: (data: VendorAccountIn) => void;
  stack_url: string;
};

type FormData = {
  tenant_name: string;
  account_id: string;
  subscription_id: string;
  azure_tenant_id: string;
  region: string;
  tenant_size: string;
};

type SelectedVendorData = {
  cloud_provider: 'AWS' | 'Azure';
  fields: string[];
};

type GetPayloadForSelectedVendor = (data: FormData) => VendorAccountIn;

const credentialsSchema = (
  selectedVendor: string
): ObjectSchema<any, AnyObject, any, ''> => {
  let shape = {};

  if (selectedVendor === 'AWS') {
    shape = {
      tenant_name: Yup.string()
        .required('Required')
        .matches(
          /^[a-z-]+$/,
          'Tenant Name only accepts lowercase letters and -'
        )
        .max(10, 'Tenant Name must be less than 10 letters'),
      account_id: Yup.string()
        .required('Required')
        .matches(/^[0-9]+$/, 'AWS Accounts must be only digits')
        .min(12)
        .max(12, 'AWS Accounts must be 12 digits')
    };
  }

  if (selectedVendor === 'AZURE') {
    shape = {
      tenant_name: Yup.string()
        .required('Required')
        .matches(
          /^[a-z-]+$/,
          'Tenant Name only accepts lowercase letters and -'
        )
        .max(10, 'Tenant Name must be less than 10 letters'),
      subscription_id: Yup.string().required('Required'),
      azure_tenant_id: Yup.string().required('Required')
    };
  }

  shape = {
    ...shape,
    region: Yup.string().required('Required'),
    tenant_size: Yup.string().required('Required')
  };

  return Yup.object().shape(shape);
};

export const NewInstance: FC<NewInstanceProps> = ({
  onClose,
  onDone,
  vendors,
  stack_url
}) => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [hasUrlBeenOpened, setHasUrlBeenOpened] = useState<boolean>(false);
  const isVendorAvailable = vendors && vendors.length > 0;
  const [selectedVendor, setSelectedVendor] = useState<string>(
    isVendorAvailable ? vendors[0].name.toLocaleUpperCase() : null
  );

  const filteredVendor = (vendorName: 'AWS' | 'Azure') =>
    vendors.filter(vendor => vendor.name === vendorName)[0].regions;
  const azureRegions = filteredVendor('Azure');
  const awsRegions = filteredVendor('AWS');

  const {
    control,
    formState: { isValid },
    handleSubmit
  } = useForm({
    mode: 'onChange',
    reValidateMode: 'onChange',
    resolver: yupResolver(credentialsSchema(selectedVendor)),
    defaultValues: {
      tenant_name: '',
      account_id: '',
      subscription_id: '',
      azure_tenant_id: '',
      region: '',
      tenant_size: 'small'
    }
  });

  const instanceVendorData = {
    AZURE: {
      cloud_provider: 'Azure',
      fields: [
        'tenant_name',
        'subscription_id',
        'azure_tenant_id',
        'region',
        'tenant_size'
      ],
      text: 'The first step to deploying within AZURE is providing a name \
      to describe the AZURE Account and providing the AZURE Subscription ID',
      component: (
        <AzureInstance
          control={control}
          Controller={Controller}
          regions={azureRegions}
        />
      )
    },
    AWS: {
      cloud_provider: 'AWS',
      fields: ['tenant_name', 'account_id', 'region', 'tenant_size'],
      text: 'The first step to deploying within AWS is providing a name \
      to describe the AWS Account and providing the AWS Account ID',
      component: (
        <AWSInstance
          control={control}
          Controller={Controller}
          regions={awsRegions}
        />
      )
    }
  };

  const instanceSteps = [
    {
      id: 1,
      title: 'Select Environment',
      component: (
        <Environment
          vendors={vendors}
          selectedVendor={selectedVendor}
          onSelect={vendor =>
            setSelectedVendor(vendor.name.toLocaleUpperCase())
          }
        />
      ),
      text: isVendorAvailable
        ? 'Select which Cloud Service Provider you would like to deploy in'
        : 'Vendors are not available, or you do not have permission to edit them.'
    },
    {
      id: 2,
      title: 'Instance Config',
      component: instanceVendorData[selectedVendor].component,
      text: instanceVendorData[selectedVendor].text
    },
    {
      id: 3,
      title: 'CloudFormation',
      component: (
        <CloudFormation
          onUrlOpened={() => setHasUrlBeenOpened(true)}
          cloudFormationUrl={stack_url}
        />
      )
    }
  ];

  const isLastStep = activeStep === instanceSteps.length;
  const isFirstStep = activeStep === 1;
  const isCloudFormationStep = activeStep === 2;

  function onPreviousStep() {
    // If we are on the first step, we can close the dialog
    if (isFirstStep) {
      onClose();
    }
    setActiveStep(activeStep - 1);
  }

  const onSubmit: SubmitHandler<FormData> = data => {
    const payload: VendorAccountIn = getPayloadForSelectedVendor(data);
    onDone(payload);
    setActiveStep(activeStep + 1);
  };

  const getPayloadForSelectedVendor: GetPayloadForSelectedVendor = data => {
    const selectedVendorData: SelectedVendorData =
      instanceVendorData[selectedVendor];
    if (selectedVendorData) {
      const { fields, cloud_provider } = selectedVendorData;
      const payload: VendorAccountIn = {
        cloud_provider,
        tenant_name: '',
        region: ''
      };

      fields.forEach(field => {
        if (data[field] !== undefined) {
          payload[field] = data[field];
        }
      });

      return payload;
    }
  };

  async function onNextStep() {
    setActiveStep(activeStep + 1);
    if (isLastStep) {
      onClose();
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className={css.container}>
      <section className={css.steps}>
        <List className={css.list}>
          <ListItem className={classNames(activeStep === 1 && css.active)}>
            Select Environment
          </ListItem>
          <ListItem className={classNames(activeStep === 2 && css.active)}>
            Instance Config
          </ListItem>
          <ListItem className={classNames(activeStep === 3 && css.active)}>
            Deployment Template
          </ListItem>
        </List>
      </section>
      <section className={css.content}>
        {instanceSteps.map(
          step =>
            activeStep === step.id && (
              <div key={step.id}>
                <header className={css.header}>
                  <SmallHeading>
                    <Stack justifyContent="spaceBetween">
                      <span>{step.title}</span>
                    </Stack>
                  </SmallHeading>
                  <Text className={css.tagline}>{step.text}</Text>
                </header>
                {step.component}
              </div>
            )
        )}
        <footer>
          <Stack justifyContent="end" alignItems="end">
            {!isLastStep && (
              <Button variant="outline" size="small" onClick={onPreviousStep}>
                {isFirstStep ? 'Cancel' : 'Previous'}
              </Button>
            )}
            <Button
              color="primary"
              size="small"
              onClick={!isCloudFormationStep ? onNextStep : undefined}
              type={isCloudFormationStep ? 'submit' : 'button'}
              disabled={
                (isFirstStep && !isVendorAvailable) ||
                (isLastStep && !hasUrlBeenOpened) ||
                (isCloudFormationStep && !isValid)
              }
            >
              {isLastStep ? 'Done' : 'Next'}
            </Button>
          </Stack>
        </footer>
      </section>
    </form>
  );
};
