export { InstanceManagerContainer as default } from './InstanceManagerContainer';
