import React, { Suspense, lazy } from 'react';
import ReactDOM from 'react-dom/client';
import { Helmet, HelmetProvider } from 'react-helmet-async';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Notifications, ThemeProvider } from 'reablocks';
import { ReactRouter6Adapter } from 'use-query-params/adapters/react-router-6';
import { QueryParamProvider } from 'use-query-params';

// Shared
import { theme } from 'shared/utils/Theme';
import { ErrorBoundary } from 'shared/utils/ErrorBoundary';
import { Loader } from 'shared/elements/Loader';

// Core
import { Auth, AuthRoute } from 'core/Auth';
import { Organization } from 'core/Organization';
import { QueryProvider } from 'core/Api';

import './index.css';

// Ag-grid
import { LicenseManager } from 'ag-grid-enterprise';

// Lazy pages
const App = lazy(() => import('./App'));
const Login = lazy(() => import('./App/Login'));
const Signup = lazy(() => import('./App/Signup'));
const Passcode = lazy(() => import('./App/Passcode'));
const UserOnboarding = lazy(() => import('./App/UserOnboarding'));
const PendingApproval = lazy(() => import('./App/PendingApproval'));

LicenseManager.setLicenseKey(import.meta.env.VITE_AG_GRID_LICENSE_KEY || '');

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <BrowserRouter>
      <QueryProvider>
        <QueryParamProvider adapter={ReactRouter6Adapter}>
          <HelmetProvider>
            <Helmet
              titleTemplate="%s | Abstract Security"
              defaultTitle="Abstract Security"
            />
            <ThemeProvider theme={theme}>
              <ErrorBoundary>
                <Notifications>
                  <Auth>
                    <Organization>
                      <Suspense fallback={<Loader />}>
                        <Routes>
                          <Route element={<AuthRoute />}>
                            <Route
                              path="user-onboarding"
                              element={<UserOnboarding />}
                            />
                            <Route
                              path="pending-approval"
                              element={<PendingApproval />}
                            />
                            <Route path="*" element={<App />} />
                          </Route>
                          <Route path="login" element={<Login />} />
                          <Route path="signup" element={<Signup />} />
                          <Route path="passcode" element={<Passcode />} />
                        </Routes>
                      </Suspense>
                    </Organization>
                  </Auth>
                </Notifications>
              </ErrorBoundary>
            </ThemeProvider>
          </HelmetProvider>
        </QueryParamProvider>
      </QueryProvider>
    </BrowserRouter>
  </React.StrictMode>
);
