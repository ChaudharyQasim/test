import { FC } from 'react';
import { Pager as ReaPager, PagerProps, Stack } from 'reablocks';

import { ReactComponent as PreviousArrow } from 'assets/icons/arrow-left.svg';
import { ReactComponent as NextArrow } from 'assets/icons/arrow-right.svg';
import { ReactComponent as LastArrow } from 'assets/icons/arrow-last.svg';
import { ReactComponent as FirstArrow } from 'assets/icons/arrow-first.svg';

import css from './Pager.module.css';

export const Pager: FC<PagerProps> = ({
  className,
  previousArrow,
  nextArrow,
  ...rest
}) => (
  <ReaPager
    className={css.pager}
    pageClassName={css.page}
    previousArrow={
      <Stack>
        <PreviousArrow /> Previous
      </Stack>
    }
    nextArrow={
      <Stack>
        Next <NextArrow />
      </Stack>
    }
    startArrow={
      <Stack className={css.startIcon}>
        <FirstArrow /> Start
      </Stack>
    }
    endArrow={
      <Stack className={css.endIcon}>
        Last <LastArrow />
      </Stack>
    }
    {...rest}
  />
);
