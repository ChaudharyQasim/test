import { FC, useState } from 'react';
import { Button, Textarea } from 'reablocks';

// CSS
import css from './Comments.module.css';

// Modules
import { Comment } from './modules/Comment';
import {
  AddCommentRequest,
  CommentDetail as CommentType,
  Reaction
} from 'core/Api';

// Types
type CommentsProps = {
  comments: CommentType[];
  onCreateComment?: (data: AddCommentRequest) => Promise<void>;
  onDeleteComment?: (commentId: string) => void;
  onAddReaction?: (commentId: string, reaction: Reaction) => Promise<void>;
  onRemoveReaction?: (commentId: string, reaction: Reaction) => Promise<void>;
  currentUser: string;
};

export const Comments: FC<CommentsProps> = ({
  comments,
  onCreateComment,
  onDeleteComment,
  onAddReaction,
  onRemoveReaction,
  currentUser
}) => {
  const [showCommentButton, setShowCommentButton] = useState<boolean>(false);
  const [commentText, setCommentText] = useState<string>('');

  async function onNewCommentButtonHandler() {
    await onCreateComment({
      content: commentText,
      tagged_users: ['']
    });

    setShowCommentButton(false);
    setCommentText('');
  }

  return (
    <section className={css.container}>
      {comments.map((comment: CommentType) => {
        return (
          <Comment
            key={comment.id}
            currentUser={currentUser}
            comment={comment}
            onDeleteComment={onDeleteComment}
            onReaction={async (reaction_id: string) =>
              await onAddReaction(comment.id, {
                reaction_id: reaction_id
              })
            }
            onRemoveReaction={async (reaction_id: string) =>
              await onRemoveReaction(comment.id, {
                reaction_id: reaction_id
              })
            }
          />
        );
      })}
      <section className={css.postArea}>
        <Textarea
          fullWidth
          size="large"
          minRows={5}
          onChange={event => setCommentText(event.target.value)}
          value={commentText}
          onFocus={e => {
            e.stopPropagation();
            setShowCommentButton(true);
          }}
          placeholder="Add a comment here..."
        />
        {showCommentButton && (
          <Button
            disabled={!commentText}
            variant="filled"
            color="primary"
            className={css.postButton}
            onClick={onNewCommentButtonHandler}
          >
            Comment
          </Button>
        )}
      </section>
    </section>
  );
};
