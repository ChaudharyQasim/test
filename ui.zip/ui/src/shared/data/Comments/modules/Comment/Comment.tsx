import { FC, useRef, useState } from 'react';
import { parseISO } from 'date-fns';
import {
  Button,
  Card,
  DateFormat,
  Menu,
  SecondaryHeading,
  SmallHeading,
  Stack,
  Text
} from 'reablocks';
import Picker from '@emoji-mart/react';

// CSS
import css from './Comment.module.css';

// Icons
import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as AddEmojiIcon } from 'assets/icons/add-emoji.svg';
import { CommentDetail as CommentType } from 'core/Api';
import classNames from 'classnames';
import { DATE_FORMAT } from 'shared/utils/Constants';

// Types
type CommentProps = {
  comment: CommentType;
  onDeleteComment: (commentId: string) => void;
  onReaction: (reaction_id: string) => Promise<void>;
  onRemoveReaction: (reaction_id: string) => Promise<void>;
  currentUser: string;
};

export const Comment: FC<CommentProps> = ({
  comment,
  onDeleteComment,
  onReaction,
  onRemoveReaction,
  currentUser
}) => {
  const [showEmojiPicker, setShowEmojiPicker] = useState<boolean>(false);

  const btnRef = useRef<HTMLButtonElement | null>(null);

  const groupByReaction = comment.reactions.reduce(
    (acc, { reaction, user }) => {
      if (!acc[reaction]) {
        acc[reaction] = [];
      }
      acc[reaction].push(user);
      return acc;
    },
    {}
  );

  /**
   * @description Handle add or remove reaction from each comment
   * @param reaction
   */
  function onHandleReactionToggle(reaction: string) {
    const reactionUsers = groupByReaction[reaction];
    const hasUser = reactionUsers?.includes(currentUser);

    if (hasUser && reactionUsers) {
      onRemoveReaction(reaction);
    } else {
      onReaction(reaction);
    }
  }

  return (
    <Card className={css.container}>
      <Button
        disableMargins
        disablePadding
        className={css.deleteIcon}
        variant="text"
        onClick={() => {
          onDeleteComment(comment.id);
        }}
      >
        <DeleteIcon />
      </Button>
      <header className={css.header}>
        <span className={css.picture}></span>
        <SecondaryHeading className={css.name}>
          {comment.first_name} {comment.last_name}
        </SecondaryHeading>
        <SmallHeading className={css.date}>
          <DateFormat
            date={parseISO(comment.created_date)}
            format={DATE_FORMAT}
          />
        </SmallHeading>
      </header>

      <section className={css.description}>
        <Text>{comment.content}</Text>
      </section>

      <footer className={css.actions}>
        <Stack>
          <Button
            className={css.add}
            variant="filled"
            color="primary"
            size="small"
            ref={btnRef}
            disablePadding
            onClick={() => {
              setShowEmojiPicker(!showEmojiPicker);
            }}
          >
            <AddEmojiIcon />
          </Button>
          {comment.reactions.length > 0 &&
            Object.keys(groupByReaction).map((reaction, index) => (
              <Button
                key={reaction + index}
                variant="text"
                disablePadding
                disableMargins
                className={classNames(css.emojiAction, {
                  [css.reacted]: groupByReaction[reaction].includes(currentUser)
                })}
                onClick={() => {
                  onHandleReactionToggle(reaction);
                }}
              >
                {String.fromCodePoint(parseInt(`0x${reaction}`))} +{' '}
                {groupByReaction[reaction].length}
              </Button>
            ))}
          <Menu
            reference={btnRef}
            open={showEmojiPicker}
            placement="bottom-end"
            onClose={() => setShowEmojiPicker(false)}
          >
            <Picker
              onEmojiSelect={async emoji => {
                onHandleReactionToggle(emoji.unified);
                setShowEmojiPicker(false);
              }}
            />
          </Menu>
        </Stack>
      </footer>
    </Card>
  );
};
