import { Stack, Text } from "reablocks";
import { FC } from "react";
import { ReactComponent as LineChartIcon } from 'assets/icons/line-chart.svg';
import { ReactComponent as BarChartIcon } from 'assets/icons/bar-chart.svg';
import css from './SemiCircleChartTooltip.module.css';


interface SemiCircleChartTooltipProps {
  date: string;
  volume: string;
  reduction: string;
  findings: string;
  insights: string;
}

export const SemiCircleChartTooltip: FC<SemiCircleChartTooltipProps> = ({
  date,
  volume,
  reduction,
  findings,
  insights
}) => (
  <Stack direction="column" alignItems="start" className={css.container}>
    <Text fontStyle="bold">{date}</Text>
    <Stack justifyContent="spaceBetween" className={css.values}>
      <Stack dense justifyContent="start">
        <Stack dense>
          <LineChartIcon className={css.volume} />
          {volume}
        </Stack>
        .
        <Stack dense>
          <LineChartIcon className={css.reduction} />
          {reduction}
        </Stack>
      </Stack>
      <Stack dense justifyContent="end">
        <Stack dense>
          <BarChartIcon className={css.findings} />
          {findings}
        </Stack>
        .
        <Stack dense>
          <BarChartIcon className={css.insights} />
          {insights}
        </Stack>
      </Stack>
    </Stack>
  </Stack>
)