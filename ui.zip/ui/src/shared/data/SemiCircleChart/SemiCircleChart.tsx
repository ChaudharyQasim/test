import { arc } from 'd3-shape';
import { FC, Fragment } from 'react';
import { DataSize, formatSize } from 'reablocks';
import { format } from 'date-fns';
import {
  ChartContainer,
  ChartContainerChildProps,
  ChartContainerProps,
  ChartNestedDataShape,
  ChartShallowDataShape,
  RadialAxis,
  RadialAxisArc,
  RadialAxisArcSeries,
  RadialAxisTick,
  RadialAxisTickLabel,
  RadialAxisTickLine,
  RadialAxisTickSeries
} from 'reaviz';
import { RadarAreaChart } from './RadarAreaChart';
import { RadarBarChart } from './RadarBarChart';
import {
  ARC_COUNT,
  INNER_RADIUS,
  buildScale,
  getMaxValue,
  getRadius
} from './utils';
import classNames from 'classnames';
import css from './SemiCircleChart.module.css';
import { binaryScale } from 'shared/utils/Constants/data';
import { DATE_FORMAT } from 'shared/utils/Constants';
import { SemiCircleChartTooltip } from './SemiCircleChartTooltip/SemiCircleChartTooltip';

interface SemiCircleChartProps extends Partial<ChartContainerProps> {
  insightsFindingsData: ChartNestedDataShape[];
  reductionData: ChartShallowDataShape[];
  volumeData: ChartShallowDataShape[];
  width?: number;
  height?: number;
  labelFormat?: string;
}

export const SemiCircleChart: FC<SemiCircleChartProps> = ({
  margins = 100,
  insightsFindingsData = [],
  reductionData = [],
  volumeData = [],
  width,
  height,
  labelFormat = 'MM/d'
}) => {
  const startAngle = -0.5 * Math.PI;
  const endAngle = 0.5 * Math.PI;

  const maxReductionVal = getMaxValue(reductionData);
  const maxVolumeVal = getMaxValue(volumeData);
  const maxInsightsFindingsVal = getMaxValue(insightsFindingsData, true);

  const renderAxis = (height: number, width: number) => {
    const { xScale } = buildScale(
      reductionData,
      undefined,
      undefined,
      startAngle,
      endAngle
    );
    return (
      <RadialAxis
        height={height}
        width={width}
        innerRadius={INNER_RADIUS}
        xScale={xScale}
        arcs={
          <RadialAxisArcSeries
            count={ARC_COUNT}
            arc={
              <RadialAxisArc
                strokeDasharray={(index: number) =>
                  [1, 6, 9, 12].includes(index) ? 'none' : '1,3'
                }
                stroke={(index: number) => (index < 2 ? 'none' : '#A09B9E')}
              />
            }
          />
        }
        ticks={
          <RadialAxisTickSeries
            count={24}
            tick={({ index }) => {
              const [position, stroke]: ['inside' | 'outside', string] =
                index === 6 || index === 18
                  ? ['inside', '#333132']
                  : ['outside', '#A09B9E'];
              const label =
                index % 2 === 0 ? (
                  <RadialAxisTickLabel
                    fill="#A09B9E"
                    format={date => format(date, labelFormat)}
                  />
                ) : null;
              return (
                <RadialAxisTick
                  line={
                    <RadialAxisTickLine position={position} stroke={stroke} />
                  }
                  label={label}
                />
              );
            }}
          />
        }
        startAngle={startAngle}
        endAngle={endAngle}
      />
    );
  };

  const renderLabels = (
    height,
    width,
    maxInsightsFindingsValue = 20,
    maxReductionValue = 100,
    maxVolumeValue = 100
  ) => {
    const maxInsightsFindings = Math.round(maxInsightsFindingsValue);
    const maxReduction = Math.round(maxReductionValue);
    const maxVolume = Math.round(maxVolumeValue);

    const midInsightsFindings = Math.round(maxInsightsFindingsValue / 2);
    const midReduction = Math.round(maxReductionValue / 2);
    const midVolume = Math.round(maxVolumeValue / 2);

    const minDimension = Math.min(height, width);

    // Scaling positions based on a fixed scale
    const maxInsightsFindingsLabelPosition = (
      (-83 / 383) *
      minDimension
    ).toString();
    const maxReductionLabelPosition = ((-143 / 383) * minDimension).toString();
    const maxVolumeLabelPosition = ((-190 / 383) * minDimension).toString();

    const midInsightsFindingsLabelPosition = (
      (-69 / 383) *
      minDimension
    ).toString();
    const midReductionLabelPosition = ((-125 / 383) * minDimension).toString();
    const midVolumeLabelPosition = ((-170 / 383) * minDimension).toString();

    const insightsFindingLabelPosition = ((50 / 383) * minDimension).toString();
    const reductionLabelPosition = ((110 / 383) * minDimension).toString();
    const volumeLabelPosition = ((150 / 383) * minDimension).toString();

    return (
      <g>
        <text
          x={maxVolumeLabelPosition}
          y="20"
          className={classNames(css.label, { [css.small]: height < 500 })}
        >
          {maxVolume !== midVolume && (
            <DataSize value={maxVolume} scale={binaryScale} />
          )}
        </text>
        <text
          x={midVolumeLabelPosition}
          y="20"
          className={classNames(css.label, { [css.small]: height < 500 })}
        >
          <DataSize value={midVolume} scale={binaryScale} />
        </text>
        <text
          x={maxReductionLabelPosition}
          y="20"
          className={classNames(css.label, { [css.small]: height < 500 })}
        >
          {maxReduction !== midReduction && (
            <DataSize value={maxReduction} scale={binaryScale} />
          )}
        </text>
        <text
          x={midReductionLabelPosition}
          y="20"
          className={classNames(css.label, { [css.small]: height < 500 })}
        >
          <DataSize value={midReduction} scale={binaryScale} />
        </text>
        <text
          x={maxInsightsFindingsLabelPosition}
          y="20"
          className={classNames(css.label, { [css.small]: height < 500 })}
        >
          {maxInsightsFindings !== midInsightsFindings && (
            <DataSize value={maxInsightsFindings} scale={binaryScale} />
          )}
        </text>
        <text
          x={midInsightsFindingsLabelPosition}
          y="20"
          className={classNames(css.label, { [css.small]: height < 500 })}
        >
          <DataSize value={midInsightsFindings} scale={binaryScale} />
        </text>

        <text
          x={insightsFindingLabelPosition}
          y="20"
          className={classNames(css.label, { [css.small]: height < 500 })}
        >
          INSIGHTS/FINDINGS
        </text>
        <text
          x={reductionLabelPosition}
          y="20"
          className={classNames(css.label, { [css.small]: height < 500 })}
        >
          REDUCTION
        </text>
        <text
          x={volumeLabelPosition}
          y="20"
          className={classNames(css.label, { [css.small]: height < 500 })}
        >
          VOLUME
        </text>
      </g>
    );
  };

  const renderInnerSemiCircle = (radius: number) => {
    const startAngle = -0.5 * Math.PI;
    const endAngle = 0.5 * Math.PI;
    const { innerRadius, outerRadius } = getRadius(0, 2, radius);

    const d = arc()({
      innerRadius: 0,
      outerRadius: outerRadius,
      startAngle: startAngle,
      endAngle: endAngle
    });

    return (
      <path d={d!} opacity="1" cursor="auto" stroke="black" fill="black" />
    );
  };

  const renderTooltip = (dateTime: Date) => {
    const formattedDate = format(dateTime, DATE_FORMAT);
    const index = reductionData?.findIndex(row => (row.key as Date)?.toISOString() === dateTime?.toISOString());

    const volume = volumeData[index]?.data as number ?? 0;
    const reduction = reductionData[index]?.data as number ?? 0;
    const findings = insightsFindingsData[1]?.data[index]?.data?.toLocaleString() ?? '0';
    const insights = insightsFindingsData[0]?.data[index]?.data?.toLocaleString() ?? '0';

    const formattedVolume = formatSize(volume, undefined, binaryScale) as string;
    const formattedReduction = formatSize(reduction, undefined, binaryScale) as string;

    return (
      <SemiCircleChartTooltip
        date={formattedDate}
        volume={formattedVolume}
        reduction={formattedReduction}
        findings={findings}                  
        insights={insights}                  
      />
    )
    
  }

  return (
    <ChartContainer
      id="radar"
      width={width}
      height={height}
      margins={margins}
      xAxisVisible={false}
      yAxisVisible={false}
      centerX
      className={css.svgContainer}
    >
      {({
        width: chartWidth,
        height: chartHeight
      }: ChartContainerChildProps) => {
        const rad = Math.min(chartWidth, chartHeight) / 2;
        return (
          <Fragment>
            {renderAxis(chartHeight, chartWidth)}
            {insightsFindingsData?.length > 0 && (
              <RadarBarChart
                // Scaling the height/width to position the tooltip correctly
                height={chartHeight*0.45} 
                width={chartWidth*0.45}
                radius={rad}
                data={insightsFindingsData}
                tooltipContent={renderTooltip}
              />
            )}
            {reductionData?.length > 0 && (
              <RadarAreaChart
                id="reduction"
                // Scaling the height/width to position the tooltip correctly
                height={chartHeight * 0.65}
                width={chartWidth * 0.65}
                radius={rad}
                innerRad={6}
                outerRad={8}
                data={reductionData}
                color="#FDB730"
                tooltipContent={renderTooltip}
              />
            )}
            {volumeData?.length > 0 && (
              <RadarAreaChart
                id="volume"
                height={chartHeight}
                width={chartWidth}
                radius={rad}
                innerRad={9}
                outerRad={12}
                data={volumeData}
                color="#EB477C"
                tooltipContent={renderTooltip}
              />
            )}
            {renderLabels(
              chartHeight,
              chartWidth,
              maxInsightsFindingsVal,
              maxReductionVal,
              maxVolumeVal
            )}
            {renderInnerSemiCircle(rad)}
          </Fragment>
        );
      }}
    </ChartContainer>
  );
};
