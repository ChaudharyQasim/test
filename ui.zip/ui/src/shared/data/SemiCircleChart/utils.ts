import { range } from 'd3-array';
import { scaleBand, scaleLinear, scalePoint } from 'd3-scale';
import { addDays, startOfDay } from 'date-fns';
import {
  ChartDataShape,
  ChartInternalShallowDataShape,
  ChartNestedDataShape,
  ChartShallowDataShape,
  buildNestedChartData,
  buildShallowChartData,
  getRadialYScale,
  getYDomain,
  uniqueBy
} from 'reaviz';

export const ARC_COUNT = 12;
export const INNER_RADIUS = 25;

export const randomNumber = (min, max) =>
  Math.round(Math.random() * (max - min) + min);

const startDate = startOfDay(new Date());
export const generateData = (count = 48, maxVal = 100) =>
  range(count).map(i => ({
    // Dont do this, its for demo purposes
    id: `${new Date().getTime()}-${i})}`,
    key: addDays(startDate, 1 * i),
    data: randomNumber(0, maxVal)
  }));

export const getRadius = (startIdx: number, endIdx: number, rad: number) => {
  const scale = scaleLinear().domain([0, ARC_COUNT]).range([INNER_RADIUS, rad]);

  const arcs = scale.ticks(ARC_COUNT);
  return {
    innerRadius: scale(arcs[startIdx]),
    outerRadius: scale(arcs[endIdx])
  };
};

export const buildScale = (
  initialData: ChartDataShape[],
  outerRad = 0,
  innerRad = 0,
  startAngle = 0,
  endAngle = 2 * Math.PI,
  type: 'standard' | 'grouped' = 'standard'
) => {
  const isMultiSeries = type === 'grouped';

  let data;
  if (isMultiSeries) {
    data = buildNestedChartData(initialData as ChartNestedDataShape[], true);
  } else {
    data = buildShallowChartData(initialData as ChartShallowDataShape[]);
  }

  let xDomain;
  if (isMultiSeries) {
    xDomain = uniqueBy<ChartInternalShallowDataShape>(
      data,
      dd => dd.data,
      dd => dd.x
    );
  } else {
    xDomain = uniqueBy<ChartInternalShallowDataShape>(data, dd => dd.x);
  }

  let xScale;
  xDomain = (xDomain ||
    uniqueBy<ChartInternalShallowDataShape>(data, d => d.x)) as [Date, Date];

  const isFullCircle = Math.abs(endAngle - startAngle) >= 2 * Math.PI;

  if (isFullCircle) {
    xScale = scaleBand()
      .range([0, 2 * Math.PI])
      .domain(xDomain);
  } else {
    xScale = scalePoint().range([startAngle, endAngle]).domain(xDomain);
  }

  const yDomain = getYDomain({ data, scaled: false });

  return {
    yScale: getRadialYScale(innerRad, outerRad, yDomain),
    xScale,
    data
  };
};

export const getMaxValue = (
  data: ChartShallowDataShape[] | ChartNestedDataShape[],
  isNested = false
): number => {
  let newData;
  if (isNested) {
    newData = data.flatMap(nestedRow => nestedRow.data);
  } else {
    newData = data;
  }
  return Math.max(...newData.map(row => row.data), 0);
};
