import { FC } from 'react';
import {
  ChartShallowDataShape,
  ChartTooltip,
  GradientStop,
  RadialArea,
  RadialAreaSeries,
  RadialAreaSeriesProps,
  RadialGradient,
  RadialLine,
  TooltipArea,
} from 'reaviz';
import { buildScale, getRadius } from './utils';

interface RadarAreaChartProps
  extends Partial<Omit<RadialAreaSeriesProps, 'data'>> {
  radius: number;
  innerRad: number;
  outerRad: number;
  color: string;
  data: ChartShallowDataShape[];
  tooltipContent: (dateTime: Date) => any;
}

export const RadarAreaChart: FC<RadarAreaChartProps> = ({
  id,
  height,
  width,
  radius,
  data,
  innerRad = 6,
  outerRad = 12,
  color = '#1E5DC8',
  tooltipContent
}) => {
  const startAngle = -0.5 * Math.PI;
  const endAngle = 0.5 * Math.PI;

  const { innerRadius, outerRadius } = getRadius(innerRad, outerRad, radius);
  const {
    yScale,
    xScale,
    data: areaData
  } = buildScale(data, outerRadius, innerRadius, startAngle, endAngle);

  return (
    <RadialAreaSeries
      id={`radar-area${id}`}
      data={areaData}
      xScale={xScale}
      yScale={yScale}
      height={height}
      width={width}
      outerRadius={outerRadius}
      innerRadius={innerRadius}
      colorScheme={[color]}
      line={<RadialLine strokeWidth={2} />}
      area={
        <RadialArea
          gradient={
            <RadialGradient
              stops={[
                <GradientStop key={1} offset="60%" stopOpacity={0} />,
                <GradientStop key={2} offset="20" stopOpacity={0.4} />
              ]}
            />
          }
        />
      }
      startAngle={-0.5 * Math.PI}
      endAngle={0.5 * Math.PI}
      isClosedCurve={false}
      tooltip={
        <TooltipArea
          tooltip={
            <ChartTooltip
              content={(data, color) => (
               tooltipContent(data.x)
              )}
            />
          }
        />
      }
    />
  );
};
