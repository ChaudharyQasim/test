import { FC } from 'react';
import {
  ChartNestedDataShape,
  ChartTooltip,
  RadialBar,
  RadialBarSeries,
  RadialBarSeriesProps,
  TooltipArea
} from 'reaviz';
import { buildScale, getRadius } from './utils';

interface RadarBarChartProps
  extends Partial<Omit<RadialBarSeriesProps, 'data'>> {
  radius: number;
  data: ChartNestedDataShape[];
  tooltipContent: (dateTime: Date) => any;
}

export const RadarBarChart: FC<RadarBarChartProps> = ({
  height,
  width,
  radius,
  data,
  tooltipContent
}) => {
  const startAngle = -0.5 * Math.PI;
  const endAngle = 0.5 * Math.PI;
  const { innerRadius, outerRadius } = getRadius(2, 4, radius);
  const {
    yScale,
    xScale,
    data: barData
  } = buildScale(
    data,
    outerRadius,
    innerRadius,
    startAngle,
    endAngle,
    'grouped'
  );

  return (
    <RadialBarSeries
      id="radar-bars"
      colorScheme={['#843DE8', '#EFA9C6']}
      data={barData}
      xScale={xScale}
      yScale={yScale}
      innerRadius={innerRadius}
      outerRadius={outerRadius}
      width={width}
      height={height}
      bar={<RadialBar gradient={false} />}
      type="grouped"
      startAngle={startAngle}
      endAngle={endAngle}
      tooltip={
        <TooltipArea
          tooltip={
            <ChartTooltip
              content={(data, color) => (
               tooltipContent(data.x)
              )}
            />
          }
        />
      }
    />
  );
};
