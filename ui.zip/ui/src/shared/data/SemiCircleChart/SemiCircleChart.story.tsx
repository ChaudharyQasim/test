import { ChartNestedDataShape, ChartShallowDataShape } from 'reaviz';
import { SemiCircleChart } from './SemiCircleChart';
import { generateData } from './utils';

export default {
  title: 'Data/SemiCircleChart',
  component: SemiCircleChart
};

export const MockInsightsFindingsData: ChartNestedDataShape[] = [
  {
    key: 'Insights',
    data: generateData(48, 20)
  },
  {
    key: 'Findings',
    data: generateData(48, 20)
  }
];

export const MockReductionData: ChartShallowDataShape[] = generateData(48, 100);
export const MockVolumeData: ChartShallowDataShape[] = generateData(48, 100);

export const Default = () => (
  <SemiCircleChart
    insightsFindingsData={MockInsightsFindingsData}
    reductionData={MockReductionData}
    volumeData={MockVolumeData}
    margins={[600, 0]}
    width={1000}
    height={750}
  />
);

export const Empty = () => (
  <SemiCircleChart
    insightsFindingsData={[]}
    reductionData={[]}
    volumeData={[]}
    margins={[600, 0]}
    width={1000}
    height={750}
  />
);
