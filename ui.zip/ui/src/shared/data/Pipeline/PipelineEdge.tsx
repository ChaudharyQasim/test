import { FC } from 'react';
import Xarrow from 'react-xarrows';
import css from './PipelineCanvas.module.css';

export interface PipelineEdgeData {
  id: string;
  start?: string;
  end?: string;
  color?: string;
  dashness?: boolean;
  showHead?: boolean;
}

export type PipelineEdgeProps = PipelineEdgeData;

export const PipelineEdge: FC<PipelineEdgeProps> = ({
  start,
  end,
  showHead = false,
  color = 'var(--gray-100)',
  dashness = false
}) => (
  <Xarrow
    color={color}
    strokeWidth={1}
    dashness={dashness}
    showHead={showHead}
    start={start}
    end={end}
    divContainerProps={{
      className: css.edge
    }}
  />
);
