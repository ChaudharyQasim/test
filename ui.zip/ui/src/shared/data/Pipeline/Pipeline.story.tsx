import { useState } from 'react';
import { Pipeline } from './Pipeline';
import { PipelineEdgeData } from './PipelineEdge';
import { PipelineNodeData } from './PipelineNode';

export default {
  title: 'Data/Pipeline',
  component: Pipeline
};

export const Default = () => {
  const [nodes, setNodes] = useState<PipelineNodeData[]>([
    { id: '1', label: 'Source 1', category: 'SOURCE', pipelineId: '1' },
    { id: '2', label: 'Source 2', category: 'SOURCE', pipelineId: '1' },
    { id: '3', label: 'Route 1', category: 'ROUTE', pipelineId: '1' },
    {
      id: '4',
      label: 'Destination 1',
      category: 'DESTINATION',
      pipelineId: '1'
    }
  ]);

  const [edges, setEdges] = useState<PipelineEdgeData[]>([
    { id: '1-3', start: '1', end: '3' },
    { id: '3-4', start: '3', end: '4' }
  ]);

  const [count, setCount] = useState<number>(nodes.length + 1);

  const getNodes = (category: 'SOURCE' | 'ROUTE' | 'DESTINATION') => [
    ...nodes,
    { id: `${count}`, label: `${category} ${count}`, category, pipelineId: '1' }
  ];

  const actions = (menuId: number, id: string) => {
    if (menuId === 1) {
      // Perform deletion operation.
      setNodes(nodes.filter(node => id !== node.id));
    }
  };

  return (
    <div
      style={{ position: 'absolute', top: 20, left: 20, right: 20, bottom: 20 }}
    >
      <Pipeline
        nodes={nodes}
        edges={edges}
        onAddConnection={(start, end) => {
          const routeId = `${count}`;

          setNodes(getNodes('ROUTE'));
          setEdges([
            ...edges,
            { id: `${start}-${routeId}`, start, end: routeId },
            { id: `${routeId}-${end}`, start: routeId, end }
          ]);
          setCount(count + 1);
        }}
        actions={actions}
      />
    </div>
  );
};

export const Disabled = () => (
  <div
    style={{ position: 'absolute', top: 20, left: 20, right: 20, bottom: 20 }}
  >
    <Pipeline
      disabled
      nodes={[
        { id: '1', label: 'Source 1', category: 'SOURCE', pipelineId: '1' },
        { id: '2', label: 'Source 2', category: 'SOURCE', pipelineId: '2' },
        { id: '3', label: 'Route 1', category: 'ROUTE', pipelineId: '3' },
        {
          id: '4',
          label: 'Destination 1',
          category: 'DESTINATION',
          pipelineId: '4'
        }
      ]}
      edges={[
        { id: '1-3', start: '1', end: '3' },
        { id: '3-4', start: '3', end: '4' }
      ]}
    />
  </div>
);
