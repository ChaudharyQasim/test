import { FC } from 'react';
import { PipelineCanvas, PipelineCanvasProps } from './PipelineCanvas';
import { Xwrapper } from 'react-xarrows';

export type PipelineProps = PipelineCanvasProps;

export const Pipeline: FC<PipelineProps> = props => (
  <Xwrapper>
    <PipelineCanvas {...props} />
  </Xwrapper>
);
