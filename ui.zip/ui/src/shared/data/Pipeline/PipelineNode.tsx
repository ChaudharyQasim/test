import { FC } from 'react';
import { motion } from 'framer-motion';
import { PipelinePort } from './PipelinePort';
import { useXarrow } from 'react-xarrows';
import classNames from 'classnames';
import { Divider, Stack, Text } from 'reablocks';
import css from './PipelineCanvas.module.css';

import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as NodeIcon } from 'assets/icons/node.svg';
import { ReactComponent as PipelineIcon } from 'assets/icons/pipeline.svg';
import { ReactComponent as CheckIcon } from 'assets/icons/check.svg';
import { ReactComponent as DestinationIcon } from 'assets/icons/destination.svg';
import { ReactComponent as PencilIcon } from 'assets/icons/pencil.svg';
import { ListMenu } from 'shared/elements/ListMenu/ListMenu';
import { LabelChip } from 'shared/elements/Chip';
import { CircularLoader } from 'shared/elements/Loader/CircularLoader';

export interface PipelineNodeData {
  id: string;
  label?: string;
  pipelineLabel?: string;
  icon?: string;
  is_passthrough?: boolean;
  category?: 'SOURCE' | 'ROUTE' | 'DESTINATION';
  isNodeLoading?: boolean;
  pipelineId: string;
}

export interface PipelineNodeProps {
  id: string;
  data: PipelineNodeData;
  startPortVisible?: boolean;
  endPortVisible?: boolean;
  active?: boolean;
  highlight?: boolean;
  disabled?: boolean;
  invalid?: boolean;
  onDragStart?: (state: any) => void;
  onDrag?: (state: any) => void;
  onDragEnd?: (state: any) => void;
  onPointerOut?: (event: any) => void;
  onPointerOver?: (event: any) => void;
  onEdit?: () => void;
  onDelete?: () => void;
  actions: (menuId: number, id: string, pipelineId: string) => void;
}

const NODE_OPTIONS = [
  {
    icon: <PencilIcon />,
    iconName: 'Edit Pipeline',
    iconId: 0
  }
];

const ROUTE_OPTIONS = [
  ...NODE_OPTIONS,
  {
    icon: <DeleteIcon />,
    iconName: 'Delete',
    iconId: 1
  }
];

export const PipelineNode: FC<PipelineNodeProps> = ({
  id,
  data,
  active,
  highlight,
  disabled,
  invalid,
  startPortVisible,
  endPortVisible,
  actions,
  onPointerOut,
  onPointerOver,
  onEdit,
  onDelete,
  ...rest
}) => {
  const updateXarrow = useXarrow();
  const {
    label,
    pipelineLabel,
    category,
    icon,
    is_passthrough,
    isNodeLoading
  } = data;

  const iconUrl = `data:image/png;base64, ${icon}`;

  let nodeIcon = <img className={css.nodeIcon} src={iconUrl} />;

  if (category === 'ROUTE') {
    nodeIcon = <PipelineIcon className={css.routeIcon} />;
  }

  // NOTE: I would like to do layout animations on the motion
  // but there is no good way to get the layout animation itteration
  // to trigger the arrow line update animation
  return (
    <motion.div
      className={classNames(css.card, {
        [css.active]: active,
        [css.invalid]: invalid,
        [css.highlight]: highlight,
        [css.nodeLoader]: isNodeLoading
      })}
      onPointerOver={onPointerOver}
      onPointerOut={onPointerOut}
      onAnimationComplete={updateXarrow}
      onLayoutAnimationComplete={updateXarrow}
    >
      {startPortVisible && (
        <PipelinePort
          {...rest}
          id={`${id}-${data.id}-end`}
          active={active}
          disabled={disabled}
          direction="start"
          sourceConnection={category === 'SOURCE'}
        />
      )}
      {endPortVisible && (
        <PipelinePort
          {...rest}
          id={`${id}-${data.id}-start`}
          active={active}
          disabled={disabled}
          direction="end"
          sourceConnection={category === 'SOURCE'}
        />
      )}
      {!isNodeLoading && <div className={css.iconBox}>{nodeIcon}</div>}
      {isNodeLoading ? (
        <CircularLoader />
      ) : (
        <div className={css.content}>
          {label && (
            <>
              <Text className={css.label} fontStyle="bold">
                {label}
              </Text>
              <Stack className={css.category} dense>
                {category === 'SOURCE' && (
                  <>
                    <NodeIcon className={css.categoryIcon} /> Source
                  </>
                )}
                {category === 'DESTINATION' && (
                  <>
                    <DestinationIcon className={css.typeIcon} /> Destination
                  </>
                )}
                {category === 'ROUTE' && (
                  <>
                    <PipelineIcon className={css.categoryIcon} /> Pipeline
                  </>
                )}
              </Stack>
            </>
          )}
          {label && pipelineLabel && <Divider className={css.divider} />}
          {pipelineLabel && (
            <Stack direction="column" alignItems="start" className={css.name}>
              <Text className={css.label} fontStyle="bold">
                {pipelineLabel}
              </Text>
              {is_passthrough ? (
                <LabelChip variant="outline" color="secondary">
                  <Stack dense>
                    <CheckIcon /> PASSTHROUGH ENABLED
                  </Stack>
                </LabelChip>
              ) : (
                <Stack className={css.category} dense>
                  <PipelineIcon className={css.typeIcon} /> Pipeline
                </Stack>
              )}
            </Stack>
          )}
        </div>
      )}
      {!isNodeLoading && (
        <ListMenu
          isHorizontalDots
          listItems={category === 'ROUTE' ? ROUTE_OPTIONS : NODE_OPTIONS}
          onItemClick={menuId => actions(menuId, data.id, data.pipelineId)}
        />
      )}
    </motion.div>
  );
};
