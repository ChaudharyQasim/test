import { FC, useCallback, useEffect, useMemo, useState } from 'react';
import classNames from 'classnames';
import { Chip } from 'shared/elements/Chip';
import { Count } from 'reaviz';
import { MotionGroup, Stack } from 'reablocks';
import { Portal, useId } from 'rdk';
import { PipelineNode, PipelineNodeData } from './PipelineNode';
import { PipelineEdge, PipelineEdgeData } from './PipelineEdge';
import { useXarrow } from 'react-xarrows';
import css from './PipelineCanvas.module.css';

export interface PipelineCanvasProps {
  nodes?: PipelineNodeData[];
  edges?: PipelineEdgeData[];
  disabled?: boolean;
  canvasClassName?: string;
  actions?: (menuId: number, id: string, pipelineId: string) => void;
  onAddConnection?: (sourceId: string, destinationId: string) => void;
}

export const PipelineCanvas: FC<PipelineCanvasProps> = ({
  nodes = [],
  edges = [],
  disabled,
  canvasClassName,
  actions,
  onAddConnection
}) => {
  const id = useId();
  const updateXarrow = useXarrow();
  const [activeNode, setActiveNode] = useState<PipelineNodeData | null>(null);
  const [hoveredNode, setHoveredNode] = useState<PipelineNodeData | null>(null);
  const [[top, left], setPosition] = useState<[number, number]>([0, 0]);
  const [invalid, setInvalid] = useState<boolean>(false);

  const [sources, routes, destinations] = useMemo(
    () => [
      nodes?.filter(node => node.category === 'SOURCE'),
      nodes?.filter(node => node.category === 'ROUTE'),
      nodes?.filter(node => node.category === 'DESTINATION')
    ],
    [nodes]
  );

  useEffect(() => {
    updateXarrow();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nodes, edges]);

  const onPortDrag = useCallback(state => {
    const [nextX, nextY] = state.movement;
    const [initialX, initialY] = state.initial;
    setPosition([initialY + nextY, initialX + nextX]);
    updateXarrow();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const highlightedEdges = useMemo(() => {
    if (!hoveredNode) {
      return [];
    }

    // get all routes types attached to hovered node
    const highlightedRoutes: string[] = [];
    switch (hoveredNode.category) {
      case 'ROUTE':
        highlightedRoutes.push(hoveredNode.id);
        break;
      case 'SOURCE':
        edges.forEach(edge => {
          if (edge.start === hoveredNode.id) {
            highlightedRoutes.push(edge.end);
          }
        });
        break;
      case 'DESTINATION':
        edges.forEach(edge => {
          if (edge.end === hoveredNode.id) {
            highlightedRoutes.push(edge.start);
          }
        });
        break;
      default:
        break;
    }

    // get all edges connected to highlighted routes
    const edgesToHighlight: PipelineEdgeData[] = [];
    edges.forEach(edge => {
      if (
        highlightedRoutes.includes(edge.start) ||
        highlightedRoutes.includes(edge.end)
      ) {
        edgesToHighlight.push(edge);
      }
    });

    return edgesToHighlight;
  }, [edges, hoveredNode]);

  const highlightCurrentNode = (id: string) =>
    !activeNode &&
    !!highlightedEdges.find(
      routeToDestination =>
        routeToDestination.start === id || routeToDestination.end === id
    );

  useEffect(() => {
    const isValid =
      hoveredNode?.category === 'SOURCE' ||
      hoveredNode?.category === 'ROUTE' ||
      (hoveredNode?.category === 'DESTINATION' &&
        !!highlightedEdges.find(edge => edge?.start === activeNode?.id));
    setInvalid(isValid);
  }, [hoveredNode, activeNode, highlightedEdges]);

  return (
    <>
      <div className={css.headers}>
        <header className={css.colHeader}>
          <Stack>
            Sources{' '}
            <Chip variant="outline" color="secondary">
              <Count to={sources?.length} />
            </Chip>
          </Stack>
        </header>
        <header className={css.colHeader}>
          <Stack>
            Routes{' '}
            <Chip variant="outline" color="secondary">
              <Count to={routes?.length} />
            </Chip>
          </Stack>
        </header>
        <header className={css.colHeader}>
          <Stack>
            Destinations{' '}
            <Chip variant="outline" color="secondary">
              <Count to={destinations?.length} />
            </Chip>
          </Stack>
        </header>
      </div>
      <div className={classNames(css.container, canvasClassName)}>
        <div
          className={classNames(css.col, css.sourceCol)}
          onScroll={() => updateXarrow()}
        >
          <MotionGroup className={css.cards}>
            {sources?.map(source => (
              <PipelineNode
                key={source.id}
                id={id}
                data={source}
                disabled={disabled}
                endPortVisible
                active={!activeNode && hoveredNode?.id === source.id}
                invalid={activeNode && hoveredNode?.id === source.id}
                onDragStart={() => setActiveNode(source)}
                onDrag={onPortDrag}
                highlight={highlightCurrentNode(source?.id)}
                onDragEnd={() => {
                  if (!invalid && activeNode && hoveredNode) {
                    onAddConnection(activeNode.id, hoveredNode.id);
                  }
                  setActiveNode(null);
                }}
                onPointerOver={() => setHoveredNode(source)}
                onPointerOut={() => setHoveredNode(null)}
                actions={actions}
              />
            ))}
          </MotionGroup>
        </div>
        <div className={classNames(css.col, css.routeCol)}>
          <MotionGroup className={css.cards}>
            {routes?.map(route => (
              <PipelineNode
                id={id}
                key={route.id}
                disabled={disabled}
                data={route}
                startPortVisible
                endPortVisible
                active={!activeNode && hoveredNode?.id === route.id}
                invalid={activeNode && hoveredNode?.id === route.id}
                highlight={highlightCurrentNode(route?.id)}
                onPointerOver={() => setHoveredNode(route)}
                onPointerOut={() => setHoveredNode(null)}
                actions={actions}
              />
            ))}
          </MotionGroup>
        </div>
        <div className={classNames(css.col, css.destCol)}>
          <MotionGroup className={css.cards}>
            {destinations?.map(destination => (
              <PipelineNode
                key={destination.id}
                id={id}
                disabled={disabled}
                startPortVisible
                data={destination}
                highlight={highlightCurrentNode(destination?.id)}
                active={hoveredNode?.id === destination?.id && !invalid}
                invalid={hoveredNode?.id === destination?.id && invalid}
                onPointerOver={() => setHoveredNode(destination)}
                onPointerOut={() => setHoveredNode(null)}
                onDrag={onPortDrag}
                actions={actions}
              />
            ))}
          </MotionGroup>
        </div>
        {edges.map(edge => {
          const highlightEdge =
            !activeNode &&
            !!highlightedEdges.find(
              edgeToHighlight =>
                edgeToHighlight.start === edge.start &&
                edgeToHighlight.end === edge.end
            );

          return (
            <PipelineEdge
              key={edge.id}
              id={id}
              {...edge}
              start={`${id}-${edge.start}-start`}
              end={`${id}-${edge.end}-end`}
              color={highlightEdge ? 'var(--primary-background)' : undefined}
            />
          );
        })}
        {activeNode && (
          <PipelineEdge
            id={id}
            start={`${id}-${activeNode.id}-start`}
            end={`${id}-dragger`}
            dashness
            color="var(--primary-background)"
            showHead
          />
        )}
        <Portal>
          <div
            id={`${id}-dragger`}
            className={css.dragger}
            style={{
              top,
              left
            }}
          />
        </Portal>
      </div>
    </>
  );
};
