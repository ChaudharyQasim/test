import { FC, useState } from 'react';
import classNames from 'classnames';
import { motion } from 'framer-motion';
import { useCursor, useUserSelect } from 'rdk';
import { useDrag } from '@use-gesture/react';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import css from './PipelineCanvas.module.css';

export interface PipelinePortProps {
  id: string;
  direction: 'start' | 'end';
  active?: boolean;
  disabled?: boolean;
  sourceConnection?: boolean;
  onDragStart?: (state: any) => void;
  onDrag?: (state: any) => void;
  onDragEnd?: (state: any) => void;
}

export const PipelinePort: FC<PipelinePortProps> = ({
  id,
  direction,
  active,
  disabled,
  sourceConnection,
  onDragStart,
  onDrag,
  onDragEnd
}) => {
  const [dragging, setDragging] = useState<boolean>(false);

  useUserSelect(dragging);
  useCursor(dragging, 'crosshair');

  const bindings = useDrag(
    state => {
      if (direction === 'start') {
        return;
      }

      if (state.first) {
        setDragging(true);
        onDragStart?.(state);
      }

      onDrag?.(state);

      if (state.last) {
        onDragEnd?.(state);
        setDragging(false);
      }
    },
    {
      enabled: !disabled,
      pointer: {
        capture: false
      }
    }
  );

  return (
    <motion.div
      id={id}
      {...(bindings() as any)}
      animate={{
        scale: active ? 2.1 : 1
      }}
      className={classNames({
        [css.active]: active,
        [css.disabled]: disabled,
        [css.portStart]: direction === 'start',
        [css.portEnd]: direction === 'end',
        [css.sourceNodePort]: active && sourceConnection
      })}
    >
      {active && sourceConnection ? <PlusIcon /> : null}
    </motion.div>
  );
};
