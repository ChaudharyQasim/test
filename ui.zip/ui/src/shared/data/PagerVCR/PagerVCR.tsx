import { FC } from 'react';
import { PagerProps, Button } from 'reablocks';
import { Tooltip } from 'shared/layers/Tooltip';

import { ReactComponent as BackwardArrow } from 'assets/icons/Backward.svg'
import { ReactComponent as RewindArrow } from 'assets/icons/Rewind.svg'
import { ReactComponent as FastForwardArrow } from 'assets/icons/fastForward.svg'
import { ReactComponent as ForwardArrow } from 'assets/icons/Forward.svg'
import { ReactComponent as PlayArrow } from 'assets/icons/Vector.svg'
import { ReactComponent as PauseArrow } from 'assets/icons/pause.svg'
import css from './PagerVCR.module.css';

interface PagerPropsExtended extends PagerProps {
  handleLiveDataClick?: React.MouseEventHandler<HTMLButtonElement>;
  isLive?: boolean;
  startLive?: boolean;
}

export const PagerVCR: FC<PagerPropsExtended> = ({ page, total, size, onPageChange, handleLiveDataClick, isLive, startLive }) => {
  const isFirstPage = page === 0;
  const lastPage = Math.ceil(total / size) - 1;

  const isLastPage = lastPage === page;

  const goToFirstPage = () => {
    if (!isFirstPage) {
      onPageChange(0);
    }
  };

  const goToPreviousPage = () => {
    if (!isFirstPage) {
      onPageChange(page - 1);
    }
  };

  const goToNextPage = () => {
    if (!isLastPage) {
      onPageChange(page + 1);
    }
  };

  const goToLastPage = () => {
    if (!isLastPage) {
      onPageChange(lastPage);
    }
  };

  return (
    <div className={css.paginationContainer}>
      <div className={css.buttonGroup}>
        <Tooltip content='First Page'>
          <Button onClick={goToFirstPage} disabled={isFirstPage} variant='outline'>
            <BackwardArrow />
          </Button>
        </Tooltip>
      </div>
      <div className={css.buttonGroup}>
        <Tooltip content='Previous Page'>
          <Button onClick={goToPreviousPage} disabled={isFirstPage} variant='outline'>
            <RewindArrow />
          </Button>
        </Tooltip>
      </div>
      <div className={css.buttonGroup}>
        <Tooltip content={
          startLive ? 'Pause RealTime Data' : 'RealTime Data'
        }>
          <Button onClick={handleLiveDataClick} disabled={!isLive} variant='outline'>
            {
              startLive ? <PauseArrow /> : <PlayArrow />
            }
          </Button>
        </Tooltip>
      </div>
      <div className={css.buttonGroup}>
        <Tooltip content='Next Page'>
          <Button onClick={goToNextPage} disabled={isLastPage} variant='outline'>
            <FastForwardArrow />
          </Button>
        </Tooltip>
      </div>
      <div className={css.buttonGroup}>
        <Tooltip content='Last Page'>
          <Button onClick={goToLastPage} disabled={isLastPage} variant='outline'>
            <ForwardArrow />
          </Button>
        </Tooltip>
      </div>
    </div>

  );
};
