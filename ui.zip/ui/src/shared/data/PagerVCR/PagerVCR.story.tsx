import { useState } from 'react';
import { PagerVCR } from './PagerVCR';

export default {
  title: 'Components/Data/PagerVCR',
  component: PagerVCR
};

export const Basic = () => {
  const [page, setPage] = useState<number>(0);

  return (
    <div style={{ width: 600 }}>
      <PagerVCR page={page} size={10} total={100} onPageChange={setPage} displayMode="items"/>
    </div>
  );
};
