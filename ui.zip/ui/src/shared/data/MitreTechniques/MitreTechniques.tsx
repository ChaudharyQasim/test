import { FC, useCallback, useEffect, useState } from 'react';
import classNames from 'classnames';
import {
  Block,
  Button,
  List,
  ListItem,
  Select,
  SelectOption,
  SmallHeading,
  Stack,
  Text,
  Toggle,
  Tree,
  TreeNode
} from 'reablocks';

// CSS
import css from './MitreTechniques.module.css';

// Shared
import { SearchInput } from 'shared/form/Input';
import { Checkbox } from 'shared/form/Checkbox';

// Constants
import { MITRE_PLATFORMS_FILTER } from 'shared/utils/Constants';

// Types
import { MitreTechniqueType } from './MitreTechniques.types';

type MitreTechniquesProps = {
  reset?: boolean;
  isMenu?: boolean;
  selectedTechniques?: MitreTechniqueType[];
  mitreTechniques: (type: string) => any[];
  onChange?: (selectedInsideTechniques: MitreTechniqueType[]) => void;
};

export const MitreTechniques: FC<MitreTechniquesProps> = ({
  mitreTechniques,
  onChange,
  isMenu,
  selectedTechniques,
  reset
}) => {
  const [showSubgroups, setShowSubgroups] = useState<boolean>(true);
  const [selectedInsideTechniques, setSelectedInsideTechniques] = useState<
    MitreTechniqueType[]
  >(selectedTechniques || []);
  const [searchTechnique, setSearchTechnique] = useState<string>('');
  const [selectedPlatform, setSelectedPlatform] = useState<string>('');

  const [toggleSelectedTechniques, setToggleSelectedTechniques] =
    useState<boolean>(false);
  const [savePreviousTechniques, setSavePreviousTechniques] = useState<
    MitreTechniqueType[]
  >([]);
  const [selectedTechniqueFilter, setSelectedTechniqueFilter] =
    useState<string>('enterprise');
  const [onHoverTechnique, setOnHoverTechnique] =
    useState<MitreTechniqueType>(null);
  const [techniques, setTechniques] = useState<MitreTechniqueType[]>(() =>
    mitreTechniques('enterprise')
  );

  /**
   * @description This function resets the techniques state to its initial value.
   */
  const resetTechniques = useCallback(() => {
    if (onChange) {
      onChange([]);
    }

    setSelectedInsideTechniques([]);
    setSelectedPlatform('');
    setSelectedTechniqueFilter('enterprise');
    setTechniques(mitreTechniques('enterprise'));
  }, [mitreTechniques, onChange]);

  /**
   *  @description This function is used to filter the techniques by type (enterprise | mobile | ics).
   */
  function onFilterTechniques(type: string) {
    const updatedTechniques = mitreTechniques(type).map(
      checkSelectedTechniques
    );

    setSearchTechnique('');
    setSelectedTechniqueFilter(type);
    setTechniques(updatedTechniques);
  }

  /**
   *  @description This function is used to filter the techniques by platform. (windows | linux | mac | etc).
   */
  function filterByPlatform(platform: string) {
    const updatedTechniques = mitreTechniques(selectedTechniqueFilter).map(
      checkSelectedTechniques
    );
    if (!platform) {
      setTechniques(updatedTechniques);
      setSelectedPlatform('');
      return;
    }
    const filteredTechniques = updatedTechniques.filter(technique => {
      return technique.platforms.some(
        (techniquePlatform: string) => techniquePlatform === platform
      );
    });
    setSelectedPlatform(platform);
    setTechniques(filteredTechniques);
  }

  /**
   * @description This function is used to check if the technique is selected
   */
  function checkSelectedTechniques(technique: MitreTechniqueType) {
    // Check if the technique has any subgroups.
    if (technique.subgroups.length > 0) {
      // Map over the subgroups and check if they are selected.
      technique.subgroups = technique.subgroups.map(subgroup => ({
        ...subgroup,
        checked: selectedInsideTechniques.some(
          item => item.id === technique.id && item.sub_id === subgroup.sub_id
        )
      }));
    } else {
      // Check if the technique is selected.
      technique.checked = selectedInsideTechniques.some(
        item => item.id === technique.id && item.sub_id === ''
      );
    }

    // Return the updated technique object.
    return technique;
  }

  function onSearchTechnique(event: React.ChangeEvent<HTMLInputElement>) {
    const searchValue = event.target.value;
    const updatedTechniques = mitreTechniques(selectedTechniqueFilter)
      .filter(technique => {
        return (
          technique.name.toLowerCase().includes(searchValue.toLowerCase()) ||
          technique.id.toLowerCase().includes(searchValue.toLowerCase())
        );
      })
      .map(checkSelectedTechniques);

    setSearchTechnique(searchValue);
    setTechniques(updatedTechniques);
  }

  /**
   * @description This function is used to update the main technique or
   * the subgroup that was checked
   */
  function updateTechniquesSelected(mainTechnique: MitreTechniqueType) {
    return techniques.map(technique => {
      // This updates only the subgroup that was checked
      // else it updates the main technique
      if (mainTechnique.sub_id !== '' && technique.id === mainTechnique.id) {
        const findSubgroupIndex = technique.subgroups.findIndex(
          subgroup => subgroup.sub_id === mainTechnique.sub_id
        );
        technique.subgroups[findSubgroupIndex] = mainTechnique;
      } else if (
        mainTechnique.sub_id === '' &&
        technique.id === mainTechnique.id
      ) {
        return mainTechnique;
      }
      return technique;
    });
  }

  /**
   * @description This function is used to handle the selection of the techniques
   */
  function onHandleTechniqueSelection(
    checked: boolean,
    selectedTechnique: MitreTechniqueType
  ) {
    const mainTechnique = { ...selectedTechnique };
    mainTechnique.checked = checked;

    // If the main technique is checked, check/uncheck all subgroups
    if (mainTechnique.sub_id === '' && mainTechnique.subgroups.length > 0) {
      mainTechnique.subgroups = mainTechnique.subgroups.map(subgroup => ({
        ...subgroup,
        checked
      }));
    }

    const updatedTechniques = updateTechniquesSelected(mainTechnique);

    setSelectedInsideTechniques(prevState => {
      // If the main technique is checked, select/unselect all subgroups
      if (checked && mainTechnique.sub_id === '') {
        return [...prevState, mainTechnique, ...mainTechnique.subgroups];
      }
      // If the sub_id is not empty, add the subgroup to the selected items
      if (checked && mainTechnique.sub_id !== '') {
        return [...prevState, mainTechnique];
      }
      // If the sub_id is empty, remove the main technique and all subgroups
      // else remove only the subgroup
      return prevState.filter(item =>
        mainTechnique.sub_id === ''
          ? item.id !== mainTechnique.id
          : item.sub_id !== mainTechnique.sub_id
      );
    });
    setTechniques(updatedTechniques);
  }

  /**
   * @description This function is used to show/hide the selected techniques
   */
  function onShowHideSelectedTechniques() {
    setSavePreviousTechniques(techniques);
    let updatedTechniques = [];

    if (toggleSelectedTechniques) {
      // go back to the original state with the checked techniques
      updatedTechniques = savePreviousTechniques;
    } else {
      updatedTechniques = techniques.filter(
        technique =>
          technique.checked || technique.subgroups.some(sub => sub.checked)
      );
    }

    setToggleSelectedTechniques(!toggleSelectedTechniques);
    setTechniques(updatedTechniques);
  }

  /**
   * @description This function renders the subgroups of each technique if it has any.
   * also it has a recursive call to render the subgroups of the subgroups.
   */
  function renderSubgroups(subgroups: MitreTechniqueType[]) {
    if (!subgroups) {
      return null;
    }

    return subgroups.map((subgroup, index: number) => (
      <TreeNode
        key={subgroup.id + index}
        label={
          <Stack>
            <Checkbox
              containerClassName={css.checkboxContainer}
              checked={subgroup.checked}
              onChange={value => onHandleTechniqueSelection(value, subgroup)}
            />
            {subgroup.name} [{subgroup.sub_id}]
          </Stack>
        }
        expanded={subgroup?.subgroups?.length > 0}
      >
        {subgroup.subgroups && renderSubgroups(subgroup.subgroups)}
      </TreeNode>
    ));
  }

  function variantTechniqueButton(type: string) {
    return selectedTechniqueFilter === type ? 'filled' : 'outline';
  }
  function colorTechniqueButton(type: string) {
    return selectedTechniqueFilter === type ? 'primary' : 'default';
  }

  useEffect(() => {
    // This checks the selected techniques when the component is mounted
    if (selectedTechniques.length > 0) {
      const updatedTechniques = mitreTechniques(selectedTechniqueFilter).map(
        checkSelectedTechniques
      );
      setTechniques(updatedTechniques);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    // The selectedInsideTechniques state is updated when the selectedTechniques prop changes
    // the comparision is to avoid an infinite loop
    if (
      onChange &&
      selectedInsideTechniques.length !== selectedTechniques.length
    ) {
      onChange(selectedInsideTechniques);
    }
  }, [selectedInsideTechniques, onChange, selectedTechniques]);

  useEffect(() => {
    if (reset) {
      resetTechniques();
    }
  }, [reset, resetTechniques]);

  return (
    <Stack alignItems="start">
      <section
        className={classNames(css.techniquesSection, {
          [css.fullwidth]: isMenu
        })}
      >
        <header>
          <Block>
            <Stack>
              <Button
                fullWidth
                size="small"
                variant={variantTechniqueButton('enterprise')}
                color={colorTechniqueButton('enterprise')}
                onClick={() => onFilterTechniques('enterprise')}
              >
                Enterprise
              </Button>
              <Button
                fullWidth
                size="small"
                variant={variantTechniqueButton('mobile')}
                color={colorTechniqueButton('mobile')}
                onClick={() => onFilterTechniques('mobile')}
              >
                Mobile
              </Button>
              <Button
                fullWidth
                size="small"
                variant={variantTechniqueButton('ics')}
                color={colorTechniqueButton('ics')}
                onClick={() => onFilterTechniques('ics')}
              >
                ICS
              </Button>
            </Stack>
          </Block>
          <Block>
            <Stack>
              <Select
                value={selectedPlatform}
                placeholder="Select an platform"
                onChange={filterByPlatform}
              >
                {MITRE_PLATFORMS_FILTER[selectedTechniqueFilter].map(
                  ({ value, label }: { value: string; label: string }) => (
                    <SelectOption key={value} value={value}>
                      {label}
                    </SelectOption>
                  )
                )}
              </Select>
              <SearchInput
                fullWidth
                value={searchTechnique}
                containerClassname={css.search}
                placeholder="Find Technique..."
                onChange={onSearchTechnique}
              />
            </Stack>
          </Block>
          <Block>
            <Stack justifyContent="spaceBetween">
              <Stack>
                <Toggle
                  size="small"
                  checked={showSubgroups}
                  onChange={value => setShowSubgroups(value)}
                />
                <Text>Show Techniques</Text>
              </Stack>
              <Button
                variant="text"
                disableMargins
                disablePadding
                className={css.showFilterButton}
                onClick={onShowHideSelectedTechniques}
              >
                <Text className={css.text}>
                  Show{' '}
                  {!toggleSelectedTechniques
                    ? `selected (${selectedInsideTechniques.length})`
                    : 'all'}
                </Text>
              </Button>
            </Stack>
          </Block>
        </header>
        <Tree className={css.mitreTree}>
          {techniques.map(group => {
            const hasSomeSubgroupsChecked =
              group.subgroups &&
              group.subgroups.some(subgroup => subgroup.checked);
            return (
              <span
                onMouseEnter={() => setOnHoverTechnique(group)}
                className={css.mainTechnique}
                key={group.id}
              >
                <TreeNode
                  expanded={group.checked && showSubgroups}
                  label={
                    <Stack inline>
                      <Checkbox
                        containerClassName={css.checkboxContainer}
                        checked={group.checked || hasSomeSubgroupsChecked}
                        intermediate={
                          hasSomeSubgroupsChecked &&
                          !group.subgroups.every(subgroup => subgroup.checked)
                        }
                        onChange={value =>
                          onHandleTechniqueSelection(value, group)
                        }
                      />
                      <Text>
                        {group.name} [{group.id}]
                      </Text>
                    </Stack>
                  }
                >
                  {showSubgroups && renderSubgroups(group.subgroups)}
                </TreeNode>
              </span>
            );
          })}
        </Tree>
      </section>
      {!isMenu && (
        <section className={css.techniqueDescription}>
          {onHoverTechnique && (
            <Stack direction="column" alignItems="start">
              <SmallHeading>
                {onHoverTechnique.name} [{onHoverTechnique.id}]
              </SmallHeading>
              <Text className={css.text}>{onHoverTechnique.description}</Text>
              {onHoverTechnique.subgroups.length > 0 && (
                <List className={css.list}>
                  <SmallHeading>Sub-Techniques</SmallHeading>
                  {onHoverTechnique.subgroups.map(subgroup => (
                    <ListItem
                      disablePadding
                      className={css.item}
                      key={subgroup.sub_id}
                    >
                      {subgroup.name} [{subgroup.sub_id}]
                    </ListItem>
                  ))}
                </List>
              )}
              <Stack direction="column" alignItems="start">
                {onHoverTechnique.platforms.length > 0 && (
                  <List className={css.list}>
                    <SmallHeading>Platforms</SmallHeading>
                    {onHoverTechnique.platforms.map(platform => (
                      <ListItem
                        disablePadding
                        className={css.item}
                        key={platform}
                      >
                        {platform}
                      </ListItem>
                    ))}
                  </List>
                )}
              </Stack>
            </Stack>
          )}
        </section>
      )}
    </Stack>
  );
};
