export type MitreTechniqueType = {
  id: string;
  name: string;
  sub_id?: string;
  sub_name?: string;
  description?: string;
  subgroups?: MitreTechniqueType[];
  checked?: boolean;
  platforms?: string[];
};

export type TechniquesType = {
  enterprise: MitreTechniqueType[];
  ics: MitreTechniqueType[];
  mobile: MitreTechniqueType[];
};
