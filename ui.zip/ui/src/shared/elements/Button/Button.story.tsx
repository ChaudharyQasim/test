import { Button, Stack } from 'reablocks';

export default {
  title: 'Elements/Button',
  component: Button
};

export const Variants = () => (
  <Stack>
    <Button color="primary">Primary</Button>
    <Button variant="outline">Secondary</Button>
    <Button color="primary" variant="text">
      Text
    </Button>
  </Stack>
);

export const Sizes = () => (
  <Stack>
    <Button color="primary" size="small">
      Small
    </Button>
    <Button color="primary">Large</Button>
  </Stack>
);

export const Disabled = () => (
  <Stack>
    <Button color="primary" disabled>
      Primary
    </Button>
    <Button variant="outline" disabled>
      Secondary
    </Button>
  </Stack>
);
