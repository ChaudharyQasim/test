import defaultBg1 from 'assets/images/bg_1.png';
import defaultBg2 from 'assets/images/bg_2.png';
import defaultBg3 from 'assets/images/bg_3.png';
import defaultBg4 from 'assets/images/bg_4.png';
import defaultBg5 from 'assets/images/bg_5.png';
import defaultBg6 from 'assets/images/bg_6.png';
import defaultBg7 from 'assets/images/bg_7.png';

export const getRandomBackground = (uniqueId: number) => {
  const backgroundIdx = uniqueId ? (uniqueId % 7) + 1 : 0;

  let selectedImage;
  switch (backgroundIdx) {
    case 1:
      selectedImage = defaultBg1;
      break;
    case 2:
      selectedImage = defaultBg2;
      break;
    case 3:
      selectedImage = defaultBg3;
      break;
    case 4:
      selectedImage = defaultBg4;
      break;
    case 5:
      selectedImage = defaultBg5;
      break;
    case 6:
      selectedImage = defaultBg6;
      break;
    case 7:
      selectedImage = defaultBg7;
      break;
    default:
      selectedImage = defaultBg1;
  }
  return selectedImage;
};
