import { InitialsAvatar } from './';

export default {
  title: 'Elements/InitialsAvatar',
  component: InitialsAvatar
};

export const UserDefaultImage = () => (
  <InitialsAvatar name="John Doe" size={100} />
);

export const OrganizationDefaultImage = () => (
  <InitialsAvatar orgName="My Organization" size={100} />
);
