import { FC } from 'react';
import { Avatar } from 'reablocks';
import classNames from 'classnames';
import getInitials from 'name-initials';
import { getRandomBackground } from './utils';

import css from './InitialsAvatar.module.css';

interface InitialsAvatarProps {
  name?: string;
  orgName?: string;
  id?: number;
  src?: string;
  size: number;
  rounded?: boolean;
}

export const InitialsAvatar: FC<InitialsAvatarProps> = ({
  name,
  orgName,
  id,
  src,
  size,
  rounded = false
}) => {
  const initialsFontSize =
    name || orgName
      ? orgName || getInitials(name).length === 1
        ? size * 0.8
        : size * 0.5
      : 0;

  const imageSource = src ?? getRandomBackground(id);

  return src ? (
    <Avatar
      className={css.avatarBorder}
      rounded={rounded}
      size={size}
      src={imageSource}
    />
  ) : (
    <div
      className={css.container}
      style={{ width: `${size}px`, height: `${size}px` }}
    >
      <Avatar
        className={css.avatarBorder}
        rounded={rounded}
        size={size}
        src={imageSource}
      />
      {name || orgName ? (
        <span
          className={css.initial}
          style={{ fontSize: `${initialsFontSize}px` }}
        >
          {orgName ? getInitials(orgName)[0] : getInitials(name)}
        </span>
      ) : null}
    </div>
  );
};
