import { Button } from 'reablocks';
import { EmptyState } from './EmptyState';

import { ReactComponent as Illustration } from 'assets/illustrations/empty-list.svg';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';

export default {
  title: 'Layout/EmptyState',
  component: EmptyState
};

export const Simple = () => (
  <EmptyState
    illustration={<Illustration />}
    title="No rules under development"
    subtitle="Lorem ipsum dolor sit amet, consectetur adipiscing elit"
    actions={
      <Button color="primary" onClick={() => console.log('click')}>
        <PlusIcon />
        New Rule
      </Button>
    }
  />
);
