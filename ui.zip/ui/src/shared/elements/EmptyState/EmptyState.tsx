import { FC, ReactElement, ReactNode } from 'react';
import {
  MotionGroup,
  MotionItem,
  SmallHeading,
  Stack,
  Text,
  VerticalSpacer
} from 'reablocks';
import css from './EmptyState.module.css';

interface EmptyStateProps {
  illustration: ReactElement;
  title: string;
  subtitle?: string;
  body?: ReactNode;
  actions?: ReactNode;
}

export const EmptyState: FC<EmptyStateProps> = ({
  illustration,
  title,
  subtitle,
  body,
  actions
}) => (
  <MotionGroup className={css.empty}>
    <MotionItem>
      <Stack direction="column">
        {illustration}
        <SmallHeading>{title}</SmallHeading>
        {subtitle && <Text className={css.caption}>{subtitle}</Text>}
        {body}
        {actions}
        <VerticalSpacer space="xxl" />
      </Stack>
    </MotionItem>
  </MotionGroup>
);
