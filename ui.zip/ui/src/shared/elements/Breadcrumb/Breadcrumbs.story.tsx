import { Breadcrumb, BreadcrumbItem } from './';

export default {
  title: 'Elements/Breadcrumb',
  component: Breadcrumb
};

export const Simple = () => (
  <Breadcrumb>
    <BreadcrumbItem href="/">Marketplace</BreadcrumbItem>
    <BreadcrumbItem>Palo Alto Networks</BreadcrumbItem>
  </Breadcrumb>
);
