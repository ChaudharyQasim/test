import { FC, PropsWithChildren } from 'react';
import classNames from 'classnames';
import { PrimaryHeading, Stack } from 'reablocks';
import css from './Breadcrumb.module.css';

interface BreadcrumbProps extends PropsWithChildren {
  className?: string;
}

export const Breadcrumb: FC<BreadcrumbProps> = ({ className, children }) => (
  <nav aria-label="breadcrumb">
    <PrimaryHeading>
      <Stack className={classNames(css.breadcrumb, className)}>
        {children}
      </Stack>
    </PrimaryHeading>
  </nav>
);
