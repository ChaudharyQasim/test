import { FC, PropsWithChildren } from 'react';

interface BreadcrumbItemProps extends PropsWithChildren {
  className?: string;
  href?: string;
}

export const BreadcrumbItem: FC<BreadcrumbItemProps> = ({
  className,
  href,
  children
}) => (
  <>
    {href ? (
      <a href={href} className={className}>
        {children}
      </a>
    ) : (
      <span>{children}</span>
    )}
  </>
);
