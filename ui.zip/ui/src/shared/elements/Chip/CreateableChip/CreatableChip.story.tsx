import { useState } from 'react';
import { Stack } from 'reablocks';
import { CreatableChip } from './CreatableChip';
import { Chip } from '../Chip';

export default {
  title: 'Layout/Chip/CreatableChip',
  component: CreatableChip
};

export const Simple = () => {
  const [chips, setChips] = useState<string[]>(['hello']);

  return (
    <Stack>
      {chips.map(chip => (
        <Chip key={chip} variant="outline">
          {chip}
        </Chip>
      ))}
      <CreatableChip onCreate={value => setChips([...chips, value])} />
    </Stack>
  );
};
