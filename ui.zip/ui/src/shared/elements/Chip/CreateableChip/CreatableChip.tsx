import { ChangeEvent, FC, KeyboardEvent, useRef, useState } from 'react';
import classNames from 'classnames';
import {
  Button,
  Card,
  Chip,
  InlineInput,
  List,
  ListItem,
  Stack
} from 'reablocks';
import css from './CreatableChip.module.css';

import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import { Menu } from 'shared/layers/Menu';

interface CreatableChipProps {
  placeholder?: string;
  onCreate: (value: string) => void;
  tags?: string[];
}

export const CreatableChip: FC<CreatableChipProps> = ({
  placeholder = 'Add a tag...',
  onCreate,
  tags
}) => {
  const [editing, setEditing] = useState<boolean>(false);
  const [text, setText] = useState<string>('');
  const [showMitreTechniques, setShowMitreTechniques] = useState<string>('');
  const instanceMenuRef = useRef(null);

  const onCancel = () => {
    setText('');
    setEditing(false);
  };

  const onButtonClick = () => {
    if (editing) {
      onCancel();
    } else {
      setEditing(true);
    }
  };

  const onKeyDown = (event: KeyboardEvent) => {
    if (event.key === 'Enter') {
      onCreate(text);
      setText('');
      setShowMitreTechniques('');
    } else if (event.key === 'Escape') {
      onCancel();
    }
  };

  return (
    <Chip variant="outline" color={editing ? 'primary' : 'default'}>
      <Stack>
        {editing && (
          <Button
            variant="text"
            ref={instanceMenuRef}
            disableAnimation
            disableMargins
            disablePadding
          >
            <InlineInput
              className={classNames(css.container, {
                [css.collapsed]: !editing
              })}
              inputClassName={css.input}
              value={text}
              placeholder={placeholder}
              onKeyDown={onKeyDown}
              onChange={(event: ChangeEvent<HTMLInputElement>) => {
                const value = event.target.value;
                setText(value);
                setShowMitreTechniques(value);
              }}
              autoFocus
              placeholderIsMinWidth
            />
          </Button>
        )}

        <Button
          variant="text"
          className={classNames(css.addBtn, { [css.editing]: editing })}
          onClick={onButtonClick}
          disableAnimation
          disableMargins
          disablePadding
        >
          <PlusIcon />
        </Button>
        {/* TODO: This can change once new design is available */}
        {tags && (
          <Menu
            reference={instanceMenuRef}
            placement="bottom-start"
            className={css.menu}
            open={Boolean(showMitreTechniques)}
            onClose={() => setShowMitreTechniques('')}
          >
            <Card className={css.card}>
              <List>
                {tags.map((tag, index) => (
                  <ListItem
                    key={index}
                    // start={<DeleteIcon />}
                    onClick={() => {
                      // setInstanceMenuOpen(false);
                      // onDeleteChange(row.id);
                      onCreate(tag);
                      setText('');
                      setShowMitreTechniques('');
                    }}
                  >
                    {tag}
                  </ListItem>
                ))}
              </List>
            </Card>
          </Menu>
        )}
      </Stack>
    </Chip>
  );
};
