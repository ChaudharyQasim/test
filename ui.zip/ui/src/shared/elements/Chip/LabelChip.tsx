import { FC, forwardRef, Ref } from 'react';
import classNames from 'classnames';
import { Chip, ChipProps, ChipRef } from 'reablocks';
import css from './LabelChip.module.css';

export const LabelChip: FC<ChipProps & ChipRef> = forwardRef(
  (
    { children, className, color = 'default', variant = 'filled', ...rest },
    ref: Ref<HTMLDivElement>
  ) => (
    <Chip
      ref={ref}
      className={classNames(css.chip, css[color], css[variant], className)}
      color={color}
      variant={variant}
      {...rest}
    >
      {children}
    </Chip>
  )
);
