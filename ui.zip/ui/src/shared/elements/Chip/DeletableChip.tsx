import { FC, forwardRef, Ref } from 'react';
import classNames from 'classnames';
import {
  DeletableChip as ReaDeletableChip,
  DeletableChipProps,
  ChipRef
} from 'reablocks';
import css from './DeletableChip.module.css';

import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';

export const DeletableChip: FC<DeletableChipProps & ChipRef> = forwardRef(
  (
    {
      children,
      className,
      color = 'default',
      variant = 'filled',
      deleteIcon = <CloseIcon />,
      ...rest
    },
    ref: Ref<HTMLDivElement>
  ) => (
    <ReaDeletableChip
      ref={ref}
      className={classNames(css.chip, css[color], css[variant], className)}
      color={color}
      variant={variant}
      deleteIcon={deleteIcon}
      {...rest}
    >
      {children}
    </ReaDeletableChip>
  )
);
