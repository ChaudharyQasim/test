import { FC, forwardRef, Ref } from 'react';
import classNames from 'classnames';
import { Chip as ReaChip, ChipProps, ChipRef } from 'reablocks';
import css from './Chip.module.css';

export const Chip: FC<ChipProps & ChipRef> = forwardRef(
  (
    { children, className, color = 'default', variant = 'filled', ...rest },
    ref: Ref<HTMLDivElement>
  ) => (
    <ReaChip
      ref={ref}
      className={classNames(css.chip, css[color], css[variant], className)}
      {...rest}
    >
      {children}
    </ReaChip>
  )
);
