import { Stack } from 'reablocks';
import { Chip } from './Chip';
import { DeletableChip } from './DeletableChip';
import { LabelChip } from './LabelChip';

import { ReactComponent as CheckIcon } from 'assets/icons/check.svg';

export default {
  title: 'Layout/Chip',
  component: Chip
};

export const Simple = () => (
  <Stack>
    <Chip variant="outline">Simple Chip</Chip>
    <Chip variant="outline" color="secondary">
      Secondary
    </Chip>
  </Stack>
);

export const LabelChips = () => (
  <Stack>
    <LabelChip variant="outline">SOURCE</LabelChip>
    <LabelChip variant="outline" color="secondary">
      <CheckIcon /> PASSTHROUGH ENABLED
    </LabelChip>
  </Stack>
);

export const Deletable = () => (
  <DeletableChip variant="outline">Simple Chip</DeletableChip>
);
