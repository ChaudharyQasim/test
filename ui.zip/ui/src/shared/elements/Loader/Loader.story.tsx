import { DotsLoader } from 'reablocks';
import { Loader } from './Loader';

export default {
  title: 'Elements/Loader',
  component: Loader
};

export const Dots = () => <DotsLoader />;

export const Logo = () => <Loader />;
