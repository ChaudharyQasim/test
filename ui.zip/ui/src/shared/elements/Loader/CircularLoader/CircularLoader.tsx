import { FC } from 'react';
import { motion } from 'framer-motion';
import { ReactComponent as CircularIcon } from 'assets/icons/circular-loader.svg';
import css from './CircularLoader.module.css';
import classNames from 'classnames';

interface LoaderProps {
  className?: string;
}

export const CircularLoader: FC<LoaderProps> = ({ className }) => (
  <motion.div
    className={classNames(css.loader, className)}
    initial={{ rotate: 0 }}
    animate={{ rotate: 360 }}
    transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
  >
    <CircularIcon />
  </motion.div>
);
