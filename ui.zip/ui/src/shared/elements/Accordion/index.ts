export { Accordion as default } from './Accordion';
