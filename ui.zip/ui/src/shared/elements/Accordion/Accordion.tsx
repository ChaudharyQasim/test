import { useLayoutEffect, useRef, useState, PointerEvent } from 'react';
import { useResizeObserver } from 'core/Hooks/useResizeObserver';
import classNames from 'classnames';
import css from './Accordion.module.css';

export type AccordionProps = {
  header: any;
  body: any;
  open?: boolean;
  name?: string;
  setOpen?: any;
  onToggle?: any;
  maxHeight?: number;
  className?: any;
  disabled?: boolean;
};

export const Accordion = ({
  header,
  body,
  onToggle,
  open,
  className,
  disabled
}: AccordionProps) => {
  const $header = useRef<HTMLElement | null>(null);
  const $body = useRef<HTMLDivElement | null>(null);
  const [headerHeight, setHeaderHeight] = useState<number>(0);
  const [bodyHeight, setBodyHeight] = useState<number>(0);
  const [initialized, setInitialized] = useState(false);

  useResizeObserver($body, ([width, height]) => {
    setBodyHeight(height);
  });
  useResizeObserver($header, ([width, height]) => {
    setHeaderHeight(height);
  });

  useLayoutEffect(() => {
    const header = $header.current.getBoundingClientRect();
    const body = $body.current.getBoundingClientRect();
    setHeaderHeight(header.height);
    setBodyHeight(body.height);
    setInitialized(true);
  }, []);

  function getMaxHeight() {
    if (!initialized) {
      return 'auto';
    }

    if (!open || disabled) {
      return `${headerHeight}px`;
    }

    if (open) {
      return `${headerHeight + bodyHeight}px`;
    }
  }

  return (
    <div
      className={classNames(css.accordion, className, disabled && css.disabled)}
      onTransitionEnd={e => e.stopPropagation()}
      style={{ maxHeight: getMaxHeight() }}
    >
      <header
        ref={$header}
        className={classNames(css.header, open && css.open)}
        onClick={(event: PointerEvent<HTMLElement>) => {
          event.stopPropagation();
          event.preventDefault();
          if (
            !disabled &&
            (event.nativeEvent?.target as HTMLElement)?.dataset?.collapse
          ) {
            onToggle?.();
          }
        }}
      >
        {header}
      </header>
      <div ref={$body} className={classNames(css.body, open && css.open)}>
        {body}
      </div>
    </div>
  );
};

Accordion.defaultProps = {
  open: true
};
