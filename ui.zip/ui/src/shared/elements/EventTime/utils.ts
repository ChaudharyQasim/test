import {
  subMinutes,
  subHours,
  subWeeks,
  subMonths,
  addDays,
  subDays
} from 'date-fns';

export const EVENT_TIME_TYPES = {
  RANGE: {
    label: 'Range',
    value: 'range'
  },
  RELATIVE: {
    label: 'Relative',
    value: 'relative'
  },
  REAL_TIME: {
    label: 'Real Time',
    value: 'realTime'
  }
};

export const TIME_UNITS = {
  MINUTES: {
    label: 'Minutes',
    value: 'minute'
  },
  HOURS: {
    label: 'Hours',
    value: 'hour'
  },
  DAYS: {
    label: 'Days',
    value: 'day'
  },
  WEEKS: {
    label: 'Weeks',
    value: 'week'
  },
  MONTHS: {
    label: 'Months',
    value: 'month'
  }
};

export interface FixedTime {
  unit: 'minute' | 'hour' | 'day' | 'week' | 'month';
  value: number;
}

export interface Time {
  type: 'range' | 'relative' | 'realTime';
  timestamp: [Date, Date] | FixedTime | null;
}

export const getRelativeTime = (time: FixedTime): Date => {
  const currentTime = new Date();
  const { unit, value } = time;
  if (unit === 'minute') {
    return subMinutes(currentTime, value);
  }
  if (unit === 'hour') {
    return subHours(currentTime, value);
  }
  if (unit === 'day') {
    return subDays(currentTime, value);
  }
  if (unit === 'week') {
    return subWeeks(currentTime, value);
  }
  if (unit === 'month') {
    return subMonths(currentTime, value);
  }
  return currentTime;
};

export const mockRangeTime = (currTime: Date): Time => ({
  type: 'range',
  timestamp: [currTime, addDays(currTime, 2)]
});

export const mockRelativeTime: Time = {
  type: 'relative',
  timestamp: {
    unit: 'week',
    value: 2
  }
};

export const mockRealTimeTime: Time = {
  type: 'realTime',
  timestamp: {
    unit: 'hour',
    value: 5
  }
};
