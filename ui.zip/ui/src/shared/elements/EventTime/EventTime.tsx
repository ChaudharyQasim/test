import { Input, Select, SelectOption, Stack, safeFormat } from 'reablocks';
import { Dispatch, FC, SetStateAction, useCallback, useEffect, useState } from 'react';
import {
  EVENT_TIME_TYPES,
  FixedTime,
  TIME_UNITS,
  Time,
  getRelativeTime
} from './utils';
import css from './EventTime.module.css';
import { ConditionDate } from 'shared/form/Input/ConditionDate';
import { DateRange } from '../EventCondition/utils';
import { calculateRealTimeRange } from 'shared/utils/Helper/timeHelper';
import { DATE_FORMAT_STREAM_VIEW } from 'shared/utils/Constants';
import { endOfDay, startOfDay } from 'date-fns';

interface EventTimeProps {
  onTimeChange: (timestamp: string | [string, string]) => void;
  className?: string;
  defaultTime?: Time;
  typeValue?: string;
  setTypeValue?: Dispatch<SetStateAction<string>>
}

const formatDateValue = (value: string) =>
  safeFormat(value, { format: DATE_FORMAT_STREAM_VIEW }).formatted;

const currentDate = new Date();

const dropdownOptions = () => Object.values(EVENT_TIME_TYPES).map(({ value, label }) => (
  <SelectOption key={value} value={value}>
    {label}
  </SelectOption>
));

export const EventTime: FC<EventTimeProps> = ({
  onTimeChange,
  className,
  defaultTime,
  typeValue,
  setTypeValue
}) => {

  const [timeRangeValue, setTimeRangeValue] = useState<DateRange>([
    (defaultTime?.timestamp as [Date, Date])?.[0] || currentDate,
    (defaultTime?.timestamp as [Date, Date])?.[1] || currentDate
  ]);

  const [fixedTimeValue, setFixedTimeValue] = useState<FixedTime>({
    unit: (defaultTime?.timestamp as FixedTime)?.unit || 'hour',
    value: (defaultTime?.timestamp as FixedTime)?.value || 1
  });

  const renderRangeType = useCallback(
    () => (
      <div className={css.dateInput}>
        <ConditionDate
          value={timeRangeValue}
          onChange={value => setTimeRangeValue(value as DateRange)}
          isRange
        />
      </div>
    ),
    [timeRangeValue]
  );

  useEffect(() => {
    if (typeValue === EVENT_TIME_TYPES.RANGE.value) {
      const startDate = startOfDay(timeRangeValue[0]);
      const endDate = endOfDay(timeRangeValue[1]);
      onTimeChange([
        formatDateValue(startDate.toLocaleString('en-US')),
        formatDateValue(endDate.toLocaleString('en-US'))
      ]);
    } else if (typeValue === EVENT_TIME_TYPES.RELATIVE.value) {
      onTimeChange(getRelativeTime(fixedTimeValue).toISOString());
    } else if (typeValue === EVENT_TIME_TYPES.REAL_TIME.value) {
      const { value, unit } = fixedTimeValue;
      onTimeChange(calculateRealTimeRange(unit, value));
    }
  }, [timeRangeValue, fixedTimeValue, typeValue, onTimeChange]);

  const renderRelativeOrRealTimeType = useCallback(
    (isRealTime: boolean = false) => {
      return (
        <Stack direction="row">
          <div className={css.text}>{isRealTime ? 'Now minus' : 'Past'}</div>
          <Input
            className={css.numberInput}
            type="number"
            min={0}
            value={fixedTimeValue.value}
            onValueChange={newFixedTime =>
              setFixedTimeValue({
                ...fixedTimeValue,
                value: parseInt(newFixedTime) || 0
              })
            }
          />
          <Select
            className={css.select}
            value={fixedTimeValue.unit}
            onChange={newTimeValue =>
              setFixedTimeValue({ ...fixedTimeValue, unit: newTimeValue })
            }
            createable={false}
            clearable={false}
            filterable={false}
          >
            {Object.values(TIME_UNITS).map(({ value, label }) => (
              <SelectOption key={value} value={value}>
                {label}
              </SelectOption>
            ))}
          </Select>
        </Stack>
      );
    },
    [fixedTimeValue]
  );
  return (
    <Stack direction="row" className={className}>
      <Select
        className={css.select}
        value={typeValue}
        onChange={setTypeValue}
        createable={false}
        clearable={false}
        filterable={false}
      >
        {dropdownOptions()}
      </Select>
      {typeValue === EVENT_TIME_TYPES.RANGE.value && renderRangeType()}
      {typeValue === EVENT_TIME_TYPES.RELATIVE.value &&
        renderRelativeOrRealTimeType(false)}
      {typeValue === EVENT_TIME_TYPES.REAL_TIME.value &&
        renderRelativeOrRealTimeType(true)}
    </Stack>
  );
};
