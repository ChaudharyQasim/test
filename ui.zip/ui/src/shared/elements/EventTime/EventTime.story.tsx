import { useState } from 'react';
import { EventTime } from './EventTime';
import {
  Time,
  mockRangeTime,
  mockRealTimeTime,
  mockRelativeTime
} from './utils';

export default {
  title: 'Elements/EventTime',
  component: EventTime
};

export const Simple = () => {
  const [selectedTime, setSelectedTime] = useState<string | [string, string]>(
    ''
  );
  return (
    <>
      <div style={{ width: 600 }}>
        <EventTime onTimeChange={setSelectedTime} />
      </div>
      <br />
      <div>
        Selected Time:{' '}
        {Array.isArray(selectedTime) ? selectedTime.join(' to ') : selectedTime}
      </div>
    </>
  );
};

export const DefaultRangeValue = () => {
  const currTime = new Date();
  const defaultTime = mockRangeTime(currTime);

  const [selectedTime, setSelectedTime] = useState<string | [string, string]>(
    ''
  );
  return (
    <>
      <div style={{ width: 600 }}>
        <EventTime onTimeChange={setSelectedTime} defaultTime={defaultTime} />
      </div>
      <br />
      <div>
        Selected Time:{' '}
        {Array.isArray(selectedTime) ? selectedTime.join(' to ') : selectedTime}
      </div>
    </>
  );
};

export const DefaultRelativeValue = () => {
  const defaultTime: Time = mockRelativeTime;

  const [selectedTime, setSelectedTime] = useState<string | [string, string]>(
    ''
  );
  return (
    <>
      <div style={{ width: 600 }}>
        <EventTime onTimeChange={setSelectedTime} defaultTime={defaultTime} />
      </div>
      <br />
      <div>
        Selected Time:{' '}
        {Array.isArray(selectedTime) ? selectedTime.join(' to ') : selectedTime}
      </div>
    </>
  );
};

export const DefaultRealtimeValue = () => {
  const defaultTime: Time = mockRealTimeTime;

  const [selectedTime, setSelectedTime] = useState<string | [string, string]>(
    ''
  );
  return (
    <>
      <div style={{ width: 600 }}>
        <EventTime onTimeChange={setSelectedTime} defaultTime={defaultTime} />
      </div>
      <br />
      <div>
        Selected Time:{' '}
        {Array.isArray(selectedTime) ? selectedTime.join(' to ') : selectedTime}
      </div>
    </>
  );
};
