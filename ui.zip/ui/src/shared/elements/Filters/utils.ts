export const getUpdatedFilter = (
  key: string,
  value: string,
  isCurrentlySelected: boolean,
  currentFilter: { [key: string]: string[] }
) => {
  const newFilter = currentFilter ? { ...currentFilter } : {};
  if (isCurrentlySelected) {
    newFilter[key] = [...newFilter[key].filter(f => f !== value)];
    // clean up url params if the filter is empty
    if (newFilter[key].length === 0) {
      delete newFilter[key];
    }
  } else {
    newFilter[key] = newFilter[key] ? [...newFilter[key], value] : [value];
  }

  return newFilter;
};
