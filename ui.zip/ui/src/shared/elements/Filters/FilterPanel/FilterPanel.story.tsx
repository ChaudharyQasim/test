import { useRef, useState } from 'react';
import { FilterPanel, FilterType } from './FilterPanel';
import { Button } from 'reablocks';

export default {
  title: 'Elements/Filters/Filter Panel',
  component: FilterPanel
};

const filters: FilterType = {
  type: {
    label: 'Type',
    options: [
      { value: 'eventSource', label: 'Event Source' },
      { value: 'eventDest', label: 'Event Destination' },
      { value: 'alertForward', label: 'Alert Forward' },
      { value: 'dataEnrichment', label: 'Data Enrichment' }
    ]
  },
  category: {
    label: 'Category',
    options: [
      { value: 'api', label: 'Api' },
      { value: 'authentication', label: 'Authentication' },
      { value: 'confiruation', label: 'Configuration' },
      { value: 'database', label: 'Database' }
    ]
  },
  author: {
    label: 'Author',
    options: [
      { value: 'fireeye', label: 'FireEye' },
      { value: 'fortinet', label: 'Fortinet' },
      { value: 'trendMicro', label: 'Trend Micro' },
      { value: 'sophos', label: 'Sophos' }
    ]
  },
  tenant: {
    label: 'Tenant',
    options: [
      { value: 'aws-us-east1', label: 'AWS US-EAST1' },
      { value: 'alto-eu-west2', label: 'ALTO EU-WEST2' },
      { value: 'sforce-pt-s2', label: 'SFORCE PT-S2' },
      { value: 'sos-eu-nort1', label: 'SOS EU-NORT1' }
    ]
  }
};

export const Simple = () => {
  const btnRef = useRef<HTMLButtonElement | null>(null);
  const [open, setOpen] = useState<boolean>(false);
  const [filter, setFilter] = useState<any>({});

  return (
    <>
      <Button ref={btnRef} variant="outline" onClick={() => setOpen(!open)}>
        Filter
      </Button>
      <FilterPanel
        reference={btnRef}
        open={open}
        onClose={() => setOpen(false)}
        filter={filter}
        filters={filters}
        onFilterChange={setFilter}
      />
    </>
  );
};
