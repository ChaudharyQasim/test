import { FC } from 'react';
import classNames from 'classnames';
import { Card, List, ListItem, MenuProps, Stack } from 'reablocks';
import { Checkbox } from 'shared/form/Checkbox';
import { getUpdatedFilter } from '../utils';
import { Menu, NestedMenu } from 'shared/layers/Menu';
import css from './FilterPanel.module.css';

import { ReactComponent as Chevron } from 'assets/icons/chevron-down.svg';

export interface FilterOption {
  value: string;
  label: string;
}

export interface FilterType {
  [key: string]: { label: string; options: FilterOption[] };
}

interface FilterPanelProps extends Partial<MenuProps> {
  filter: any;
  filters: FilterType;
  onFilterChange: (filter: any) => void;
}

export const FilterPanel: FC<FilterPanelProps> = ({
  filter,
  filters,
  onFilterChange,
  ...menuProps
}) => {
  const onFilterClick = (
    key: string,
    value: string,
    isCurrentlySelected: boolean
  ) => {
    const updatedFilter = getUpdatedFilter(
      key,
      value,
      isCurrentlySelected,
      filter
    );
    onFilterChange(updatedFilter);
  };

  return (
    <Menu {...menuProps}>
      <Card>
        <List>
          {Object.keys(filters).map(key => (
            <ListItem key={key} className={css.filterCategory}>
              <NestedMenu
                label={
                  <Stack justifyContent="spaceBetween" inline={false}>
                    {filters[key]?.label}
                    <Chevron className={css.arrow} />
                  </Stack>
                }
                menuClassName={css.submenu}
              >
                <Card>
                  <List>
                    {filters[key]?.options.map(option => {
                      const isSelected =
                        filter && filter[key]?.includes(option.value);
                      return (
                        <ListItem
                          key={option.value}
                          onClick={() =>
                            onFilterClick(key, option.value, isSelected)
                          }
                          start={<Checkbox checked={isSelected} />}
                          className={classNames(css.subItem, {
                            [css.isActive]: isSelected
                          })}
                        >
                          {option.label}
                        </ListItem>
                      );
                    })}
                  </List>
                </Card>
              </NestedMenu>
            </ListItem>
          ))}
        </List>
      </Card>
    </Menu>
  );
};
