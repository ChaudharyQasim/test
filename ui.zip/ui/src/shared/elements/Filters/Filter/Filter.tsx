import { FC, useRef, useState } from 'react';
import classNames from 'classnames';
import { Button, Card, List, ListItem, Menu, Text } from 'reablocks';
import { Checkbox } from 'shared/form/Checkbox';
import { FilterOption } from 'shared/elements/Filters';
import { getUpdatedFilter } from '../utils';
import css from './Filter.module.css';

import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';

interface FilterProps {
  category: string;
  categoryLabel: string;
  options: FilterOption[];
  filter: any;
  onFilterChange: (filter: any) => void;
}

export const Filter: FC<FilterProps> = ({
  category,
  categoryLabel,
  options = [],
  filter,
  onFilterChange
}) => {
  const btnRef = useRef<HTMLButtonElement | null>(null);
  const [open, setOpen] = useState<boolean>(false);

  const [firstFilter = '', ...otherFilters] = filter[category] || [];
  const firstFilterLabel = options.find(option => option.value === firstFilter)
    ?.label;

  const onFilterClick = (
    key: string,
    value: string,
    isCurrentlySelected: boolean
  ) => {
    const updatedFilter = getUpdatedFilter(
      key,
      value,
      isCurrentlySelected,
      filter
    );

    onFilterChange(updatedFilter);
  };

  const onClearFilters = () => {
    const updatedFilters = { ...filter };
    delete updatedFilters[category];

    onFilterChange(updatedFilters);
  };

  return (
    <>
      <Button
        ref={btnRef}
        className={css.filterDisplay}
        size="small"
        variant="outline"
        onClick={() => setOpen(!open)}
        disableAnimation
      >
        <Text className={css.filterLabel}>{categoryLabel}:</Text>
        {firstFilterLabel ? (
          <Text fontStyle="bold">{firstFilterLabel}</Text>
        ) : (
          <Text fontStyle="italic" className={css.noFilters}>
            None selected
          </Text>
        )}
        {otherFilters.length > 0 && (
          <Text className={css.filterLabel}>
            +{otherFilters.length.toLocaleString()}
          </Text>
        )}
        <CloseIcon
          onClick={event => {
            event.stopPropagation();
            onClearFilters();
          }}
        />
      </Button>
      <Menu reference={btnRef} open={open} onClose={() => setOpen(false)}>
        <Card className={css.card}>
          <List>
            {options.map(option => {
              const { value, label } = option;
              const isCurrentlySelected = filter[category]?.includes(value);

              return (
                <ListItem
                  key={value}
                  onClick={() =>
                    onFilterClick(category, value, isCurrentlySelected)
                  }
                  start={<Checkbox checked={isCurrentlySelected} />}
                  className={classNames(css.subItem, {
                    [css.isActive]: isCurrentlySelected
                  })}
                >
                  {label}
                </ListItem>
              );
            })}
          </List>
        </Card>
      </Menu>
    </>
  );
};
