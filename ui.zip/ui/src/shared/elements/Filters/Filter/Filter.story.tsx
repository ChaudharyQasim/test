import { useState } from 'react';
import { Filter } from './Filter';

export default {
  title: 'Elements/Filters/Filter',
  component: Filter
};

export const Simple = () => {
  const [filter, setFilter] = useState<{ [key: string]: string[] }>({
    type: ['alertForward']
  });
  return (
    <Filter
      category="type"
      categoryLabel="Type"
      options={[
        { value: 'eventSource', label: 'Event Source' },
        { value: 'eventDest', label: 'Event Destination' },
        { value: 'alertForward', label: 'Alert Forward' },
        { value: 'dataEnrichment', label: 'Data Enrichment' }
      ]}
      filter={filter}
      onFilterChange={setFilter}
    />
  );
};
