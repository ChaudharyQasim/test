import { Alert } from './Alert';
import { ReactComponent as WarningIcon } from 'assets/icons/warning.svg';

export default {
  title: 'Elements/Alert',
  component: Alert
};

export const Variants = () => (
  <div style={{ maxWidth: 600 }}>
    <Alert
      icon={<WarningIcon style={{ fill: 'var(--warning-background)' }} />}
      text="THIS BLOCK HAS UNDERGONE CHANGES. WOULD YOU LIKE TO APPLY THESE MODIFICATIONS TO ALL OTHER INSTANCES OF THIS BLOCK, OR WOULD YOU PREFER TO CREATE A NEW BLOCK?"
    />
  </div>
);
