import { FC, ReactElement } from 'react';
import { Stack } from 'reablocks';
import css from './Alert.module.css';

interface AlertProps {
  icon?: ReactElement;
  text: string;
}

export const Alert: FC<AlertProps> = ({ icon, text }) => (
  <Stack className={css.alert} alignItems="start" dense>
    {icon ? icon : null}
    <span className={css.text}>{text}</span>
  </Stack>
);
