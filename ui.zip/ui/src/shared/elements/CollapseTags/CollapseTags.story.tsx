import { CollapseTags } from './CollapseTags';
export default {
  title: 'Layout/CollapseTags',
  component: CollapseTags
};

export const Simple = () => <CollapseTags tagList={['Simple Chip']} />;

export const Fallback = () => (
  <CollapseTags tagList={[]} fallback={<span>No Tags added</span>} />
);

export const CollapsedTags = () => (
  <CollapseTags
    tagList={[...new Array(20)].map((_, index) => `Tag ${index + 1}`)}
  />
);
