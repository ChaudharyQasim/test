import React, { FC } from 'react';
import { useInfinityList, Chip } from 'reablocks';

// CSS
import css from './CollapseTags.module.css';

// Types
type CollapseTagsProps = {
  tagList: string[];
  fallback?: React.ReactNode | string;
  size?: number;
  nextSize?: number;
  children?: React.ReactNode;
};

export const CollapseTags: FC<CollapseTagsProps> = ({
  tagList,
  fallback = '',
  size = 4,
  nextSize = Infinity,
  children
}) => {
  const {
    data: dataList,
    hasMore,
    remaining,
    showNext
  } = useInfinityList({
    items: tagList,
    size,
    nextSize
  });

  return (
    <span className={css.chipTechniques}>
      {dataList.length ? (
        dataList.map((name, index) => (
          <Chip
            variant="outline"
            color="info"
            key={`${name.split(' ').join('_')}-${index}`}
          >
            {name}
          </Chip>
        ))
      ) : (
        <>{fallback}</>
      )}
      {hasMore && (
        <Chip
          variant="outline"
          color="info"
          onClick={event => {
            event.stopPropagation();
            showNext();
          }}
        >
          +{remaining.toLocaleString()} more
        </Chip>
      )}
      {children}
    </span>
  );
};
