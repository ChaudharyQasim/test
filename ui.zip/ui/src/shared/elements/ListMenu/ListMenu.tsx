import { Button, Card, List, ListItem, Menu } from 'reablocks';
import { FC, useRef, useState } from 'react';
import { ReactComponent as DotsIcon } from 'assets/icons/dots.svg';
import { ReactComponent as HorizontalDotsIcon } from 'assets/icons/dots-horz.svg';
import css from './ListMenu.module.css';
import classNames from 'classnames';

export interface ListItem {
  icon: React.ReactNode;
  iconName: string;
  iconId: number;
}

export interface ListMenuProps {
  listItems: ListItem[];
  disableOptions?: boolean;
  disabledMargin?: boolean;
  disabledPadding?: boolean;
  onItemClick: (iconId: number) => void;
  className?: string;
  isHorizontalDots?: boolean;
}

export const ListMenu: FC<ListMenuProps> = ({
  listItems,
  disabledMargin = false,
  disabledPadding = false,
  disableOptions = false,
  className = '',
  isHorizontalDots,
  onItemClick
}) => {
  const btnRef = useRef<HTMLButtonElement | null>(null);
  const [menuOpen, setMenuOpen] = useState<boolean>(false);

  return (
    <div className={classNames(css.menuCol, className)}>
      <Button
        variant="text"
        ref={btnRef}
        onClick={event => {
          event.stopPropagation();
          setMenuOpen(!menuOpen);
        }}
        disableMargins={disabledMargin}
        disablePadding={disabledPadding}
      >
        {isHorizontalDots ? <HorizontalDotsIcon /> : <DotsIcon />}
      </Button>
      <Menu
        reference={btnRef}
        open={menuOpen}
        placement="bottom-end"
        onClose={() => setMenuOpen(false)}
      >
        <Card>
          <List>
            {listItems.map(({ icon, iconId, iconName }) => (
              <ListItem
                start={icon}
                key={iconId}
                disabled={disableOptions}
                onClick={() => {
                  onItemClick(iconId);
                  setMenuOpen(false);
                }}
              >
                {iconName}
              </ListItem>
            ))}
          </List>
        </Card>
      </Menu>
    </div>
  );
};
