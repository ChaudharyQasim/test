import { Icons, IconName } from './imports';
import { SVGProps } from 'react';

export interface IconProps extends Partial<SVGProps<SVGElement>> {
  name: IconName;
}

export const Icon = (props: IconProps) => {
  const SVG = Icons[props.name];
  return <SVG {...(props as any)} />;
};
