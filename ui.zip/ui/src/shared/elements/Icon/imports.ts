import { ReactComponent as AddEmojiIcon } from 'assets/icons/add-emoji.svg';
import { ReactComponent as AnalystIcon } from 'assets/icons/analyst.svg';
import { ReactComponent as ArrowDownIcon } from 'assets/icons/arrow-down.svg';
import { ReactComponent as ArrowLeftIcon } from 'assets/icons/arrow-left.svg';
import { ReactComponent as ArrowRightIcon } from 'assets/icons/arrow-right.svg';
import { ReactComponent as ArrowUpIcon } from 'assets/icons/arrow-up.svg';
import { ReactComponent as BarChartIcon } from 'assets/icons/bar-chart.svg';
import { ReactComponent as BreadcrumbSeparatorIcon } from 'assets/icons/breadcrumb-separator.svg';
import { ReactComponent as CalendarIcon } from 'assets/icons/calendar.svg';
import { ReactComponent as CheckCircleIcon } from 'assets/icons/check-circle.svg';
import { ReactComponent as CheckIcon } from 'assets/icons/check.svg';
import { ReactComponent as ChevronAltDownIcon } from 'assets/icons/chevron-alt-down.svg';
import { ReactComponent as ChevronDownIcon } from 'assets/icons/chevron-down.svg';
import { ReactComponent as ChevronFilledDownIcon } from 'assets/icons/chevron-filled-down.svg';
import { ReactComponent as ChevronFilledRightIcon } from 'assets/icons/chevron-filled-right.svg';
import { ReactComponent as ChevronRightIcon } from 'assets/icons/chevron-right.svg';
import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';
import { ReactComponent as CollectionIcon } from 'assets/icons/collection.svg';
import { ReactComponent as CommunityIcon } from 'assets/icons/community.svg';
import { ReactComponent as CostReductionIcon } from 'assets/icons/cost-reduction.svg';
import { ReactComponent as CsvIcon } from 'assets/icons/csv.svg';
import { ReactComponent as DashboardIcon } from 'assets/icons/dashboard.svg';
import { ReactComponent as DataConfigIcon } from 'assets/icons/data-config.svg';
import { ReactComponent as DateIcon } from 'assets/icons/date.svg';
import { ReactComponent as DeleteIcon } from 'assets/icons/delete.svg';
import { ReactComponent as DetailsIcon } from 'assets/icons/details.svg';
import { ReactComponent as DetectionEffectivenessIcon } from 'assets/icons/detection-effectiveness.svg';
import { ReactComponent as DevelopmentIcon } from 'assets/icons/development.svg';
import { ReactComponent as DocsIcon } from 'assets/icons/docs.svg';
import { ReactComponent as DocumentIcon } from 'assets/icons/document.svg';
import { ReactComponent as DotIcon } from 'assets/icons/dot.svg';
import { ReactComponent as DotsHorzIcon } from 'assets/icons/dots-horz.svg';
import { ReactComponent as DotsIcon } from 'assets/icons/dots.svg';
import { ReactComponent as DownloadIcon } from 'assets/icons/download.svg';
import { ReactComponent as DragIcon } from 'assets/icons/drag.svg';
import { ReactComponent as DuplicateIcon } from 'assets/icons/duplicate.svg';
import { ReactComponent as EditIcon } from 'assets/icons/edit.svg';
import { ReactComponent as EnvironmentVisibilityIcon } from 'assets/icons/environment-visibility.svg';
import { ReactComponent as ExportJsonIcon } from 'assets/icons/export-json.svg';
import { ReactComponent as ExportIcon } from 'assets/icons/export.svg';
import { ReactComponent as FilledArrowDownIcon } from 'assets/icons/filled-arrow-down.svg';
import { ReactComponent as FilterIcon } from 'assets/icons/filter.svg';
import { ReactComponent as FunctionIcon } from 'assets/icons/function.svg';
import { ReactComponent as GoogleIcon } from 'assets/icons/google.svg';
import { ReactComponent as GroupIcon } from 'assets/icons/group.svg';
import { ReactComponent as HeadIcon } from 'assets/icons/head.svg';
import { ReactComponent as HelpIcon } from 'assets/icons/help.svg';
import { ReactComponent as InvestigationsIcon } from 'assets/icons/investigations.svg';
import { ReactComponent as KindAlertIcon } from 'assets/icons/kind-alert.svg';
import { ReactComponent as KindAssetIcon } from 'assets/icons/kind-asset.svg';
import { ReactComponent as KindEnrichmentIcon } from 'assets/icons/kind-enrichment.svg';
import { ReactComponent as KindEventIcon } from 'assets/icons/kind-event.svg';
import { ReactComponent as KindFindingIcon } from 'assets/icons/kind-finding.svg';
import { ReactComponent as KindMetricIcon } from 'assets/icons/kind-metric.svg';
import { ReactComponent as KindPipelineIcon } from 'assets/icons/kind-pipeline.svg';
import { ReactComponent as KindStateIcon } from 'assets/icons/kind-state.svg';
import { ReactComponent as LineChartIcon } from 'assets/icons/line-chart.svg';
import { ReactComponent as LinkIcon } from 'assets/icons/link.svg';
import { ReactComponent as ListViewIcon } from 'assets/icons/list-view.svg';
import { ReactComponent as ListsIcon } from 'assets/icons/lists.svg';
import { ReactComponent as LiveIcon } from 'assets/icons/live.svg';
import { ReactComponent as LogoutIcon } from 'assets/icons/logout.svg';
import { ReactComponent as MicrosoftIcon } from 'assets/icons/microsoft.svg';
import { ReactComponent as MinusIcon } from 'assets/icons/minus.svg';
import { ReactComponent as MoreIcon } from 'assets/icons/more.svg';
import { ReactComponent as NestIcon } from 'assets/icons/nest.svg';
import { ReactComponent as NoDataIcon } from 'assets/icons/no-data.svg';
import { ReactComponent as NodeIcon } from 'assets/icons/node.svg';
import { ReactComponent as PdfIcon } from 'assets/icons/pdf.svg';
import { ReactComponent as PencilIcon } from 'assets/icons/pencil.svg';
import { ReactComponent as PipelineConnectorIcon } from 'assets/icons/pipeline-connector.svg';
import { ReactComponent as PipelineIcon } from 'assets/icons/pipeline.svg';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import { ReactComponent as ReadIcon } from 'assets/icons/read.svg';
import { ReactComponent as ReductionIcon } from 'assets/icons/reduction.svg';
import { ReactComponent as ReportIcon } from 'assets/icons/report.svg';
import { ReactComponent as SaveIcon } from 'assets/icons/save.svg';
import { ReactComponent as SearchIcon } from 'assets/icons/search.svg';
import { ReactComponent as SettingsIcon } from 'assets/icons/settings.svg';
import { ReactComponent as SeverityIcon } from 'assets/icons/severity.svg';
import { ReactComponent as ShareIcon } from 'assets/icons/share.svg';
import { ReactComponent as TooltipArrowIcon } from 'assets/icons/tooltip-arrow.svg';
import { ReactComponent as UploadInputIcon } from 'assets/icons/upload-input.svg';
import { ReactComponent as UploadIcon } from 'assets/icons/upload.svg';
import { ReactComponent as UserIcon } from 'assets/icons/user.svg';
import { ReactComponent as ViewsIcon } from 'assets/icons/views.svg';
import { ReactComponent as WarningIcon } from 'assets/icons/warning.svg';

export const Icons = {
  'add-emoji': AddEmojiIcon,
  analyst: AnalystIcon,
  'arrow-down': ArrowDownIcon,
  'arrow-left': ArrowLeftIcon,
  'arrow-right': ArrowRightIcon,
  'arrow-up': ArrowUpIcon,
  'bar-chart': BarChartIcon,
  'breadcrumb-separator': BreadcrumbSeparatorIcon,
  calendar: CalendarIcon,
  'check-circle': CheckCircleIcon,
  check: CheckIcon,
  'chevron-alt-down': ChevronAltDownIcon,
  'chevron-down': ChevronDownIcon,
  'chevron-filled-down': ChevronFilledDownIcon,
  'chevron-filled-right': ChevronFilledRightIcon,
  'chevron-right': ChevronRightIcon,
  close: CloseIcon,
  collection: CollectionIcon,
  community: CommunityIcon,
  'cost-reduction': CostReductionIcon,
  csv: CsvIcon,
  dashboard: DashboardIcon,
  'data-config': DataConfigIcon,
  date: DateIcon,
  delete: DeleteIcon,
  details: DetailsIcon,
  'detection-effectiveness': DetectionEffectivenessIcon,
  development: DevelopmentIcon,
  docs: DocsIcon,
  document: DocumentIcon,
  dot: DotIcon,
  'dots-horz': DotsHorzIcon,
  dots: DotsIcon,
  download: DownloadIcon,
  drag: DragIcon,
  duplicate: DuplicateIcon,
  edit: EditIcon,
  'environment-visibility': EnvironmentVisibilityIcon,
  'export-json': ExportJsonIcon,
  export: ExportIcon,
  'filled-arrow-down': FilledArrowDownIcon,
  filter: FilterIcon,
  function: FunctionIcon,
  google: GoogleIcon,
  group: GroupIcon,
  head: HeadIcon,
  help: HelpIcon,
  investigations: InvestigationsIcon,
  'kind-alert': KindAlertIcon,
  'kind-asset': KindAssetIcon,
  'kind-enrichment': KindEnrichmentIcon,
  'kind-event': KindEventIcon,
  'kind-finding': KindFindingIcon,
  'kind-metric': KindMetricIcon,
  'kind-pipeline': KindPipelineIcon,
  'kind-state': KindStateIcon,
  'line-chart': LineChartIcon,
  link: LinkIcon,
  'list-view': ListViewIcon,
  lists: ListsIcon,
  live: LiveIcon,
  logout: LogoutIcon,
  microsoft: MicrosoftIcon,
  minus: MinusIcon,
  more: MoreIcon,
  nest: NestIcon,
  'no-data': NoDataIcon,
  node: NodeIcon,
  pdf: PdfIcon,
  pencil: PencilIcon,
  'pipeline-connector': PipelineConnectorIcon,
  pipeline: PipelineIcon,
  plus: PlusIcon,
  read: ReadIcon,
  reduction: ReductionIcon,
  report: ReportIcon,
  save: SaveIcon,
  search: SearchIcon,
  settings: SettingsIcon,
  severity: SeverityIcon,
  share: ShareIcon,
  'tooltip-arrow': TooltipArrowIcon,
  'upload-input': UploadInputIcon,
  upload: UploadIcon,
  user: UserIcon,
  views: ViewsIcon,
  warning: WarningIcon
} as const;

export type IconName = keyof typeof Icons;
