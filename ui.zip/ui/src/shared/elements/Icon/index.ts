export { Icon as default } from './Icon';
export type { IconName } from './imports';
