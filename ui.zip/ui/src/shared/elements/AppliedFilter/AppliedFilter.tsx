import { FC, Fragment, useRef } from 'react';
import { Button, MenuProps, Stack, VerticalSpacer } from 'reablocks';

import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';

import css from './AppliedFilter.module.css';

import { Filter, FilterType } from '../Filters';

interface KeyToListStringMap {
  [key: string]: string[];
}

interface FilterPanelProps extends Partial<MenuProps> {
  filter: KeyToListStringMap;
  filterOptions: FilterType;
  setFilter: (filter: KeyToListStringMap) => void;
  addFilter: (dropdownRef: React.MutableRefObject<HTMLButtonElement>) => void;
}

export const AppliedFilter: FC<FilterPanelProps> = ({
  filter,
  filterOptions,
  setFilter,
  addFilter,
  ...menuProps
}) => {
  const plusBtnRef = useRef<HTMLButtonElement | null>(null);
  const hasFilter = filter && Object.keys(filter).length > 0;

  return (
    <>
      <Stack {...menuProps}>
        {hasFilter && (
          <>
            {Object.keys(filter).map(key => (
              <Fragment key={key}>
                <Filter
                  category={key}
                  categoryLabel={filterOptions[key]?.label}
                  options={filterOptions[key]?.options}
                  filter={filter}
                  onFilterChange={setFilter}
                />
              </Fragment>
            ))}
            <Button
              ref={plusBtnRef}
              className={css.addButton}
              size="small"
              variant="outline"
              onClick={() => addFilter(plusBtnRef)}
            >
              <PlusIcon />
            </Button>
            <div className={css.pushRight}>
              <Button
                size="small"
                variant="outline"
                className={css.clearButton}
                onClick={() => setFilter(null)}
              >
                <CloseIcon /> Clear Filters
              </Button>
            </div>
          </>
        )}
      </Stack>
      {hasFilter && <VerticalSpacer space="xxl" />}
    </>
  );
};
