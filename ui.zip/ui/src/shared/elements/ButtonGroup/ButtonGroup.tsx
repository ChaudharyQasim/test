import { FC, PropsWithChildren } from 'react';
import { Stack } from 'reablocks';
import css from './ButtonGroup.module.css';

export const ButtonGroup: FC<PropsWithChildren> = ({ children }) => (
  <Stack className={css.group}>{children}</Stack>
);
