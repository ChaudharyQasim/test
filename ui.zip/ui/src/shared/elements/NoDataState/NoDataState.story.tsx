import { NoDataState } from './NoDataState';

export default {
  title: 'Elements/NoDataState',
  component: NoDataState
};

export const NoData = () => <NoDataState />;
