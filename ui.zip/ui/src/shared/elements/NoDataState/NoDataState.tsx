import { FC } from 'react';
import { SmallHeading, Stack } from 'reablocks';
import css from './NoDataState.module.css';

import { ReactComponent as NoDataIcon } from 'assets/icons/no-data.svg';

import classNames from 'classnames';

type NoDataStateType = {
  message?: string;
  className?: string;
};

export const NoDataState: FC<NoDataStateType> = ({
  message = 'No Data Yet',
  className
}) => (
  <Stack
    alignItems="center"
    justifyContent="center"
    direction="column"
    className={classNames(css.noDataWrapper, className)}
  >
    <NoDataIcon />
    <SmallHeading className={css.noData}>{message}</SmallHeading>
  </Stack>
);
