import { FC, useEffect } from 'react';
import { ConditionInput } from 'shared/form/Input';
import { ConditionType } from './EventCondition';
import { ConditionList } from 'shared/form/Input/ConditionList';
import { NumberRange } from './utils';

type NumberInputProps = {
  condition: ConditionType;
  onValueChange: (value: number | number[] | NumberRange) => void;
};

export const NumberInput: FC<NumberInputProps> = ({
  condition,
  onValueChange
}) => {
  const { field_operation, subFieldOperation } = condition;
  const isRange =
    ['IN_RANGE', 'OUTSIDE_RANGE'].includes(field_operation) ||
    ['IN_RANGE', 'OUTSIDE_RANGE'].includes(subFieldOperation);
  const isList =
    ['IN_LIST', 'NOT_IN_LIST'].includes(field_operation) ||
    ['IN_LIST', 'NOT_IN_LIST'].includes(subFieldOperation);

  useEffect(() => {
    const isArray = Array.isArray(condition.value);
    if (isRange && !isArray) {
      onValueChange([condition.value, condition.value] as NumberRange);
    } else if (!isRange && !isList && isArray) {
      onValueChange(condition.value[0] as number);
    }
  }, [isRange, isList, condition.value, onValueChange]);

  const handleConditionListChange = (values: number[] | string[]) =>
    onValueChange(values as number[]);

  return (
    <>
      {isRange && <span>of</span>}
      {isList ? (
        <ConditionList
          type="number"
          placeholder="0"
          value={
            Array.isArray(condition.value)
              ? (condition.value as number[])
              : condition.value && typeof condition.value === 'number'
              ? [condition.value]
              : []
          }
          onChange={handleConditionListChange}
        />
      ) : (
        <ConditionInput
          type="number"
          placeholder="0"
          value={isRange ? condition.value[0] : condition.value || undefined}
          onChange={event => {
            const newValue = isRange
              ? [Number(event.target.value), condition.value[1]]
              : Number(event.target.value);
            onValueChange(newValue as number | NumberRange);
          }}
        />
      )}
      {isRange && (
        <>
          <span>to</span>
          <ConditionInput
            type="number"
            placeholder="0"
            value={isRange ? condition.value[1] : undefined}
            onChange={event =>
              onValueChange([condition.value[0], Number(event.target.value)])
            }
          />
        </>
      )}
    </>
  );
};
