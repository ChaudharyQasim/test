import { FC, memo } from 'react';
import { ConditionInput } from 'shared/form/Input';
import { ConditionType } from './EventCondition';
import { CoordinateRange } from './utils';
import isEqual from 'react-fast-compare';

interface CoordinateInputProps {
  condition: ConditionType;
  onValueChange: (value: CoordinateRange) => void;
}

export const CoordinateInput: FC<CoordinateInputProps> = memo(
  ({ condition, onValueChange }) => (
    <>
      <span>a</span>
      <ConditionInput
        type="number"
        placeholder="500"
        value={(condition.value as CoordinateRange)?.range ?? undefined}
        onChange={event =>
          onValueChange({
            ...(condition.value as CoordinateRange),
            range: Number(event.target.value)
          })
        }
      />
      <span>kilometer radius of latitude</span>
      <ConditionInput
        type="number"
        placeholder="-30"
        value={(condition.value as CoordinateRange)?.lat ?? undefined}
        min={-90}
        max={90}
        onChange={event =>
          onValueChange({
            ...(condition.value as CoordinateRange),
            lat: Number(event.target.value)
          })
        }
      />
      <span>and longitude</span>
      <ConditionInput
        type="number"
        placeholder="150"
        value={(condition.value as CoordinateRange)?.long ?? undefined}
        min={-180}
        max={180}
        onChange={event =>
          onValueChange({
            ...(condition.value as CoordinateRange),
            long: Number(event.target.value)
          })
        }
      />
    </>
  ),
  (prevProps, nextProps) => isEqual(prevProps.condition, nextProps.condition)
);
