import {
  DndContext,
  DragEndEvent,
  DragMoveEvent,
  DragOverEvent,
  DragOverlay,
  DragStartEvent,
  MeasuringStrategy,
  PointerSensor,
  UniqueIdentifier,
  closestCenter,
  useSensor,
  useSensors
} from '@dnd-kit/core';
import {
  SortableContext,
  arrayMove,
  verticalListSortingStrategy
} from '@dnd-kit/sortable';
import { ReactComponent as NestIcon } from 'assets/icons/nest.svg';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import { ACSFieldType, TypeEnum } from 'core/Api';
import { Button, Pluralize, SelectOption, Stack } from 'reablocks';
import { Dispatch, FC, SetStateAction, memo, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { ConditionSelect } from 'shared/form/Select';
import { EventTime } from '../EventTime/EventTime';
import { Time } from '../EventTime/utils';
import { FieldOperations, FieldType } from './ConditionField';
import css from './EventCondition.module.css';
import { SortableTreeItem } from './SortableTreeItem';
import {
  FlattenedConditionType,
  ValueType,
  buildTree,
  createEmptyCondition,
  dropAnimationConfig,
  findItemDeep,
  flatten,
  getProjection,
  indentationWidth,
  removeChildrenOf,
  removeItem
} from './utils';

export type ConditionType = {
  id?: string;
  field?: string;
  field_operation?: string;
  subFieldOperation?: string;
  subOperation?: ConditionType | null;
  operator?: 'and' | 'or';
  value?: ValueType | ConditionType[];
  values?: ValueType[];
  to?: number;
  from?: number;
  fieldType?: TypeEnum;
  caseSensitive?: boolean;
};

export interface EventConditionProps extends Partial<Element> {
  fields: ACSFieldType[] | FieldType[];
  fieldOperationsMap?: FieldOperations;
  conditions: ConditionType[];
  defaultTime?: Time;
  hideNestButton?: boolean;
  hideToolbarButtons?: boolean;
  operator?: 'and' | 'or';
  updateBaseOperator?: (operator: 'and' | 'or') => void;
  onConditionsChange: (conditions: ConditionType[]) => void;
  onTimeChange?: (timestamp: string | [string, string]) => void;
  showHeaderConditionText?: boolean;
  typeValue?: string;
  setTypeValue?: Dispatch<SetStateAction<string>>;
  isLoadingStreamViewData?: boolean;
}

export const EventCondition: FC<EventConditionProps> = memo(
  ({
    fields,
    fieldOperationsMap,
    conditions,
    operator,
    updateBaseOperator,
    onConditionsChange,
    onTimeChange,
    defaultTime,
    hideNestButton = false,
    hideToolbarButtons = false,
    showHeaderConditionText = true,
    typeValue,
    setTypeValue,
    isLoadingStreamViewData,
    ...rest
  }) => {
    const [activeId, setActiveId] = useState<UniqueIdentifier | null>(null);
    const [overId, setOverId] = useState<UniqueIdentifier | null>(null);
    const [offsetLeft, setOffsetLeft] = useState(0);
    const [currentPosition, setCurrentPosition] = useState<{
      parentId: UniqueIdentifier | null;
      overId: UniqueIdentifier;
    } | null>(null);

    const noConditions = conditions.length === 0;

    const onConditionChange = (
      condition: ConditionType,
      idx: UniqueIdentifier
    ) => {
      const updated = [...conditions];
      const itemIndex = updated.findIndex(item => item.id === idx);
      if (itemIndex !== -1) {
        updated[itemIndex] = { ...updated[itemIndex], ...condition };
        onConditionsChange(updated);
      }
    };

    const onNewCondition = (nested: boolean = false, idx?: number) => {
      const newCondition = createEmptyCondition(nested);
      const updated = [...conditions];
      updated.splice(
        idx !== undefined ? idx + 1 : conditions?.length,
        0,
        newCondition
      );
      onConditionsChange(updated);
    };

    const flattenedItems = useMemo(() => {
      const flattenedTree = flatten(conditions);

      return removeChildrenOf(flattenedTree, activeId ? [activeId] : []);
    }, [activeId, conditions]);

    const projected =
      activeId && overId
        ? getProjection(
          flattenedItems,
          activeId,
          overId,
          offsetLeft,
          indentationWidth
        )
        : null;

    const sensors = useSensors(useSensor(PointerSensor));

    const sortedIds = useMemo(
      () => flattenedItems.map(({ id }) => id),
      [flattenedItems]
    );

    const activeItem = activeId
      ? flattenedItems.find(({ id }) => id === activeId)
      : null;

    const measuring = {
      droppable: {
        strategy: MeasuringStrategy.Always
      }
    };

    const handleDragStart = ({ active: { id: activeId } }: DragStartEvent) => {
      setActiveId(activeId);
      setOverId(activeId);

      const activeItem = flattenedItems.find(({ id }) => id === activeId);

      if (activeItem) {
        setCurrentPosition({
          parentId: activeItem.parentId,
          overId: activeId
        });
      }

      document.body.style.setProperty('cursor', 'grabbing');
    };

    const handleDragMove = ({ delta }: DragMoveEvent) => {
      setOffsetLeft(delta.x);
    };

    const handleDragOver = ({ over }: DragOverEvent) => {
      setOverId(over?.id ?? null);
    };

    const handleDragEnd = (dragEndEvent: DragEndEvent) => {
      const { active, over } = dragEndEvent;

      resetState();
      if (projected && over) {
        const { depth, parentId } = projected;
        const clonedItems: FlattenedConditionType[] = JSON.parse(
          JSON.stringify(flatten(conditions))
        );
        const overIndex = clonedItems.findIndex(({ id }) => id === over.id);
        const activeIndex = clonedItems.findIndex(({ id }) => id === active.id);
        const activeTreeItem = clonedItems[activeIndex];

        const parentIndex = clonedItems.findIndex(({ id }) => id === parentId);
        const parentObj = clonedItems[parentIndex];

        if (!parentObj?.operator && parentId) {
          const newParentItem: FlattenedConditionType = {
            ...createEmptyCondition(true),
            parentId: parentObj?.parentId,
            depth: parentObj?.depth + 1,
            index: 0
          };
          clonedItems[activeIndex] = {
            ...activeTreeItem,
            depth: parentObj?.depth + 1,
            parentId: newParentItem.id
          };
          clonedItems.push(newParentItem);
        } else {
          clonedItems[activeIndex] = { ...activeTreeItem, depth, parentId };
        }

        const sortedItems = arrayMove(clonedItems, activeIndex, overIndex);
        const newItems = buildTree(sortedItems);

        onConditionsChange(newItems);
      }
    };

    const handleDragCancel = () => {
      resetState();
    };

    const resetState = () => {
      setOverId(null);
      setActiveId(null);
      setOffsetLeft(0);
      setCurrentPosition(null);

      document.body.style.setProperty('cursor', '');
    };

    const handleRemove = (id: UniqueIdentifier) => {
      onConditionsChange(removeItem(conditions, id));
    };

    const onAddCondition = (parentId: UniqueIdentifier) => {
      if (!parentId) {
        onNewCondition();
      } else {
        const newCondition = createEmptyCondition();
        const updated = [...conditions];
        const item = findItemDeep(updated, parentId);
        const updatedItem = { ...item };
        (updatedItem.value as ConditionType[]).push(newCondition);
        Object.assign(item, updatedItem);
        onConditionsChange(updated);
      }
    };

    return (
      <div className={css.condition} {...rest}>
        <Stack justifyContent="spaceBetween">
          <Stack dense>
            Events must match
            {conditions?.length > 1 ? (
              <ConditionSelect value={operator} onChange={updateBaseOperator}>
                <SelectOption value="and">all</SelectOption>
                <SelectOption value="or">any</SelectOption>
              </ConditionSelect>
            ) : (
              ' the '
            )}
            <Pluralize
              singular="condition"
              count={conditions.length}
              showCount={false}
              zero="condition"
            />
          </Stack>
          {onTimeChange && (
            <EventTime
              onTimeChange={onTimeChange}
              defaultTime={defaultTime}
              typeValue={typeValue}
              setTypeValue={setTypeValue}
            />
          )}
        </Stack>
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          measuring={measuring}
          onDragStart={handleDragStart}
          onDragMove={handleDragMove}
          onDragOver={handleDragOver}
          onDragEnd={handleDragEnd}
          onDragCancel={handleDragCancel}
        >
          <SortableContext
            items={sortedIds}
            strategy={verticalListSortingStrategy}
          >
            {flattenedItems.map(flattenedCondition => (
              <SortableTreeItem
                key={flattenedCondition.id}
                id={flattenedCondition.id}
                depth={
                  flattenedCondition.id === activeId && projected
                    ? projected.depth
                    : flattenedCondition.depth
                }
                indentationWidth={indentationWidth}
                fields={fields as ACSFieldType[]}
                fieldOperationsMap={fieldOperationsMap}
                condition={flattenedCondition}
                showDrag={flattenedItems.length > 1}
                onConditionChange={(condition: ConditionType) =>
                  onConditionChange(condition, flattenedCondition.id)
                }
                onNew={parentId => onAddCondition(parentId)}
                onDelete={() => handleRemove(flattenedCondition.id)}
              />
            ))}

            {createPortal(
              <DragOverlay
                dropAnimation={dropAnimationConfig}
                modifiers={undefined}
              >
                {activeId && activeItem ? (
                  <SortableTreeItem
                    id={activeId}
                    depth={activeItem.depth}
                    indentationWidth={indentationWidth}
                    fields={fields as ACSFieldType[]}
                    fieldOperationsMap={fieldOperationsMap}
                    condition={activeItem}
                    showDrag={conditions.length > 1}
                    onConditionChange={() => null}
                    onNew={() => null}
                    onDelete={() => null}
                  />
                ) : null}
              </DragOverlay>,
              document.body
            )}
          </SortableContext>
        </DndContext>

        {noConditions && (
          <div className={css.emptyConditions}>There are no conditions</div>
        )}

        <div>
          <div className={css.toolbar}>
            <Button
              variant="text"
              size="small"
              className={css.toolbarBtn}
              onClick={() => onNewCondition()}
            >
              <PlusIcon />
            </Button>
            {!hideNestButton && (
              <Button
                variant="text"
                size="small"
                className={css.toolbarBtn}
                onClick={() => onNewCondition(true)}
              >
                <NestIcon />
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }
);
