import {
  DropAnimation,
  UniqueIdentifier,
  defaultDropAnimation
} from '@dnd-kit/core';
import { AnimateLayoutChanges, arrayMove } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { nanoid } from 'nanoid';
import { ConditionType } from './EventCondition';

export type DateRange = [Date, Date];
export type NumberRange = [number, number];
export type IpRange = [string, string];
export type CoordinateRange = { range: number; lat: number; long: number };
export type JSONMatch = {
  key: string;
  field_operation: string;
  value: number | string | boolean;
};

export type ValueType =
  | boolean
  | string
  | string[]
  | number
  | number[]
  | NumberRange
  | Date
  | DateRange
  | JSONMatch
  | CoordinateRange;

export const createEmptyCondition = (isNested: boolean = false) => {
  return isNested
    ? ({
        id: nanoid(),
        operator: 'and',
        value: [{ id: nanoid(), field: '', field_operation: '', value: '' }]
      } as ConditionType)
    : ({
        id: nanoid(),
        field: '',
        field_operation: '',
        value: ''
      } as ConditionType);
};

/**
 * Returns the reference to the object specified by the nested path
 * @param conditions
 * @param path Nested path [A, B, C] meaning A -> B -> C
 * @returns Reference to the 'C' object
 */
const findCondition = (conditions: ConditionType[], path: string[]) => {
  let conditionsRef = conditions;
  let i = 1;
  while (i < path.length) {
    const id = path[i];
    const index = conditionsRef.findIndex(condition => condition.id === id);
    conditionsRef = conditionsRef[index].value as ConditionType[];
    i++;
  }
  return conditionsRef;
};

/**
 * Move the condition in-place
 * @param conditions
 * @param sourcePath Source's parent's path
 * @param destinationPath Destination's parent's path
 * @param sourceIndex Index of the condition to be swapped, in the original parent object
 * @param destinationIndex Index where to add the above removed condition in the new parent object
 */
export const moveCondition = (
  conditions: ConditionType[],
  sourcePath: string[],
  destinationPath: string[],
  sourceIndex: number,
  destinationIndex: number
) => {
  const sourceParent = findCondition(conditions, sourcePath);
  const removed = sourceParent.splice(sourceIndex, 1)[0];
  const destinationParent = findCondition(conditions, destinationPath);
  destinationParent.splice(destinationIndex, 0, removed);
};

/* dnd kit utils with references from https://github.com/clauderic/dnd-kit/tree/master/stories/3%20-%20Examples/Tree */
export interface FlattenedConditionType extends ConditionType {
  parentId: string | null;
  depth: number;
  index: number;
}

export const indentationWidth = 30;

/**
 * Recursively flatten the conditions
 */
export const flatten = (
  items: ConditionType[],
  parentId: string | null = null,
  depth = 0
): FlattenedConditionType[] => {
  return items.reduce<FlattenedConditionType[]>((acc, item, index) => {
    return [
      ...acc,
      { ...item, parentId, depth, index },
      ...flatten(
        item?.operator ? (item.value as ConditionType[]) : [],
        item.id,
        depth + 1
      )
    ];
  }, []);
};

export const removeChildrenOf = (
  items: FlattenedConditionType[],
  ids: UniqueIdentifier[]
) => {
  const excludeParentIds = [...ids];

  return items.filter(item => {
    const shouldExclude =
      item.parentId && excludeParentIds.includes(item.parentId);
    if (shouldExclude && item.operator && item.value) {
      excludeParentIds.push(item.id);
    }

    return !shouldExclude;
  });
};

/**
 * Check for any orphaned parent nodes and remove them
 */
const sanitizeTree = (nodes: ConditionType[]) => {
  const newNodes = [];
  for (const node of nodes) {
    if (node?.operator) {
      const nestedItems = sanitizeTree(node?.value as ConditionType[]);
      if (nestedItems?.length === 0) {
        continue;
      }
      node.value = nestedItems;
    }
    newNodes.push(node);
  }
  return newNodes;
};

/**
 * Builds back the nested conditions from the flattened list of conditions
 * @param flattenedItems
 * @returns List of Conditions
 */
export const buildTree = (
  flattenedItems: FlattenedConditionType[]
): ConditionType[] => {
  const root: ConditionType = { id: 'root', value: [] };
  const nodes: Record<string, ConditionType> = { [root.id]: root };
  const items = flattenedItems.map(item => ({ ...item, value: [] }));

  for (const item of items) {
    const { id, value } = item;
    const parentId = item.parentId ?? root.id;
    const parent = nodes[parentId] ?? findItem(items, parentId);

    nodes[id] = { id, value };
    (parent.value as ConditionType[]).push(item);
  }

  return sanitizeTree(root.value as ConditionType[]);
};

export const findItem = (items: ConditionType[], itemId: UniqueIdentifier) => {
  return items.find(({ id }) => id === itemId);
};

export const getProjection = (
  items: FlattenedConditionType[],
  activeId: UniqueIdentifier,
  overId: UniqueIdentifier,
  dragOffset: number,
  indentationWidth: number
) => {
  const overItemIndex = items.findIndex(({ id }) => id === overId);
  const activeItemIndex = items.findIndex(({ id }) => id === activeId);
  const activeItem = items[activeItemIndex];
  const newItems = arrayMove(items, activeItemIndex, overItemIndex);
  const previousItem = newItems[overItemIndex - 1];
  const nextItem = newItems[overItemIndex + 1];
  const dragDepth = getDragDepth(dragOffset, indentationWidth);
  const projectedDepth = activeItem.depth + dragDepth;
  const maxDepth = getMaxDepth({
    previousItem
  });
  const minDepth = getMinDepth({ nextItem });
  let depth = projectedDepth;

  if (projectedDepth >= maxDepth) {
    depth = maxDepth;
  } else if (projectedDepth < minDepth) {
    depth = minDepth;
  }

  const getParentId = () => {
    if (depth === 0 || !previousItem) {
      return null;
    }

    if (depth === previousItem.depth) {
      return previousItem.parentId;
    }

    if (depth > previousItem.depth) {
      return previousItem.id;
    }

    const newParent = newItems
      .slice(0, overItemIndex)
      .reverse()
      .find(item => item.depth === depth)?.parentId;

    return newParent ?? null;
  };

  return { depth, maxDepth, minDepth, parentId: getParentId() };
};

const getDragDepth = (offset: number, indentationWidth: number) => {
  return Math.round(offset / indentationWidth);
};

const getMaxDepth = ({
  previousItem
}: {
  previousItem: FlattenedConditionType;
}) => {
  if (previousItem) {
    return previousItem.depth + 1;
  }

  return 0;
};

const getMinDepth = ({ nextItem }: { nextItem: FlattenedConditionType }) => {
  if (nextItem) {
    return nextItem.depth;
  }

  return 0;
};

/**
 * Get number of descendents
 */
export const getChildCount = (items: ConditionType[], id: UniqueIdentifier) => {
  const item = findItemDeep(items, id);

  return item?.operator ? countChildren(item.value as ConditionType[]) : 0;
};

/**
 * Finds and returns the condition by id from the nested conditions
 */
export const findItemDeep = (
  items: ConditionType[],
  itemId: UniqueIdentifier
): ConditionType | undefined => {
  for (const item of items) {
    const { id, value, operator } = item;

    if (id === itemId) {
      return item;
    }

    if (operator && (value as ConditionType[]).length) {
      const child = findItemDeep(value as ConditionType[], itemId);

      if (child) {
        return child;
      }
    }
  }

  return undefined;
};

/**
 * Helper function to count children of a node
 */
const countChildren = (items: ConditionType[], count = 0): number => {
  return items.reduce((acc, { value, operator }) => {
    if (operator && (value as ConditionType[]).length) {
      return countChildren(value as ConditionType[], acc + 1);
    }

    return acc + 1;
  }, count);
};

export const dropAnimationConfig: DropAnimation = {
  keyframes({ transform }) {
    return [
      { opacity: 1, transform: CSS.Transform.toString(transform.initial) },
      {
        opacity: 0,
        transform: CSS.Transform.toString({
          ...transform.final,
          x: transform.final.x + 5,
          y: transform.final.y + 5
        })
      }
    ];
  },
  easing: 'ease-out',
  sideEffects({ active }) {
    active.node.animate([{ opacity: 0 }, { opacity: 1 }], {
      duration: defaultDropAnimation.duration,
      easing: defaultDropAnimation.easing
    });
  }
};

export const animateLayoutChanges: AnimateLayoutChanges = ({
  isSorting,
  wasDragging
}) => (isSorting || wasDragging ? false : true);

/**
 * Return list of items after removing the item with given id
 */
export const removeItem = (items: ConditionType[], id: UniqueIdentifier) => {
  const newItems = [];

  for (const item of items) {
    if (item.id === id) {
      continue;
    }

    if (item?.operator && (item?.value as ConditionType[]).length) {
      const nestedItems = removeItem(item.value as ConditionType[], id);

      if (nestedItems?.length === 0) {
        continue;
      }
      item.value = nestedItems;
    }

    newItems.push(item);
  }

  return newItems;
};
