import classNames from 'classnames';
import { ACSFieldType } from 'core/Api';
import { AnimatePresence, motion } from 'framer-motion';
import { nanoid } from 'nanoid';
import { Button, SelectOption } from 'reablocks';
import { FC, HTMLAttributes, Ref, forwardRef, useState } from 'react';
import { ConditionDate } from 'shared/form/Input/ConditionDate';
import { ConditionSelect } from 'shared/form/Select';
import { FIELD_TYPES } from 'shared/utils/Constants';
import css from './ConditionField.module.css';
import { CoordinateInput } from './CoordinateInput';
import { ConditionType } from './EventCondition';
import { IpInput } from './IpInput';
import { ListInput } from './ListInput';
import { NumberInput } from './NumberInput';
import { StringInput } from './StringInput';
import { CoordinateRange, DateRange, FlattenedConditionType, createEmptyCondition } from './utils';

import { UniqueIdentifier } from '@dnd-kit/core';
import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';
import { ReactComponent as DragHandle } from 'assets/icons/drag.svg';
import { ReactComponent as NestIcon } from 'assets/icons/nest.svg';
import { ReactComponent as PlusIcon } from 'assets/icons/plus.svg';
import { TypeEnum } from 'core/Api';

type Operation = {
  value: string;
  label: string;
  subtype?: string;
};

export type FieldOperations = {
  condition: {
    [key: string]: Operation[];
  };
  rule: {
    [key: string]: Operation[];
  };
  fate: {
    [key: string]: Operation[];
  };
};

export type FieldType = {
  field: string;
  data_type: FIELD_TYPES;
  type: string;
};

export interface ConditionFieldProps extends Omit<HTMLAttributes<HTMLLIElement>, 'id'> {
  fields: ACSFieldType[];
  fieldOperationsMap: FieldOperations;
  condition: FlattenedConditionType;
  showDrag?: boolean;
  onConditionChange: (condition: ConditionType) => void;
  onNew: (parentId: UniqueIdentifier) => void;
  onDelete: () => void;
  depth: number;
  indentationWidth: number;
  handleProps?: any;
  wrapperRef?(node: HTMLLIElement): void;
}

export interface ConditionFieldRef {
  ref?: Ref<HTMLDivElement>;
}

export const ConditionField: FC<ConditionFieldProps & ConditionFieldRef> = forwardRef(
  ({
    fields,
    fieldOperationsMap,
    condition,
    showDrag = false,
    onConditionChange,
    onNew,
    onDelete,
    depth,
    indentationWidth,
    handleProps,
    wrapperRef,
    style
  }, ref) => {
    const [hovered, setHovered] = useState<boolean>(false);

    const { fieldType, parentId } = condition;

    const onNestCondition = () => {
      if (condition.operator) {
        const newCondition = createEmptyCondition();
        const updated = [...(condition.value as ConditionType[]), newCondition];
        onConditionChange({ ...condition, value: updated });
      } else {
        onConditionChange({
          id: nanoid(),
          operator: 'and',
          value: [condition]
        } as ConditionType);
      }
    };

    return (
        <div
          ref={ref}
          key={condition.id}
          // TODO: there's an animation clash for when new items are added and the pointer is
          // over the item as it comes in if using onPointerEnter - using onPointerMove mitigates
          // but does not completely solve this issue.
          onPointerMove={() => setHovered(true)}
          onPointerLeave={() => setHovered(false)}
          style={
            {
              '--spacing': `${indentationWidth * depth}px`,
            } as React.CSSProperties
          }
        >
          <div className={css.container} style={style}>
            <AnimatePresence>
              {showDrag && (
                <motion.div
                  initial={{ width: 0, opacity: 0 }}
                  animate={{ width: 'auto', opacity: 1 }}
                  exit={{ width: 0, opacity: 0 }}
                  className={css.dragHandle}
                  ref={wrapperRef}
                  {...handleProps}
                >
                  <Button variant="text" size="small" className={css.dragBtn}>
                    <DragHandle />
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
            {condition.operator ? (
              <div className={css.joinRow}>
                <ConditionSelect
                  value={condition.operator}
                  onChange={operator =>
                    onConditionChange({ ...condition, operator })
                  }
                >
                  <SelectOption value="and">all</SelectOption>
                  <SelectOption value="or">any</SelectOption>
                </ConditionSelect>
                of the following are true
              </div>
            ) : (
              <div className={classNames(css.field, { [css.active]: hovered })}>
                <ConditionSelect
                  value={condition?.field || ''}
                  placeholder="field"
                  onInputChange={(e) => {
                    if(!e.target.value) {
                      onConditionChange({
                        ...condition,
                        field: '',
                        field_operation: '',
                        value: '',
                        subFieldOperation: '',
                        fieldType: null
                      });
                    }
                  }}
                  onChange={value => {
                    const fieldType = fields.find(({ field }) => value === field)
                      ?.data_type;
                    onConditionChange({
                      ...condition,
                      field: value,
                      field_operation: '',
                      value: '',
                      subFieldOperation: '',
                      fieldType
                    });
                  }}
                >
                  {fields?.map(({ field }) => (
                    <SelectOption key={field} value={field}>
                      {field}
                    </SelectOption>
                  ))}
                </ConditionSelect>
                {condition.field && (
                  <ConditionSelect
                    value={condition?.field_operation || ''}
                    placeholder="field operation"
                    onChange={value =>
                      onConditionChange({
                        ...condition,
                        field_operation: value,
                        subFieldOperation: ''
                      })
                    }
                    onInputChange={(e) => {
                      if(!e.target.value) {
                        onConditionChange({
                          ...condition,
                          field_operation: '',
                          subFieldOperation: ''
                        });
                      }
                    }}
                  >
                    {fieldType &&
                      fieldOperationsMap?.condition[fieldType]?.map(operation => (
                        <SelectOption key={operation.value} value={operation.value}>
                          {operation.label}
                        </SelectOption>
                      ))}
                  </ConditionSelect>
                )}
                {['Float32', 'Float64', 'Long'].includes(fieldType) && (
                  <NumberInput
                    condition={condition}
                    onValueChange={value =>
                      onConditionChange({ ...condition, value })
                    }
                  />
                )}
                {['String', 'Enum'].includes(fieldType) && (
                  <StringInput
                    condition={condition}
                    onValueChange={value =>
                      onConditionChange({ ...condition, value })
                    }
                    onCaseSensitiveChange={caseSensitive =>
                      onConditionChange({
                        ...condition,
                        caseSensitive
                      })
                    }
                  />
                )}
                {fieldType === 'Date' && (
                  <ConditionDate
                    value={
                      condition?.field_operation === 'IN_RANGE'
                        ? (condition.value as DateRange)
                        : (condition.value as Date)
                    }
                    onChange={value => onConditionChange({ ...condition, value })}
                    isRange={condition?.field_operation === 'IN_RANGE'}
                  />
                )}
                {['Ipv4', 'Ipv6'].includes(fieldType) &&
                  condition?.field_operation !== 'IS_RFC1989' && (
                    <IpInput
                      type={fieldType as TypeEnum}
                      condition={condition}
                      onValueChange={value =>
                        onConditionChange({ ...condition, value })
                      }
                    />
                  )}
                {fieldType === 'Coordinate' && (
                  <CoordinateInput
                    condition={condition}
                    onValueChange={(value: CoordinateRange) =>
                      onConditionChange({ ...condition, value })
                    }
                  />
                )}
                {['List(String)'].includes(fieldType) && (
                  <ListInput
                    condition={condition}
                    fieldOperationsMap={fieldOperationsMap}
                    onValueChange={(subFieldOperation, value) =>
                      onConditionChange({
                        ...condition,
                        subFieldOperation,
                        value
                      })
                    }
                    onCaseSensitiveChange={caseSensitive =>
                      onConditionChange({ ...condition, caseSensitive })
                    }
                  />
                )}
              </div>
            )}
            <AnimatePresence>
              {hovered && (
                <motion.div
                  className={css.toolbar}
                  initial={{ width: 0, opacity: 0 }}
                  animate={{ width: 'auto', opacity: 1 }}
                  exit={{ width: 0, opacity: 0 }}
                >
                  <Button
                    variant="text"
                    size="small"
                    className={css.toolbarBtn}
                    onClick={() => onNew(parentId)}
                  >
                    <PlusIcon />
                  </Button>
                  <Button
                    variant="text"
                    size="small"
                    className={css.toolbarBtn}
                    onClick={onNestCondition}
                  >
                    <NestIcon />
                  </Button>
                  <Button
                    variant="text"
                    size="small"
                    className={css.toolbarBtn}
                    onClick={onDelete}
                  >
                    <CloseIcon />
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
    );
  },
);
