import { FC, memo } from 'react';
import { ConditionInput } from 'shared/form/Input';
import { ConditionList } from 'shared/form/Input/ConditionList';
import { ConditionType } from './EventCondition';
import { ConditionSelect } from 'shared/form/Select';
import { NumberInput } from './NumberInput';
import { SelectOption } from 'reablocks';
import { ValueType } from './utils';
import { FieldOperations } from './ConditionField';
import { OperationsEnum, TypeEnum } from 'core/Api';

interface ListInputProps {
  condition: ConditionType;
  fieldOperationsMap: FieldOperations;
  onValueChange: (subFieldOperation: string, value: ValueType) => void;
  onCaseSensitiveChange: (caseSensitive: boolean) => void;
}

export const ListInput: FC<ListInputProps> = ({
  condition,
  fieldOperationsMap,
  onValueChange,
  onCaseSensitiveChange
}) => {
  const isList = ['ALL', 'ANY'].includes(condition.field_operation);

  const commonProps = {
    placeholder: 'enter value...',
    caseSensitive: condition.caseSensitive,
    onCaseSensitiveChange
  };

  return (
    <>
      {condition.field_operation === OperationsEnum.LENGTH ? (
        <>
          <ConditionSelect
            value={condition.subFieldOperation || ''}
            placeholder="subfield operation"
            onChange={value =>
              onValueChange(value, condition.value as number | null)
            }
          >
            {fieldOperationsMap?.condition['Float64'].map(operation => (
              <SelectOption key={operation.value} value={operation.value}>
                {operation.label}
              </SelectOption>
            ))}
          </ConditionSelect>
          <NumberInput
            condition={condition}
            onValueChange={value =>
              onValueChange(condition.subFieldOperation, value)
            }
          />
        </>
      ) : (
        <>
          {isList ? (
            <ConditionList
              {...commonProps}
              value={
                Array.isArray(condition.value)
                  ? (condition.value as string[])
                  : condition.value && typeof condition.value === 'string'
                  ? [condition.value]
                  : []
              }
              onChange={values => onValueChange('', values as string[])}
            />
          ) : (
            <ConditionInput
              {...commonProps}
              value={(condition.value as string) || ''}
              onChange={event => onValueChange('', event.target.value)}
              disableCaseSensitive={condition.field_operation === 'REGEX'}
            />
          )}
        </>
      )}
    </>
  );
};
