import { FC } from 'react';
import { ConditionInput } from 'shared/form/Input';
import { ConditionType } from './EventCondition';
import { ConditionList } from 'shared/form/Input/ConditionList';

type StringInputProps = {
  condition: ConditionType;
  onValueChange: (value: string | string[]) => void;
  onCaseSensitiveChange: (caseSensitive: boolean) => void;
};

export const StringInput: FC<StringInputProps> = ({
  condition,
  onValueChange,
  onCaseSensitiveChange
}) => {
  const isList = ['IN_LIST', 'NOT_IN_LIST'].includes(condition.field_operation);

  const commonProps = {
    placeholder: 'enter value...',
    caseSensitive: condition.caseSensitive,
    onCaseSensitiveChange
  };

  return isList ? (
    <ConditionList
      {...commonProps}
      value={
        Array.isArray(condition.value)
          ? (condition.value as string[])
          : condition.value && typeof condition.value === 'string'
          ? [condition.value]
          : []
      }
      onChange={values => onValueChange(values as string[])}
    />
  ) : (
    <ConditionInput
      {...commonProps}
      value={condition.value as string}
      onChange={event => onValueChange(event.target.value)}
      disableCaseSensitive={condition.field_operation === 'REGEX'}
    />
  );
};
