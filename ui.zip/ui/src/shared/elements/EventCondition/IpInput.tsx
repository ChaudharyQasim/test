import { FC, useEffect } from 'react';
import { ConditionInput } from 'shared/form/Input';
import { ConditionList } from 'shared/form/Input/ConditionList';
import { ConditionType } from './EventCondition';
import { IpRange } from './utils';
import { TypeEnum } from 'core/Api';

type IpInputProps = {
  type: TypeEnum;
  condition: ConditionType;
  onValueChange: (value: string | string[] | IpRange) => void;
};

export const IpInput: FC<IpInputProps> = ({
  type,
  condition,
  onValueChange
}) => {
  const isRange = ['IN_RANGE', 'OUTSIDE_RANGE'].includes(
    condition.field_operation
  );
  const isList = ['IN_LIST', 'NOT_IN_LIST'].includes(condition.field_operation);
  const isSubnet = ['IN_SUBNET', 'NOT_IN_SUBNET'].includes(
    condition.field_operation
  );
  const placeholder =
    type === 'Ipv4' ? '192.168.0.0' : '2001:0db8:0:42::8a2e:370:7334';

  const subnetPlaceholder =
    type === 'Ipv4' ? '192.168.0.0/8' : '2001:0db8::/32';

  const rangePlaceholder =
    type === 'Ipv4' ? '192.168.0.10' : '2001:0db8:0:42::8a2e:370:8555';

  useEffect(() => {
    const isArray = Array.isArray(condition.value);
    if (isRange && !isArray) {
      onValueChange([condition.value, condition.value] as IpRange);
    } else if (!isRange && isArray) {
      onValueChange(condition.value[0] as string);
    }
  }, [isRange, onValueChange, condition.value]);

  const handleConditionInputChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const newValue = isRange
      ? [event.target.value, condition.value[1]]
      : event.target.value;
    onValueChange(newValue);
  };

  return (
    <>
      {isList ? (
        <ConditionList
          placeholder={isSubnet ? subnetPlaceholder : placeholder}
          value={
            Array.isArray(condition.value)
              ? (condition.value as string[])
              : condition.value && typeof condition.value === 'string'
              ? [condition.value]
              : []
          }
          onChange={values => onValueChange(values as string[])}
        />
      ) : (
        <ConditionInput
          placeholder={isSubnet ? subnetPlaceholder : placeholder}
          value={isRange ? condition.value[0] : condition.value}
          onChange={handleConditionInputChange}
        />
      )}
      {isRange && (
        <>
          <span>to</span>
          <ConditionInput
            placeholder={rangePlaceholder}
            value={isRange ? condition.value[1] : undefined}
            onChange={handleConditionInputChange}
          />
        </>
      )}
    </>
  );
};
