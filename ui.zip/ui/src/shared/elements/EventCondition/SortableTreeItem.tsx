import type { UniqueIdentifier } from '@dnd-kit/core';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { CSSProperties, FC } from 'react';
import { ConditionField, ConditionFieldProps } from './ConditionField';
import { animateLayoutChanges } from './utils';


interface SortableTreeItemProps extends ConditionFieldProps {
  id: UniqueIdentifier;
}

export const SortableTreeItem: FC<SortableTreeItemProps> = ({id, depth, ...rest}) => {
  const {
    attributes,
    listeners,
    setDraggableNodeRef,
    setDroppableNodeRef,
    transform,
    transition,
  } = useSortable({
    id,
    animateLayoutChanges: animateLayoutChanges,
  });
  const style: CSSProperties = {
    transform: CSS.Translate.toString(transform),
    transition,
  };

  return (
    <ConditionField
      ref={setDraggableNodeRef}
      wrapperRef={setDroppableNodeRef}
      style={style}
      depth={depth}
      handleProps={{
        ...attributes,
        ...listeners,
      }}
      {...rest}
    />
  );
}
