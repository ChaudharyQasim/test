import { FC, memo, useMemo, useState, ReactNode } from 'react';
import { Button, SelectOption } from 'reablocks';

import { AnimatePresence, motion } from 'framer-motion';

// CSS
import css from './EventConditionRow.module.css';

// Icons
import { ReactComponent as CloseIcon } from 'assets/icons/close.svg';

// Shared
import { ConditionSelect } from 'shared/form/Select';

import classNames from 'classnames';
import isEqual from 'react-fast-compare';

export type conditionOptionsType = {
  label: string;
  value: string;
};

type ConditionType = {
  conditionOptions: conditionOptionsType[];
  value: string[];
  onConditionChange: (value: string[]) => void;
};

type EventConditionRowType = {
  conditions?: ConditionType[];
  showError?: boolean;
  onDelete?: () => void;
  customConditions?: ReactNode;
};

export const EventConditionRow: FC<EventConditionRowType> = memo(
  ({ conditions, showError = false, onDelete, customConditions }) => {
    const [hovered, setHovered] = useState(false);

    const isInvalidRow = useMemo(() => {
      if (!conditions) {
        return false;
      }
      return conditions?.some(
        condition =>
          condition.value.includes(null) || condition.value.includes('')
      );
    }, [conditions]);

    const createConditionSelect = useMemo(
      () =>
        conditions?.map(
          (condition, index) =>
            condition?.value.map((value, valueIndex) => {
              // custominput here
              const handleChange = (newValue: string[]) => {
                condition.onConditionChange(newValue);
              };

              return (
                <ConditionSelect
                  key={`${index}-${valueIndex}`}
                  placeholder={value || 'Select'}
                  value={value}
                  onChange={handleChange}
                >
                  {condition?.conditionOptions?.map(option => (
                    <SelectOption key={option.value} value={option?.value}>
                      {option?.label}
                    </SelectOption>
                  ))}
                </ConditionSelect>
              );
            })
        ),
      [conditions]
    );

    return (
      <div
        className={css.container}
        onPointerMove={() => setHovered(true)}
        onPointerLeave={() => setHovered(false)}
      >
        <div
          className={classNames(css.field, {
            [css.active]: hovered,
            [css.isError]: isInvalidRow && showError
          })}
        >
          {createConditionSelect}
          {customConditions && customConditions}
        </div>
        <AnimatePresence>
          {hovered && onDelete && (
            <motion.div
              className={css.toolbar}
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 'auto', opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
            >
              <Button
                variant="text"
                size="small"
                className={css.toolbarBtn}
                onClick={onDelete}
              >
                <CloseIcon />
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  },
  isEqual
);
