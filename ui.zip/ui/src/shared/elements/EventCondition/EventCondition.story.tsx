import { useState } from 'react';
import { ConditionType, EventCondition } from './EventCondition';
import { FieldType } from './ConditionField';
import { Button } from 'reablocks';
import { FIELD_OPERATIONS_MAP } from 'shared/utils/Constants';

export default {
  title: 'Elements/EventCondition',
  component: EventCondition
};

const testFields: FieldType[] = [
  {
    field: 'event.outcome',
    data_type: 'String',
    type: 'acs'
  },
  {
    field: 'event.action',
    data_type: 'String',
    type: 'acs'
  },
  {
    field: 'cloud.region',
    data_type: 'String',
    type: 'acs'
  },
  {
    field: 'event.severity',
    data_type: 'Float32',
    type: 'acs'
  },
  {
    field: 'abstract.cloudtrail.management_event',
    data_type: 'Boolean',
    type: 'acs'
  },
  {
    field: '@timestamp',
    data_type: 'Date',
    type: 'acs'
  },
  {
    field: 'client.ip',
    data_type: 'Ipv4',
    type: 'acs'
  },
  {
    field: 'event.strType',
    data_type: 'List(String)',
    type: 'acs'
  },
  {
    field: 'event.enumType',
    data_type: 'List(Enum)',
    type: 'acs'
  },
  {
    field: 'abstract.cloudtrail.user_identity',
    data_type: 'JSON',
    type: 'acs'
  },
  {
    field: 'cloud.location',
    data_type: 'Coordinate',
    type: 'acs'
  }
];

export const SingleEventConditions = () => {
  const [baseOperator, setBaseOperator] = useState<'and' | 'or'>('and');
  const [conditions, setConditions] = useState<ConditionType[]>([]);

  return (
    <div style={{ width: 600 }}>
      <EventCondition
        fields={testFields}
        fieldOperationsMap={FIELD_OPERATIONS_MAP}
        conditions={conditions}
        operator={baseOperator}
        updateBaseOperator={setBaseOperator}
        onConditionsChange={setConditions}
      />
    </div>
  );
};

export const MultiEventConditions = () => {
  const [baseOperator, setBaseOperator] = useState<'and' | 'or'>('and');
  const [events, setEvents] = useState<ConditionType[][]>([[]]);

  const onEventChange = (event: ConditionType[], idx: number) => {
    const updated = [...events];
    updated[idx] = event;
    setEvents(updated);
  };

  return (
    <div style={{ width: 600 }}>
      {events.map((eventConditions, idx) => (
        <div
          key={idx}
          style={{
            borderRadius: 'var(--border-radius-md)',
            border: '1px solid var(--gray-100)',
            padding: 'var(--spacing-md)',
            marginBottom: 'var(--spacing-lg)'
          }}
        >
          <EventCondition
            fields={testFields}
            fieldOperationsMap={FIELD_OPERATIONS_MAP}
            conditions={eventConditions}
            operator={baseOperator}
            updateBaseOperator={setBaseOperator}
            onConditionsChange={event => onEventChange(event, idx)}
          />
        </div>
      ))}
      <br />
      <Button
        variant="text"
        onClick={() => setEvents([...events, []])}
        disableMargins
        disablePadding
      >
        New event
      </Button>
    </div>
  );
};
