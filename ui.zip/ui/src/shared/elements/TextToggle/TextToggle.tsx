import { FC } from 'react';
import styles from './TextToggle.module.css';
import classNames from 'classnames';
export type TextToggleProps = {
  text: [string, string];
  condition: boolean;
};

export const TextToggle: FC<TextToggleProps> = ({ text, condition }) => {
  return (
    <div className={styles.textToggle}>
      <span className={classNames(styles.text, condition && styles.visible)}>
        {text[0]}
      </span>
      <span
        className={classNames(
          styles.text,
          styles.absolute,
          !condition && styles.visible
        )}
      >
        {text[1]}
      </span>
    </div>
  );
};
