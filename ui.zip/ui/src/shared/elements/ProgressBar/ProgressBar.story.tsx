import { ProgressBar } from './ProgressBar';

export default {
  title: 'Elements/Progress Bar',
  component: ProgressBar
};

export const Basic = () => (
  <div style={{ width: 300 }}>
    <ProgressBar progress={60} />
  </div>
);
