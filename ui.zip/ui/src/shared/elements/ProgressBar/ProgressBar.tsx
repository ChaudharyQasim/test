import { FC } from 'react';
import css from './ProgressBar.module.css';
import { motion } from 'framer-motion';

interface ProgressBarProps {
  progress: number;
}

export const ProgressBar: FC<ProgressBarProps> = ({ progress }) => (
  <div className={css.bar}>
    <motion.div
      className={css.progress}
      initial={{ width: 0 }}
      animate={{ width: `${progress}%` }}
    />
  </div>
);
