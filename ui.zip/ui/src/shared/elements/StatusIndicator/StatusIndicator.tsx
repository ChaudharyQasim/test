import { FC } from 'react';
import classNames from 'classnames';
import css from './StatusIndicator.module.css';

interface StatusIndicatorProps {
  status: 'Active' | 'Disabled' | 'Pending' | 'Error';
}

export const StatusIndicator: FC<StatusIndicatorProps> = ({ status }) => (
  <div className={classNames(css.status, css[status.toLowerCase()])} />
);
